/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package launch;

import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JOptionPane;

import ui.GUI;
import util.SplashBitmap;

/**
 * The ODEToolkit class launches the ODE Toolkit GUI and interprets any optional
 * arguments. The main method displays a splash screen, then initiates the
 * creation of a workspace after interpreting any optional arguments, such as
 * auto-loading a URL path to a .ode file.
 * 
 * @author Andres perez 09
 */
public class ODEToolkit {
	/**
	 * The main function that runs ODEToolkit.
	 * @param args the arguments - could have -urlpath <URL>
	 */
	public static void main(String args[]) {
		// Show the splash screen
		SplashBitmap splash = new SplashBitmap(GUI.class
				.getResource("images/splashscreen1.4.png"));
		splash.hideOnClick();
		splash.hideOnTimeout(3000);
		splash.showSplash();
		splash.setAlwaysOnTop(true);

		// Launch the GUI
		GUI gui = new GUI();

		// Extract auto-loading argument if present
		// Note: two arguments are required for auto-loading.
		URL webPath = null;
		boolean urlSpecified = false;

		if (args.length > 1 && args[0].equalsIgnoreCase("-urlpath")) {
			urlSpecified = true;

			try {
				webPath = new URL(args[1]); // Extract URL from second argument
			} catch (MalformedURLException e) {
				System.out.println("URL extraction was unsuccessful.");
			}
		}

		// Auto-launch an ode file if specified.
		if (urlSpecified) {
			try {
				io.AutoLaunch.loadURL(gui, webPath);
			} catch (NullPointerException e1) {
				gui.showMessage(
						"There was an error loading the .ode file at:\n"
								+ webPath.toString(), "Error",
						JOptionPane.ERROR_MESSAGE);
				System.out
						.println("Couldn't launch .ode file at specified URL");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
//This comment exists to test Subclipse
