/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package drawer;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Hashtable;

/**
 * Graphics class supporting EPS export from plots. To use this class,
 * instantiate it as you would a graphics object and draw to it as normal. EPS
 * is then sent via the specified OutputStream.
 * 
 * Originally implemented in greyscale. Color functionality added, but must be
 * specified in construction.
 * 
 * @author Eric Harley
 */
public class EPSGraphics extends Graphics {
	/**
	 * In grayscale mode, colors are replaced by grayscale and line patterns.
	 * Better if color printing is unavailable.
	 */
	private boolean grayscale;

	/**
	 * The problem with this class is that it doesn't inherit implemented
	 * functions, and doesn't know things like the FontMetrics for various fonts
	 * which are used by the Drawer to do the essential drawing tasks. To
	 * alleviate this, this class maintains a "real" Graphics object to
	 * reference. Note it does NOT draw on this reference.
	 */
	private Graphics graphicsReferen;

	/** for getClipBounds, used by Drawer. */
	private Rectangle clipBounds;

	/** Java color to draw lines with */
	private Color currentColor = Color.black;

	/** Java font to draw text with */
	private Font currentFont;

	/** dimensions of the embedded postscript image */
	private int width, height;

	/** Hash table keeping pairs of color and dash-line patterns */
	private Hashtable<Color, String> linepattern = new Hashtable<Color, String>();

	/** file handle to write EPS code to */
	private OutputStream out;

	/** where we store the code before we write it out */
	private StringBuffer buffer = new StringBuffer();

	/**
	 * Default line patterns. When color is turned off, the class cycles through
	 * the line patterns in order to distinguish among curves.
	 */
	static private String[] patterns = { "[]", "[1 1]", "[4 4]", "[4 4 1 4]",
			"[2 2]", "[4 2 1 2 1 2]", "[5 3 2 3]", "[3 3]", "[4 2 1 2 2 2]",
			"[1 2 5 2 1 2 1 2]", "[4 1 2 1]", };

	/** The index for the pattern used */
	private int patternIndex = 0;

	/**
	 * Constructor for a Graphics object that writes encapsulated PostScript to
	 * the specified output stream. If the out argument is null, then it writes
	 * to standard output. Right now the generated postscript is constrained to
	 * a one page bounding box. Future versions should support splitting the
	 * image across multiple pages.
	 * 
	 * @param o
	 *            The stream to write to, or null to write to standard out.
	 * @param w
	 *            The width of the plot graphic, in units of 1/72 inch.
	 * @param h
	 *            The height of the plot graphic, in units of 1/72 inch.
	 * @param gray
	 *            Whether we want to output greyscale or not
	 */
	public EPSGraphics(OutputStream o, int w, int h, boolean gray) {
		grayscale = gray;

		// create a reference Graphics object, for calculating fontmetrics etc.
		BufferedImage tempImage = new BufferedImage(1, 1,
				BufferedImage.TYPE_INT_ARGB);
		graphicsReferen = tempImage.getGraphics();

		width = w;
		height = h;
		// the drawer needs to extract this info as the drawable area.
		setClip(0, 0, w, h);

		out = o;

		buffer.append("%!PS-Adobe-3.0 EPSF-3.0\n");
		buffer.append("%%Creator: ODEToolkit\n");

		// The bounding box is very important for EPS.
		// Otherwise our picture won't be properly displayed.
		buffer.append("%%BoundingBox: " + 0 + " " + 0 + " " + w + " " + h
				+ "\n");

		buffer.append("%%Pages: 1\n");
		buffer.append("%%Page: 1 1\n");
		buffer.append("%%LanguageLevel: 2\n");
	}

	// /////////////////////////////////////////////////////////////////
	// // public methods ////

	/** Does nothing */
	public void clearRect(int x, int y, int w, int h) {

	}

	/**
	 * Intersects the current clip with the specified rectangle. The resulting
	 * clipping area is the intersection of the current clipping area and the
	 * specified rectangle. This method can only be used to make the current
	 * clip smaller. To set the current clip larger, use any of the setClip
	 * methods. Rendering operations have no effect outside of the clipping
	 * area.
	 * 
	 * Parameters:
	 * 
	 * @param x
	 *            x-coordinate of the rectangle to intersect the clip with.
	 * @param y
	 *            y-coordinate of the rectangle to intersect the clip with.
	 * @param w
	 *            width of the rectangle to intersect the clip with.
	 * @param h
	 *            height of the rectangle to intersect the clip with.
	 */
	public void clipRect(int x, int y, int w, int h) {

		Point start = _convert(x, y);

		// the Postscript rectclip command intersects the current
		// clipping path with a rectangular path defined by the
		// operands to produce a new, smaller clipping path.
		// [Postscript Language Reference, 3rd Ed., p641]

		buffer.append(start.x + " " + start.y + " " + w + " " + h
				+ " rectclip\n");

	}

	/** Does nothing */
	public void copyArea(int x, int y, int w, int h, int dx, int dy) {
	}

	/**
	 * Returns copy of current EPSGraphics setup, but not the actual EPS drawing
	 */
	public Graphics create() {
		return new EPSGraphics(out, width, height, grayscale);
	}

	/** Does nothing */
	public void dispose() {
	}

	/** Does nothing */
	public void drawArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
	}

	/** Does nothing */
	public boolean drawImage(Image img, int x, int y, ImageObserver observer) {
		return true;
	}

	/** Does nothing */
	public boolean drawImage(Image img, int x, int y, int w, int h,
			ImageObserver observer) {
		return true;
	}

	/** Does nothing */
	public boolean drawImage(Image img, int x, int y, Color bgcolor,
			ImageObserver observer) {
		return true;
	}

	/** Does nothing */
	public boolean drawImage(Image img, int x, int y, int w, int h,
			Color bgcolor, ImageObserver observer) {
		return true;
	}

	/** Does nothing */
	public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2,
			int sx1, int sy1, int sx2, int sy2, ImageObserver observer) {
		return true;
	}

	/** Does nothing */
	public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2,
			int sx1, int sy1, int sx2, int sy2, Color bgcolor,
			ImageObserver observer) {
		return true;
	}

	/**
	 * Draw a line, using the current color, between the points (x1, y1) and
	 * (x2, y2) in this graphics context's coordinate system.
	 * 
	 * @param x1
	 *            the x coordinate of the first point.
	 * @param y1
	 *            the y coordinate of the first point.
	 * @param x2
	 *            the x coordinate of the second point.
	 * @param y2
	 *            the y coordinate of the second point.
	 */
	public void drawLine(int x1, int y1, int x2, int y2) {
		Point start = _convert(x1, y1);
		Point end = _convert(x2, y2);
		buffer.append("newpath " + start.x + " " + start.y + " moveto\n");
		buffer.append("" + end.x + " " + end.y + " lineto\n");
		buffer.append("stroke\n");
	}

	/**
	 * Draws a sequence of connected lines defined by arrays of x and y
	 * coordinates. Each pair of (x, y) coordinates defines a point. The figure
	 * is not closed if the first point differs from the last point.
	 * 
	 * Parameters:
	 * 
	 * @param xPoints
	 *            an array of x points
	 * @param yPoints
	 *            an array of y points
	 * @param nPoints
	 *            the total number of points
	 */
	public void drawPolyline(int xPoints[], int yPoints[], int nPoints) {

		Point start = _convert(xPoints[0], yPoints[0]);

		if (nPoints > 0) {
			buffer.append("newpath " + start.x + " " + start.y + " moveto\n");

			for (int i = 1; i < nPoints; i++) {

				start = _convert(xPoints[i], yPoints[i]);

				buffer.append("" + start.x + " " + start.y + " lineto\n");

			}

			buffer.append("stroke\n");

		} else {
			// do nothing, we need a positive number of points to draw a line
		}
	}

	/**
	 * Draw a closed polygon defined by arrays of x and y coordinates. Each pair
	 * of (x, y) coordinates defines a vertex. The third argument gives the
	 * number of vertices. If the arrays are not long enough to define this many
	 * vertices, or if the third argument is less than three, then nothing is
	 * drawn.
	 * 
	 * @param xPoints
	 *            An array of x coordinates.
	 * @param yPoints
	 *            An array of y coordinates.
	 * @param nPoints
	 *            The total number of vertices.
	 */
	public void drawPolygon(int xPoints[], int yPoints[], int nPoints) {
		if (!_polygon(xPoints, yPoints, nPoints)) {
			return;
		} else {
			buffer.append("closepath stroke\n");
		}
	}

	/**
	 * Draw an oval bounded by the specified rectangle with the current color.
	 * 
	 * @param x
	 *            The x coordinate of the upper left corner
	 * @param y
	 *            The y coordinate of the upper left corner
	 * @param w
	 *            The width of the oval to be filled.
	 * @param h
	 *            The height of the oval to be filled.
	 */
	// FIXME: Currently, this ignores the fourth argument and draws a circle
	// with diameter given by the third argument.
	public void drawOval(int x, int y, int w, int h) {
		int radius = w / 2;
		Point center = _convert(x + radius, y + radius);
		buffer.append("newpath " + center.x + " " + center.y + " " + radius
				+ " 0 360 arc closepath stroke\n");
	}

	public void drawRect(int x, int y, int w, int h) {
		Point start = _convert(x, y);
		buffer.append("newpath " + start.x + " " + start.y + " moveto\n");
		buffer.append("0 " + (-h) + " rlineto\n");
		buffer.append("" + w + " 0 rlineto\n");
		buffer.append("0 " + h + " rlineto\n");
		buffer.append("" + (-w) + " 0 rlineto\n");
		buffer.append("closepath stroke\n");
	}

	/** Does nothing */
	public void drawRoundRect(int x, int y, int w, int h, int arcWidth,
			int arcHeight) {
	}

	public void drawString(String str, int x, int y) {
		Point start = _convert(x, y);
		buffer.append("" + start.x + " " + start.y + " moveto\n");
		buffer.append("(" + str + ") show\n");
	}

	/** Does nothing. Here for compatibility with older JDK's. */
	public void drawString(java.text.AttributedCharacterIterator str, int x,
			int y) {
	}

	/** Does nothing */
	public void fillArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
	}

	/**
	 * Draw a filled polygon defined by arrays of x and y coordinates. Each pair
	 * of (x, y) coordinates defines a vertex. The third argument gives the
	 * number of vertices. If the arrays are not long enough to define this many
	 * vertices, or if the third argument is less than three, then nothing is
	 * drawn.
	 * 
	 * @param xPoints
	 *            An array of x coordinates.
	 * @param yPoints
	 *            An array of y coordinates.
	 * @param nPoints
	 *            The total number of vertices.
	 */
	public void fillPolygon(int xPoints[], int yPoints[], int nPoints) {
		if (!_polygon(xPoints, yPoints, nPoints)) {
			return;
		} else {
			buffer.append("closepath fill\n");
		}
	}

	/**
	 * Fill an oval bounded by the specified rectangle with the current color.
	 * 
	 * @param x
	 *            The x coordinate of the upper left corner
	 * @param y
	 *            The y coordinate of the upper left corner
	 * @param w
	 *            The width of the oval to be filled.
	 * @param h
	 *            The height of the oval to be filled.
	 */
	// FIXME: Currently, this ignores the fourth argument and draws a circle
	// with diameter given by the third argument.
	public void fillOval(int x, int y, int w, int h) {
		int radius = w / 2;
		Point center = _convert(x + radius, y + radius);
		buffer.append("newpath " + center.x + " " + center.y + " " + radius
				+ " 0 360 arc closepath fill\n");
	}

	/**
	 * Fill the specified rectangle and draw a thin outline around it. The left
	 * and right edges of the rectangle are at x and x + width - 1. The top and
	 * bottom edges are at y and y + height - 1. The resulting rectangle covers
	 * an area width pixels wide by height pixels tall. The rectangle is filled
	 * using the brightness of the current color to set the level of gray.
	 * 
	 * @param x
	 *            The x coordinate of the top left corner.
	 * @param y
	 *            The y coordinate of the top left corner.
	 * @param w
	 *            The width of the rectangle.
	 * @param h
	 *            The height of the rectangle.
	 */
	public void fillRect(int x, int y, int w, int h) {
		Point start = _convert(x, y);

		if (grayscale)
			_fillPattern();

		buffer.append("newpath " + start.x + " " + start.y + " moveto\n");
		buffer.append("0 " + (-h) + " rlineto\n");
		buffer.append("" + w + " 0 rlineto\n");
		buffer.append("0 " + h + " rlineto\n");
		buffer.append("" + (-w) + " 0 rlineto\n");
		buffer.append("closepath gsave fill grestore\n");

		setColor(currentColor);

		buffer.append("1 setlinewidth\n");
	}

	/** Does nothing */
	public void fillRoundRect(int x, int y, int w, int h, int arcWidth,
			int arcHeight) {
	}

	/** Does nothing */
	public Shape getClip() {
		return null;
	}

	/** Does nothing */
	public Rectangle getClipBounds() {
		return clipBounds;
	}

	/** Returns the current color being used to draw the image */
	public Color getColor() {
		return currentColor;
	}

	/** Returns the current font being used to draw text */
	public Font getFont() {
		return currentFont;
	}

	/** Routes to the reference graphics object. */
	public FontMetrics getFontMetrics(Font f) {
		return graphicsReferen.getFontMetrics(f);
	}

	/**
	 * Sets the current font to use for drawing text in the EPS file
	 * 
	 * @param font
	 *            java.awt.Font to use for setting text. If this font is not
	 *            installed in your postscript system then your generated image
	 *            may not look as you intended it.
	 */
	public void setFont(Font font) {
		int size = font.getSize();
		boolean bold = font.isBold();
		if (bold) {
			buffer.append("/Helvetica-Bold findfont\n");
		} else {
			buffer.append("/Helvetica findfont\n");
		}
		buffer.append("" + size + " scalefont setfont\n");
		currentFont = font;
	}

	/** Does nothing. */
	public void setClip(Shape clip) {
	}

	/**
	 * Sets the current clip to the rectangle specified by the given
	 * coordinates. Rendering operations have no effect outside of the clipping
	 * area.
	 * 
	 * @param x
	 *            The x coordinate of the new clip rectangle.
	 * @param y
	 *            The y coordinate of the new clip rectangle.
	 * @param w
	 *            The width of the new clip rectangle.
	 * @param h
	 *            The height of the new clip rectangle.
	 */
	public void setClip(int x, int y, int w, int h) {
		clipBounds = new Rectangle(x, y, w, h);

		Point start = _convert(x, y);

		// start a new path and use rlineto(relative line to) to draw
		// from the starting location to the right, down, left, and up
		// (to close) the rectangle.

		buffer.append("newpath \n" + start.x + " " + start.y + " moveto \n" + w
				+ " 0 " + " rlineto \n" + "0 " + (-h) + " rlineto \n" + (-w)
				+ " 0 " + " rlineto \n" + "0 " + h
				+ " rlineto closepath \n clip\n");
	}

	/**
	 * Sets the current color depending on whether we are in RGB or greyscale
	 * mode.
	 * 
	 * @param c
	 *            The desired current color.
	 */
	public void setColor(Color c) {
		if (grayscale)
			setColorGrayscale(c);
		else
			setColorRGB(c);
		currentColor = c;
	}

	/**
	 * Sets the current color in RGB mode
	 * 
	 * @param c
	 *            The desired current color.
	 */
	private void setColorRGB(Color c) {
		double r, g, b, a;
		a = ((double) c.getAlpha()) / 255;
		r = a * ((double) c.getRed()) / 255;
		g = a * ((double) c.getGreen()) / 255;
		b = a * ((double) c.getBlue()) / 255;

		buffer.append(r + " " + g + " " + b + " setrgbcolor\n");
		buffer.append("[] 0 setdash\n");
		buffer.append("1 setlinewidth\n");
	}

	/**
	 * Sets the current color in grayscale. (only supports the colors black,
	 * lightGray and white). If another color is specified then a dashed line is
	 * drawn.
	 * 
	 * @param c
	 *            The desired current color.
	 */
	private void setColorGrayscale(Color c) {
		if (c == Color.black) {
			buffer.append("0 setgray\n");
			buffer.append("[] 0 setdash\n");
			buffer.append("1 setlinewidth\n");
		} else if (c == Color.white) {
			buffer.append("1 setgray\n");
			buffer.append("[] 0 setdash\n");
			buffer.append("1 setlinewidth\n");
		} else if (c == Color.lightGray) {
			buffer.append("0.9 setgray\n");
			buffer.append("[] 0 setdash\n");
			buffer.append("0.5 setlinewidth\n");
		} else {
			if (linepattern.containsKey(c)) {
				buffer.append((String) linepattern.get(c) + " 0 setdash\n");
				buffer.append("1 setlinewidth\n");
			} else {
				buffer.append("0 setgray\n");
				// construct a new line pattern.
				if (patternIndex >= patterns.length) {
					patternIndex = 0;
				}
				buffer.append(patterns[patternIndex] + " 0 setdash\n");
				buffer.append("1 setlinewidth\n");
				linepattern.put(c, patterns[patternIndex]);
				patternIndex++;
			}
		}
	}

	/** Does nothing. */
	public void setPaintMode() {
	}

	/** Does nothing. */
	public void setXORMode(Color c1) {
	}

	/**
	 * Issue the PostScript showpage command, then write and flush the output.
	 * If the output argument of the constructor was null, then write to the
	 * clipboard. If no output stream was set then nothing is written.
	 */
	public void showpage() {

		buffer.append("showpage\n");

		if (out != null) {
			PrintWriter output = new PrintWriter(new BufferedOutputStream(out));

			output.println(buffer.toString());
			output.flush();

		} else {
			/** Does nothing. */
		}
	}

	/** Does nothing. */
	public void translate(int x, int y) {
	}

	// /////////////////////////////////////////////////////////////////
	// // private methods ////

	/** Convert the screen coordinate system to that of postscript. */
	private Point _convert(int x, int y) {
		return new Point(x, height - y);
	}

	/**
	 * Draw a closed polygon defined by arrays of x and y coordinates. Return
	 * false if arguments are misformed.
	 */
	private boolean _polygon(int xPoints[], int yPoints[], int nPoints) {
		if (nPoints < 3 || xPoints.length < nPoints || yPoints.length < nPoints)
			return false;
		Point start = _convert(xPoints[0], yPoints[0]);
		buffer.append("newpath " + start.x + " " + start.y + " moveto\n");
		for (int i = 1; i < nPoints; i++) {
			Point vertex = _convert(xPoints[i], yPoints[i]);
			buffer.append("" + vertex.x + " " + vertex.y + " lineto\n");
		}
		return true;
	}

	/**
	 * Issue a command to set the fill pattern. Currently, this is a gray level
	 * that is a function of the color.
	 */
	private void _fillPattern() {
		// We probably want a fill pattern rather than
		// just a gray scale.
		int red = currentColor.getRed();
		int green = currentColor.getGreen();
		int blue = currentColor.getBlue();
		// Scaling constants so that fully saturated R, G, or B appear
		// different.
		double bluescale = 0.6; // darkest
		double redscale = 0.8;
		double greenscale = 1.0; // lightest
		double fullscale = Math.sqrt(255.0 * 255.0 * (bluescale * bluescale
				+ redscale * redscale + greenscale * greenscale));
		double graylevel = Math.sqrt((double) (red * red * redscale * redscale
				+ blue * blue * bluescale * bluescale + green * green
				* greenscale * greenscale))
				/ fullscale;
		buffer.append("" + graylevel + " setgray\n");
		// NOTE -- for debugging, output color spec in comments
		buffer.append("%---- rgb: " + red + " " + green + " " + blue + "\n");
	}
}
