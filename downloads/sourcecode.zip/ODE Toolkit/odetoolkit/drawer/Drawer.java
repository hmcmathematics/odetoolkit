/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package drawer;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.util.ListIterator;
import java.util.Vector;

import data.Curve;
import data.Equilibrium;
import data.ODEVar;
import data.ODEVarVector;
import data.Tick;
import data.plotstates.Plot3DState;
import data.plotstates.PlotState;
import data.plotstates.SinglePlotState;

/**
 * The Drawer is what actually creates the graphical representation of the plot
 * states for display on the screen. There are overloaded functions that take
 * specific types of plot states.
 * 
 * Plot states typically call drawPlotBackground first, which draws the plot's
 * frame (titles, labels, tick marks, grid). Then they call drawCurve for each
 * of their curves, passing in a separate graphics object from the screen one.
 * This offscreen buffer is usually larger, than is visible, to make panning
 * more efficient.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
public abstract class Drawer {
	/** Font for the label */
	private static final Font labelFont = new Font("Helvetica", Font.PLAIN, 12);
	/** Font for the title */
	private static final Font titleFont = new Font("Helvetica", Font.BOLD, 14);

	/**
	 * Horizontal padding. Derived classes can increment these to make space
	 * around the plot.
	 */
	private static final int HORIZONTAL_PADDING = 10;

	/**
	 * Vertical padding. Derived classes can increment these to make space
	 * around the plot.
	 */
	private static final int VERTICAL_PADDING = 10;

	/** Length of tick marks. */
	private static final int TICK_LENGTH = 5;

	/**
	 * Direction field drawing parameters. Arrow length/width refer to arrowhead
	 * dimensions.
	 */
	private static final int DOT_RADIUS = 2, LINE_LENGTH = 10,
			ARROW_LENGTH = 6, ARROW_WIDTH = 8;

	/** Radius to draw equilibrium points in */
	private static final int EQUILIBRIUM_RADIUS = 4;

	/** Vertical padding for y-axis labels */
	public static final int MIN_GRID_SPACING = 20, MAX_GRID_SPACING = 70;

	/*
	 * ************************ MAJOR DRAWING FUNCTIONS ************************
	 * These functions are the highest level drawing functions, and the only
	 * ones that should be public.
	 */

	/**
	 * This is the publicly accessible function for drawing the plot box, its
	 * border, the title and axis labels, and the tick marks and tick
	 * labels--i.e. everything except the curves themselves.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @return the Rectangle defining the viewing range
	 */
	public static Rectangle drawPlotBackground(Graphics graphics,
			PlotState state) {
		graphics.setPaintMode();

		Rectangle viewingWindow = cutAllLabelSpace(graphics, state);
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;

		// fill a box with white
		graphics.setColor(Color.WHITE);
		graphics.fillRect(viewingWindow.x, viewingWindow.y,
				viewingWindow.width, viewingWindow.height);
		graphics.setColor(Color.BLACK);

		// draw all of the labels, including tick marks, axes, title
		drawAllLabels(graphics, state, viewingWindow);

		// draw a border around box at viewing window
		graphics.drawRect(viewingWindow.x - 1, viewingWindow.y - 1,
				viewingWindow.width + 1, viewingWindow.height + 1);

		return viewingWindow;
	}

	/**
	 * Draws a set of solution curves on the given virtual image.
	 * 
	 * @param c
	 *            The curve to be drawn
	 * @param x
	 *            Which curve variable is the independent one
	 * @param y
	 *            Which curve variable is the dependent one
	 * @param offscreenPlot
	 *            The offscreen image buffer
	 * @param state
	 *            The plot state which will display the curve
	 * @param viewingWindow
	 *            The area available for display
	 */
	public static void drawCurve(Curve c, ODEVar x, ODEVar y,
			Graphics offscreenPlot, PlotState state, Rectangle viewingWindow)

	{
		double[][] pointList = c.getPoints();
		int xPos = c.getVariables().indexOf(x);
		int yPos = c.getVariables().indexOf(y);
		if (xPos == -1 || yPos == -1)
			return;

		offscreenPlot.setColor(c.getVisualProperties().getColor());
		Point last, current;
		last = state.plotToPixelCoords(new Point2D.Double(pointList[xPos][0],
				pointList[yPos][0]), viewingWindow);
		for (int ptIndex = 0; ptIndex < pointList[0].length; ptIndex++) {
			// Set point
			current = state.plotToPixelCoords(new Point2D.Double(
					pointList[xPos][ptIndex], pointList[yPos][ptIndex]),
					viewingWindow);
			// Draw a line from this point to the last point if it is within
			// the range of the graphing window.
			if (pointList[yPos][ptIndex] <= 10E20
					&& pointList[yPos][ptIndex] >= -10E20) {
				offscreenPlot.drawLine(last.x, last.y, current.x, current.y);
			}

			last = current;
		}
		offscreenPlot.setColor(Color.BLACK);
	}

	/**
	 * Draws Equilibrium on the given virtual image.
	 * 
	 * @param e
	 *            The Equilibrium to be drawn
	 * @param x
	 *            Which Equilibrium variable is the independent one
	 * @param y
	 *            Which Equilibrium variable is the dependent one
	 * @param offscreenPlot
	 *            The offscreen image buffer
	 * @param state
	 *            The plot state which will display the curve
	 * @param viewingWindow
	 *            The area available for display
	 */
	public static void drawEquilibrium(Equilibrium e, ODEVar x, ODEVar y,
			Graphics offscreenPlot, PlotState state, Rectangle viewingWindow) {
		int xPos = e.getVariables().indexOf(x);
		int yPos = e.getVariables().indexOf(y);
		if (xPos < 0 || yPos < 0)
			return;
		double[] point = e.getPoint();
		Point2D.Double plotPt = new Point2D.Double(point[xPos], point[yPos]);
		Point pt = state.plotToPixelCoords(plotPt, viewingWindow);
		offscreenPlot.setColor(e.getVisualProperties().getColor());
		offscreenPlot.fillOval(pt.x - EQUILIBRIUM_RADIUS, pt.y
				- EQUILIBRIUM_RADIUS, 2 * EQUILIBRIUM_RADIUS,
				2 * EQUILIBRIUM_RADIUS);
		offscreenPlot.setColor(Color.BLACK);
	}

	/**
	 * Draws a curve on a 3D Plot Panel in the specified color. Note that
	 * buffering is not implemented in 3D.
	 * 
	 * @param state
	 *            Plot3DState representing the Plot Panel to draw on
	 * @param c
	 *            Curve to be drawn
	 * @param x
	 *            The variable corresponding to the x-axis
	 * @param y
	 *            The variable corresponding to the y-axis
	 * @param z
	 *            The variable corresponding to the z-axis
	 */
	public static void draw3DCurve(Plot3DState state, Curve c, ODEVar x,
			ODEVar y, ODEVar z) {
		// first find the positions of each ODEVar in the ODEVarVector
		int xPos = c.getVariables().indexOf(x);
		int yPos = c.getVariables().indexOf(y);
		int zPos = c.getVariables().indexOf(z);
		if (xPos == -1 || yPos == -1 || zPos == -1)
			return;

		double[][] plotPoints = c.getPoints();
		state.getGraph3DPanel()
				.getPlot3DPanel()
				.addLinePlot("", c.getVisualProperties().getColor(),
						plotPoints[xPos], plotPoints[yPos], plotPoints[zPos]);
	}

	/**
	 * Draws a Equilibrium on a 3D Plot Panel in the specified color. Note that
	 * buffering is not implemented in 3D.
	 * 
	 * @param state
	 *            Plot3DState representing the Plot Panel to draw on
	 * @param e
	 *            Equilibrium to be drawn
	 * @param x
	 *            The variable corresponding to the x-axis
	 * @param y
	 *            The variable corresponding to the y-axis
	 * @param z
	 *            The variable corresponding to the z-axis
	 */
	public static void draw3DEquilibrium(Plot3DState state, Equilibrium e,
			ODEVar x, ODEVar y, ODEVar z) {
		// first find the positions of each ODEVar in the ODEVarVector
		int xPos = e.getVariables().indexOf(x);
		int yPos = e.getVariables().indexOf(y);
		int zPos = e.getVariables().indexOf(z);
		if (xPos < 0 || yPos < 0 || zPos < 0)
			return;

		double xPoint[] = new double[1];
		xPoint[0] = e.getPoint()[xPos];
		double yPoint[] = new double[1];
		yPoint[0] = e.getPoint()[yPos];
		double zPoint[] = new double[1];
		zPoint[0] = e.getPoint()[zPos];
		state.getGraph3DPanel()
				.getPlot3DPanel()
				.addScatterPlot("", e.getVisualProperties().getColor(), xPoint,
						yPoint, zPoint);
	}

	/*
	 * ********************* LABEL DRAWING FUNCTIONS ***************************
	 * These functions are responsible for centering and drawing the labels and
	 * the title.
	 */

	/**
	 * Given the already-cut viewingWindow, this draws all the non-plot details.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawAllLabels(Graphics graphics, PlotState state,
			Rectangle viewingWindow) {
		drawTitle(graphics, state.getTitle(), viewingWindow);
		drawAllTicks(graphics, state, viewingWindow);
		drawXAxisLabel(graphics, state.getXLabel(), viewingWindow);
		drawYAxisLabel(graphics, state.getYLabel(), viewingWindow);
	}

	/**
	 * This function is responsible for drawing and horizontally centering the
	 * graph title.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param title
	 *            The graph title
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawTitle(Graphics graphics, String title,
			Rectangle viewingWindow) {
		FontMetrics fm = graphics.getFontMetrics(titleFont);

		graphics.setFont(titleFont);
		graphics.drawString(title,
				viewingWindow.x + (viewingWindow.width - fm.stringWidth(title))
						/ 2, VERTICAL_PADDING + fm.getHeight());
	}

	/**
	 * This function is responsible for drawing and horizontally centering the
	 * graph's x-axis label.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param label
	 *            The label to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawXAxisLabel(Graphics graphics, String label,
			Rectangle viewingWindow) {
		FontMetrics fm = graphics.getFontMetrics(labelFont);
		graphics.setFont(labelFont);

		graphics.drawString(label,
				viewingWindow.x + (viewingWindow.width - fm.stringWidth(label))
						/ 2,
				viewingWindow.y + viewingWindow.height + 2 * fm.getHeight()
						+ VERTICAL_PADDING);
	}

	/**
	 * This function is responsible for drawing the graph's y-axis label.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param label
	 *            The label to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawYAxisLabel(Graphics graphics, String label,
			Rectangle viewingWindow) {
		FontMetrics fm = graphics.getFontMetrics(labelFont);
		graphics.setFont(labelFont);

		graphics.drawString(label, HORIZONTAL_PADDING,
				(viewingWindow.height + fm.getHeight() / 2) / 2
						+ viewingWindow.y);
	}

	/*
	 * *********************** TICK MARK DRAWING FUNCTIONS *********************
	 * These functions are responsible for drawing tick marks and labels.
	 */

	/**
	 * Draws all x and y tick marks, and their labels.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawAllTicks(Graphics graphics, PlotState state,
			Rectangle viewingWindow) {
		drawAllXTicks(graphics, state, viewingWindow);
		drawAllYTicks(graphics, state, viewingWindow);
	}

	/**
	 * Draws all x-axis tick marks and tick labels. Ensures that labels do not
	 * overlap each other.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawAllXTicks(Graphics graphics, PlotState state,
			Rectangle viewingWindow) {
		ListIterator<Tick> tick = (state.getXAxis()).ComputeTickMarks(
				viewingWindow.width).listIterator();
		int minStart = -1;
		while (tick.hasNext()) {
			Tick pt = tick.next();

			// only label the next tick mark if the label wouldn't overlap with
			// a previous
			// tick label.
			if (xTickLabelStart(pt, graphics.getFontMetrics(labelFont),
					viewingWindow) > minStart) {
				minStart = drawXTickLabel(graphics, pt, viewingWindow);
				drawXTickMark(graphics, state, viewingWindow, pt);
			}
			drawXTickMark(graphics, state, viewingWindow, pt);
		}
	}

	/**
	 * Draws all y-axis tick marks and tick labels.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawAllYTicks(Graphics graphics, PlotState state,
			Rectangle viewingWindow) {
		ListIterator<Tick> tick = state.getYAxis()
				.ComputeTickMarks(viewingWindow.height).listIterator();
		while (tick.hasNext()) {
			Tick pt = tick.next();
			drawYTickLabel(graphics, state, pt, viewingWindow);
			drawYTickMark(graphics, state, viewingWindow, pt);
		}
	}

	/**
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param tick
	 *            The tick object to draw
	 * @param viewingWindow
	 *            The area available for display
	 * @return the smallest position at which the next label can begin.
	 */
	private static int drawXTickLabel(Graphics graphics, Tick tick,
			Rectangle viewingWindow) {
		FontMetrics fm = graphics.getFontMetrics(labelFont);
		graphics.setFont(labelFont);
		String label = tick.toString();

		graphics.drawString(label, xTickLabelStart(tick, fm, viewingWindow),
				viewingWindow.y + viewingWindow.height + fm.getHeight());

		return xTickLabelStart(tick, fm, viewingWindow) + fm.stringWidth(label)
				+ HORIZONTAL_PADDING;
	}

	/**
	 * Draws the label for a single Y tick mark.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @param tick
	 *            The tick object to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static void drawYTickLabel(Graphics graphics, PlotState state,
			Tick tick, Rectangle viewingWindow) {
		int yPix = viewingWindow.y + viewingWindow.height
				- tick.getPixelPosition();
		FontMetrics fm = graphics.getFontMetrics(labelFont);
		graphics.setFont(labelFont);
		String label = tick.toString();

		graphics.drawString(label, viewingWindow.x - fm.stringWidth(label)
				- HORIZONTAL_PADDING, yPix + fm.getHeight() / 4);
	}

	/**
	 * Draws a single X tick mark. If the grid is turned on, it also draws full
	 * lines across at that tick mark.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @param viewingWindow
	 *            The area available for display
	 * @param pt
	 *            The tick mark to draw
	 */
	private static void drawXTickMark(Graphics graphics, PlotState state,
			Rectangle viewingWindow, Tick pt) {
		int xPix = viewingWindow.x + pt.getPixelPosition();
		// If necessary draw grid lines
		if (state.getGrid()) {
			graphics.setColor(Color.LIGHT_GRAY);
			graphics.drawLine(xPix, viewingWindow.y, xPix, viewingWindow.y
					+ viewingWindow.height);
			graphics.setColor(Color.BLACK);
		}
		// draw tick mark
		graphics.drawLine(xPix, viewingWindow.y, xPix, viewingWindow.y
				+ TICK_LENGTH);
		graphics.drawLine(xPix, viewingWindow.y + viewingWindow.height
				- TICK_LENGTH, xPix, viewingWindow.y + viewingWindow.height);
	}

	/**
	 * Draws a single Y tick mark. If the grid is turned on, it also draws full
	 * lines across at that tick mark.
	 * 
	 * @param graphics
	 *            The graphics context on which to draw
	 * @param state
	 *            The plot state to draw
	 * @param viewingWindow
	 *            The area available for display
	 * @param pt
	 *            The tick mark to draw
	 */
	private static void drawYTickMark(Graphics graphics, PlotState state,
			Rectangle viewingWindow, Tick pt) {
		int yPix = viewingWindow.y + viewingWindow.height
				- pt.getPixelPosition();
		// If necessary draw grid lines
		if (state.getGrid()) {
			graphics.setColor(Color.LIGHT_GRAY);
			graphics.drawLine(viewingWindow.x, yPix, viewingWindow.x
					+ viewingWindow.width, yPix);
			graphics.setColor(Color.BLACK);
		}
		// draw tick mark
		graphics.drawLine(viewingWindow.x, yPix, viewingWindow.x + TICK_LENGTH,
				yPix);
		graphics.drawLine(viewingWindow.x + viewingWindow.width - TICK_LENGTH,
				yPix, viewingWindow.x + viewingWindow.width, yPix);
	}

	/*
	 * ********************** SPACE CUTTING FUNCTIONS **************************
	 * These functions are responsible for trimming space off of the viewing
	 * window prior to drawing the labels and title.
	 */

	/**
	 * Cuts space out of the viewing window to fit the graph's title and all of
	 * its labels.
	 * 
	 * @param graphics
	 *            The graphics context in which we intend to draw
	 * @param state
	 *            The plot state we intend to draw
	 */
	private static Rectangle cutAllLabelSpace(Graphics graphics, PlotState state) {
		Rectangle viewingWindow = graphics.getClipBounds();

		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;

		viewingWindow = cutTitleSpace(graphics, viewingWindow);
		viewingWindow = cutXAxisLabelSpace(graphics, viewingWindow);
		viewingWindow = cutYAxisLabelSpace(graphics, state.getYLabel(),
				viewingWindow);
		viewingWindow = cutRightMarginSpace(viewingWindow);
		viewingWindow = cutXTickLabelSpace(graphics, viewingWindow);
		viewingWindow = cutYTickLabelSpace(graphics, state, viewingWindow);
		return viewingWindow;
	}

	/**
	 * Cuts space out of the viewing window to fit the graph's title.
	 * 
	 * @param graphics
	 *            The graphics context in which we intend to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static Rectangle cutTitleSpace(Graphics graphics,
			Rectangle viewingWindow) {
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;

		FontMetrics fm = graphics.getFontMetrics(titleFont);

		// 2 * horizontal padding, one for left, one for right
		int width = viewingWindow.width;

		// 3 * vertical padding, one for top to font, one for font to
		// viewingWindow,
		// one for viewingWindow to bottom.
		int height = viewingWindow.height - fm.getHeight() - 3
				* VERTICAL_PADDING;

		viewingWindow = new Rectangle(viewingWindow.x, viewingWindow.y
				+ VERTICAL_PADDING * 2 + fm.getHeight(), width, height);

		return viewingWindow;
	}

	/**
	 * Cuts space out of the viewing window to fit the graph's x-axis label.
	 * 
	 * @param graphics
	 *            The graphics context in which we intend to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static Rectangle cutXAxisLabelSpace(Graphics graphics,
			Rectangle viewingWindow) {
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;

		FontMetrics fm = graphics.getFontMetrics(labelFont);
		graphics.setFont(labelFont);
		int yOffset = fm.getHeight() + 2 * VERTICAL_PADDING;

		viewingWindow = new Rectangle(viewingWindow.x, viewingWindow.y,
				viewingWindow.width, viewingWindow.height - yOffset);

		return viewingWindow;
	}

	/**
	 * Cuts space out of the viewing window to fit the graph's y-axis label.
	 * 
	 * @param graphics
	 *            The graphics context in which we intend to draw
	 * @param label
	 *            The label we intend to draw
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static Rectangle cutYAxisLabelSpace(Graphics graphics,
			String label, Rectangle viewingWindow) {
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;

		FontMetrics fm = graphics.getFontMetrics(labelFont);
		graphics.setFont(labelFont);
		int xOffset = fm.stringWidth(label) + 2 * HORIZONTAL_PADDING;

		viewingWindow = new Rectangle(viewingWindow.x + xOffset,
				viewingWindow.y, viewingWindow.width - xOffset,
				viewingWindow.height);
		return viewingWindow;
	}

	/**
	 * Cuts space out of the viewing window for the right margin, for appearance
	 * 
	 * @param viewingWindow
	 *            The area available for display
	 */
	private static Rectangle cutRightMarginSpace(Rectangle viewingWindow) {
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;
		viewingWindow = new Rectangle(viewingWindow.x, viewingWindow.y,
				viewingWindow.width - 2 * HORIZONTAL_PADDING,
				viewingWindow.height);
		return viewingWindow;
	}

	/**
	 * Cuts space on the bottom of the graph for the X-Tick labels.
	 * 
	 * @param graphics
	 *            The graphics context in which we intend to draw
	 * @param viewingWindow
	 *            The area available for display
	 * @return the reduced viewing window boundary
	 */
	private static Rectangle cutXTickLabelSpace(Graphics graphics,
			Rectangle viewingWindow) {
		// Because tick mark labels use the same font as axis labels, they'll
		// always have the
		// same height as x-axis labels and will thus need the same amount of
		// space, so we can just
		// call cutXAxisLabelSpace again. If you decide make the tick-mark
		// labels use a different
		// different than the axis labels you will need to change this function.
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;
		return cutXAxisLabelSpace(graphics, viewingWindow);
	}

	/**
	 * Cuts space at the side of the graph for Y-Tick Labels
	 * 
	 * @param graphics
	 *            The graphics context in which we intend to draw
	 * @param state
	 *            The plot state we intend to draw
	 * @param viewingWindow
	 *            The area available for display
	 * @return the reduced viewing window boundary
	 */
	private static Rectangle cutYTickLabelSpace(Graphics graphics,
			PlotState state, Rectangle viewingWindow) {
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;

		// Because of potentially variable width of yAxis labels and because
		// these shave
		// width off of the viewingWindow, we need to shave enough space for the
		// largest
		// label.
		Vector<Tick> ticks = state.getYAxis().ComputeTickMarks(
				viewingWindow.height);
		int xOffset = HORIZONTAL_PADDING + maxYTickLabelWidth(graphics, ticks);
		return new Rectangle(viewingWindow.x + xOffset, viewingWindow.y,
				viewingWindow.width - xOffset, viewingWindow.height);
	}

	/*
	 * *************************** HELPER FUNCTIONS ****************************
	 * These miscellenaeous functions are used internally and are generally
	 * useful.
	 */

	private static int xTickLabelStart(Tick tick, FontMetrics fm,
			Rectangle viewingWindow) {
		return viewingWindow.x + tick.getPixelPosition()
				- fm.stringWidth(tick.toString()) / 2;
	}

	/**
	 * The following two functions are responsible for finding the width of the
	 * widest y-tick label.
	 */
	private static int maxYTickLabelWidth(Graphics graphics, Vector<Tick> ticks) {
		ListIterator<Tick> tick = ticks.listIterator();
		return maxYTickLabelWidth(graphics, tick);
	}

	private static int maxYTickLabelWidth(Graphics graphics,
			ListIterator<Tick> tick) {
		FontMetrics fm = graphics.getFontMetrics(labelFont);
		int maxWidth = 0;
		int newWidth;

		while (tick.hasNext()) {
			// convert the value of the next tick to a string
			String label = (tick.next()).toString();

			// store its pixel width
			newWidth = fm.stringWidth(label);

			if (maxWidth < newWidth)
				maxWidth = newWidth;
		}
		return maxWidth;
	}

	/**
	 * Draw a direction field on the current plot object for the given ODE.
	 * Performs a check to see if the direction field can be plotted for the
	 * requested variables. If it cannot, then a non-zero value is returned.
	 * 
	 * @param graphics
	 *            graphics object to display direction field on.
	 * @param state
	 *            the plot to draw the direction field for.
	 * @param viewingWindow
	 *            The area available for display
	 */
	public static void drawDirField(Graphics graphics, SinglePlotState state,
			Rectangle viewingWindow) {

		if (state.getCurrentODE() == null)
		{
			// looks like somebody didn't initialize their equation...
			System.out.println("No equation(s) for slopefield specified.");
			return;
		}
		if (!state.isDirFieldPossible()) {
			// can't draw a direction field for this system on these axes
			System.out.println("Dir Field Not Possible.");
			return;
		}

		Rectangle oldClipBounds = graphics.getClipBounds();
		graphics.setClip(viewingWindow);

		SinglePlotState.DirFieldSettings dfSettings = state
				.getDirFieldCopySettings();

		// plot a slope line with midpoint here in graphics space:
		Point midpoint;

		// compute the spacing of the slope lines
		double xStep = ((viewingWindow.width) / (double) dfSettings
				.getDirXCount());
		double yStep = ((viewingWindow.height) / (double) dfSettings
				.getDirYCount());

		// Divide the pixel space according to the number of dir field lines,
		// finding the midpoints. March through and draw.
		for (int i = 1; i <= dfSettings.getDirXCount() - 1; i++) {
			for (int j = 1; j <= dfSettings.getDirYCount() - 1; j++) {
				// plot a slope line with midpoint here in graphics space:
				midpoint = new Point((int) (viewingWindow.x + i * xStep),
						(int) (viewingWindow.y + j * yStep));

				drawDirMark(midpoint, dfSettings, graphics, state,
						viewingWindow);
			}
		}

		// reset to the old clip bounds
		graphics.setClip(oldClipBounds);

	}

	/**
	 * Draws a single direction field mark at the specified point on the screen.
	 * 
	 * 1) Get the corresponding plot space coordinate 2) Using dy/dt and dx/dt,
	 * calculate the slope dy/dx at the point 3) Extract the x and y components,
	 * normalizing to unit vector 4) Scale according to user settings into pixel
	 * space 5) Draw.
	 * 
	 * @param midpoint
	 *            the midpoint of the mark, in Graphics space
	 * @param dfSettings
	 *            the direction field settings
	 * @param graphics
	 *            graphics object to display direction field on.
	 * @param state
	 *            the plot to draw the direction field for.
	 */
	private static void drawDirMark(Point midpoint,
			SinglePlotState.DirFieldSettings dfSettings, Graphics graphics,
			SinglePlotState state, Rectangle viewingWindow) {
		graphics.setColor(dfSettings.getDirFieldColor());

		// The corresponding midpoint in plot space
		Point2D.Double plotPoint = state.pixelToPlotCoords(midpoint,
				viewingWindow);

		// coordinates of slope line start and end in graphics space
		// The end will have the arrowhead.
		Point drawStart;
		Point drawEnd;

		// to call getSlope in the ParserInterface class we need an
		// array of values. Each entry corresponds to an entry in the
		// varsVec Vector where the variable names are stored
		ODEVarVector varsVec = new ODEVarVector();
		varsVec.add(state.getXVar());
		varsVec.add(state.getYVar());

		// (dx/dt) and (dy/dt) at (x,y)
		double dxdt, dydt;
		// The magnitude of the vector (dx/dt, dy/dt) for normalization
		double dzdt;
		// The normalized x and y components
		double dx, dy;

		// compute the scaling of each axis, defined as
		// "pixel" per "increment rate on the axis"
		double xScale = ((viewingWindow.width) / state.getXAxis()
				.getIncrementRate(plotPoint.x));
		double yScale = ((viewingWindow.height) / state.getYAxis()
				.getIncrementRate(plotPoint.y));

		try {
			// note: if one of the variables is t, then the
			// variable index is -1 and the getSlope() method
			// returns a slope of 1.

			// store the current point in an array for getSlope

			// vertical value (y')
			dydt = state.getCurrentODE().getSlope(varsVec.get(1), varsVec,
					plotPoint)
					* yScale;

			// horizontal value (x')
			dxdt = state.getCurrentODE().getSlope(varsVec.get(0), varsVec,
					plotPoint)
					* xScale;

		} catch (Exception e) {
			// probably a division by zero...
			// continue on to the next slope line.
			return;
		}

		// compute the magnitude of the vector (dx/dt, dy/dt)
		dzdt = Math.sqrt((dxdt * dxdt) + (dydt * dydt));

		if (dzdt == 0) {
			// if both f and g are 0, which is implied by
			// dn == 0, then we don't want to draw any line
			return;
		}

		// calculate the normalized x and y components
		dx = dxdt / dzdt;
		dy = dydt / dzdt;

		// scale the lengths according to the user's settings
		dx *= dfSettings.getDirScale();
		dy *= dfSettings.getDirScale();

		dx *= LINE_LENGTH;
		dy *= LINE_LENGTH;

		// note that y-axis increase means Graphics space decrease
		drawStart = new Point(midpoint.x - (int) dx, midpoint.y + (int) dy);
		drawEnd = new Point(midpoint.x + (int) dx, midpoint.y - (int) dy);

		// draw the slope line
		graphics.drawLine(drawStart.x, drawStart.y, drawEnd.x, drawEnd.y);

		// now draw the head of the slope line
		if (dfSettings.getDirLineType() == SinglePlotState.DirLineType.ARROW) {
			drawArrowhead(graphics, drawStart, drawEnd);
		} else if (dfSettings.getDirLineType() == SinglePlotState.DirLineType.LINE_DOT) {
			graphics.fillOval(drawEnd.x - DOT_RADIUS, drawEnd.y - DOT_RADIUS,
					DOT_RADIUS * 2, DOT_RADIUS * 2);
		}
	}

	/**
	 * Draws an arrowhead at the end of the line specified by the two input
	 * points.
	 * 
	 * @param g
	 *            The graphics context to draw on
	 * @param start
	 *            Point storing the start of the line to be drawn
	 * @param end
	 *            Point storing the end of the line to be drawn
	 */
	private static void drawArrowhead(Graphics g, Point start, Point end) {
		int al = ARROW_LENGTH; // Arrow length
		int aw = ARROW_WIDTH; // Arrow width

		// Arrays to hold the coordinates of the triangle.
		// Used by fillpolygon
		int x[] = new int[3];
		int y[] = new int[3];

		// Draw the body of the arrow
		g.drawLine(start.x, start.y, end.x, end.y);

		// Calculate quadrant the arrow head points to.
		double arrowAng = Math.atan((aw / 2.0) / al);

		// the length of the slanted side of the arrow...almost
		double dist = Math.sqrt(al * al + aw);

		// the angle the slanted side makes with the arrow body
		double lineAng = Math.atan2((Math.abs(start.x - end.x)),
				(Math.abs(start.y - end.y)));

		// Adjust line angle for quadrant
		if (start.x > end.x) {

			// South East
			if (start.y > end.y)
				lineAng = Math.PI - lineAng;

		} else {

			// South West
			if (start.y > end.y)
				lineAng = Math.PI + lineAng;

			// North West
			else
				lineAng = Math.PI * 2 - lineAng;
		}

		// Calculate coords for the base of the arrow
		x[0] = end.x;
		y[0] = end.y;

		x[1] = end.x + (int) (Math.sin(lineAng - arrowAng) * dist);
		y[1] = end.y - (int) (Math.cos(lineAng - arrowAng) * dist);

		x[2] = end.x + (int) (Math.sin(lineAng + arrowAng) * dist);
		y[2] = end.y - (int) (Math.cos(lineAng + arrowAng) * dist);

		// draw the arrow head
		g.fillPolygon(x, y, 3);
	}

}
