/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package solver;

import parser.ParseException;
import data.ODE;

/**
 * EulerSolver implements the Euler algorithm to approximate ODE solutions
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */
public class EulerSolver extends Solver {

	/**
	 * Array to store derivatives at each step in the solve (we create it in run
	 * so that we do not have to allocate memory for it each step in the solve
	 */
	private double[] yDot;

	/**
	 * Constructor for Euler Solver
	 * 
	 * @param ode
	 *            the ODE to solve
	 * @param params
	 *            the parameters to the solver
	 */
	public EulerSolver(ODE ode, SolverParameters params) {
		super(ode, params);
	}

	/**
	 * Compute y at time t+stepsize using Euler Algorithm.
	 * 
	 * @param t
	 *            the independent variable (time)
	 * @param y
	 *            the array where the values of the ODE variables at time
	 *            t+stepsize will be put after running Euler algorithm
	 * @return t+stepsize
	 * @throws Exception
	 *             if there was an error in ode.evaluate, or an infinite or
	 *             undefined result is encountered
	 */
	public double step(double t, double[] y) throws Exception {

		ode.evaluateODEs(t, y, yDot);

		for (int i = 0; i < y.length; i++) {
			y[i] += stepsize * yDot[i];
			if (Double.isInfinite(y[i]) || Double.isNaN(y[i]))
				throw new Exception();
		}

		return t + stepsize;
	}

	/**
	 * Starts the thread and computes the solution based on the given
	 * parameters. When run exits, the thread dies.
	 */
	@Override
	public void run() {

		try {
			boolean done = false;
			int numEqn = ode.getNumEquations();

			// allocate memory for array of derivatives - doing this here saves
			// time since we dont have to do it every step of the solve
			yDot = new double[ode.getNumEquations()];

			// the current value of the independent var
			double t = initialConditions[0];

			// the current values of the dependent vars
			double[] y = new double[numEqn];

			// initialize y to y0
			System.arraycopy(initialConditions, 1, y, 0, numEqn);

			solution = new PointsManager(numEqn + 1);

			while (!stop && !done) {

				solution.addPoint(t, y);

				// compute the next point
				try {
					t = step(t, y);
				} catch (Exception e) {
					if (e instanceof ParseException)
						notifySolutionReadyError("Euler.step() threw a ParseException");
					else
						notifySolutionReadyError("Infinity of NaN was encountered by the Euler solver... stopping solve");
					break;
				}
				if (solveForward && t >= initialConditions[0] + solveSpan)
					done = true;
				if (!solveForward && t <= initialConditions[0] - solveSpan)
					done = true;
			}

			if (!stop)
				solveDone();
		} catch (OutOfMemoryError e) {
			solveError("Out of memory : try reducing solve span or increasing step size.");
		}
	}

	// stop the thread safely
	@Override
	public void kill() {
		stop = true;
		solveError("EULER SOLVER THREAD KILLED");
	}
}
