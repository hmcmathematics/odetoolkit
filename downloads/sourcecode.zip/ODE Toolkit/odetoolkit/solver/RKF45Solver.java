/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package solver;

import parser.ParseException;
import data.ODE;

/**
 * RKF45Solver implements the Runge-Kutta Fehlberg (4/5) algorithm to
 * approximate ODE solutions
 * 
 * References: _Numerical Recipies in C_ (2nd Edition) by Press, Teutolsky,
 * Vetterling, and Flannery Cambridge University Press, 1992
 * 
 * Error monitoring is based on the famous Fortran implementation of RKF45 by
 * L.F. Shampine and H.A. Watts of Sandia National Labs (see
 * http://www.netlib.org/sfmm/rkf45.f)
 * 
 * @author Chris Moore Created: 6/30/02, modified by Clinic 10-11,
 * Max Comstock 2013
 */
public class RKF45Solver extends Solver {

	/**
	 * Constants used to adapt the stepsize according to the error in the last
	 * step
	 */
	// (see _Numerical Recipies in C_)
	public static final double SAFETY = 0.9, PGROW = -0.2, PSHRNK = -0.25,
			ERRCON = Math.pow(5.0 / SAFETY, 1.0 / PGROW);

	/**
	 * The constants aX, bXY, and cX, are coefficients used in method step()
	 * Computed by Cash and Karp
	 */
	// (see _Numerical Recipies in C_ pp. 716-717)
	public static final double a2 = 1.0 / 5.0, a3 = 3.0 / 10.0, a4 = 3.0 / 5.0,
			a5 = 1.0, a6 = 7.0 / 8.0;

	/** Constants for solving */
	public static final double b21 = 1.0 / 5.0, b31 = 3.0 / 40.0,
			b32 = 9.0 / 40.0, b41 = 3.0 / 10.0, b42 = -9.0 / 10.0,
			b43 = 6.0 / 5.0, b51 = -11.0 / 54.0, b52 = 5.0 / 2.0,
			b53 = -70.0 / 27.0, b54 = 35.0 / 27.0, b61 = 1631.0 / 55296.0,
			b62 = 175.0 / 512.0, b63 = 575.0 / 13824.0,
			b64 = 44275.0 / 110592.0, b65 = 253.0 / 4096.0;

	/** Constants for solving */
	public static final double c1 = 37.0 / 378.0, c2 = 0.0, c3 = 250.0 / 621.0,
			c4 = 125.0 / 594.0, c5 = 0.0, c6 = 512.0 / 1771.0;

	/**
	 * dX corresponds to cX-c_starX given in table
	 * "Cash-Karp Parameters for Embedded Runga-Kutta Method" in _Numerical
	 * Recipies in C_ (see above reference) the constants dX are used in
	 * computing the local error due to a step
	 */
	public static final double d1 = c1 - 2825.0 / 27648.0, d2 = c2,
			d3 = c3 - 18575.0 / 48384.0, d4 = c4 - 13525.0 / 55296.0,
			d5 = c5 - 277.0 / 14336.0, d6 = c6 - 0.25;

	/**
	 * the minimum acceptable value of relTol - attempts to obtain higher
	 * accuracy than this are usually very expensive
	 */
	public static final double RELMIN = 1.0E-12;

	/** maximum stepsize */
	private double hMax;
	/** minimum stepsize */
	private double hMin;

	/** the current step size */
	private double h;

	/** absolute tolerance */
	private double absTol;
	/** relative tolerance */
	private double relTol;

	/** the current value of the independent variable */
	private double t;

	/** the current values of the dependent variables */
	private double[] y;

	/** arrays to store derivative evaluations */
	private double[] f1, f2, f3, f4, f5, f6;

	/** used in error monitoring */
	// see the Fortran implementation mentioned above for reference
	double scale, ae;

	/** Temporary array to hold the values of dependent variables */
	double[] yTemp;

	/**
	 * Constructor for RKF45 solver, where local copies of necessary parameters
	 * are created.
	 * 
	 * @param ode
	 * @param params
	 */
	public RKF45Solver(ODE ode, SolverParameters params) {
		super(ode, params);

		hMax = params.getMaxStepSize();
		hMin = params.getMinStepSize();

		absTol = params.getAbsoluteTolerance();
		relTol = params.getRelativeTolerance();

		stop = false;
	}

	/**
	 * Takes one Runge-Kutta 4th-5th step of size h. Computes the scaled local
	 * error in each equation after the step and returns the largest one (see
	 * the Fortran implementation by Shampine and Watts for reference). returns
	 * -1 if there any result was infinite or NaN.
	 */
	private double step() throws ParseException {
		int i;
		double largestError = 0;
		// never used: double yError;
		double scaleError;

		ode.evaluateODEs(t, yTemp, f1);

		for (i = 0; i < y.length; i++)
			yTemp[i] = y[i] + h * (b21 * f1[i]);
		ode.evaluateODEs(t + a2 * h, yTemp, f2);

		for (i = 0; i < y.length; i++)
			yTemp[i] = y[i] + h * (b31 * f1[i] + b32 * f2[i]);
		ode.evaluateODEs(t + a3 * h, yTemp, f3);

		for (i = 0; i < y.length; i++)
			yTemp[i] = y[i] + h * (b41 * f1[i] + b42 * f2[i] + b43 * f3[i]);
		ode.evaluateODEs(t + a4 * h, yTemp, f4);

		for (i = 0; i < y.length; i++)
			yTemp[i] = y[i] + h
					* (b51 * f1[i] + b52 * f2[i] + b53 * f3[i] + b54 * f4[i]);
		ode.evaluateODEs(t + a5 * h, yTemp, f5);

		for (i = 0; i < y.length; i++)
			yTemp[i] = y[i]
					+ h
					* (b61 * f1[i] + b62 * f2[i] + b63 * f3[i] + b64 * f4[i] + b65
							* f5[i]);
		ode.evaluateODEs(t + a6 * h, yTemp, f6);

		/**
		 * This step computes the error estimates so that they can be compared
		 * to the allowed tolerances. Based on the Fortran implementation
		 * mentioned above.
		 */
		largestError = 0;
		for (i = 0; i < y.length; i++) {
			yTemp[i] = y[i]
					+ h
					* (c1 * f1[i] + c3 * f3[i] + c4 * f4[i] + c5 * f5[i] + c6
							* f6[i]);
			scaleError = (Math.abs( ( -2090.0 * f1[i]
					+ ( 21970.0 * f3[i] - 15048.0 * f4[i] ))
                    + ( 22528.0 * f2[i] - 27360.0 * f5[i] ) ))
					/ (Math.abs(y[i]) + Math.abs(f1[i]) + ae);
			if (scaleError > largestError)
				largestError = scaleError;
			if (Double.isInfinite(yTemp[i]) || Double.isNaN(yTemp[i]))
				return -1;
		}

		return largestError;

	}

	@Override
	public void run() {

		try {

			int numEqn = ode.getNumEquations();
			double localError = 0;
			int solutionIndex = 0;

			// temporary variable used when adjusting stepsize
			double tNew;

			// was the last step successful? (do we have to repeat the step
			// with a smaller stepsize?)
			boolean lastStepSuccessful = false;

			// Compute epsilon. This is the smallest double X such that
			// 1.0+X!=1.0
			double eps = SolverInterface.UnitRoundoff();
			// never used: double u26 = 26.0 * eps;

			y = new double[numEqn];
			yTemp = new double[numEqn];

			f1 = new double[numEqn];
			f2 = new double[numEqn];
			f3 = new double[numEqn];
			f4 = new double[numEqn];
			f5 = new double[numEqn];
			f6 = new double[numEqn];

			solution = new PointsManager(numEqn + 1);

			// Restrict relative error tolerance to be at least as large as
			// 2*eps+RELMIN to avoid limiting precision difficulties arising
			// from impossible accuracy requests
			double relMin = 2.0 * eps + RELMIN;
			if (relTol < relMin)
				relTol = relMin;

			if (hMin >= hMax) {
				solveError("Min. step size cannot be >= max. step size");
				stop = true;
			}

			if (relTol <= 0 || absTol <= 0) {
				solveError("The relative and absolute tolerances must be >= 0");
				stop = true;
			}

			if (hMin < 0) {
				solveError("Min. step size must be >= 0");
				stop = true;
			}
			if (hMax <= 0) {
				solveError("Max. step size must be > 0");
				stop = true;
			}

			// set up some vars used to monitor error: see the Fortran
			// implementation of RKF45 by Shampine and Watts (mentioned earlier)
			// for reference
			scale = 2.0 / relTol;
			ae = scale * absTol;

			// set t to the initial independent value and y[] to the
			// initial dependent values
			t = initialConditions[0];
			System.arraycopy(initialConditions, 1, y, 0, numEqn);

			solution.addPoint(t, y);

			// set initial stepsize - we want to try the maximum stepsize to
			// begin
			// with and move to smaller values if necessary
			if (solveForward)
				h = hMax;
			else
				h = -hMax;

			while (!stop) {

				// if the last step was successful (t was updated)...
				if (lastStepSuccessful) {

					// ... and the current t differs from the last recorded one
					// by
					// at least stepsize...
					if (Math.abs(solution.getPoints()[0][solutionIndex] - t) >= Math
							.abs(stepsize)) {

						// ...we want to record the current point in the
						// solution
						// matrix and notify all pointReadyListeners of the
						// point

						solutionIndex++;
						solution.addPoint(t, y);
					}
				}

				// see if we're done
				if (solveForward) {
					if (t >= initialConditions[0] + solveSpan) {
						break;
					}
				} else if (t <= initialConditions[0] - solveSpan)
					break;

				// copy the current point into yTemp
				System.arraycopy(y, 0, yTemp, 0, y.length);
				try {

					// take a step
					localError = step();
				} catch (Exception ex) {
					solveError("RKF45.step() threw an exception");
					stop = true;
				}

				if (localError == -1) {
					solveError("Infinity or NaN encountered by the RKF45 solver... stopping solve");
					stop = true;
				}

				//see the Fortran 77 implementation
				localError = Math.abs(h) * localError * scale / 752400.0;

				// good step
				if (localError <= 1.0) {
					t += h;
					System.arraycopy(yTemp, 0, y, 0, y.length);

					// increase stepsize (see _Numerical Recipies in C_ for
					// explanation)
					if (localError > ERRCON)
						h = SAFETY * h * Math.pow(localError, PGROW);
					else
						h *= 5.0;
					lastStepSuccessful = true;

				} else {

					// if we just tried to use the minimum stepsize and still
					// failed to achieve the desired accuracy, it's useless to
					// continue, so we crap out
					if (Math.abs(h) <= Math.abs(hMin)) {
						solveError("Requested tolerance could not be achieved, even at the minumum stepsize.  Please increase the tolerance or decrease the minimum stepsize.");
						stop = true;
					}

					// decrease stepsize to try the step again (see _Numerical
					// Recipies in C_ for explanation)
					h = SAFETY * h * Math.pow(localError, PSHRNK);
					if (h < 0.1 * h) // what is this?? --Richard
						h *= 0.1;
					tNew = t + h;
					if (tNew == t) {
						solveError("Stepsize underflow in RKF45 solver");
						stop = true;
					}
					lastStepSuccessful = false;
				}

				// check bounds on the new stepsize
				if (Math.abs(h) < hMin) {
					if (solveForward)
						h = hMin;
					else
						h = -hMin;
				} else if (Math.abs(h) > hMax) {
					if (solveForward)
						h = hMax;
					else
						h = -hMax;
				}

			} // while(!stop)

			if (!stop)
				solveDone();
		} catch (OutOfMemoryError e) {
			solveError("Out of memory while solving: try reducing solve span or increasing step size.");
		}
	}

	@Override
	public void kill() {
		stop = true;
		solveError("RK SOLVER THREAD KILLED");
	}

}
