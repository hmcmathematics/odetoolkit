/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package solver;

import parser.ParseException;
import solver.MatrixOperations.MatrixException;
import data.ODE;

/**
 * RBSolver implements the Rosenbrock method to approximate ODE solutions
 * 
 * References: _Numerical Recipies_ (3rd Edition) by Press, Teutolsky,
 * Vetterling, and Flannery Cambridge University Press, 1992-----change-------
 * 
 * @author Clinic 10-11, modification of the RKF45Solver written by Chris Moore
 */
public class RBSolver extends Solver {

	/**
	 * Constants used to adapt the stepsize according to the error in the last
	 * step (see rodas.f)
	 */
	public static final double SAFETY = 0.9, fac1 = 1.0 / 6.0, fac2 = 5,
			PWR = 0.25;

	// The constants cX, dX, aXY, and cXY, are coefficients used in method
	// step()
	// Given in a webnote (see _Numerical Recipies_3rd ed) ----give
	// reference-----

	/** Constants for solving */
	public static final double c2 = 0.386, c3 = 0.21, c4 = 0.63;

	/** Constants for solving */
	public static final double a21 = 1.544000000000000,
			a31 = 0.9466785280815826, a32 = 0.2557011698983284,
			a41 = 3.314825187068521, a42 = 2.896124015972201,
			a43 = 0.9986419139977817, a51 = 1.221224509226641,
			a52 = 6.019134481288629, a53 = 12.53708332932087,
			a54 = -0.6878860361058950;

	/** Constants for solving */
	public static final double gam = 0.250;

	/** Constants for solving */
	public static final double c21 = -5.668800000000000,
			c31 = -2.430093356833875, c32 = -0.2063599157091915,
			c41 = -0.1073529058151375, c42 = -9.594562251023355,
			c43 = -20.47028614809616, c51 = 7.496443313967647,
			c52 = -10.24680431464352, c53 = -33.99990352819905,
			c54 = 11.70890893206160, c61 = 8.083246795921522,
			c62 = -7.981132988064893, c63 = -31.52159432874371,
			c64 = 16.31930543123136, c65 = -6.058818238834054;

	public static final double d1 = 0.25, d2 = 0.1043, d3 = 0.1035,
			d4 = -0.0362;

	/**
	 * the minimum acceptable value of relTol - attempts to obtain higher
	 * accuracy than this are usually very expensive
	 */
	public static final double RELMIN = 1.0E-12;

	/** maximum stepsize */
	private double hMax;
	/** minimum stepsize */
	private double hMin;

	/** absolute tolerance */
	private double absTol;
	/** relative tolerance */
	private double relTol;

	/** the current value of the independent variable */
	private double t;

	/** the current step size */
	private double h;

	/** factor for calculating error value used in adjusting step size */
	double sk;
	/**
	 * factor used for adjusting the step size, divide current step size by
	 * hAdap to get new step size
	 */
	double hAdap;

	/** The number of equations */
	int numEqn = ode.getNumEquations();

	/** the current values of the dependent variables */
	private double[] y;

	/** arrays to store derivative evaluations and intermediate steps */
	private double[] f1, f2, f3, f4, f5, f6, k1, k2, k3, k4, k5;

	/**
	 * array that is y with approximated errors added on, used for comparing y
	 * to y+yerr
	 */
	double[] yNew;

	/** array that holds approximate errors in the values in y */
	private double[] yerr;

	/** helper array to hold intermediate values */
	double[] yTemp, ya, yb, g0, g1, g2, g1x, g2x, DFDX;
	/** helper array to hold intermediate values */
	int[] indx;
	/** helper array to hold intermediate values */
	double[][] JAC, FAC, I;

	/**
	 * Constructor for RB solver, where local copies of necessary parameters are
	 * created.
	 * 
	 * @param ode
	 *            the ODE to solve
	 * @param params
	 *            the parameters for the RB solver
	 */
	public RBSolver(ODE ode, SolverParameters params) {
		super(ode, params);
		hMax = params.getMaxStepSize();
		hMin = params.getMinStepSize();

		absTol = params.getAbsoluteTolerance();
		relTol = params.getRelativeTolerance();

		stop = false;

		// allocate arrays
		y = new double[numEqn];
		f1 = new double[numEqn];
		f2 = new double[numEqn];
		f3 = new double[numEqn];
		f4 = new double[numEqn];
		f5 = new double[numEqn];
		f6 = new double[numEqn];
		k1 = new double[numEqn];
		k2 = new double[numEqn];
		k3 = new double[numEqn];
		k4 = new double[numEqn];
		k5 = new double[numEqn];
		yNew = new double[numEqn];
		yerr = new double[numEqn];
		yTemp = new double[numEqn];
		ya = new double[numEqn];
		yb = new double[numEqn];
		g0 = new double[numEqn];
		g1 = new double[numEqn];
		g2 = new double[numEqn];
		g1x = new double[numEqn];
		g2x = new double[numEqn];
		DFDX = new double[numEqn];
		indx = new int[numEqn];
		JAC = new double[numEqn][numEqn];
		FAC = new double[numEqn][numEqn];
		I = new double[numEqn][numEqn];
	}

	/**
	 * Takes one Rosenbrock step of size h.(method from Numerical Recipes 3rd
	 * ed.) Compute local error in each equation after the step and returns the
	 * largest one Returns -1 if there any result was infinite or NaN.
	 */
	private double step() throws ParseException {
		double largestError = 0;

		// Derivative calculation -
		// approximation with second order forward difference
		// First declare the variables needed

		ode.evaluateODEs(t, y, g0);
		for (int j = 0; j < numEqn; j++) {
			System.arraycopy(y, 0, ya, 0, numEqn);
			ya[j] += h;
			System.arraycopy(y, 0, yb, 0, numEqn);
			yb[j] += 2 * h;
			ode.evaluateODEs(t, ya, g1);
			ode.evaluateODEs(t, yb, g2);
			for (int q = 0; q < numEqn; q++) {
				JAC[q][j] = (-3 * g0[q] + 4 * g1[q] - g2[q]) / (2 * h);
			}
		}
		for (int i = 0; i < numEqn; i++) {
			for (int j = 0; j < numEqn; j++) {
				if (i == j) {
					I[i][j] = 1;
				} else {
					I[i][j] = 0;
				}
			}
		}

		for (int i = 0; i < numEqn; i++)
			for (int j = 0; j < numEqn; j++)
				FAC[i][j] = I[i][j] / (gam * h) - JAC[i][j];

		// Forward difference approx for derivative of f
		// WRT the independent variable
		ode.evaluateODEs(t + h, y, g1x);
		ode.evaluateODEs(t + 2 * h, y, g2x);
		for (int i = 0; i < numEqn; i++)
			DFDX[i] = g0[i] * -3 / (2 * h) + g1x[i] * 2 / h + g2x[i] * -1
					/ (2 * h);

		// Here the work of taking the step begins
		// It uses the derivatives calculated above
		ode.evaluateODEs(t, yTemp, f1);
		for (int i = 0; i < numEqn; i++) {
			k1[i] = f1[i] + DFDX[i] * h * d1;
		}

		try {
			MatrixOperations.ludcmp(FAC, indx);
		} catch (MatrixException e) {
			solveError("Rosenbrock solver returns an error due to singular matrix.");
		}

		MatrixOperations.lubksb(FAC, indx, k1);

		for (int i = 0; i < numEqn; i++)
			yTemp[i] = y[i] + k1[i] * a21;
		ode.evaluateODEs(t + c2 * h, yTemp, f2);
		for (int i = 0; i < numEqn; i++)
			k2[i] = f2[i] + DFDX[i] * h * d2 + k1[i] * c21 / h;
		MatrixOperations.lubksb(FAC, indx, k2);

		for (int i = 0; i < numEqn; i++)
			yTemp[i] = y[i] + k1[i] * a31 + k2[i] * a32;
		ode.evaluateODEs(t + c3 * h, yTemp, f3);
		for (int i = 0; i < numEqn; i++)
			k3[i] = f3[i] + DFDX[i] * h * d3 + k1[i] * c31 / h + k2[i] * c32
					/ h;
		MatrixOperations.lubksb(FAC, indx, k3);

		for (int i = 0; i < numEqn; i++)
			yTemp[i] = y[i] + k1[i] * a41 + k2[i] * a42 + k3[i] * a43;
		ode.evaluateODEs(t + c4 * h, yTemp, f4);
		for (int i = 0; i < numEqn; i++)
			k4[i] = f4[i] + DFDX[i] * h * d4 + k1[i] * c41 / h + k2[i] * c42
					/ h + k3[i] * c43 / h;
		MatrixOperations.lubksb(FAC, indx, k4);

		for (int i = 0; i < numEqn; i++)
			yTemp[i] = y[i] + k1[i] * a51 + k2[i] * a52 + k3[i] * a53 + k4[i]
					* a54;
		ode.evaluateODEs(t + h, yTemp, f5);
		for (int i = 0; i < numEqn; i++)
			k5[i] = f5[i] + k1[i] * c51 / h + k2[i] * c52 / h + k3[i] * c53 / h
					+ k4[i] * c54 / h;
		MatrixOperations.lubksb(FAC, indx, k5);

		for (int i = 0; i < numEqn; i++)
			yTemp[i] += k5[i];
		ode.evaluateODEs(t + h, yTemp, f6);
		for (int i = 0; i < numEqn; i++)
			yerr[i] = f6[i] + k1[i] * c61 / h + k2[i] * c62 / h + k3[i] * c63
					/ h + k4[i] * c64 / h + k5[i] * c65 / h;
		MatrixOperations.lubksb(FAC, indx, yerr);

		for (int i = 0; i < numEqn; i++)
			yNew[i] = yTemp[i] + yerr[i];

		for (int i = 0; i < numEqn; i++) {
			sk = absTol + relTol * Math.max(Math.abs(y[i]), Math.abs(yNew[i]));
			largestError += Math.pow(yerr[i] / sk, 2);

			if (Double.isInfinite(yTemp[i]) || Double.isNaN(yTemp[i]))
				return -1;
		}
		largestError = Math.pow(largestError / numEqn, 0.5);
		return largestError;
	}

	@Override
	public void run() {

		try {

			double localError = 0;
			int solutionIndex = 0;

			// temporary variable used when adjusting stepsize
			double tNew;

			// was the last step successful? (do we have to repeat the step
			// with a smaller stepsize?)
			boolean lastStepSuccessful = false;

			// Compute epsilon. This is the smallest double X such that
			// 1.0+X!=1.0
			double eps = SolverInterface.UnitRoundoff();

			// Matrix in which to store the solution points
			solution = new PointsManager(numEqn + 1);

			// Restrict relative error tolerance to be at least as large as
			// 2*eps+RELMIN to avoid limiting precision difficulties arising
			// from impossible accuracy requests
			double relMin = 2.0 * eps + RELMIN;
			if (relTol < relMin)
				relTol = relMin;

			if (hMin >= hMax) {
				solveError("Min. step size cannot be >= max. step size");
				stop = true;
			}

			if (relTol <= 0 || absTol <= 0) {
				solveError("The relative and absolute tolerances must be >= 0");
				stop = true;
			}

			if (hMin < 0) {
				solveError("Min. step size must be >= 0");
				stop = true;
			}
			if (hMax <= 0) {
				solveError("Max. step size must be > 0");
				stop = true;
			}

			// set t to the initial independent value and y[] to the
			// initial dependent values
			t = initialConditions[0];

			for (int i = 0; i < numEqn; i++)
				y[i] = initialConditions[i + 1];

			// add the initial conditions to the solution matrix and let all
			// point
			// ready listeners know about it
			solution.addPoint(t, y);

			// set initial stepsize - we want to try the maximum stepsize to
			// begin
			// with and move to smaller values if necessary
			if (solveForward)
				h = hMax;
			else
				h = -hMax;

			while (!stop) {

				// if the last step was successful (t was updated)...
				if (lastStepSuccessful) {

					// ... and the current t differs from the last recorded one
					// by
					// at least stepsize...
					if (Math.abs(solution.getPoints()[0][solutionIndex] - t) >= Math
							.abs(stepsize)) {

						// ...we want to record the current point in the
						// solution
						// matrix and notify all pointReadyListeners of the
						// point

						solutionIndex++;
						solution.addPoint(t, y);
					}
				}

				// see if we're done
				if (solveForward) {
					if (t >= initialConditions[0] + solveSpan) {
						break;
					}
				} else if (t <= initialConditions[0] - solveSpan)
					break;

				// copy the current point into yTemp
				System.arraycopy(y, 0, yTemp, 0, numEqn);
				try {

					// take a step
					localError = step();
				} catch (Exception ex) {
					solveError("RB.step() threw an exception" + ex);
					stop = true;
				}

				if (localError == -1) {
					solveError("Infinity or NaN encountered by the RB solver... stopping solve");
					stop = true;
				}

				// good step
				if (localError <= 1.0) {
					t += h;
					System.arraycopy(yTemp, 0, y, 0, numEqn);

					// change stepsize (see Rodas.f) require 0.2<=hnew/h<=6
					hAdap = Math.max(fac1,
							Math.min(fac2, Math.pow(localError, PWR) / SAFETY));
					h = h / hAdap;
					lastStepSuccessful = true;

				} else {

					// if we just tried to use the minimum stepsize and still
					// failed to achieve the desired accuracy, it's useless to
					// continue, so we stop
					if (Math.abs(h) <= Math.abs(hMin)) {
						solveError("Requested tolerance could not be achieved, even at the minumum stepsize.  Please increase the tolerance or decrease the minimum stepsize.");
						stop = true;
					}

					// change stepsize (see Rodas.f) require 0.2<=hnew/h<=6
					hAdap = Math.max(fac1,
							Math.min(fac2, Math.pow(localError, PWR) / SAFETY));
					h = h / hAdap;
					tNew = t + h;
					if (tNew == t) {
						solveError("Stepsize underflow in Rosenbrock solver");
						stop = true;
					}
					lastStepSuccessful = false;
				}

				// check bounds on the new stepsize
				if (Math.abs(h) < hMin) {
					if (solveForward)
						h = hMin;
					else
						h = -hMin;
				} else if (Math.abs(h) > hMax) {
					if (solveForward)
						h = hMax;
					else
						h = -hMax;
				}

			}

			if (!stop)
				solveDone();
		} catch (OutOfMemoryError e) {
			solveError("Out of memory : try reducing solve span or increasing step size.");
		}
	}

	@Override
	public void kill() {
		stop = true;
		solveError("RB SOLVER THREAD KILLED");
	}
}
