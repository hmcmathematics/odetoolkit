/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package solver;

import java.util.Vector;

import util.SolutionReadyListener;
import data.Curve;
import data.ODE;

/**
 * Solver is the parent class of all of the individual solvers (ex: EulerSolver,
 * NetworkSolver, etc.)
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */
public abstract class Solver extends Thread {

	/** The initial value of listener list capacity */
	public final int listenerListInitCapacity = 5;

	/** The solve span to solve for */
	protected double solveSpan;
	/** The number of steps to take */
	protected int numSteps;

	/** The size of each step */
	protected double stepsize;

	/** a pointer to the ODE that this solver will find solutions to */
	protected ODE ode;

	/** a pointer to the Curve that this solver will find solutions for */
	protected Curve curve;

	/** PointsManager that keeps track of the solution */
	protected PointsManager solution;

	/**
	 * the initial values of the variables - the independent var is stored
	 * first, followed by the dependent vars
	 */
	protected double[] initialConditions;

	/**
	 * Vectors of SolutionReadyListeners and PointReadyListeners, respectively,
	 * to be notified when an entire solution is ready or a single point is
	 * ready, respectively
	 */
	protected Vector<SolutionReadyListener> slnReadyList;

	/** Keep track whether the thread is killed or not */
	protected boolean stop;

	/**
	 * true if we are solving forward in time, false if we are solving backward
	 */
	protected boolean solveForward;

	// Functions to add listeners to be notified at the appropriate time

	/**
	 * Add listener to the list of solution ready listener
	 * 
	 * @param srl
	 *            the listener to add
	 */
	public void addSolutionReadyListener(SolutionReadyListener srl) {
		slnReadyList.add(srl);
	}

	/**
	 * Add a vector of listeners to the list of solution ready listener
	 * 
	 * @param srls
	 *            the vector of listeners to add
	 */
	public void addSolutionReadyListeners(Vector<SolutionReadyListener> srls) {
		if (srls != null)
			for (int i = 0; i < srls.size(); i++)
				slnReadyList.add(srls.elementAt(i));
	}

	/**
	 * Takes care of the curve and plots when solving is done
	 */
	public void solveDone() {
		try {
			solution.removeUnusedPoints();
		} catch (OutOfMemoryError e) {
			// ignore memory error at last step
		}
		curve.setPoints(solution.getNumPoints(), solution.getPoints());
		ode.solveDone();
		try {
			notifySolutionReadyListeners(solution.getPoints());
		} catch (OutOfMemoryError e) {
			notifySolutionReadyError("Out of memory while plotting: the plots and the data tab may not be shown correctly.");
		}
	}

	/**
	 * Notify listeners when the solving is done
	 * 
	 * @param soln
	 *            the solution
	 */
	public void notifySolutionReadyListeners(double[][] soln) {
		for (int i = 0; i < slnReadyList.size(); i++)
			(slnReadyList.elementAt(i)).solutionReady(soln);
	}

	/**
	 * Takes care of the curve and plots when an error occurs
	 * 
	 * @param string
	 *            the error message
	 */
	public void solveError(String string) {
		try {
			solution.removeUnusedPoints();
		} catch (OutOfMemoryError e) {
			// ignore memory error at last step
		}
		curve.setPoints(solution.getNumPoints(), solution.getPoints());
		ode.solveError();
		notifySolutionReadyError(string);
		try {
			notifySolutionReadyListeners(solution.getPoints());
		} catch (OutOfMemoryError e) {
			notifySolutionReadyError("Out of memory while plotting: the plots and the data tab may not be shown correctly.");
		}
	}

	/**
	 * Notify listeners that an error occurs
	 * 
	 * @param e
	 *            the exception
	 */
	public void notifySolutionReadyError(Exception e) {
		for (int i = 0; i < slnReadyList.size(); i++)
			(slnReadyList.elementAt(i)).errorCondition(e);
	}

	/**
	 * Notify listeners that an error occurs
	 * 
	 * @param s
	 *            the error message
	 */
	public void notifySolutionReadyError(String s) {
		for (int i = 0; i < slnReadyList.size(); i++)
			(slnReadyList.elementAt(i)).errorCondition(s);
	}

	/**
	 * Remove all listeners from solution ready listerers list
	 */
	public void emptyNotifyLists() {
		slnReadyList.clear();
	}

	/** Start the thread */
	@Override
	public abstract void run();

	/** Stop the thread */
	public abstract void kill();

	/**
	 * Constructor for a Solver
	 * 
	 * @param ode
	 *            the ODE to solve for
	 * @param params
	 *            the parameters for the solver
	 */
	public Solver(ODE ode, SolverParameters params) {

		slnReadyList = new Vector<SolutionReadyListener>(
				listenerListInitCapacity);

		stepsize = 1.0 / params.getResolution();
		solveSpan = params.getSolveSpan();
		numSteps = params.getNumPoints();

		this.ode = ode;
		this.initialConditions = params.getInitialConditions();

		stop = false;

		solveForward = params.getSolveDirection();
		if (!solveForward)
			stepsize = -stepsize;

	}

	/**
	 * Assign a curve to be solved for
	 * 
	 * @param pendingCurve
	 *            the curve to be solved for
	 */
	public void setCurve(Curve pendingCurve) {
		curve = pendingCurve;
	}
}
