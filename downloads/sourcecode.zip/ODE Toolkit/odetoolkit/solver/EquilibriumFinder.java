/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package solver;

import parser.ParserInterface;
import solver.MatrixOperations.MatrixException;

/**
 * The purpose of this class is to search for equilibrium solutions of an
 * autonomous ODE (one with no independent variable on the right hand side of
 * the system).
 * 
 * @author Clinic 08-09, modified by Clinic 10-11
 */

/*
 * NOTE (April '09: We are continuing to support double[]s instead of
 * Point2D.Doubles because this is apparently designed to be able to find
 * equilibria for equations with more than 2 variables. We did however add an
 * overloaded function definition so that it could deal with Point2D.Doubles.
 */
public class EquilibriumFinder {

	/**
	 * Maximum number of iterations to run equilibrium calculator for.
	 * 
	 * NOTE: At this time, the mnewt() method has it's own idea of what too many
	 * iterations are. For other methods to be implemented later, use this
	 * variable.
	 */
	public static final int MAXITS = 1000;

	/**
	 * Find an equilibrium point
	 * 
	 * @param equation
	 *            the system to find equilibrium point
	 * @param guess
	 *            the initial guess of the equilibrium point's location
	 * @return an array representing the equilibrium point
	 * @throws MatrixException
	 */
	public static double[] findEquilibrium(ParserInterface equation,
			double guess[]) throws MatrixException {

		// default to maximum iterations of Newton's method
		return findEquilibrium(equation, guess, MAXITS, 0);
	}

	/**
	 * Find an equilibrium point, with number of iterations specified.
	 * 
	 * @param equation
	 *            the system to find equilibrium point
	 * @param guess
	 *            the initial guess of the equilibrium point's location
	 * @param iterations
	 *            the number of iterations
	 * @return an array representing the equilibrium point
	 * @throws MatrixException
	 */
	public static double[] findEquilibrium(ParserInterface equation,
			double guess[], int iterations) throws MatrixException {

		// default to newton's method
		return findEquilibrium(equation, guess, iterations, 0);
	}

	/**
	 * Find an equilibrium point, with number of iterations and method
	 * specified.
	 * 
	 * @param equation
	 *            the system to find equilibrium point
	 * @param guess
	 *            the initial guess of the equilibrium point's location
	 * @param iterations
	 *            the number of iterations
	 * @param method
	 *            the index of method to use
	 * @return an array representing the equilibrium point
	 * @throws MatrixException
	 */
	public static double[] findEquilibrium(ParserInterface equation,
			double guess[], int iterations, int method) throws MatrixException {
		if (equation == null) {

			// throw invalid equation exception
			throw new MatrixException("Error: No equation(s) specified.");

		} else if (!equation.isAutonomous()) {
			// can't find an equilibrium point for a non-autonomous system

			// throw invalid equation exception
			throw new MatrixException(
					"Error: Can only calculate equilibrium points for autonomous (time independent) systems.");

		} else if (equation.getNumEquations() != guess.length) {
			// values specified mismatch the equation

			// throw invalid equation exception

			throw new MatrixException(
					"Error: Not all unknowns have been specified.");

		}

		// else let's compute some equilibrium

		if (method == 0) {

			// newton's method uses the initial guess for the
			// equilibrium stored in x and improves the guess until an
			// equilibrium solution is found, or the max number of
			// iterations is reached.

			// copy the guess into a new array x because the newton's
			// method routine returns the answer inside the parameter
			// and we don't want to lose our initial guess
			double x[] = new double[guess.length];
			System.arraycopy(guess, 0, x, 0, guess.length);

			MatrixOperations.mnewt(iterations, equation, x);

			double yDot[] = new double[x.length];

			// check to see if the vector is really an equilibrium solution
			double errf = 0;
			try {

				equation.evaluateODEs(0, x, yDot);

				for (int i = 0; i < yDot.length; i++)
					errf += Math.abs(yDot[i]);

				if (errf <= MatrixOperations.TOLF) {

					// go through and set all the really frickin' tiny
					// values to 0.0
					for (int i = 0; i < x.length; i++) {
						if (Math.abs(x[i]) <= MatrixOperations.EPS)
							x[i] = 0.0;
					}

					return x;

				} else {

					// throw an exception to signal that we don't
					// really have an equilibrium point. Try a
					// different guess or more iterations.
					throw new MatrixException(
							"Error: Could not calculate an equilibrium solution from initial guess. Please try another estimate.");

				}

			} catch (Exception e) {
				// problem evaluating the expression.

				throw new MatrixException(
						"Error: Could not evaluate function. Please check syntax and try again.");

			}

		} else {

			// There are some globally convergent methods in Numerical
			// Recipes that would probably work out here, but they are
			// harder to implement. For the types of systems that we
			// will be working with mainly Newton's method should be
			// adequate. If there is a time in the future when a more
			// sophisticated method is needed, fill in with code
			// hereabouts.

			// throw invalid method exception
			throw new MatrixException(
					"Error: Invalid equilibrium solution method specified. Please try another.");

		}

	}

	/**
	 * Given an equation and an equilibrium point, compute the eigenvalues of
	 * the linearized system at that point. The linearized system is
	 * approximated by the numerically computed Jacobian.
	 * 
	 * Returns zero upon success, non-zero upon problem.
	 * 
	 * @param equation
	 *            the ODE equation
	 * @param valsArray
	 *            the array of values for each variable
	 * @param wr
	 *            array for return values of real components
	 * @param wi
	 *            array for return values of imaginary components
	 * @return 0 iff success
	 */

	public static int computeEigenvalues(ParserInterface equation,
			double valsArray[], double wr[], double wi[])
			throws MatrixException {
		if (equation == null) {
			throw new MatrixException("Error: Invalid system specified.");
		} else if (equation.getNumEquations() != valsArray.length) {
			throw new MatrixException("Error: Invalid system specified.");
		}

		// else go ahead and compute the eigenvalues

		// compute the jacobian at the given point.
		// this linearizes the system...kind of...
		double a[][] = MatrixOperations.fdjac(equation, valsArray);

		// balance the values of the matrix a for processing to a
		// Hessenberg matrix
		MatrixOperations.balance(a);

		// convert the matrix to a Hessenberg matrix
		MatrixOperations.elmhes(a);

		// make sure we were passed legit places to store the eigenvalues
		if (wr == null) {
			wr = new double[a.length];
		}

		if (wi == null) {
			wi = new double[a.length];
		}

		if (wr.length != valsArray.length) {
			wr = null;
			wr = new double[a.length];
		}

		if (wi.length != valsArray.length) {
			wi = null;
			wi = new double[a.length];
		}

		// use QR to solve the Hessenberg matrix
		MatrixOperations.hqr(a, wr, wi);

		// the eigenvalues are returned inside wr and wi.
		return 0;
	}

	/**
	 * This routine, when given a vector of eigenvalues (wr holds the real
	 * components, wi holds the imaginary components) for an equilibrium point
	 * in an ODE returns a string describing the classification of an
	 * equilibrium point with a linearized system having those eigenvalues. This
	 * classification scheme was put together by general consensus from the
	 * following references:
	 * 
	 * -Borrelli and Coleman, "Differential Equations a Modeling Approach"
	 * Wiley, 1998, Pages 389
	 * 
	 * -Boyce and diPrima, "Elementary Differential Equations and BVPs." Wiley,
	 * 7th Edition, Pages N/A
	 * 
	 * -Polking, "Ordinary Differential Equations using MATLAB" Prentice Hall,
	 * 1995, Pages 182-185
	 * 
	 * Here are the rules established Classification of systems: 2nd order:
	 * 
	 * -attracting node -repelling node r1,r2<0 r1,r2 > 0
	 * 
	 * -sadle -degenerate r1 < 0 < r2 r1 == 0 or r2 == 0
	 * 
	 * Complex cases (here the real parts r1 and r2 are equal and i1 = -i2)
	 * 
	 * -attracting spiral -repelling spiral r < 0, i != 0 r > 0, i != 0
	 * 
	 * -center (This is a problem. It's only a center if it's a linear
	 * combination of the state variables) r ==0, i != 0
	 * 
	 * nth order: -If all the eigenvalues have negative real part then the point
	 * is asymptotically stable
	 * 
	 * -If one of the eigenvalues has positive real part then the point is
	 * unstable
	 * 
	 * -If all of the eigenvalues have zero real part then a classification
	 * cannot be made.
	 * 
	 * @param wr
	 *            the array specified in the function description
	 * @param wi
	 *            the array specified in the function description
	 * @return the String representing the type of classification of an
	 *         equilibrium point
	 */
	public static String classifyEquilibriumEigenvalues(double wr[],
			double wi[]) {
		String classification;

		// Planar systems are a special case
		if (wr.length == 2) {
			double r1 = wr[0];
			double r2 = wr[1];

			// complex components of real matrices occur in
			// conjugate pairs so we use only one of the values
			// in our analysis

			double c = wi[0];

			if (c != 0) {
				if (r1 < 0) {
					classification = new String("Attracting spiral");

				} else if (r1 > 0) {
					classification = new String("Unstable spiral");

				} else {
					// r1 == 0;
					classification = new String("Center point");
				}

			} else {
				if ((r1 == 0) || (r2 == 0)) {
					classification = new String("Degenerate");

				} else if (r1 > 0 && r2 > 0) {
					classification = new String("Repelling node");

				} else if (r1 < 0 && r2 < 0) {
					classification = new String("Attracting node");

				} else {
					// if (((r1 > 0) && (r2 < 0)) || ((r1 < 0) && (r2 > 0))) {
					// this computation is implied by the preceding
					// if statements
					classification = new String("Saddle point");
				}

			}

		} else {
			boolean allNegativeReal = true;
			boolean allZeroReal = true;

			// if all the eigenvalues have negative real part then the
			// point is "asymptotically stable"

			for (int i = 0; i < wr.length; i++) {
				if (wr[i] != 0) {
					allZeroReal = false;
				}
				if (wr[i] > 0) {
					allNegativeReal = false;
				}
			}

			if (allNegativeReal) {
				classification = new String("Asymptotically Stable");
			} else if (allZeroReal) {
				classification = new String("Unknown Classification");
			} else {
				classification = new String("Unstable");
			}

		}

		return classification;

	}


/*	Test routine for the equilibrium finding class 
	public static void main(String args[]) {

		// System of interest from:
		// "Ordinary Differential Equations using MATLAB"
		// Page 196.
		// Polking, J. 1995, Prentice Hall

		String eqTest = "x'=2*x - y + 3*(x^2-y^2) + 2*x*y\ny'=x - 3*y - 3*(x^2-y^2) + 3*x*y\n";

		try {
			ParserInterface equation = new ParserInterface(eqTest);

			double valsArray[] = new double[2];
			valsArray[0] = -1000;
			valsArray[1] = 1000;

			// try 200 iterations of the newton-rhapson method with
			// initial guess in valsArray on the ODE stored in
			// equation
			valsArray = findEquilibrium(equation, valsArray);

			System.out.println("Approximation: ");
			for (int i = 0; i < valsArray.length; i++) {
				System.out.println("x[" + i + "]" + ": " + valsArray[i]);
			}

			double wr[] = new double[equation.getNumEquations()];
			double wi[] = new double[equation.getNumEquations()];

			if (computeEigenvalues(equation, valsArray, wr, wi) != 0) {
				// problem... 

			} else {
				System.out.println("Eigenvalues:");

				for (int i = 0; i < wr.length; i++)
					System.out.println("\t" + wr[i] + " + " + wi[i] + "i");

				System.out.println(classifyEquilibriumEigenvalues(wr, wi));

			}
		}

		catch (Exception e) {
			// sorry, chief looks like you got a bad equation.
			System.out.println(e);
			System.exit(0);
		}

	} // main
*/
	
} // eqFind
