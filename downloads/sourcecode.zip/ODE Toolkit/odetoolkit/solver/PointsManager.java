/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package solver;

/**
 * This class manages the points for the solution in a 2D array, and
 * automatically expands the array as more space is needed.
 * 
 * @author Clinic 10-11
 */
public class PointsManager {
	/** The points for the solution */
	private double[][] points;
	/** The current number of points in the solution */
	private int currentNumPoints;

	/**
	 * Constructor that creates an array for only one point.
	 * 
	 * @param numVars
	 *            the number of variables need to store in the solution
	 */
	public PointsManager(int numVars) {
		points = new double[numVars][1];
	}

	/**
	 * Returns the points of the solution
	 * 
	 * @return the points of the solution
	 */
	public double[][] getPoints() {
		return points;
	}

	/**
	 * Returns the number of points in the solution
	 * 
	 * @return the number of points in the solution
	 */
	public int getNumPoints() {
		return currentNumPoints;
	}

	/**
	 * Add a new point to the solution
	 * 
	 * @param init
	 *            the value of the independent variable
	 * @param pnt
	 *            the values of the dependent variables
	 */
	public void addPoint(double init, double[] pnt) {
		if (currentNumPoints == points[0].length) {
			double[][] temp = new double[points.length][currentNumPoints * 2];
			for (int i = 0; i < points.length; i++)
				System.arraycopy(points[i], 0, temp[i], 0, currentNumPoints);
			points = temp;
		}

		points[0][currentNumPoints] = init;
		for (int i = 0; i < pnt.length; i++)
			points[i + 1][currentNumPoints] = pnt[i];
		currentNumPoints++;
	}

	/**
	 * Create a new array with exact length needed to store all points.
	 */
	public void removeUnusedPoints() {
		double[][] temp = new double[points.length][currentNumPoints];
		for (int i = 0; i < points.length; i++)
			System.arraycopy(points[i], 0, temp[i], 0, currentNumPoints);
		points = temp;
	}
}
