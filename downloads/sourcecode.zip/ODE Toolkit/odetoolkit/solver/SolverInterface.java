/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package solver;

import data.ODE;


/**
 * The SolverInterface class provide a static function for the ODE Toolkit
 * components which hold data to interact with the solvers. It is the
 * responsibility of the SolverInterface to call the correct Solver based
 * on the value of the currentSolver String in an ODE's SolverSettings.
 * 
 * @author Clnic 10-11, modified from Andres Perez 09
 */
public class SolverInterface {
	/**
	 * Constructor for creating a specific Solver
	 * 
	 * @param ode the ODE to solve for
	 * @param p the parameters for the Solver
	 * @return the desired Solver
	 */
	public static Solver solve(ODE ode, SolverParameters p) {
		SolverParameters params = new SolverParameters(p);
		String solverType = params.getSolver();
		if (solverType.equals("EULER")) {
			EulerSolver eu = new EulerSolver(ode, params);
			if (ode.setupSolve(eu, params))
				return eu;
		}
		if (solverType.equals("RK")) {
			RKF45Solver rk = new RKF45Solver(ode, params);
			if (ode.setupSolve(rk, params))
				return rk;
		}
		if (solverType.equals("RB")) {
			RBSolver rb = new RBSolver(ode, params);
			if (ode.setupSolve(rb, params))
				return rb;
		}
		return null;
	}

	/**
	 * Returns an approximation to the error involved with the current
	 * arithmetic implementation
	 * @return the approximation as described above
	 */
	public static double UnitRoundoff() {
		double u;
		double one_plus_u;

		u = 1.0;
		one_plus_u = 1.0 + u;
		// Check to see if the number 1.0 plus some positive offset
		// computes to be the same as one.
		while (one_plus_u != 1.0) {
			u /= 2.0;
			one_plus_u = 1.0 + u;
		}
		u *= 2.0; // Go back one step

		return (u);
	}

}
