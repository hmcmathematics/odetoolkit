/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * Author: Ken Dye
 * Date: summer 2002
 */
package solver;

import util.ServerRequest;
import data.ODEVar;
import data.ODEVarVector;

/**
 * Solver parameters is just a collection of variables, with getters and
 * setters, that a solver may need to do some solving.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */
public class SolverParameters {
	/** the name of the solver */
	String solver;

	/** Absolute tolerance for solving, for adaptive solver */
	private double absoluteTolerance;
	/** Relative tolerance for solving, for adaptive solver */
	private double relativeTolerance;
	/** The minimum step size, for adaptive solver */
	private double minStepSize;
	/** The maximum step size, for adaptive solver */
	private double maxStepSize;
	/** The number of points per step to solve, for non-adaptive solver */
	private double resolution;
	/** The length of time (dependent variable) to solve for */
	private double solveSpan;
	/** Keep whether the solving is done in forward or backward direction */
	private boolean solveForward;
	/**
	 * Constant for Removed Solvers - we keep this parameter because it is
	 * likely that a new solver to be added may require this parameter
	 */
	private int _multiStepMethod;
	/** The maximum number of steps, for non-adaptive solver */
	private int _maxSteps;

	/** The initial condition to solve */
	private double[] _initialConditions;
	/** The variables associated with the ODE */
	private ODEVarVector _variables;

	/**
	 * Prints debugging information
	 */
	public void printMe() {
		System.out.print("solver=" + solver);
		System.out.print(";atol=" + absoluteTolerance);
		System.out.print(";rtol=" + relativeTolerance);
		System.out.print(";minstep=" + minStepSize);
		System.out.print(";maxstep=" + maxStepSize);
		System.out.print(";resolution=" + resolution);
		System.out.print(";span=" + solveSpan);
		System.out.print(";solvedir=" + solveForward);
		System.out.print(";multistep=" + _multiStepMethod);
		System.out.print(";maxsteps=" + _maxSteps);

		System.out.print(";variables=");
		for (int i = 0; i < _variables.size(); i++)
			System.out.print(_variables.getName(i) + " ");
		System.out.print(";iconditions=");
		for (int i = 0; i < _initialConditions.length; i++)
			System.out.print(_initialConditions[i] + " ");
		System.out.println();
	}

	/**
	 * Returns the maximum number of steps (used in reading/writing file).
	 * 
	 * @return the maximum number of steps
	 */
	public int getMaxSteps() {
		return _maxSteps;
	}

	/**
	 * Set the maximum number of steps (used in reading/writing file).
	 * 
	 * @param d
	 *            the maximum number of steps to set to
	 */
	public void setMaxSteps(int d) {
		_maxSteps = d;
	}

	/**
	 * Returns the value of multi step method (Constant for Removed Solvers)
	 * 
	 * @return the value of multi step method (Constant for Removed Solvers)
	 */
	public int getMultiStepMethod() {
		return _multiStepMethod;
	}

	/**
	 * Set the value of multi step method (Constant for Removed Solvers)
	 * 
	 * @param i
	 *            the value of multi step method to set to
	 */
	public void setMultiStepMethod(int i) {
		_multiStepMethod = i;
	}

	/**
	 * Set the initial condition of a variable
	 * 
	 * @param var
	 *            the variable to modify the value
	 * @param val
	 *            the value to modify to
	 */
	public void setIC(ODEVar var, double val) {
		for (int i = 0; i < _variables.size(); i++)
			if (var.equals(_variables.get(i))) // if the variable is found
				_initialConditions[i] = val;
	}

	/**
	 * Set the initial conditions
	 * 
	 * @param d
	 *            the initial conditions as array of double to set to
	 */
	public void setInitialConditions(double[] d) {
		_initialConditions = d;
	}

	/**
	 * Returns the initial conditions
	 * 
	 * @return the initial conditions as array of double
	 */
	public double[] getInitialConditions() {
		return _initialConditions;
	}

	/**
	 * Set the variables involved in solve
	 * 
	 * @param v
	 *            the ODEVarVector containing the variables to set to
	 */
	public void setVariables(ODEVarVector v) {
		_variables = v;

		if (_initialConditions == null || _initialConditions.length != v.size()) {
			_initialConditions = new double[v.size()];
			for (int i = 0; i < v.size(); ++i)
				_initialConditions[i] = 0;
		}
	}

	/**
	 * Returns the ODEVarVector of variables involved in solve
	 * 
	 * @return the ODEVarVector of variables involved in solve
	 */
	public ODEVarVector getVariables() {
		return _variables;
	}

	/**
	 * Set the solver type (by name)
	 * 
	 * @param sol
	 *            the name of the solver to set to
	 */
	public void setSolver(String sol) {
		solver = sol;
	}

	/**
	 * Returns the solver name
	 * 
	 * @return solver name
	 */
	public String getSolver() {
		return solver;
	}

	/**
	 * Set the absolute tolerance
	 * 
	 * @param d
	 *            the absolute tolerance to set to
	 */
	public void setAbsoluteTolerance(double d) {
		absoluteTolerance = d;
	}

	/**
	 * Returns the absolute tolerance
	 * 
	 * @return the absolute tolerance
	 */
	public double getAbsoluteTolerance() {
		return absoluteTolerance;
	}

	/**
	 * Set the relative tolerance
	 * 
	 * @param d
	 *            the relative tolerance to set to
	 */
	public void setRelativeTolerance(double d) {
		relativeTolerance = d;
	}

	/**
	 * Returns the relative tolerance
	 * 
	 * @return the relative tolerance
	 */
	public double getRelativeTolerance() {
		return relativeTolerance;
	}

	/**
	 * Set the minimum step size
	 * 
	 * @param d
	 *            the minimum step size to set to
	 */
	public void setMinStepSize(double d) {
		minStepSize = d;
	}

	/**
	 * Returns the minimum step size
	 * 
	 * @return the minimum step size
	 */
	public double getMinStepSize() {
		return minStepSize;
	}

	/**
	 * Set the maximum step size
	 * 
	 * @param d
	 *            the maximum step size to set to
	 */
	public void setMaxStepSize(double d) {
		maxStepSize = d;
	}

	/**
	 * Returns the maximum step size
	 * 
	 * @return the maximum step size
	 */
	public double getMaxStepSize() {
		return maxStepSize;
	}

	/**
	 * Set the resolution
	 * 
	 * @param d
	 *            the resolution to set to
	 */
	public void setResolution(double d) {
		resolution = d;
	}

	/**
	 * Returns the resolution
	 * 
	 * @return the resolution
	 */
	public double getResolution() {
		return resolution;
	}

	/**
	 * Set the solve span
	 * 
	 * @param d
	 *            the solve span to set to
	 */
	public void setSolveSpan(double d) {
		solveSpan = d;
	}

	/**
	 * Returns the solve span
	 * 
	 * @return the solve span
	 */
	public double getSolveSpan() {
		return solveSpan;
	}

	/**
	 * Copy constructor
	 * 
	 * @param sp
	 *            the SolverParameters to copy
	 */
	public SolverParameters(SolverParameters sp) {
		solver = new String(sp.getSolver());
		absoluteTolerance = sp.getAbsoluteTolerance();
		relativeTolerance = sp.getRelativeTolerance();
		minStepSize = sp.getMinStepSize();
		maxStepSize = sp.getMaxStepSize();
		resolution = sp.getResolution();
		solveSpan = sp.getSolveSpan();
		solveForward = sp.getSolveDirection();
		_variables = sp.getVariables();
		_initialConditions = new double[sp.getInitialConditions().length];
		for (int i = 0; i < _initialConditions.length; i++)
			_initialConditions[i] = sp.getInitialConditions()[i];
		_maxSteps = sp.getMaxSteps();
		_multiStepMethod = sp.getMultiStepMethod();
	}

	/**
	 * Default constructor - set the solve span to the default value
	 */
	public SolverParameters() {
		solveSpan = 10.0;
	}

	/**
	 * Returns the number of points a solver given these parameters would
	 * generate. Because of rounding, we may run into problems if the number of
	 * points that the solver should return based on the solveSpan and
	 * resolution is not integral.
	 * 
	 * @return the number of maximum points for non-adaptive solve
	 */
	public int getNumPoints() {
		Double d = new Double(solveSpan * resolution);
		return d.intValue() + 1;
	}

	/**
	 * Sets the solve directions.
	 * 
	 * @param dir
	 *            true iff the direction is to set to be forward direction
	 */
	public void setSolveDirection(boolean dir) {
		solveForward = dir;
	}

	/**
	 * Returns whether the solving direction is forward
	 * 
	 * @return true iff the solving direction is forward, false if backward
	 */
	public boolean getSolveDirection() {
		return solveForward;
	}

	/**
	 * Method to check whether two solver parameters are of the same type
	 * 
	 * @param sp
	 *            the solver parameters to be compared to
	 * @return true iff the solvers are of the same type
	 */
	public boolean equals(SolverParameters sp) {
		return sp.toString().equals(this.toString());
	}

	/**
	 * Writes out the solver parameters in the format of server commands.
	 * 
	 * @return the solver parameters in server commands
	 */
	@Override
	public String toString() {
		String rt = new String("");

		rt += ServerRequest.SOLVER + solver + ServerRequest.DELIMITER;

		rt += ServerRequest.DIRECTION;
		if (solveForward)
			rt += ServerRequest.DIRECTION_FORWARD;
		else
			rt += ServerRequest.DIRECTION_BACKWARD;
		rt += ServerRequest.DELIMITER;

		rt += ServerRequest.INITIAL_VALUE_INDEPENDENT_VAR
				+ _initialConditions[0] + ServerRequest.DELIMITER;

		rt += ServerRequest.INITIAL_VALUE_DEPENDENT_VARS
				+ _initialConditions[1];
		for (int i = 2; i < _initialConditions.length; i++)
			rt += ";" + _initialConditions[i];

		rt += ServerRequest.DELIMITER;

		rt += ServerRequest.STEP_SIZE + (1 / resolution)
				+ ServerRequest.DELIMITER;

		rt += ServerRequest.SOLVE_SPAN + solveSpan + ServerRequest.DELIMITER;

		rt += ServerRequest.RELATIVE_TOLERANCE + relativeTolerance
				+ ServerRequest.DELIMITER;

		rt += ServerRequest.ABSOLUTE_TOLERANCE + absoluteTolerance
				+ ServerRequest.DELIMITER;

		if (solver == ServerRequest.SOLVER_EULER) {
			rt += ServerRequest.EULER_MAXSTEP + (resolution * solveSpan);
		} else if (solver == ServerRequest.SOLVER_RB) {
			rt += ServerRequest.RB_IFLAG + "1";
		} else if (solver == ServerRequest.SOLVER_RK) {
			rt += ServerRequest.RK_IFLAG + "1";
		}
		rt += ServerRequest.DELIMITER;

		rt += ServerRequest.OUTPUT_MODE;

		rt += ServerRequest.DELIMITER;

		return rt;
	}

	/**
	 * Returns the variable at the specified index
	 * 
	 * @param index
	 *            the index of the variable desired
	 * @return the variable at the specified index
	 */
	public ODEVar getVar(int index) {
		return _variables.get(index);
	}

	/**
	 * Returns the variable name at the specified index
	 * 
	 * @param index
	 *            the index of the variable desired
	 * @return the variable name at the specified index
	 */
	public String getVarName(int index) {
		return _variables.getName(index);
	}

	/**
	 * Method to check whether the solver options are the same
	 * 
	 * @param other
	 *            the solver parameters to be compared to
	 * @return true iff the solver options are the same
	 */
	public boolean sameSolverOptions(SolverParameters other) {
		return solver.equals(other.getSolver())
				&& absoluteTolerance == other.getAbsoluteTolerance()
				&& relativeTolerance == other.getRelativeTolerance()
				&& minStepSize == other.getMinStepSize()
				&& maxStepSize == other.getMaxStepSize()
				&& resolution == other.getResolution()
				&& _maxSteps == other.getMaxSteps()
				&& _multiStepMethod == other.getMultiStepMethod()
				&& solveSpan == other.getSolveSpan();
	}

	/**
	 * Returns the number of dimensions of the ODE
	 * 
	 * @return the number of dimensions of the ODE
	 */
	public int getDimension() {
		return _variables.size();
	}
}
