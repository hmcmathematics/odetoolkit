/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package io;

import io.castor.CurveType;
import io.castor.DirFieldSettings;
import io.castor.EquilibriumType;
import io.castor.OdeFileType;
import io.castor.PointType;
import io.castor.SolverParametersType;
import io.castor.VisualPropertiesType;
import io.castor.XAxis;
import io.castor.XMLCurves;
import io.castor.XMLEquilibria;
import io.castor.XMLInputPanel;
import io.castor.XMLOde;
import io.castor.XMLOdeFile;
import io.castor.XMLOdes;
import io.castor.XMLPlotState;
import io.castor.XMLPlotStates;
import io.castor.XMLPoint;
import io.castor.XMLPoints;
import io.castor.XMLSolverParameters;
import io.castor.XMLVarList;
import io.castor.XMLVisualProperties;
import io.castor.YAxis;
import io.castor.ZAxis;

import java.awt.Color;
import java.awt.Component;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Arrays;
import java.util.Vector;

import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.math.plot.Plot3DPanel;

import solver.SolverParameters;
import ui.GUI;
import ui.InputPanel;
import ui.outputpanels.ComponentGraphPanel;
import ui.outputpanels.Graph3DPanel;
import ui.outputpanels.GraphPanel;
import ui.outputpanels.MultiGraphPanel;
import ui.outputpanels.ODEWorkspace;
import ui.outputpanels.PhaseGraphPanel;
import ui.outputpanels.PlotPanel;
import data.Curve;
import data.Equilibrium;
import data.ODE;
import data.ODEVarKeeper;
import data.ODEVarVector;
import data.VisualProperties;
import data.WorkspaceData;
import data.plotstates.Plot3DState;
import data.plotstates.PlotState;
import data.plotstates.SinglePlotState;
import data.plotstates.SinglePlotState.DirLineType;

/**
 * The ODEFileHandler class provides static methods for reading and writing
 * ODEWorkspaces. The Castor library is used to marshal and unmarshal the .ode
 * files to and from XML format. The XML format is detailed in the XML schema
 * file, ODEFileSchema.xsd. These methods are written to use Castor 1.0.1. This
 * class has been re-written since the versions by Ken Dye and George Tucker.
 * 
 * @author Clinic 10-11, adapted from Andres Perez 09
 */
public abstract class ODEFileHandler {
	/**
	 * Unmarshals a .ode file using Castor and opens the contents in a new
	 * ODEWorkspace.
	 * 
	 * @param odeFile
	 *            File to be read
	 * @param gui
	 *            GUI to load workspace in
	 * @return ODEWorkspace contained in the .ode file
	 * @throws IOException
	 *             If unmarshalling the .ode file failed
	 */
	public static ODEWorkspace readFile(File odeFile, GUI gui)
			throws IOException {
		// Initialize the Castor objects
		XMLOdeFile xmlOdeFile = new XMLOdeFile();

		// Unmarshal the .ode file contents into an XMLOdeFile
		try {
			FileReader reader = new FileReader(odeFile);
			xmlOdeFile = (XMLOdeFile) Unmarshaller.unmarshal(XMLOdeFile.class,
					reader);
		} catch (FileNotFoundException e) {
		} catch (MarshalException e) {
			System.out.println("There was a problem reading the workspace "
					+ "from the .ode file. (MarshalException)");
			e.printStackTrace();
			return null;
		} catch (ValidationException e) {
			System.out.println("There was a problem reading the workspace "
					+ "from the .ode file. (ValidationException)");
			e.printStackTrace();
		}

		// If unmarshalling fails, throw an IOException
		if (xmlOdeFile == null)
			throw new IOException("Error reading the file contents.");

		System.out.println("Unmarshalling successful.");

		return readWorkspace(odeFile, xmlOdeFile, gui);
	}

	/**
	 * Read ODEWorkspace from xml ode file structure.
	 * 
	 * @param odeFile
	 *            the File read, used as reference by the Workspace
	 * @param xmlOdeFile
	 *            the xml ode file structure to read
	 * @param gui
	 *            GUI to load workspace in
	 * @return the ODEWorkspace read
	 */
	private static ODEWorkspace readWorkspace(File odeFile, OdeFileType xmlOdeFile,
			GUI gui) {
		XMLInputPanel xmlInputPanel = xmlOdeFile.getXMLInputPanel();
		XMLVarList XMLVarList = new XMLVarList();

		String workspaceName = xmlOdeFile.getWorkspaceName();

		String odeName = xmlInputPanel.getName();
		String odeDef = xmlInputPanel.getDefinition();
		XMLSolverParameters xmlSolverParameters = xmlInputPanel
				.getXMLSolverParameters();

		ODEWorkspace odews = new ODEWorkspace(gui, workspaceName);
		odews.getInputPanel().setDefinition(odeDef);
		odews.getInputPanel().setName(odeName);

		WorkspaceData ws = odews.getWorkspace();
		ws.setODENumber(xmlOdeFile.getOdeNumber());

		ODEVarKeeper varKeeper = new ODEVarKeeper();
		readVarVector(XMLVarList, varKeeper);
		odews.setVarKeeper(varKeeper);

		if (xmlSolverParameters != null)
			odews.setParameters(readSolverParameters(xmlSolverParameters,
					varKeeper));

		if (xmlOdeFile.getXMLOdes() != null) {
			// Retrieve the Odes Castor Object
			XMLOdes xmlOdes = xmlOdeFile.getXMLOdes();
			for (XMLOde xmlOde : xmlOdes.getXMLOde()) {
				ODE ode = readODE(xmlOde, varKeeper);
				ws.addODE(ode);
			}
		}

		odews.setFile(odeFile);

		// Add the workspace to the GUI
		GUI.workspaces.addTab(odews.getName(), odews);
		// Set as active workspace
		GUI.workspaces.setSelectedComponent(odews);
		GUI.activeWorkspace = odews;
		// Redraw the workspace
		GUI.activeWorkspace.reload();

		if (odews != null && odews.getTabbedGraphPanel().getTabCount() > 1) {
			readPlotStates(xmlOdeFile, odews);
			odews.getInputPanel().enableSolveComponents(true);
		}

		return odews;
	}

	/**
	 * Read plot states from xml ode file structure.
	 * 
	 * @param xmlOdeFile
	 *            the xml old file structure
	 * @param odews
	 *            the ODEWorkspace to read the plot states into
	 */
	private static void readPlotStates(OdeFileType xmlOdeFile, ODEWorkspace odews) {

		XMLPlotStates xmlPlotStates = new XMLPlotStates();
		XMLPlotState xmlPlotState = new XMLPlotState();
		XAxis xmlXAxis = new XAxis();
		YAxis xmlYAxis = new YAxis();
		ZAxis xmlZAxis = new ZAxis();
		DirFieldSettings xmlDirFieldSettings = new DirFieldSettings();
		ODEVarVector varVector = odews.getCurrentODEVarVector();
		ODEVarKeeper varKeeper = odews.getVarKeeper();

		// Configure the PlotStates
		if (odews != null && odews.getTabbedGraphPanel().getTabCount() > 1) {
			// Retrieve the plot states
			xmlPlotStates = xmlOdeFile.getXMLPlotStates();

			// Iterate through all the graph panels and load the plot states
			for (int i = 0; i < odews.getTabbedGraphPanel().getTabCount(); i++) {
				Component panelComponent = odews.getTabbedGraphPanel()
						.getComponentAt(i);

				if (panelComponent instanceof GraphPanel) {
					GraphPanel panel = (GraphPanel) odews.getTabbedGraphPanel()
							.getComponentAt(i);
					PlotPanel plot = panel.getPlotPanel();

					// Retrieve the plotState Castor object
					xmlPlotState = xmlPlotStates.getXMLPlotState(i);
					// Retrieve the plot state
					PlotState state = (panel).getPlotState();

					// Plot panel settings
					panel.setAllAutoScale(xmlPlotState.getAutoScaleOn());
					panel.setAllGrid(xmlPlotState.getGridOn());
					state.setTitle(xmlPlotState.getTitleLabel());
					// Set the horizontal axis settings
					xmlXAxis = xmlPlotState.getXAxis();
					state.setXLabel(xmlXAxis.getLabel());
					plot.setLogscaleX(xmlXAxis.getLogScaleOn());
					// Set the vertical axis settings
					xmlYAxis = xmlPlotState.getYAxis();
					state.setYLabel(xmlYAxis.getLabel());
					plot.setLogscaleY(xmlYAxis.getLogScaleOn());
					// Set the ranges last (log-scaling affects the bounds)
					state.setXRange(xmlXAxis.getMin(), xmlXAxis.getMax());
					state.setYRange(xmlYAxis.getMin(), xmlYAxis.getMax());
					// Update the label and scale dialogs with current values
					panel.updateLabelDialog();
					panel.updateScaleDialog();

					if (panel instanceof PhaseGraphPanel
							|| panel instanceof ComponentGraphPanel) {
						// Retrieve the dirFieldSettings Castor object
						xmlDirFieldSettings = xmlPlotState
								.getDirFieldSettings();
						// Retrieve the plot state's dirFieldSettings
						SinglePlotState.DirFieldSettings dirFieldSettings = ((SinglePlotState) state)
								.getDirFieldSettings();

						// Get the slope line color and line style.
						Color lineColor = new Color(
								xmlDirFieldSettings.getLineColor());
						DirLineType lineStyle = DirLineType.ARROW;
						if (xmlDirFieldSettings.getLineStyle()
								.equalsIgnoreCase("line_dot"))
							lineStyle = DirLineType.LINE_DOT;
						else if (xmlDirFieldSettings.getLineStyle()
								.equalsIgnoreCase("line"))
							lineStyle = DirLineType.LINE;

						panel.setAllDirField(xmlDirFieldSettings
								.getDirFieldOn());
						dirFieldSettings.setDirXCount(xmlDirFieldSettings
								.getDensity());
						dirFieldSettings.setDirYCount(xmlDirFieldSettings
								.getDensity());
						dirFieldSettings.setDirScale(xmlDirFieldSettings
								.getLength());
						dirFieldSettings.setDirFieldColor(lineColor);
						dirFieldSettings.setDirLineType(lineStyle);
					}

					panel.repaint();
				}

				else if (panelComponent instanceof Graph3DPanel) {
					Graph3DPanel panel = (Graph3DPanel) odews
							.getTabbedGraphPanel().getComponentAt(i);
					Plot3DPanel plot = panel.getPlot3DPanel();

					// Retrieve the plotState Castor object
					xmlPlotState = xmlPlotStates.getXMLPlotState(i);
					// Retrieve the plot state
					Plot3DState state = panel.getPlot3DState();

					// Plot panel settings
					panel.setAllAutoScale(xmlPlotState.getAutoScaleOn());
					panel.setAllGrid(xmlPlotState.getGridOn());
					state.getPlotOwner().setName(xmlPlotState.getTitleLabel());
					// Set the x-axis settings
					xmlXAxis = xmlPlotState.getXAxis();
					plot.plotCanvas.setAxisLabel(0, xmlXAxis.getLabel());
					panel.setAxisLogScale(0, xmlXAxis.getLogScaleOn());
					panel.setVar(0, varVector.indexOf(varKeeper.getVar(xmlXAxis
							.getVariable())));
					// Set the y-axis settings
					xmlYAxis = xmlPlotState.getYAxis();
					plot.plotCanvas.setAxisLabel(1, xmlYAxis.getLabel());
					panel.setAxisLogScale(1, xmlYAxis.getLogScaleOn());
					panel.setVar(1, varVector.indexOf(varKeeper.getVar(xmlYAxis
							.getVariable())));
					// Set the z-axis settings
					xmlZAxis = xmlPlotState.getZAxis();
					plot.plotCanvas.setAxisLabel(2, xmlZAxis.getLabel());
					panel.setAxisLogScale(2, xmlZAxis.getLogScaleOn());
					panel.setVar(2, varVector.indexOf(varKeeper.getVar(xmlZAxis
							.getVariable())));
					// Set the ranges last
					state.setAxisRange(0, xmlXAxis.getMin(), xmlXAxis.getMax());
					state.setAxisRange(1, xmlYAxis.getMin(), xmlYAxis.getMax());
					state.setAxisRange(2, xmlZAxis.getMin(), xmlZAxis.getMax());

					panel.updateDialogs();
					panel.repaint();
				}
			}

			// Set the currently viewed panel
			odews.getTabbedGraphPanel().setSelectedIndex(
					xmlPlotStates.getCurrentPanelIndex());
		}
	}

	/**
	 * Read an ode from xml ode structure.
	 * 
	 * @param xmlOde
	 *            the xml ode structure to be read
	 * @param varKeeper
	 *            the ODEVarKeeper to use as reference
	 * @return the ODE read
	 */
	private static ODE readODE(XMLOde xmlOde, ODEVarKeeper varKeeper) {
		ODE ode = new ODE(xmlOde.getName());
		ode.setODEText(xmlOde.getDefinition());
		ode.setCurveNumber(xmlOde.getCurveNumber());
		ode.setEquilibriumNumber(xmlOde.getEquilibriumNumber());

		// read curves
		for (CurveType xmlCurve : xmlOde.getXMLCurves()) {
			Curve c = readCurve(xmlCurve, varKeeper);
			ode.addCurve(c);
		}

		// read equilibrium points
		for (EquilibriumType xmlEquilibrium : xmlOde.getXMLEquilibria()) {
			Equilibrium eq = readEquilibrium(xmlEquilibrium, varKeeper);
			ode.addEquilibrium(eq);
		}

		return ode;
	}

	/**
	 * Read a Curve from xml curve structure.
	 * 
	 * @param xmlCurve
	 *            the xml curve structure to be read
	 * @param varKeeper
	 *            the ODEVarKeeper to use as reference
	 * @return the Curve read
	 */
	private static Curve readCurve(CurveType xmlCurve, ODEVarKeeper varKeeper) {
		String curveName = xmlCurve.getName();
		SolverParametersType xmlSolverParameters = xmlCurve
				.getXMLSolverParameters();
		SolverParameters sp = readSolverParameters(xmlSolverParameters,
				varKeeper);
		// read Coordinates
		XMLPoints xmlPoints = xmlCurve.getXMLPoints();
		int numPoints = xmlPoints.getXMLPointCount();
		int numDim = sp.getDimension();
		double[][] points = new double[numDim][numPoints];
		for (int i = 0; i < numPoints; i++) {
			XMLPoint xmlPoint = xmlPoints.getXMLPoint(i);
			for (int j = 0; j < numDim; j++) {
				points[j][i] = xmlPoint.getVarCoordinate(j);
			}
		}
		VisualProperties vp = readVisualProperties(xmlCurve
				.getXMLVisualProperties());

		return new Curve(sp, curveName, points, vp);
	}

	/**
	 * Read an Equilibrium from xml equilibrium structure.
	 * 
	 * @param xmlEquilibrium
	 *            the xml equilibrium to be read
	 * @param varKeeper
	 *            the ODEVarKeeper to use as reference
	 * @return the Equilibrium read
	 */
	private static Equilibrium readEquilibrium(EquilibriumType xmlEquilibrium,
			ODEVarKeeper varKeeper) {
		String name = xmlEquilibrium.getName();
		ODEVarVector variables = readVarVector(xmlEquilibrium.getXMLVarList(),
				varKeeper);
		double[] point = readPoint(xmlEquilibrium.getXMLPoint());
		VisualProperties visualProperties = readVisualProperties(xmlEquilibrium
				.getXMLVisualProperties());
		Equilibrium eq = new Equilibrium(variables, name, point,
				visualProperties);
		return eq;
	}

	/**
	 * Read a VisualProperties from xml visual properties structure.
	 * 
	 * @param xmlVisualProperties
	 *            the xml visual properties to be read
	 * @return the VisualProperties read
	 */
	private static VisualProperties readVisualProperties(
			VisualPropertiesType xmlVisualProperties) {
		VisualProperties visualProperties = new VisualProperties();
		visualProperties.showHide(xmlVisualProperties.getIsShown());
		visualProperties
				.setColor(new Color(xmlVisualProperties.getCurveColor()));
		return visualProperties;
	}

	/**
	 * Read a SolverParameters from xml solver parameters structure.
	 * 
	 * @param xmlSolverParameters
	 *            the xml solver parameters to be read
	 * @param varKeeper
	 *            the ODEVarKeeper to use as reference
	 * @return the SolverParameters read
	 */
	private static SolverParameters readSolverParameters(
			SolverParametersType xmlSolverParameters, ODEVarKeeper varKeeper) {
		SolverParameters sp = new SolverParameters();

		sp.setSolver(xmlSolverParameters.getSolver());
		sp.setAbsoluteTolerance(xmlSolverParameters.getAbsTol());
		sp.setRelativeTolerance(xmlSolverParameters.getRelTol());
		sp.setMinStepSize(xmlSolverParameters.getMinStepSize());
		sp.setMaxStepSize(xmlSolverParameters.getMaxStepSize());
		sp.setMaxSteps(xmlSolverParameters.getMaxSteps());
		sp.setSolveDirection(xmlSolverParameters.getSolveForward());
		sp.setMultiStepMethod(xmlSolverParameters.getMultiStepMethod());
		sp.setSolveSpan(xmlSolverParameters.getSolveSpan());
		sp.setResolution(xmlSolverParameters.getPointsPerTime());

		ODEVarVector varVector = readVarVector(
				xmlSolverParameters.getXMLVarList(), varKeeper);
		sp.setVariables(varVector);

		double[] ic = readPoint(xmlSolverParameters.getXMLPoint());
		sp.setInitialConditions(ic);
		return sp;
	}

	/**
	 * Read a single point from xml point structure.
	 * 
	 * @param xmlPoint
	 *            the xml point structure to be read
	 * @return the point read, as an array of double
	 */
	private static double[] readPoint(PointType xmlPoint) {
		int numDim = xmlPoint.getVarCoordinateCount();
		double[] point = new double[numDim];
		for (int i = 0; i < numDim; i++)
			point[i] = xmlPoint.getVarCoordinate(i);
		return point;
	}

	/**
	 * Read a list of variables from xml variable list structure.
	 * 
	 * @param varList
	 *            the xml variable list structure to be read
	 * @param varKeeper
	 *            the ODEVarKeeper to use as reference
	 * @return the variable list read, as an ODEVarVector object
	 */
	private static ODEVarVector readVarVector(XMLVarList varList, ODEVarKeeper varKeeper) {
		return varKeeper.createVarVector(Arrays.asList(varList.getVarNames()));
	}

	/**
	 * Reads the contents of a .ode file referenced by a URL, then creates a
	 * temporary file to to read the Workspace into the GUI.
	 * 
	 * @param url
	 *            URL containing the file to read
	 * @param parent
	 *            GUI controlling that the workspace exists in
	 * @return An ODEWorkspace. Call reload on the workspace, after the
	 *         workspace has been added to the parent GUI.
	 * @throws IOException
	 * @throws ParseException
	 */
	public static ODEWorkspace readWorkspaceFromURL(URL url, GUI parent)
			throws IOException {
		File temp = null;

		// Determine the name of the .ode file, given a valid URL
		// We can assume that the URL path will end with "<file>.ode."
		String urlString = url.toString();
		String name = urlString.substring(urlString.lastIndexOf('/') + 1,
				urlString.lastIndexOf('.'));
		System.out.println("Reading contents from: " + name);

		// Call helper method: Convert URL contents to String
		String urlContents;
		try {
			urlContents = urlContentsToString(url);
		} catch (NullPointerException e) {
			throw e;
		}
		System.out.println("Finished reading contents from: " + name);

		try {
			// Create temp file.
			temp = File.createTempFile(name, ".ode");

			// Delete temp file when program exits.
			temp.deleteOnExit();

			// Write to temp file
			BufferedWriter out = new BufferedWriter(new FileWriter(temp));
			out.write(urlContents);
			out.close();
		} catch (IOException ioe) {
			System.out
					.println("an IOException happened while creating the temp file.");
		}

		// Pass file into primary constructor
		System.out.println("Passing contents of " + name
				+ " to ODEWorkspace Reader");
		return readFile(temp, parent);
	}

	/**
	 * This method takes a URL that is assumed to contain a valid .ode file i
	 * XML format, and then reads out its contents into a string.
	 * 
	 * @param url
	 *            the URL to be read from
	 * @return a String containing the contents of the URL
	 */
	public static String urlContentsToString(URL url) {
		InputStream is = null;
		BufferedReader dis = null;

		String temp; // Used for building output string
		String output = ""; // String containing URL contents

		try {
			// Open the InputStream
			is = url.openStream();

			// Convert the InputStream to a buffered DataInputStream.
			dis = new BufferedReader(new InputStreamReader(is));

			// Build the output string
			while ((temp = dis.readLine()) != null)
				output = output.concat(temp + "\n");
		} catch (IOException ioe) {
			System.out
					.println("an IOException happened while opening the InputStream.");
		} finally {
			try {
				try {
					is.close(); // Close the InputStream
				} catch (NullPointerException e) {
					throw e;
				}
			} catch (IOException ioe) {
				System.out
						.println("an IOException happened while closing the InputStream.");
			}
		}

		// System.out.println("The contents are:\n" + output); // DEBUG
		return output;
	}

	/**
	 * Marshalls an WorkspaceData into a .ode file in XML format using Castor.
	 * 
	 * @param newFile
	 *            File to be written/overwritten
	 * @param ws
	 *            WorkspaceData to be marshalled into XML
	 */
	public static void writeFile(File newFile, WorkspaceData ws) {
		// Initialize and/or create the Castor objects
		XMLOdeFile xmlOdeFile = writeWorkspace(ws);

		// Write the XML Castor objects to a file
		try {
			FileWriter fileWriter = new FileWriter(newFile);
			Marshaller.marshal(xmlOdeFile, fileWriter);
			fileWriter.close();
		} catch (IOException e) {
		} catch (MarshalException e) {
			System.out.println("There was a problem saving the workspace to "
					+ "a .ode file. (MarshalException)");
			e.printStackTrace();
		} catch (ValidationException e) {
			System.out.println("There was a problem saving the workspace to "
					+ "a .ode file. (ValidationException)");
			e.printStackTrace();
		}
	}

	/**
	 * Write WorkspaceData to xml ode file structure.
	 * 
	 * @param ws
	 *            the WorkspaceData to be written
	 * @return the xml ode file structure with WorkspaceData information
	 *         included
	 */
	private static XMLOdeFile writeWorkspace(WorkspaceData ws) {
		XMLOdeFile xmlOdeFile = new XMLOdeFile();
		XMLInputPanel xmlInputPanel = new XMLInputPanel();
		xmlOdeFile.setWorkspaceName(ws.getName());
		InputPanel input = ws.getODEWorkspace().getInputPanel();
		xmlInputPanel.setName(input.getName());
		xmlInputPanel.setDefinition(input.getDefinition());

		Vector<ODE> odeVec = ws.getODEs();

		if (!odeVec.isEmpty()) {
			XMLSolverParameters xmlSolverParameters = writeSolverParameters(input
					.getParameters());
			xmlInputPanel.setXMLSolverParameters(xmlSolverParameters);

			XMLOdes xmlOdes = new XMLOdes();
			for (ODE ode : odeVec) {
				XMLOde xmlOde = writeODE(ode);
				xmlOdes.addXMLOde(xmlOde);
			}
			xmlOdeFile.setXMLOdes(xmlOdes);
		}
		xmlOdeFile.setXMLInputPanel(xmlInputPanel);

		XMLPlotStates xmlPlotStates = writePlotStates(ws.getODEWorkspace());
		xmlOdeFile.setXMLPlotStates(xmlPlotStates);

		XMLVarList varList = writeVarList(ws.getODEWorkspace().getVarKeeper()
				.allVarVector());
		xmlOdeFile.setXMLVarList(varList);

		xmlOdeFile.setOdeNumber(ws.getODENumber());

		return xmlOdeFile;
	}

	/**
	 * Write plot states to xml plot state structure.
	 * 
	 * @param odews
	 *            the ODEWorkspace with plot states to be written
	 * @return the xml plot state structure with plot states information
	 *         included
	 */
	private static XMLPlotStates writePlotStates(ODEWorkspace odews) {
		XMLPlotStates xmlPlotStates = null;
		// Store the Plotstates if there is at least one non-data panel
		if (odews != null && odews.getTabbedGraphPanel().getTabCount() > 1) {
			// Create a PlotStates Castor object
			xmlPlotStates = new XMLPlotStates();

			// Set the currently viewed panel
			xmlPlotStates.setCurrentPanelIndex(odews.getTabbedGraphPanel()
					.getSelectedIndex());

			// Iterate through all the graph panels and save the plot states
			for (int i = 0; i < odews.getTabbedGraphPanel().getTabCount(); i++) {
				Component panel = odews.getTabbedGraphPanel().getComponentAt(i);

				if (panel instanceof ComponentGraphPanel
						|| panel instanceof PhaseGraphPanel
						|| panel instanceof MultiGraphPanel) {
					// Create PlotState Castor object
					XMLPlotState xmlPlotState = new XMLPlotState();
					// Retrieve the plot state
					PlotState state = ((GraphPanel) panel).getPlotState();

					// Set PlotState settings
					xmlPlotState.setAutoScaleOn(state.getAutoscale());
					xmlPlotState.setGridOn(state.getGrid());
					xmlPlotState.setTitleLabel(state.getTitle());
					// Create and set the XAxis Castor Object
					XAxis xmlXAxis = new XAxis();
					xmlXAxis.setLabel(state.getXLabel());
					xmlXAxis.setMin(state.getXRange()[0]);
					xmlXAxis.setMax(state.getXRange()[1]);
					xmlXAxis.setLogScaleOn(state.getLogscaleX());
					xmlPlotState.setXAxis(xmlXAxis);
					// Create and set the YAxis Castor Object
					YAxis xmlYAxis = new YAxis();
					xmlYAxis.setLabel(state.getYLabel());
					xmlYAxis.setMin(state.getYRange()[0]);
					xmlYAxis.setMax(state.getYRange()[1]);
					xmlYAxis.setLogScaleOn(state.getLogscaleY());
					xmlPlotState.setYAxis(xmlYAxis);

					if (panel instanceof PhaseGraphPanel
							|| panel instanceof ComponentGraphPanel) {
						// Create DirFieldSettings Castor object
						DirFieldSettings xmlDirFieldSettings = new DirFieldSettings();
						// Retrieve DirFieldSettings
						SinglePlotState.DirFieldSettings settings = ((SinglePlotState) state)
								.getDirFieldCopySettings();

						// Set DirField settings
						xmlDirFieldSettings
								.setDirFieldOn(((SinglePlotState) state)
										.getDirectionFieldOn());
						xmlDirFieldSettings.setLength(settings.getDirScale());
						xmlDirFieldSettings.setDensity(settings.getDirXCount());
						// Encode line color to int.
						int colorCode = settings.getDirFieldColor().getRGB();
						xmlDirFieldSettings.setLineColor(colorCode);
						xmlDirFieldSettings.setLineStyle(settings
								.getDirLineType().toString());

						// Set the DirFieldSettings for the PlotState
						xmlPlotState.setDirFieldSettings(xmlDirFieldSettings);
					}

					// Add the PlotState to the PlotStates
					xmlPlotStates.addXMLPlotState(xmlPlotState);
				}

				else if (panel instanceof Graph3DPanel) {
					// Create PlotState Castor object
					XMLPlotState xmlPlotState = new XMLPlotState();
					// Retrieve the plot state
					Plot3DState state = ((Graph3DPanel) panel).getPlot3DState();

					// Set PlotState settings
					xmlPlotState.setAutoScaleOn(state.getAutoScale());
					xmlPlotState.setGridOn(state.isGridOn());
					xmlPlotState.setTitleLabel(state.getPlotOwner().getName());
					// Create and set the XAxis Castor Object
					XAxis xmlXAxis = new XAxis();
					xmlXAxis.setLabel(state.getAxisLabel(0));
					xmlXAxis.setMin(state.getAxisRange(0)[0]);
					xmlXAxis.setMax(state.getAxisRange(0)[1]);
					xmlXAxis.setLogScaleOn(state.isAxisLogScale(0));
					xmlXAxis.setVariable(state.getVar(0).getName());
					xmlPlotState.setXAxis(xmlXAxis);
					// Create and set the YAxis Castor Object
					YAxis xmlYAxis = new YAxis();
					xmlYAxis.setLabel(state.getAxisLabel(1));
					xmlYAxis.setMin(state.getAxisRange(1)[0]);
					xmlYAxis.setMax(state.getAxisRange(1)[1]);
					xmlYAxis.setLogScaleOn(state.isAxisLogScale(1));
					xmlYAxis.setVariable(state.getVar(1).getName());
					xmlPlotState.setYAxis(xmlYAxis);
					// Create and set the ZAxis Castor Object
					ZAxis xmlZAxis = new ZAxis();
					xmlZAxis.setLabel(state.getAxisLabel(2));
					xmlZAxis.setMin(state.getAxisRange(2)[0]);
					xmlZAxis.setMax(state.getAxisRange(2)[1]);
					xmlZAxis.setLogScaleOn(state.isAxisLogScale(2));
					xmlZAxis.setVariable(state.getVar(2).getName());
					xmlPlotState.setZAxis(xmlZAxis);

					// Add the PlotState to the PlotStates
					xmlPlotStates.addXMLPlotState(xmlPlotState);
				}
			}
		}
		return xmlPlotStates;
	}

	/**
	 * Write ODE to xml ode structure.
	 * 
	 * @param ode
	 *            the ODE to be written
	 * @return the xml ode structure with ODE information included
	 */
	private static XMLOde writeODE(ODE ode) {
		XMLOde xmlOde = new XMLOde();
		xmlOde.setName(ode.getName());
		xmlOde.setDefinition(ode.getODEText());
		xmlOde.setCurveNumber(ode.getCurveNumber());
		xmlOde.setEquilibriumNumber(ode.getEquilibriumNumber());

		int numCurves = ode.getNumCurves();
		Vector<Curve> curves = ode.getCurves();
		XMLCurves[] xmlCurves = new XMLCurves[numCurves];
		for (int i = 0; i < numCurves; i++) {
			xmlCurves[i] = writeCurve(curves.get(i));
		}
		xmlOde.setXMLCurves((XMLCurves[]) xmlCurves);

		int numEquilibria = ode.getNumEquilibria();
		Vector<Equilibrium> equilibria = ode.getEquilibria();
		XMLEquilibria[] xmlEquilibria = new XMLEquilibria[numEquilibria];
		for (int i = 0; i < numEquilibria; i++) {
			xmlEquilibria[i] = writeEquilibrium(equilibria.get(i));
		}
		xmlOde.setXMLEquilibria((XMLEquilibria[]) xmlEquilibria);

		return xmlOde;
	}

	/**
	 * Write ODEVarVector to xml var list structure.
	 * 
	 * @param varVector
	 *            the ODEVarVector containing the list of variables to be
	 *            written
	 * @return the xml variable list structure with variables information
	 *         included
	 */
	private static XMLVarList writeVarList(ODEVarVector varVector) {
		int numDim = varVector.size();
		String[] varNames = new String[numDim];
		for (int i = 0; i < numDim; i++) {
			varNames[i] = varVector.getName(i);
		}
		XMLVarList xmlVarList = new XMLVarList();
		xmlVarList.setVarNames(varNames);
		return xmlVarList;
	}

	/**
	 * Write Curve to xml curve structure.
	 * 
	 * @param c
	 *            the Curve to be written
	 * @return the xml curve structure with Curve information included
	 */
	private static XMLCurves writeCurve(Curve c) {
		XMLCurves xmlCurve = new XMLCurves();
		xmlCurve.setName(c.getName());
		xmlCurve.setXMLSolverParameters(writeSolverParameters(c
				.getSolverParameters()));

		XMLPoints xmlPoints = new XMLPoints();
		int numDim = c.getDimensions();
		double[][] points = c.getPoints();
		int numPoints = points[0].length;
		for (int i = 0; i < numPoints; i++) {
			XMLPoint xmlPoint = new XMLPoint();
			for (int j = 0; j < numDim; j++)
				xmlPoint.addVarCoordinate(points[j][i]);
			xmlPoints.addXMLPoint(xmlPoint);
		}
		xmlCurve.setXMLPoints(xmlPoints);

		XMLVisualProperties visualProperties = writeVisualProperties(c
				.getVisualProperties());
		xmlCurve.setXMLVisualProperties(visualProperties);

		return xmlCurve;
	}

	/**
	 * Write VisualProperties to xml visual properties structure.
	 * 
	 * @param vp
	 *            the VisualProperties to be written
	 * @return the xml visual properties structure with VisualProperties
	 *         information included
	 */
	private static XMLVisualProperties writeVisualProperties(VisualProperties vp) {
		XMLVisualProperties visualProperties = new XMLVisualProperties();
		visualProperties.setCurveColor(vp.getColor().getRGB());
		visualProperties.setIsShown(vp.isShown());
		return visualProperties;
	}

	/**
	 * Write Equilibrium to xml equilibrium structure.
	 * 
	 * @param eq
	 *            the Equilibrium to be written
	 * @return the xml equilibrium structure with Equilibrium information
	 *         included
	 */
	private static XMLEquilibria writeEquilibrium(Equilibrium eq) {
		XMLEquilibria xmlEquilibrium = new XMLEquilibria();
		xmlEquilibrium.setName(eq.getName());
		xmlEquilibrium.setXMLPoint(writePoint(eq.getPoint()));
		xmlEquilibrium.setXMLVarList(writeVarList(eq.getVariables()));
		xmlEquilibrium.setXMLVisualProperties(writeVisualProperties(eq
				.getVisualProperties()));
		return xmlEquilibrium;
	}

	/**
	 * Write SolverParameters to xml solver parameters structure.
	 * 
	 * @param sp
	 *            the SolverParameters to be written
	 * @return the xml solver parameters structure with SolverParmaeters
	 *         information included
	 */
	private static XMLSolverParameters writeSolverParameters(SolverParameters sp) {

		XMLSolverParameters xmlSolverParameters = new XMLSolverParameters();

		XMLPoint xmlPoint = writePoint(sp.getInitialConditions());
		xmlSolverParameters.setXMLPoint(xmlPoint);

		xmlSolverParameters.setSolver(sp.getSolver());
		xmlSolverParameters.setAbsTol(sp.getAbsoluteTolerance());
		xmlSolverParameters.setRelTol(sp.getRelativeTolerance());
		xmlSolverParameters.setMinStepSize(sp.getMinStepSize());
		xmlSolverParameters.setMaxStepSize(sp.getMaxStepSize());
		xmlSolverParameters.setMaxSteps(sp.getMaxSteps());
		xmlSolverParameters.setSolveForward(sp.getSolveDirection());
		xmlSolverParameters.setMultiStepMethod(sp.getMultiStepMethod());
		xmlSolverParameters.setSolveSpan(sp.getSolveSpan());
		xmlSolverParameters.setPointsPerTime(sp.getResolution());

		XMLVarList xmlVarList = writeVarList(sp.getVariables());
		xmlSolverParameters.setXMLVarList(xmlVarList);

		return xmlSolverParameters;
	}

	/**
	 * Write a single point to xml point structure.
	 * 
	 * @param point
	 *            the array of doubles representing a point
	 * @return the xml point structure with point information included
	 */
	private static XMLPoint writePoint(double[] point) {
		int numDim = point.length;
		XMLPoint xmlPoint = new XMLPoint();
		for (int i = 0; i < numDim; i++)
			xmlPoint.setVarCoordinate(point);
		return xmlPoint;
	}

	/**
	 * Appends an extension to the specified file's name. This file is called
	 * whenever an outside class saves an ODE Workspace to a file or the
	 * library, or exporting a file to postscript
	 * 
	 * @param file
	 *            File to append the extension to
	 * @param ext
	 *            Extension to append (starting with a dot '.')
	 * @return File File with a name containing the newly-added extension
	 */
	public static File appendExtension(File file, String ext) {
		String fileName = file.getPath();
		if (!fileName.toLowerCase().endsWith(ext))
			return new File(fileName.concat(ext));
		return file;
	}
}
