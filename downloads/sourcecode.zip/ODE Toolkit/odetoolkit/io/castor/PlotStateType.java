/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class PlotStateType.
 * 
 * @version $Revision$ $Date$
 */
public class PlotStateType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _autoScaleOn
     */
    private boolean _autoScaleOn;

    /**
     * keeps track of state for field: _autoScaleOn
     */
    private boolean _has_autoScaleOn;

    /**
     * Field _gridOn
     */
    private boolean _gridOn;

    /**
     * keeps track of state for field: _gridOn
     */
    private boolean _has_gridOn;

    /**
     * Field _titleLabel
     */
    private java.lang.String _titleLabel;

    /**
     * Field _dirFieldSettings
     */
    private io.castor.DirFieldSettings _dirFieldSettings;

    /**
     * Field _xAxis
     */
    private io.castor.XAxis _xAxis;

    /**
     * Field _yAxis
     */
    private io.castor.YAxis _yAxis;

    /**
     * Field _zAxis
     */
    private io.castor.ZAxis _zAxis;


      //----------------/
     //- Constructors -/
    //----------------/

    public PlotStateType() 
     {
        super();
    } //-- io.castor.PlotStateType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteAutoScaleOn
     * 
     */
    public void deleteAutoScaleOn()
    {
        this._has_autoScaleOn= false;
    } //-- void deleteAutoScaleOn() 

    /**
     * Method deleteGridOn
     * 
     */
    public void deleteGridOn()
    {
        this._has_gridOn= false;
    } //-- void deleteGridOn() 

    /**
     * Returns the value of field 'autoScaleOn'.
     * 
     * @return boolean
     * @return the value of field 'autoScaleOn'.
     */
    public boolean getAutoScaleOn()
    {
        return this._autoScaleOn;
    } //-- boolean getAutoScaleOn() 

    /**
     * Returns the value of field 'dirFieldSettings'.
     * 
     * @return DirFieldSettings
     * @return the value of field 'dirFieldSettings'.
     */
    public io.castor.DirFieldSettings getDirFieldSettings()
    {
        return this._dirFieldSettings;
    } //-- io.castor.DirFieldSettings getDirFieldSettings() 

    /**
     * Returns the value of field 'gridOn'.
     * 
     * @return boolean
     * @return the value of field 'gridOn'.
     */
    public boolean getGridOn()
    {
        return this._gridOn;
    } //-- boolean getGridOn() 

    /**
     * Returns the value of field 'titleLabel'.
     * 
     * @return String
     * @return the value of field 'titleLabel'.
     */
    public java.lang.String getTitleLabel()
    {
        return this._titleLabel;
    } //-- java.lang.String getTitleLabel() 

    /**
     * Returns the value of field 'xAxis'.
     * 
     * @return XAxis
     * @return the value of field 'xAxis'.
     */
    public io.castor.XAxis getXAxis()
    {
        return this._xAxis;
    } //-- io.castor.XAxis getXAxis() 

    /**
     * Returns the value of field 'yAxis'.
     * 
     * @return YAxis
     * @return the value of field 'yAxis'.
     */
    public io.castor.YAxis getYAxis()
    {
        return this._yAxis;
    } //-- io.castor.YAxis getYAxis() 

    /**
     * Returns the value of field 'zAxis'.
     * 
     * @return ZAxis
     * @return the value of field 'zAxis'.
     */
    public io.castor.ZAxis getZAxis()
    {
        return this._zAxis;
    } //-- io.castor.ZAxis getZAxis() 

    /**
     * Method hasAutoScaleOn
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasAutoScaleOn()
    {
        return this._has_autoScaleOn;
    } //-- boolean hasAutoScaleOn() 

    /**
     * Method hasGridOn
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasGridOn()
    {
        return this._has_gridOn;
    } //-- boolean hasGridOn() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'autoScaleOn'.
     * 
     * @param autoScaleOn the value of field 'autoScaleOn'.
     */
    public void setAutoScaleOn(boolean autoScaleOn)
    {
        this._autoScaleOn = autoScaleOn;
        this._has_autoScaleOn = true;
    } //-- void setAutoScaleOn(boolean) 

    /**
     * Sets the value of field 'dirFieldSettings'.
     * 
     * @param dirFieldSettings the value of field 'dirFieldSettings'
     */
    public void setDirFieldSettings(io.castor.DirFieldSettings dirFieldSettings)
    {
        this._dirFieldSettings = dirFieldSettings;
    } //-- void setDirFieldSettings(io.castor.DirFieldSettings) 

    /**
     * Sets the value of field 'gridOn'.
     * 
     * @param gridOn the value of field 'gridOn'.
     */
    public void setGridOn(boolean gridOn)
    {
        this._gridOn = gridOn;
        this._has_gridOn = true;
    } //-- void setGridOn(boolean) 

    /**
     * Sets the value of field 'titleLabel'.
     * 
     * @param titleLabel the value of field 'titleLabel'.
     */
    public void setTitleLabel(java.lang.String titleLabel)
    {
        this._titleLabel = titleLabel;
    } //-- void setTitleLabel(java.lang.String) 

    /**
     * Sets the value of field 'xAxis'.
     * 
     * @param xAxis the value of field 'xAxis'.
     */
    public void setXAxis(io.castor.XAxis xAxis)
    {
        this._xAxis = xAxis;
    } //-- void setXAxis(io.castor.XAxis) 

    /**
     * Sets the value of field 'yAxis'.
     * 
     * @param yAxis the value of field 'yAxis'.
     */
    public void setYAxis(io.castor.YAxis yAxis)
    {
        this._yAxis = yAxis;
    } //-- void setYAxis(io.castor.YAxis) 

    /**
     * Sets the value of field 'zAxis'.
     * 
     * @param zAxis the value of field 'zAxis'.
     */
    public void setZAxis(io.castor.ZAxis zAxis)
    {
        this._zAxis = zAxis;
    } //-- void setZAxis(io.castor.ZAxis) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return PlotStateType
     */
    public static io.castor.PlotStateType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.PlotStateType) Unmarshaller.unmarshal(io.castor.PlotStateType.class, reader);
    } //-- io.castor.PlotStateType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
