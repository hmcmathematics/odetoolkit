/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class DirFieldSettingsType.
 * 
 * @version $Revision$ $Date$
 */
public class DirFieldSettingsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _dirFieldOn
     */
    private boolean _dirFieldOn;

    /**
     * keeps track of state for field: _dirFieldOn
     */
    private boolean _has_dirFieldOn;

    /**
     * Field _length
     */
    private double _length;

    /**
     * keeps track of state for field: _length
     */
    private boolean _has_length;

    /**
     * Field _density
     */
    private int _density;

    /**
     * keeps track of state for field: _density
     */
    private boolean _has_density;

    /**
     * Field _lineColor
     */
    private int _lineColor;

    /**
     * keeps track of state for field: _lineColor
     */
    private boolean _has_lineColor;

    /**
     * Field _lineStyle
     */
    private java.lang.String _lineStyle;


      //----------------/
     //- Constructors -/
    //----------------/

    public DirFieldSettingsType() 
     {
        super();
    } //-- io.castor.DirFieldSettingsType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteDensity
     * 
     */
    public void deleteDensity()
    {
        this._has_density= false;
    } //-- void deleteDensity() 

    /**
     * Method deleteDirFieldOn
     * 
     */
    public void deleteDirFieldOn()
    {
        this._has_dirFieldOn= false;
    } //-- void deleteDirFieldOn() 

    /**
     * Method deleteLength
     * 
     */
    public void deleteLength()
    {
        this._has_length= false;
    } //-- void deleteLength() 

    /**
     * Method deleteLineColor
     * 
     */
    public void deleteLineColor()
    {
        this._has_lineColor= false;
    } //-- void deleteLineColor() 

    /**
     * Returns the value of field 'density'.
     * 
     * @return int
     * @return the value of field 'density'.
     */
    public int getDensity()
    {
        return this._density;
    } //-- int getDensity() 

    /**
     * Returns the value of field 'dirFieldOn'.
     * 
     * @return boolean
     * @return the value of field 'dirFieldOn'.
     */
    public boolean getDirFieldOn()
    {
        return this._dirFieldOn;
    } //-- boolean getDirFieldOn() 

    /**
     * Returns the value of field 'length'.
     * 
     * @return double
     * @return the value of field 'length'.
     */
    public double getLength()
    {
        return this._length;
    } //-- double getLength() 

    /**
     * Returns the value of field 'lineColor'.
     * 
     * @return int
     * @return the value of field 'lineColor'.
     */
    public int getLineColor()
    {
        return this._lineColor;
    } //-- int getLineColor() 

    /**
     * Returns the value of field 'lineStyle'.
     * 
     * @return String
     * @return the value of field 'lineStyle'.
     */
    public java.lang.String getLineStyle()
    {
        return this._lineStyle;
    } //-- java.lang.String getLineStyle() 

    /**
     * Method hasDensity
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasDensity()
    {
        return this._has_density;
    } //-- boolean hasDensity() 

    /**
     * Method hasDirFieldOn
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasDirFieldOn()
    {
        return this._has_dirFieldOn;
    } //-- boolean hasDirFieldOn() 

    /**
     * Method hasLength
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasLength()
    {
        return this._has_length;
    } //-- boolean hasLength() 

    /**
     * Method hasLineColor
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasLineColor()
    {
        return this._has_lineColor;
    } //-- boolean hasLineColor() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'density'.
     * 
     * @param density the value of field 'density'.
     */
    public void setDensity(int density)
    {
        this._density = density;
        this._has_density = true;
    } //-- void setDensity(int) 

    /**
     * Sets the value of field 'dirFieldOn'.
     * 
     * @param dirFieldOn the value of field 'dirFieldOn'.
     */
    public void setDirFieldOn(boolean dirFieldOn)
    {
        this._dirFieldOn = dirFieldOn;
        this._has_dirFieldOn = true;
    } //-- void setDirFieldOn(boolean) 

    /**
     * Sets the value of field 'length'.
     * 
     * @param length the value of field 'length'.
     */
    public void setLength(double length)
    {
        this._length = length;
        this._has_length = true;
    } //-- void setLength(double) 

    /**
     * Sets the value of field 'lineColor'.
     * 
     * @param lineColor the value of field 'lineColor'.
     */
    public void setLineColor(int lineColor)
    {
        this._lineColor = lineColor;
        this._has_lineColor = true;
    } //-- void setLineColor(int) 

    /**
     * Sets the value of field 'lineStyle'.
     * 
     * @param lineStyle the value of field 'lineStyle'.
     */
    public void setLineStyle(java.lang.String lineStyle)
    {
        this._lineStyle = lineStyle;
    } //-- void setLineStyle(java.lang.String) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return DirFieldSettingsType
     */
    public static io.castor.DirFieldSettingsType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.DirFieldSettingsType) Unmarshaller.unmarshal(io.castor.DirFieldSettingsType.class, reader);
    } //-- io.castor.DirFieldSettingsType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
