/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class XMLPoints.
 * 
 * @version $Revision$ $Date$
 */
public class XMLPoints extends PointsType 
implements java.io.Serializable
{


      //----------------/
     //- Constructors -/
    //----------------/

    public XMLPoints() 
     {
        super();
    } //-- io.castor.XMLPoints()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return PointsType
     */
    public static io.castor.PointsType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.PointsType) Unmarshaller.unmarshal(io.castor.XMLPoints.class, reader);
    } //-- io.castor.PointsType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
