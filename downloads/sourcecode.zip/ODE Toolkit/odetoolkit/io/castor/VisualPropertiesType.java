/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class VisualPropertiesType.
 * 
 * @version $Revision$ $Date$
 */
public class VisualPropertiesType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _curveColor
     */
    private int _curveColor;

    /**
     * keeps track of state for field: _curveColor
     */
    private boolean _has_curveColor;

    /**
     * Field _isShown
     */
    private boolean _isShown;

    /**
     * keeps track of state for field: _isShown
     */
    private boolean _has_isShown;


      //----------------/
     //- Constructors -/
    //----------------/

    public VisualPropertiesType() 
     {
        super();
    } //-- io.castor.VisualPropertiesType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteCurveColor
     * 
     */
    public void deleteCurveColor()
    {
        this._has_curveColor= false;
    } //-- void deleteCurveColor() 

    /**
     * Method deleteIsShown
     * 
     */
    public void deleteIsShown()
    {
        this._has_isShown= false;
    } //-- void deleteIsShown() 

    /**
     * Returns the value of field 'curveColor'.
     * 
     * @return int
     * @return the value of field 'curveColor'.
     */
    public int getCurveColor()
    {
        return this._curveColor;
    } //-- int getCurveColor() 

    /**
     * Returns the value of field 'isShown'.
     * 
     * @return boolean
     * @return the value of field 'isShown'.
     */
    public boolean getIsShown()
    {
        return this._isShown;
    } //-- boolean getIsShown() 

    /**
     * Method hasCurveColor
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasCurveColor()
    {
        return this._has_curveColor;
    } //-- boolean hasCurveColor() 

    /**
     * Method hasIsShown
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasIsShown()
    {
        return this._has_isShown;
    } //-- boolean hasIsShown() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'curveColor'.
     * 
     * @param curveColor the value of field 'curveColor'.
     */
    public void setCurveColor(int curveColor)
    {
        this._curveColor = curveColor;
        this._has_curveColor = true;
    } //-- void setCurveColor(int) 

    /**
     * Sets the value of field 'isShown'.
     * 
     * @param isShown the value of field 'isShown'.
     */
    public void setIsShown(boolean isShown)
    {
        this._isShown = isShown;
        this._has_isShown = true;
    } //-- void setIsShown(boolean) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return VisualPropertiesType
     */
    public static io.castor.VisualPropertiesType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.VisualPropertiesType) Unmarshaller.unmarshal(io.castor.VisualPropertiesType.class, reader);
    } //-- io.castor.VisualPropertiesType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
