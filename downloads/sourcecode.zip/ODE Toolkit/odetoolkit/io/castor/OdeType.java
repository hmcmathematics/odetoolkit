/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Vector;

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class OdeType.
 * 
 * @version $Revision$ $Date$
 */
public class OdeType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _name
     */
    private java.lang.String _name;

    /**
     * Field _definition
     */
    private java.lang.String _definition;

    /**
     * Field _XMLCurvesList
     */
    private java.util.Vector _XMLCurvesList;

    /**
     * Field _XMLEquilibriaList
     */
    private java.util.Vector _XMLEquilibriaList;

    /**
     * Field _curveNumber
     */
    private int _curveNumber;

    /**
     * keeps track of state for field: _curveNumber
     */
    private boolean _has_curveNumber;

    /**
     * Field _equilibriumNumber
     */
    private int _equilibriumNumber;

    /**
     * keeps track of state for field: _equilibriumNumber
     */
    private boolean _has_equilibriumNumber;


      //----------------/
     //- Constructors -/
    //----------------/

    public OdeType() 
     {
        super();
        _XMLCurvesList = new Vector();
        _XMLEquilibriaList = new Vector();
    } //-- io.castor.OdeType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addXMLCurves
     * 
     * 
     * 
     * @param vXMLCurves
     */
    public void addXMLCurves(io.castor.XMLCurves vXMLCurves)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLCurvesList.addElement(vXMLCurves);
    } //-- void addXMLCurves(io.castor.XMLCurves) 

    /**
     * Method addXMLCurves
     * 
     * 
     * 
     * @param index
     * @param vXMLCurves
     */
    public void addXMLCurves(int index, io.castor.XMLCurves vXMLCurves)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLCurvesList.insertElementAt(vXMLCurves, index);
    } //-- void addXMLCurves(int, io.castor.XMLCurves) 

    /**
     * Method addXMLEquilibria
     * 
     * 
     * 
     * @param vXMLEquilibria
     */
    public void addXMLEquilibria(io.castor.XMLEquilibria vXMLEquilibria)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLEquilibriaList.addElement(vXMLEquilibria);
    } //-- void addXMLEquilibria(io.castor.XMLEquilibria) 

    /**
     * Method addXMLEquilibria
     * 
     * 
     * 
     * @param index
     * @param vXMLEquilibria
     */
    public void addXMLEquilibria(int index, io.castor.XMLEquilibria vXMLEquilibria)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLEquilibriaList.insertElementAt(vXMLEquilibria, index);
    } //-- void addXMLEquilibria(int, io.castor.XMLEquilibria) 

    /**
     * Method deleteCurveNumber
     * 
     */
    public void deleteCurveNumber()
    {
        this._has_curveNumber= false;
    } //-- void deleteCurveNumber() 

    /**
     * Method deleteEquilibriumNumber
     * 
     */
    public void deleteEquilibriumNumber()
    {
        this._has_equilibriumNumber= false;
    } //-- void deleteEquilibriumNumber() 

    /**
     * Method enumerateXMLCurves
     * 
     * 
     * 
     * @return Enumeration
     */
    public java.util.Enumeration enumerateXMLCurves()
    {
        return _XMLCurvesList.elements();
    } //-- java.util.Enumeration enumerateXMLCurves() 

    /**
     * Method enumerateXMLEquilibria
     * 
     * 
     * 
     * @return Enumeration
     */
    public java.util.Enumeration enumerateXMLEquilibria()
    {
        return _XMLEquilibriaList.elements();
    } //-- java.util.Enumeration enumerateXMLEquilibria() 

    /**
     * Returns the value of field 'curveNumber'.
     * 
     * @return int
     * @return the value of field 'curveNumber'.
     */
    public int getCurveNumber()
    {
        return this._curveNumber;
    } //-- int getCurveNumber() 

    /**
     * Returns the value of field 'definition'.
     * 
     * @return String
     * @return the value of field 'definition'.
     */
    public java.lang.String getDefinition()
    {
        return this._definition;
    } //-- java.lang.String getDefinition() 

    /**
     * Returns the value of field 'equilibriumNumber'.
     * 
     * @return int
     * @return the value of field 'equilibriumNumber'.
     */
    public int getEquilibriumNumber()
    {
        return this._equilibriumNumber;
    } //-- int getEquilibriumNumber() 

    /**
     * Returns the value of field 'name'.
     * 
     * @return String
     * @return the value of field 'name'.
     */
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName() 

    /**
     * Method getXMLCurves
     * 
     * 
     * 
     * @param index
     * @return XMLCurves
     */
    public io.castor.XMLCurves getXMLCurves(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLCurvesList.size())) {
            throw new IndexOutOfBoundsException("getXMLCurves: Index value '"+index+"' not in range [0.."+(_XMLCurvesList.size() - 1) + "]");
        }
        
        return (io.castor.XMLCurves) _XMLCurvesList.elementAt(index);
    } //-- io.castor.XMLCurves getXMLCurves(int) 

    /**
     * Method getXMLCurves
     * 
     * 
     * 
     * @return XMLCurves
     */
    public io.castor.XMLCurves[] getXMLCurves()
    {
        int size = _XMLCurvesList.size();
        io.castor.XMLCurves[] mArray = new io.castor.XMLCurves[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (io.castor.XMLCurves) _XMLCurvesList.elementAt(index);
        }
        return mArray;
    } //-- io.castor.XMLCurves[] getXMLCurves() 

    /**
     * Method getXMLCurvesCount
     * 
     * 
     * 
     * @return int
     */
    public int getXMLCurvesCount()
    {
        return _XMLCurvesList.size();
    } //-- int getXMLCurvesCount() 

    /**
     * Method getXMLEquilibria
     * 
     * 
     * 
     * @param index
     * @return XMLEquilibria
     */
    public io.castor.XMLEquilibria getXMLEquilibria(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLEquilibriaList.size())) {
            throw new IndexOutOfBoundsException("getXMLEquilibria: Index value '"+index+"' not in range [0.."+(_XMLEquilibriaList.size() - 1) + "]");
        }
        
        return (io.castor.XMLEquilibria) _XMLEquilibriaList.elementAt(index);
    } //-- io.castor.XMLEquilibria getXMLEquilibria(int) 

    /**
     * Method getXMLEquilibria
     * 
     * 
     * 
     * @return XMLEquilibria
     */
    public io.castor.XMLEquilibria[] getXMLEquilibria()
    {
        int size = _XMLEquilibriaList.size();
        io.castor.XMLEquilibria[] mArray = new io.castor.XMLEquilibria[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (io.castor.XMLEquilibria) _XMLEquilibriaList.elementAt(index);
        }
        return mArray;
    } //-- io.castor.XMLEquilibria[] getXMLEquilibria() 

    /**
     * Method getXMLEquilibriaCount
     * 
     * 
     * 
     * @return int
     */
    public int getXMLEquilibriaCount()
    {
        return _XMLEquilibriaList.size();
    } //-- int getXMLEquilibriaCount() 

    /**
     * Method hasCurveNumber
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasCurveNumber()
    {
        return this._has_curveNumber;
    } //-- boolean hasCurveNumber() 

    /**
     * Method hasEquilibriumNumber
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasEquilibriumNumber()
    {
        return this._has_equilibriumNumber;
    } //-- boolean hasEquilibriumNumber() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAllXMLCurves
     * 
     */
    public void removeAllXMLCurves()
    {
        _XMLCurvesList.removeAllElements();
    } //-- void removeAllXMLCurves() 

    /**
     * Method removeAllXMLEquilibria
     * 
     */
    public void removeAllXMLEquilibria()
    {
        _XMLEquilibriaList.removeAllElements();
    } //-- void removeAllXMLEquilibria() 

    /**
     * Method removeXMLCurves
     * 
     * 
     * 
     * @param index
     * @return XMLCurves
     */
    public io.castor.XMLCurves removeXMLCurves(int index)
    {
        java.lang.Object obj = _XMLCurvesList.elementAt(index);
        _XMLCurvesList.removeElementAt(index);
        return (io.castor.XMLCurves) obj;
    } //-- io.castor.XMLCurves removeXMLCurves(int) 

    /**
     * Method removeXMLEquilibria
     * 
     * 
     * 
     * @param index
     * @return XMLEquilibria
     */
    public io.castor.XMLEquilibria removeXMLEquilibria(int index)
    {
        java.lang.Object obj = _XMLEquilibriaList.elementAt(index);
        _XMLEquilibriaList.removeElementAt(index);
        return (io.castor.XMLEquilibria) obj;
    } //-- io.castor.XMLEquilibria removeXMLEquilibria(int) 

    /**
     * Sets the value of field 'curveNumber'.
     * 
     * @param curveNumber the value of field 'curveNumber'.
     */
    public void setCurveNumber(int curveNumber)
    {
        this._curveNumber = curveNumber;
        this._has_curveNumber = true;
    } //-- void setCurveNumber(int) 

    /**
     * Sets the value of field 'definition'.
     * 
     * @param definition the value of field 'definition'.
     */
    public void setDefinition(java.lang.String definition)
    {
        this._definition = definition;
    } //-- void setDefinition(java.lang.String) 

    /**
     * Sets the value of field 'equilibriumNumber'.
     * 
     * @param equilibriumNumber the value of field
     * 'equilibriumNumber'.
     */
    public void setEquilibriumNumber(int equilibriumNumber)
    {
        this._equilibriumNumber = equilibriumNumber;
        this._has_equilibriumNumber = true;
    } //-- void setEquilibriumNumber(int) 

    /**
     * Sets the value of field 'name'.
     * 
     * @param name the value of field 'name'.
     */
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String) 

    /**
     * Method setXMLCurves
     * 
     * 
     * 
     * @param index
     * @param vXMLCurves
     */
    public void setXMLCurves(int index, io.castor.XMLCurves vXMLCurves)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLCurvesList.size())) {
            throw new IndexOutOfBoundsException("setXMLCurves: Index value '"+index+"' not in range [0.." + (_XMLCurvesList.size() - 1) + "]");
        }
        _XMLCurvesList.setElementAt(vXMLCurves, index);
    } //-- void setXMLCurves(int, io.castor.XMLCurves) 

    /**
     * Method setXMLCurves
     * 
     * 
     * 
     * @param XMLCurvesArray
     */
    public void setXMLCurves(io.castor.XMLCurves[] XMLCurvesArray)
    {
        //-- copy array
        _XMLCurvesList.removeAllElements();
        for (int i = 0; i < XMLCurvesArray.length; i++) {
            _XMLCurvesList.addElement(XMLCurvesArray[i]);
        }
    } //-- void setXMLCurves(io.castor.XMLCurves) 

    /**
     * Method setXMLEquilibria
     * 
     * 
     * 
     * @param index
     * @param vXMLEquilibria
     */
    public void setXMLEquilibria(int index, io.castor.XMLEquilibria vXMLEquilibria)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLEquilibriaList.size())) {
            throw new IndexOutOfBoundsException("setXMLEquilibria: Index value '"+index+"' not in range [0.." + (_XMLEquilibriaList.size() - 1) + "]");
        }
        _XMLEquilibriaList.setElementAt(vXMLEquilibria, index);
    } //-- void setXMLEquilibria(int, io.castor.XMLEquilibria) 

    /**
     * Method setXMLEquilibria
     * 
     * 
     * 
     * @param XMLEquilibriaArray
     */
    public void setXMLEquilibria(io.castor.XMLEquilibria[] XMLEquilibriaArray)
    {
        //-- copy array
        _XMLEquilibriaList.removeAllElements();
        for (int i = 0; i < XMLEquilibriaArray.length; i++) {
            _XMLEquilibriaList.addElement(XMLEquilibriaArray[i]);
        }
    } //-- void setXMLEquilibria(io.castor.XMLEquilibria) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return OdeType
     */
    public static io.castor.OdeType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.OdeType) Unmarshaller.unmarshal(io.castor.OdeType.class, reader);
    } //-- io.castor.OdeType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
