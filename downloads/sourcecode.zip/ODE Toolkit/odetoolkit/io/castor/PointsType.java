/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Vector;

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class PointsType.
 * 
 * @version $Revision$ $Date$
 */
public class PointsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _XMLPointList
     */
    private java.util.Vector _XMLPointList;


      //----------------/
     //- Constructors -/
    //----------------/

    public PointsType() 
     {
        super();
        _XMLPointList = new Vector();
    } //-- io.castor.PointsType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addXMLPoint
     * 
     * 
     * 
     * @param vXMLPoint
     */
    public void addXMLPoint(io.castor.XMLPoint vXMLPoint)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLPointList.addElement(vXMLPoint);
    } //-- void addXMLPoint(io.castor.XMLPoint) 

    /**
     * Method addXMLPoint
     * 
     * 
     * 
     * @param index
     * @param vXMLPoint
     */
    public void addXMLPoint(int index, io.castor.XMLPoint vXMLPoint)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLPointList.insertElementAt(vXMLPoint, index);
    } //-- void addXMLPoint(int, io.castor.XMLPoint) 

    /**
     * Method enumerateXMLPoint
     * 
     * 
     * 
     * @return Enumeration
     */
    public java.util.Enumeration enumerateXMLPoint()
    {
        return _XMLPointList.elements();
    } //-- java.util.Enumeration enumerateXMLPoint() 

    /**
     * Method getXMLPoint
     * 
     * 
     * 
     * @param index
     * @return XMLPoint
     */
    public io.castor.XMLPoint getXMLPoint(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLPointList.size())) {
            throw new IndexOutOfBoundsException("getXMLPoint: Index value '"+index+"' not in range [0.."+(_XMLPointList.size() - 1) + "]");
        }
        
        return (io.castor.XMLPoint) _XMLPointList.elementAt(index);
    } //-- io.castor.XMLPoint getXMLPoint(int) 

    /**
     * Method getXMLPoint
     * 
     * 
     * 
     * @return XMLPoint
     */
    public io.castor.XMLPoint[] getXMLPoint()
    {
        int size = _XMLPointList.size();
        io.castor.XMLPoint[] mArray = new io.castor.XMLPoint[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (io.castor.XMLPoint) _XMLPointList.elementAt(index);
        }
        return mArray;
    } //-- io.castor.XMLPoint[] getXMLPoint() 

    /**
     * Method getXMLPointCount
     * 
     * 
     * 
     * @return int
     */
    public int getXMLPointCount()
    {
        return _XMLPointList.size();
    } //-- int getXMLPointCount() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAllXMLPoint
     * 
     */
    public void removeAllXMLPoint()
    {
        _XMLPointList.removeAllElements();
    } //-- void removeAllXMLPoint() 

    /**
     * Method removeXMLPoint
     * 
     * 
     * 
     * @param index
     * @return XMLPoint
     */
    public io.castor.XMLPoint removeXMLPoint(int index)
    {
        java.lang.Object obj = _XMLPointList.elementAt(index);
        _XMLPointList.removeElementAt(index);
        return (io.castor.XMLPoint) obj;
    } //-- io.castor.XMLPoint removeXMLPoint(int) 

    /**
     * Method setXMLPoint
     * 
     * 
     * 
     * @param index
     * @param vXMLPoint
     */
    public void setXMLPoint(int index, io.castor.XMLPoint vXMLPoint)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLPointList.size())) {
            throw new IndexOutOfBoundsException("setXMLPoint: Index value '"+index+"' not in range [0.." + (_XMLPointList.size() - 1) + "]");
        }
        _XMLPointList.setElementAt(vXMLPoint, index);
    } //-- void setXMLPoint(int, io.castor.XMLPoint) 

    /**
     * Method setXMLPoint
     * 
     * 
     * 
     * @param XMLPointArray
     */
    public void setXMLPoint(io.castor.XMLPoint[] XMLPointArray)
    {
        //-- copy array
        _XMLPointList.removeAllElements();
        for (int i = 0; i < XMLPointArray.length; i++) {
            _XMLPointList.addElement(XMLPointArray[i]);
        }
    } //-- void setXMLPoint(io.castor.XMLPoint) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return PointsType
     */
    public static io.castor.PointsType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.PointsType) Unmarshaller.unmarshal(io.castor.PointsType.class, reader);
    } //-- io.castor.PointsType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
