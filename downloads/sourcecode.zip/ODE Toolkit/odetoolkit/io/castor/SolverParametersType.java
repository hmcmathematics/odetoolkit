/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class SolverParametersType.
 * 
 * @version $Revision$ $Date$
 */
public class SolverParametersType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _solver
     */
    private java.lang.String _solver;

    /**
     * Field _absTol
     */
    private double _absTol;

    /**
     * keeps track of state for field: _absTol
     */
    private boolean _has_absTol;

    /**
     * Field _relTol
     */
    private double _relTol;

    /**
     * keeps track of state for field: _relTol
     */
    private boolean _has_relTol;

    /**
     * Field _minStepSize
     */
    private double _minStepSize;

    /**
     * keeps track of state for field: _minStepSize
     */
    private boolean _has_minStepSize;

    /**
     * Field _maxStepSize
     */
    private double _maxStepSize;

    /**
     * keeps track of state for field: _maxStepSize
     */
    private boolean _has_maxStepSize;

    /**
     * Field _pointsPerTime
     */
    private double _pointsPerTime;

    /**
     * keeps track of state for field: _pointsPerTime
     */
    private boolean _has_pointsPerTime;

    /**
     * Field _solveForward
     */
    private boolean _solveForward;

    /**
     * keeps track of state for field: _solveForward
     */
    private boolean _has_solveForward;

    /**
     * Field _multiStepMethod
     */
    private int _multiStepMethod;

    /**
     * keeps track of state for field: _multiStepMethod
     */
    private boolean _has_multiStepMethod;

    /**
     * Field _maxSteps
     */
    private int _maxSteps;

    /**
     * keeps track of state for field: _maxSteps
     */
    private boolean _has_maxSteps;

    /**
     * Field _solveSpan
     */
    private double _solveSpan;

    /**
     * keeps track of state for field: _solveSpan
     */
    private boolean _has_solveSpan;

    /**
     * Field _XMLVarList
     */
    private io.castor.XMLVarList _XMLVarList;

    /**
     * Field _XMLPoint
     */
    private io.castor.XMLPoint _XMLPoint;


      //----------------/
     //- Constructors -/
    //----------------/

    public SolverParametersType() 
     {
        super();
    } //-- io.castor.SolverParametersType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteAbsTol
     * 
     */
    public void deleteAbsTol()
    {
        this._has_absTol= false;
    } //-- void deleteAbsTol() 

    /**
     * Method deleteMaxStepSize
     * 
     */
    public void deleteMaxStepSize()
    {
        this._has_maxStepSize= false;
    } //-- void deleteMaxStepSize() 

    /**
     * Method deleteMaxSteps
     * 
     */
    public void deleteMaxSteps()
    {
        this._has_maxSteps= false;
    } //-- void deleteMaxSteps() 

    /**
     * Method deleteMinStepSize
     * 
     */
    public void deleteMinStepSize()
    {
        this._has_minStepSize= false;
    } //-- void deleteMinStepSize() 

    /**
     * Method deleteMultiStepMethod
     * 
     */
    public void deleteMultiStepMethod()
    {
        this._has_multiStepMethod= false;
    } //-- void deleteMultiStepMethod() 

    /**
     * Method deletePointsPerTime
     * 
     */
    public void deletePointsPerTime()
    {
        this._has_pointsPerTime= false;
    } //-- void deletePointsPerTime() 

    /**
     * Method deleteRelTol
     * 
     */
    public void deleteRelTol()
    {
        this._has_relTol= false;
    } //-- void deleteRelTol() 

    /**
     * Method deleteSolveForward
     * 
     */
    public void deleteSolveForward()
    {
        this._has_solveForward= false;
    } //-- void deleteSolveForward() 

    /**
     * Method deleteSolveSpan
     * 
     */
    public void deleteSolveSpan()
    {
        this._has_solveSpan= false;
    } //-- void deleteSolveSpan() 

    /**
     * Returns the value of field 'absTol'.
     * 
     * @return double
     * @return the value of field 'absTol'.
     */
    public double getAbsTol()
    {
        return this._absTol;
    } //-- double getAbsTol() 

    /**
     * Returns the value of field 'maxStepSize'.
     * 
     * @return double
     * @return the value of field 'maxStepSize'.
     */
    public double getMaxStepSize()
    {
        return this._maxStepSize;
    } //-- double getMaxStepSize() 

    /**
     * Returns the value of field 'maxSteps'.
     * 
     * @return int
     * @return the value of field 'maxSteps'.
     */
    public int getMaxSteps()
    {
        return this._maxSteps;
    } //-- int getMaxSteps() 

    /**
     * Returns the value of field 'minStepSize'.
     * 
     * @return double
     * @return the value of field 'minStepSize'.
     */
    public double getMinStepSize()
    {
        return this._minStepSize;
    } //-- double getMinStepSize() 

    /**
     * Returns the value of field 'multiStepMethod'.
     * 
     * @return int
     * @return the value of field 'multiStepMethod'.
     */
    public int getMultiStepMethod()
    {
        return this._multiStepMethod;
    } //-- int getMultiStepMethod() 

    /**
     * Returns the value of field 'pointsPerTime'.
     * 
     * @return double
     * @return the value of field 'pointsPerTime'.
     */
    public double getPointsPerTime()
    {
        return this._pointsPerTime;
    } //-- double getPointsPerTime() 

    /**
     * Returns the value of field 'relTol'.
     * 
     * @return double
     * @return the value of field 'relTol'.
     */
    public double getRelTol()
    {
        return this._relTol;
    } //-- double getRelTol() 

    /**
     * Returns the value of field 'solveForward'.
     * 
     * @return boolean
     * @return the value of field 'solveForward'.
     */
    public boolean getSolveForward()
    {
        return this._solveForward;
    } //-- boolean getSolveForward() 

    /**
     * Returns the value of field 'solveSpan'.
     * 
     * @return double
     * @return the value of field 'solveSpan'.
     */
    public double getSolveSpan()
    {
        return this._solveSpan;
    } //-- double getSolveSpan() 

    /**
     * Returns the value of field 'solver'.
     * 
     * @return String
     * @return the value of field 'solver'.
     */
    public java.lang.String getSolver()
    {
        return this._solver;
    } //-- java.lang.String getSolver() 

    /**
     * Returns the value of field 'XMLPoint'.
     * 
     * @return XMLPoint
     * @return the value of field 'XMLPoint'.
     */
    public io.castor.XMLPoint getXMLPoint()
    {
        return this._XMLPoint;
    } //-- io.castor.XMLPoint getXMLPoint() 

    /**
     * Returns the value of field 'XMLVarList'.
     * 
     * @return XMLVarList
     * @return the value of field 'XMLVarList'.
     */
    public io.castor.XMLVarList getXMLVarList()
    {
        return this._XMLVarList;
    } //-- io.castor.XMLVarList getXMLVarList() 

    /**
     * Method hasAbsTol
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasAbsTol()
    {
        return this._has_absTol;
    } //-- boolean hasAbsTol() 

    /**
     * Method hasMaxStepSize
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasMaxStepSize()
    {
        return this._has_maxStepSize;
    } //-- boolean hasMaxStepSize() 

    /**
     * Method hasMaxSteps
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasMaxSteps()
    {
        return this._has_maxSteps;
    } //-- boolean hasMaxSteps() 

    /**
     * Method hasMinStepSize
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasMinStepSize()
    {
        return this._has_minStepSize;
    } //-- boolean hasMinStepSize() 

    /**
     * Method hasMultiStepMethod
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasMultiStepMethod()
    {
        return this._has_multiStepMethod;
    } //-- boolean hasMultiStepMethod() 

    /**
     * Method hasPointsPerTime
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasPointsPerTime()
    {
        return this._has_pointsPerTime;
    } //-- boolean hasPointsPerTime() 

    /**
     * Method hasRelTol
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasRelTol()
    {
        return this._has_relTol;
    } //-- boolean hasRelTol() 

    /**
     * Method hasSolveForward
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasSolveForward()
    {
        return this._has_solveForward;
    } //-- boolean hasSolveForward() 

    /**
     * Method hasSolveSpan
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasSolveSpan()
    {
        return this._has_solveSpan;
    } //-- boolean hasSolveSpan() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'absTol'.
     * 
     * @param absTol the value of field 'absTol'.
     */
    public void setAbsTol(double absTol)
    {
        this._absTol = absTol;
        this._has_absTol = true;
    } //-- void setAbsTol(double) 

    /**
     * Sets the value of field 'maxStepSize'.
     * 
     * @param maxStepSize the value of field 'maxStepSize'.
     */
    public void setMaxStepSize(double maxStepSize)
    {
        this._maxStepSize = maxStepSize;
        this._has_maxStepSize = true;
    } //-- void setMaxStepSize(double) 

    /**
     * Sets the value of field 'maxSteps'.
     * 
     * @param maxSteps the value of field 'maxSteps'.
     */
    public void setMaxSteps(int maxSteps)
    {
        this._maxSteps = maxSteps;
        this._has_maxSteps = true;
    } //-- void setMaxSteps(int) 

    /**
     * Sets the value of field 'minStepSize'.
     * 
     * @param minStepSize the value of field 'minStepSize'.
     */
    public void setMinStepSize(double minStepSize)
    {
        this._minStepSize = minStepSize;
        this._has_minStepSize = true;
    } //-- void setMinStepSize(double) 

    /**
     * Sets the value of field 'multiStepMethod'.
     * 
     * @param multiStepMethod the value of field 'multiStepMethod'.
     */
    public void setMultiStepMethod(int multiStepMethod)
    {
        this._multiStepMethod = multiStepMethod;
        this._has_multiStepMethod = true;
    } //-- void setMultiStepMethod(int) 

    /**
     * Sets the value of field 'pointsPerTime'.
     * 
     * @param pointsPerTime the value of field 'pointsPerTime'.
     */
    public void setPointsPerTime(double pointsPerTime)
    {
        this._pointsPerTime = pointsPerTime;
        this._has_pointsPerTime = true;
    } //-- void setPointsPerTime(double) 

    /**
     * Sets the value of field 'relTol'.
     * 
     * @param relTol the value of field 'relTol'.
     */
    public void setRelTol(double relTol)
    {
        this._relTol = relTol;
        this._has_relTol = true;
    } //-- void setRelTol(double) 

    /**
     * Sets the value of field 'solveForward'.
     * 
     * @param solveForward the value of field 'solveForward'.
     */
    public void setSolveForward(boolean solveForward)
    {
        this._solveForward = solveForward;
        this._has_solveForward = true;
    } //-- void setSolveForward(boolean) 

    /**
     * Sets the value of field 'solveSpan'.
     * 
     * @param solveSpan the value of field 'solveSpan'.
     */
    public void setSolveSpan(double solveSpan)
    {
        this._solveSpan = solveSpan;
        this._has_solveSpan = true;
    } //-- void setSolveSpan(double) 

    /**
     * Sets the value of field 'solver'.
     * 
     * @param solver the value of field 'solver'.
     */
    public void setSolver(java.lang.String solver)
    {
        this._solver = solver;
    } //-- void setSolver(java.lang.String) 

    /**
     * Sets the value of field 'XMLPoint'.
     * 
     * @param XMLPoint the value of field 'XMLPoint'.
     */
    public void setXMLPoint(io.castor.XMLPoint XMLPoint)
    {
        this._XMLPoint = XMLPoint;
    } //-- void setXMLPoint(io.castor.XMLPoint) 

    /**
     * Sets the value of field 'XMLVarList'.
     * 
     * @param XMLVarList the value of field 'XMLVarList'.
     */
    public void setXMLVarList(io.castor.XMLVarList XMLVarList)
    {
        this._XMLVarList = XMLVarList;
    } //-- void setXMLVarList(io.castor.XMLVarList) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return SolverParametersType
     */
    public static io.castor.SolverParametersType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.SolverParametersType) Unmarshaller.unmarshal(io.castor.SolverParametersType.class, reader);
    } //-- io.castor.SolverParametersType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
