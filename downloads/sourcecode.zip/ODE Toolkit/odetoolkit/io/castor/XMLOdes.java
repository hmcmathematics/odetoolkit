/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Vector;

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class XMLOdes.
 * 
 * @version $Revision$ $Date$
 */
public class XMLOdes implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _XMLOdeList
     */
    private java.util.Vector _XMLOdeList;


      //----------------/
     //- Constructors -/
    //----------------/

    public XMLOdes() 
     {
        super();
        _XMLOdeList = new Vector();
    } //-- io.castor.XMLOdes()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addXMLOde
     * 
     * 
     * 
     * @param vXMLOde
     */
    public void addXMLOde(io.castor.XMLOde vXMLOde)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLOdeList.addElement(vXMLOde);
    } //-- void addXMLOde(io.castor.XMLOde) 

    /**
     * Method addXMLOde
     * 
     * 
     * 
     * @param index
     * @param vXMLOde
     */
    public void addXMLOde(int index, io.castor.XMLOde vXMLOde)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLOdeList.insertElementAt(vXMLOde, index);
    } //-- void addXMLOde(int, io.castor.XMLOde) 

    /**
     * Method enumerateXMLOde
     * 
     * 
     * 
     * @return Enumeration
     */
    public java.util.Enumeration enumerateXMLOde()
    {
        return _XMLOdeList.elements();
    } //-- java.util.Enumeration enumerateXMLOde() 

    /**
     * Method getXMLOde
     * 
     * 
     * 
     * @param index
     * @return XMLOde
     */
    public io.castor.XMLOde getXMLOde(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLOdeList.size())) {
            throw new IndexOutOfBoundsException("getXMLOde: Index value '"+index+"' not in range [0.."+(_XMLOdeList.size() - 1) + "]");
        }
        
        return (io.castor.XMLOde) _XMLOdeList.elementAt(index);
    } //-- io.castor.XMLOde getXMLOde(int) 

    /**
     * Method getXMLOde
     * 
     * 
     * 
     * @return XMLOde
     */
    public io.castor.XMLOde[] getXMLOde()
    {
        int size = _XMLOdeList.size();
        io.castor.XMLOde[] mArray = new io.castor.XMLOde[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (io.castor.XMLOde) _XMLOdeList.elementAt(index);
        }
        return mArray;
    } //-- io.castor.XMLOde[] getXMLOde() 

    /**
     * Method getXMLOdeCount
     * 
     * 
     * 
     * @return int
     */
    public int getXMLOdeCount()
    {
        return _XMLOdeList.size();
    } //-- int getXMLOdeCount() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAllXMLOde
     * 
     */
    public void removeAllXMLOde()
    {
        _XMLOdeList.removeAllElements();
    } //-- void removeAllXMLOde() 

    /**
     * Method removeXMLOde
     * 
     * 
     * 
     * @param index
     * @return XMLOde
     */
    public io.castor.XMLOde removeXMLOde(int index)
    {
        java.lang.Object obj = _XMLOdeList.elementAt(index);
        _XMLOdeList.removeElementAt(index);
        return (io.castor.XMLOde) obj;
    } //-- io.castor.XMLOde removeXMLOde(int) 

    /**
     * Method setXMLOde
     * 
     * 
     * 
     * @param index
     * @param vXMLOde
     */
    public void setXMLOde(int index, io.castor.XMLOde vXMLOde)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLOdeList.size())) {
            throw new IndexOutOfBoundsException("setXMLOde: Index value '"+index+"' not in range [0.." + (_XMLOdeList.size() - 1) + "]");
        }
        _XMLOdeList.setElementAt(vXMLOde, index);
    } //-- void setXMLOde(int, io.castor.XMLOde) 

    /**
     * Method setXMLOde
     * 
     * 
     * 
     * @param XMLOdeArray
     */
    public void setXMLOde(io.castor.XMLOde[] XMLOdeArray)
    {
        //-- copy array
        _XMLOdeList.removeAllElements();
        for (int i = 0; i < XMLOdeArray.length; i++) {
            _XMLOdeList.addElement(XMLOdeArray[i]);
        }
    } //-- void setXMLOde(io.castor.XMLOde) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return XMLOdes
     */
    public static io.castor.XMLOdes unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.XMLOdes) Unmarshaller.unmarshal(io.castor.XMLOdes.class, reader);
    } //-- io.castor.XMLOdes unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
