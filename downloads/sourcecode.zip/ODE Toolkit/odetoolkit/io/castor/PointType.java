/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Vector;

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class PointType.
 * 
 * @version $Revision$ $Date$
 */
public class PointType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _varCoordinateList
     */
    private java.util.Vector _varCoordinateList;


      //----------------/
     //- Constructors -/
    //----------------/

    public PointType() 
     {
        super();
        _varCoordinateList = new Vector();
    } //-- io.castor.PointType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addVarCoordinate
     * 
     * 
     * 
     * @param vVarCoordinate
     */
    public void addVarCoordinate(double vVarCoordinate)
        throws java.lang.IndexOutOfBoundsException
    {
        _varCoordinateList.addElement(new java.lang.Double(vVarCoordinate));
    } //-- void addVarCoordinate(double) 

    /**
     * Method addVarCoordinate
     * 
     * 
     * 
     * @param index
     * @param vVarCoordinate
     */
    public void addVarCoordinate(int index, double vVarCoordinate)
        throws java.lang.IndexOutOfBoundsException
    {
        _varCoordinateList.insertElementAt(new java.lang.Double(vVarCoordinate), index);
    } //-- void addVarCoordinate(int, double) 

    /**
     * Method enumerateVarCoordinate
     * 
     * 
     * 
     * @return Enumeration
     */
    public java.util.Enumeration enumerateVarCoordinate()
    {
        return _varCoordinateList.elements();
    } //-- java.util.Enumeration enumerateVarCoordinate() 

    /**
     * Method getVarCoordinate
     * 
     * 
     * 
     * @param index
     * @return double
     */
    public double getVarCoordinate(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _varCoordinateList.size())) {
            throw new IndexOutOfBoundsException("getVarCoordinate: Index value '"+index+"' not in range [0.."+(_varCoordinateList.size() - 1) + "]");
        }
        
        return ((java.lang.Double)_varCoordinateList.elementAt(index)).doubleValue();
    } //-- double getVarCoordinate(int) 

    /**
     * Method getVarCoordinate
     * 
     * 
     * 
     * @return double
     */
    public double[] getVarCoordinate()
    {
        int size = _varCoordinateList.size();
        double[] mArray = new double[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = ((java.lang.Double)_varCoordinateList.elementAt(index)).doubleValue();
        }
        return mArray;
    } //-- double[] getVarCoordinate() 

    /**
     * Method getVarCoordinateCount
     * 
     * 
     * 
     * @return int
     */
    public int getVarCoordinateCount()
    {
        return _varCoordinateList.size();
    } //-- int getVarCoordinateCount() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAllVarCoordinate
     * 
     */
    public void removeAllVarCoordinate()
    {
        _varCoordinateList.removeAllElements();
    } //-- void removeAllVarCoordinate() 

    /**
     * Method removeVarCoordinate
     * 
     * 
     * 
     * @param index
     * @return double
     */
    public double removeVarCoordinate(int index)
    {
        java.lang.Object obj = _varCoordinateList.elementAt(index);
        _varCoordinateList.removeElementAt(index);
        return ((java.lang.Double)obj).doubleValue();
    } //-- double removeVarCoordinate(int) 

    /**
     * Method setVarCoordinate
     * 
     * 
     * 
     * @param index
     * @param vVarCoordinate
     */
    public void setVarCoordinate(int index, double vVarCoordinate)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _varCoordinateList.size())) {
            throw new IndexOutOfBoundsException("setVarCoordinate: Index value '"+index+"' not in range [0.." + (_varCoordinateList.size() - 1) + "]");
        }
        _varCoordinateList.setElementAt(new java.lang.Double(vVarCoordinate), index);
    } //-- void setVarCoordinate(int, double) 

    /**
     * Method setVarCoordinate
     * 
     * 
     * 
     * @param varCoordinateArray
     */
    public void setVarCoordinate(double[] varCoordinateArray)
    {
        //-- copy array
        _varCoordinateList.removeAllElements();
        for (int i = 0; i < varCoordinateArray.length; i++) {
            _varCoordinateList.addElement(new java.lang.Double(varCoordinateArray[i]));
        }
    } //-- void setVarCoordinate(double) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return PointType
     */
    public static io.castor.PointType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.PointType) Unmarshaller.unmarshal(io.castor.PointType.class, reader);
    } //-- io.castor.PointType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
