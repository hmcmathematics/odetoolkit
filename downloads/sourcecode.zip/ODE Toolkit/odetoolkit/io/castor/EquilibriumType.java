/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class EquilibriumType.
 * 
 * @version $Revision$ $Date$
 */
public class EquilibriumType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _name
     */
    private java.lang.String _name;

    /**
     * Field _XMLVarList
     */
    private io.castor.XMLVarList _XMLVarList;

    /**
     * Field _XMLPoint
     */
    private io.castor.XMLPoint _XMLPoint;

    /**
     * Field _XMLVisualProperties
     */
    private io.castor.XMLVisualProperties _XMLVisualProperties;


      //----------------/
     //- Constructors -/
    //----------------/

    public EquilibriumType() 
     {
        super();
    } //-- io.castor.EquilibriumType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'name'.
     * 
     * @return String
     * @return the value of field 'name'.
     */
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName() 

    /**
     * Returns the value of field 'XMLPoint'.
     * 
     * @return XMLPoint
     * @return the value of field 'XMLPoint'.
     */
    public io.castor.XMLPoint getXMLPoint()
    {
        return this._XMLPoint;
    } //-- io.castor.XMLPoint getXMLPoint() 

    /**
     * Returns the value of field 'XMLVarList'.
     * 
     * @return XMLVarList
     * @return the value of field 'XMLVarList'.
     */
    public io.castor.XMLVarList getXMLVarList()
    {
        return this._XMLVarList;
    } //-- io.castor.XMLVarList getXMLVarList() 

    /**
     * Returns the value of field 'XMLVisualProperties'.
     * 
     * @return XMLVisualProperties
     * @return the value of field 'XMLVisualProperties'.
     */
    public io.castor.XMLVisualProperties getXMLVisualProperties()
    {
        return this._XMLVisualProperties;
    } //-- io.castor.XMLVisualProperties getXMLVisualProperties() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'name'.
     * 
     * @param name the value of field 'name'.
     */
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String) 

    /**
     * Sets the value of field 'XMLPoint'.
     * 
     * @param XMLPoint the value of field 'XMLPoint'.
     */
    public void setXMLPoint(io.castor.XMLPoint XMLPoint)
    {
        this._XMLPoint = XMLPoint;
    } //-- void setXMLPoint(io.castor.XMLPoint) 

    /**
     * Sets the value of field 'XMLVarList'.
     * 
     * @param XMLVarList the value of field 'XMLVarList'.
     */
    public void setXMLVarList(io.castor.XMLVarList XMLVarList)
    {
        this._XMLVarList = XMLVarList;
    } //-- void setXMLVarList(io.castor.XMLVarList) 

    /**
     * Sets the value of field 'XMLVisualProperties'.
     * 
     * @param XMLVisualProperties the value of field
     * 'XMLVisualProperties'.
     */
    public void setXMLVisualProperties(io.castor.XMLVisualProperties XMLVisualProperties)
    {
        this._XMLVisualProperties = XMLVisualProperties;
    } //-- void setXMLVisualProperties(io.castor.XMLVisualProperties) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return EquilibriumType
     */
    public static io.castor.EquilibriumType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.EquilibriumType) Unmarshaller.unmarshal(io.castor.EquilibriumType.class, reader);
    } //-- io.castor.EquilibriumType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
