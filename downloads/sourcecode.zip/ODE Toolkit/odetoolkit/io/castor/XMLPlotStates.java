/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Vector;

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class XMLPlotStates.
 * 
 * @version $Revision$ $Date$
 */
public class XMLPlotStates implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _currentPanelIndex
     */
    private int _currentPanelIndex;

    /**
     * keeps track of state for field: _currentPanelIndex
     */
    private boolean _has_currentPanelIndex;

    /**
     * Field _XMLPlotStateList
     */
    private java.util.Vector _XMLPlotStateList;


      //----------------/
     //- Constructors -/
    //----------------/

    public XMLPlotStates() 
     {
        super();
        _XMLPlotStateList = new Vector();
    } //-- io.castor.XMLPlotStates()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addXMLPlotState
     * 
     * 
     * 
     * @param vXMLPlotState
     */
    public void addXMLPlotState(io.castor.XMLPlotState vXMLPlotState)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLPlotStateList.addElement(vXMLPlotState);
    } //-- void addXMLPlotState(io.castor.XMLPlotState) 

    /**
     * Method addXMLPlotState
     * 
     * 
     * 
     * @param index
     * @param vXMLPlotState
     */
    public void addXMLPlotState(int index, io.castor.XMLPlotState vXMLPlotState)
        throws java.lang.IndexOutOfBoundsException
    {
        _XMLPlotStateList.insertElementAt(vXMLPlotState, index);
    } //-- void addXMLPlotState(int, io.castor.XMLPlotState) 

    /**
     * Method deleteCurrentPanelIndex
     * 
     */
    public void deleteCurrentPanelIndex()
    {
        this._has_currentPanelIndex= false;
    } //-- void deleteCurrentPanelIndex() 

    /**
     * Method enumerateXMLPlotState
     * 
     * 
     * 
     * @return Enumeration
     */
    public java.util.Enumeration enumerateXMLPlotState()
    {
        return _XMLPlotStateList.elements();
    } //-- java.util.Enumeration enumerateXMLPlotState() 

    /**
     * Returns the value of field 'currentPanelIndex'.
     * 
     * @return int
     * @return the value of field 'currentPanelIndex'.
     */
    public int getCurrentPanelIndex()
    {
        return this._currentPanelIndex;
    } //-- int getCurrentPanelIndex() 

    /**
     * Method getXMLPlotState
     * 
     * 
     * 
     * @param index
     * @return XMLPlotState
     */
    public io.castor.XMLPlotState getXMLPlotState(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLPlotStateList.size())) {
            throw new IndexOutOfBoundsException("getXMLPlotState: Index value '"+index+"' not in range [0.."+(_XMLPlotStateList.size() - 1) + "]");
        }
        
        return (io.castor.XMLPlotState) _XMLPlotStateList.elementAt(index);
    } //-- io.castor.XMLPlotState getXMLPlotState(int) 

    /**
     * Method getXMLPlotState
     * 
     * 
     * 
     * @return XMLPlotState
     */
    public io.castor.XMLPlotState[] getXMLPlotState()
    {
        int size = _XMLPlotStateList.size();
        io.castor.XMLPlotState[] mArray = new io.castor.XMLPlotState[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (io.castor.XMLPlotState) _XMLPlotStateList.elementAt(index);
        }
        return mArray;
    } //-- io.castor.XMLPlotState[] getXMLPlotState() 

    /**
     * Method getXMLPlotStateCount
     * 
     * 
     * 
     * @return int
     */
    public int getXMLPlotStateCount()
    {
        return _XMLPlotStateList.size();
    } //-- int getXMLPlotStateCount() 

    /**
     * Method hasCurrentPanelIndex
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasCurrentPanelIndex()
    {
        return this._has_currentPanelIndex;
    } //-- boolean hasCurrentPanelIndex() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAllXMLPlotState
     * 
     */
    public void removeAllXMLPlotState()
    {
        _XMLPlotStateList.removeAllElements();
    } //-- void removeAllXMLPlotState() 

    /**
     * Method removeXMLPlotState
     * 
     * 
     * 
     * @param index
     * @return XMLPlotState
     */
    public io.castor.XMLPlotState removeXMLPlotState(int index)
    {
        java.lang.Object obj = _XMLPlotStateList.elementAt(index);
        _XMLPlotStateList.removeElementAt(index);
        return (io.castor.XMLPlotState) obj;
    } //-- io.castor.XMLPlotState removeXMLPlotState(int) 

    /**
     * Sets the value of field 'currentPanelIndex'.
     * 
     * @param currentPanelIndex the value of field
     * 'currentPanelIndex'.
     */
    public void setCurrentPanelIndex(int currentPanelIndex)
    {
        this._currentPanelIndex = currentPanelIndex;
        this._has_currentPanelIndex = true;
    } //-- void setCurrentPanelIndex(int) 

    /**
     * Method setXMLPlotState
     * 
     * 
     * 
     * @param index
     * @param vXMLPlotState
     */
    public void setXMLPlotState(int index, io.castor.XMLPlotState vXMLPlotState)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index >= _XMLPlotStateList.size())) {
            throw new IndexOutOfBoundsException("setXMLPlotState: Index value '"+index+"' not in range [0.." + (_XMLPlotStateList.size() - 1) + "]");
        }
        _XMLPlotStateList.setElementAt(vXMLPlotState, index);
    } //-- void setXMLPlotState(int, io.castor.XMLPlotState) 

    /**
     * Method setXMLPlotState
     * 
     * 
     * 
     * @param XMLPlotStateArray
     */
    public void setXMLPlotState(io.castor.XMLPlotState[] XMLPlotStateArray)
    {
        //-- copy array
        _XMLPlotStateList.removeAllElements();
        for (int i = 0; i < XMLPlotStateArray.length; i++) {
            _XMLPlotStateList.addElement(XMLPlotStateArray[i]);
        }
    } //-- void setXMLPlotState(io.castor.XMLPlotState) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return XMLPlotStates
     */
    public static io.castor.XMLPlotStates unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.XMLPlotStates) Unmarshaller.unmarshal(io.castor.XMLPlotStates.class, reader);
    } //-- io.castor.XMLPlotStates unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
