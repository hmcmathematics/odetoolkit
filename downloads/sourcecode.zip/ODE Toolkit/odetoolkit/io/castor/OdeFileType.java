/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.1</a>, using an XML
 * Schema.
 * $Id$
 */

package io.castor;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class OdeFileType.
 * 
 * @version $Revision$ $Date$
 */
public class OdeFileType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _XMLInputPanel
     */
    private io.castor.XMLInputPanel _XMLInputPanel;

    /**
     * Field _XMLOdes
     */
    private io.castor.XMLOdes _XMLOdes;

    /**
     * Field _XMLPlotStates
     */
    private io.castor.XMLPlotStates _XMLPlotStates;

    /**
     * Field _XMLVarList
     */
    private io.castor.XMLVarList _XMLVarList;

    /**
     * Field _workspaceName
     */
    private java.lang.String _workspaceName;

    /**
     * Field _odeNumber
     */
    private int _odeNumber;

    /**
     * keeps track of state for field: _odeNumber
     */
    private boolean _has_odeNumber;


      //----------------/
     //- Constructors -/
    //----------------/

    public OdeFileType() 
     {
        super();
    } //-- io.castor.OdeFileType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteOdeNumber
     * 
     */
    public void deleteOdeNumber()
    {
        this._has_odeNumber= false;
    } //-- void deleteOdeNumber() 

    /**
     * Returns the value of field 'odeNumber'.
     * 
     * @return int
     * @return the value of field 'odeNumber'.
     */
    public int getOdeNumber()
    {
        return this._odeNumber;
    } //-- int getOdeNumber() 

    /**
     * Returns the value of field 'workspaceName'.
     * 
     * @return String
     * @return the value of field 'workspaceName'.
     */
    public java.lang.String getWorkspaceName()
    {
        return this._workspaceName;
    } //-- java.lang.String getWorkspaceName() 

    /**
     * Returns the value of field 'XMLInputPanel'.
     * 
     * @return XMLInputPanel
     * @return the value of field 'XMLInputPanel'.
     */
    public io.castor.XMLInputPanel getXMLInputPanel()
    {
        return this._XMLInputPanel;
    } //-- io.castor.XMLInputPanel getXMLInputPanel() 

    /**
     * Returns the value of field 'XMLOdes'.
     * 
     * @return XMLOdes
     * @return the value of field 'XMLOdes'.
     */
    public io.castor.XMLOdes getXMLOdes()
    {
        return this._XMLOdes;
    } //-- io.castor.XMLOdes getXMLOdes() 

    /**
     * Returns the value of field 'XMLPlotStates'.
     * 
     * @return XMLPlotStates
     * @return the value of field 'XMLPlotStates'.
     */
    public io.castor.XMLPlotStates getXMLPlotStates()
    {
        return this._XMLPlotStates;
    } //-- io.castor.XMLPlotStates getXMLPlotStates() 

    /**
     * Returns the value of field 'XMLVarList'.
     * 
     * @return XMLVarList
     * @return the value of field 'XMLVarList'.
     */
    public io.castor.XMLVarList getXMLVarList()
    {
        return this._XMLVarList;
    } //-- io.castor.XMLVarList getXMLVarList() 

    /**
     * Method hasOdeNumber
     * 
     * 
     * 
     * @return boolean
     */
    public boolean hasOdeNumber()
    {
        return this._has_odeNumber;
    } //-- boolean hasOdeNumber() 

    /**
     * Method isValid
     * 
     * 
     * 
     * @return boolean
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * 
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'odeNumber'.
     * 
     * @param odeNumber the value of field 'odeNumber'.
     */
    public void setOdeNumber(int odeNumber)
    {
        this._odeNumber = odeNumber;
        this._has_odeNumber = true;
    } //-- void setOdeNumber(int) 

    /**
     * Sets the value of field 'workspaceName'.
     * 
     * @param workspaceName the value of field 'workspaceName'.
     */
    public void setWorkspaceName(java.lang.String workspaceName)
    {
        this._workspaceName = workspaceName;
    } //-- void setWorkspaceName(java.lang.String) 

    /**
     * Sets the value of field 'XMLInputPanel'.
     * 
     * @param XMLInputPanel the value of field 'XMLInputPanel'.
     */
    public void setXMLInputPanel(io.castor.XMLInputPanel XMLInputPanel)
    {
        this._XMLInputPanel = XMLInputPanel;
    } //-- void setXMLInputPanel(io.castor.XMLInputPanel) 

    /**
     * Sets the value of field 'XMLOdes'.
     * 
     * @param XMLOdes the value of field 'XMLOdes'.
     */
    public void setXMLOdes(io.castor.XMLOdes XMLOdes)
    {
        this._XMLOdes = XMLOdes;
    } //-- void setXMLOdes(io.castor.XMLOdes) 

    /**
     * Sets the value of field 'XMLPlotStates'.
     * 
     * @param XMLPlotStates the value of field 'XMLPlotStates'.
     */
    public void setXMLPlotStates(io.castor.XMLPlotStates XMLPlotStates)
    {
        this._XMLPlotStates = XMLPlotStates;
    } //-- void setXMLPlotStates(io.castor.XMLPlotStates) 

    /**
     * Sets the value of field 'XMLVarList'.
     * 
     * @param XMLVarList the value of field 'XMLVarList'.
     */
    public void setXMLVarList(io.castor.XMLVarList XMLVarList)
    {
        this._XMLVarList = XMLVarList;
    } //-- void setXMLVarList(io.castor.XMLVarList) 

    /**
     * Method unmarshal
     * 
     * 
     * 
     * @param reader
     * @return OdeFileType
     */
    public static io.castor.OdeFileType unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (io.castor.OdeFileType) Unmarshaller.unmarshal(io.castor.OdeFileType.class, reader);
    } //-- io.castor.OdeFileType unmarshal(java.io.Reader) 

    /**
     * Method validate
     * 
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
