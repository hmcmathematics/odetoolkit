/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package io;

import java.net.URL;

import javax.swing.JOptionPane;

import ui.GUI;

/**
 * Handles any possible -urlpath arguments specified by a jnlp file. This class
 * is called by the Main program after initiating the GUI, in order to load any
 * .ode files through specified URL paths. The .ode file, if valid, is then
 * loaded upon starting ODE Toolkit.
 * 
 * @author Andres Perez 09, modified by Clinic 10-11
 */
public class AutoLaunch {
	/**
	 * Open the workspace specified by the URL
	 * 
	 * @param gui
	 *            GUI to load workspace in
	 * @param webPath
	 *            URL to the workspace file
	 * @throws InterruptedException
	 *             if loading URL unsuccessful
	 */
	public static void loadURL(GUI gui, URL webPath)
			throws InterruptedException {
		// Try to open the ODE at the specified URL
		try {
			gui.openWorkspace(webPath);
		} catch (NullPointerException e) {
			gui.showMessage("There was an error loading the .ode file at:\n"
					+ webPath.toString(), "Error", JOptionPane.ERROR_MESSAGE);
			System.out.println("Couldn't launch .ode file at specified URL");
		}

		// Remove blank workspace if opening was successful
		if (GUI.workspaces.getTabCount() > 1) {
			GUI.workspaces.remove(0);
			System.out.println("Auto-launch of URL successful.");
			System.out.println("Removing blank workspace...");
		}
	}
}
