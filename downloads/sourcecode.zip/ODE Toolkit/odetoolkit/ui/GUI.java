/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui;

import io.ODEFileHandler;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ui.outputpanels.ODEWorkspace;
import data.WorkspaceData;

/**
 * The GUI is the controlling frame for the toolkit application. It extends the
 * JFrame class and creates a tab pane for separate ODEWorkspaces, initialized
 * with a single new ODEWorkspace, and a menubar. It first launches a splash
 * bitmap displaying the logo for ODEToolkit. It determines what libraries have
 * loaded and displays the success/failure of their loading. It also specifies
 * methods for adding, removing, saving, and opening workspaces.
 * 
 * @author Clinic 08-09
 */
@SuppressWarnings("serial")
public class GUI extends JFrame {
	/** The tabbed pane, each pane represents a workspace */
	public static JTabbedPane workspaces;
	/** The ODEWorkspace corresponding to the selected workspace */
	public static ODEWorkspace activeWorkspace;
	/** The input panel on the left side of the screen */
	public static InputPanel inputPanel;
	/** The menu on the top of the screen */
	public static MenuBar menuBar;
	/** The status bar at the lower left corner of the screen */
	public static StatusBar statusBar;

	/** The path to the .jar file */
	String jarPath = GUI.class.getProtectionDomain().getCodeSource()
			.getLocation().getFile();

	/** The name to be shown at the top */
	public static final String ODETOOLKIT_VERSION = new String(
			"ODE Toolkit (1.4)");
	/** The name of the OS */
	public static final String osName = System.getProperty("os.name");

	/**
	 * Constructor for GUI, with initializations included
	 */
	public GUI() {
		super(ODETOOLKIT_VERSION);

		try {
			jarPath = java.net.URLDecoder.decode(jarPath, "ASCII");
		} catch (Exception e) {
			System.out
					.println("Could not get JAR path. Possibly not running from a JAR file.");
			jarPath = ".";
		}
		System.out.println("Running from: " + jarPath);
		System.out.println(osName.toLowerCase(Locale.US));

		// Mac OS X look and feel
		if (osName.startsWith("Mac OS")) {
			System.setProperty("apple.laf.useScreenMenuBar", "true");
			System.setProperty(
					"com.apple.mrj.application.apple.menu.about.name",
					"ODE Toolkit");
		}

		workspaces = new JTabbedPane();
		statusBar = new StatusBar();
		add(statusBar, BorderLayout.SOUTH);

		// Create a blank workspace
		addWorkspace();

		activeWorkspace = (ODEWorkspace) workspaces.getComponentAt(workspaces
				.getSelectedIndex());

		getContentPane().add(workspaces);
		menuBar = new MenuBar(this);
		MenuBar.updatePrintStatus(false);

		// this HAS to happen after a workspace is added so that the
		// appropriate menu items are available.
		setJMenuBar(menuBar);
		pack();

		// program loaded
		// splash.hideSplash();
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setVisible(true);

		activeWorkspace.focusODEText();

		setMinimumSize(new Dimension(800, 600));

		// Window Management--provides for closing the program based on user
		// input.
		WindowListener wndCloser = new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);

		// Tabbed Panel focus listener keeps track of the ODEWorkspace which
		// is currently active.
		ChangeListener tabChanger = new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (workspaces.getSelectedIndex() == -1)
					activeWorkspace = null;
				else {
					activeWorkspace = (ODEWorkspace) workspaces
							.getComponentAt(workspaces.getSelectedIndex());
					activeWorkspace.focusODEText();
					MenuBar.updatePrintStatus(activeWorkspace
							.getTabbedGraphPanel().canPrint());
				}
			}
		};
		workspaces.addChangeListener(tabChanger);
	}

	/**
	 * Add a new ODEWorkspace to the program
	 * 
	 * @param newWorkspace
	 *            the new ODEWorkspace to add
	 */
	public void addWorkspace(ODEWorkspace newWorkspace) {
		String title = "NewWorkspace" + workspaces.getTabCount();
		workspaces.addTab(title, newWorkspace);
		newWorkspace.setName(title);
	}

	/**
	 * Add a blank ODEWorkspace to the program - automatic naming
	 */
	public void addWorkspace() {
		String title = "NewWorkspace" + (workspaces.getTabCount() + 1);
		ODEWorkspace newWorkspace = new ODEWorkspace(this, title);
		workspaces.addTab(title, newWorkspace);
		workspaces.setSelectedIndex(workspaces.indexOfComponent(newWorkspace));
	}

	/**
	 * Remove a workspace from the program
	 */
	public void removeWorkspace() {
		if (workspaces.getTabCount() > 1)
			workspaces.remove(workspaces.getSelectedIndex());
	}

	/**
	 * Saves the current workspace to the provided file. Assumes that the
	 * provided file is valid for writing. Does not allow saving to a file being
	 * currently opened.
	 * 
	 * @param f
	 *            the file to be save to
	 */
	public void saveWorkspace(File f) {
		try {
			((ODEWorkspace) (workspaces.getSelectedComponent())).setFile(f);
			WorkspaceData workspace = ((ODEWorkspace) (workspaces
					.getSelectedComponent())).getWorkspace();
			System.out.println(workspace.getName());
			System.out.println(workspace.getODEs());
			ODEFileHandler.writeFile(f, workspace);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Opens the workspace located in f
	 * 
	 * @param f
	 *            is the file where the workspace is located. f is stored in XML
	 *            format.
	 * @throws InterruptedException
	 * 
	 * @see ODEFileHandler
	 */
	public void openWorkspace(final File f) throws InterruptedException {
		// Status Bar Update
		statusBar.setStatus("Loading Workspace...", true);

		final GUI guiLink = this;

		javax.swing.SwingWorker<Void, Void> worker = new javax.swing.SwingWorker<Void, Void>() {
			@Override
			public Void doInBackground() {
				try {
					ODEFileHandler.readFile(f, guiLink);

					// Status Bar Update
					statusBar.setStatus("Workspace Loaded.", false);
				} catch (IOException e) {
					GUI.statusBar.setStatus("There was an error reading the "
							+ "file contents.", false);
				} catch (Exception e) {
					statusBar.setStatus("", false);
					e.printStackTrace();
				}
				return null;
			}

			@Override
			public void done() {
			}
		};

		worker.execute();
	}

	/**
	 * Opens the workspace located in URL url
	 * 
	 * @param url
	 *            is the URL location to a file where the workspace is located.
	 *            f is stored in XML format.
	 * @throws InterruptedException
	 * 
	 * @see ODEFileHandler
	 */
	public void openWorkspace(final URL url) throws InterruptedException {
		// Status Bar Update
		statusBar.setStatus("Opening Workspace from URL...", true);

		final GUI guiLink = this;

		javax.swing.SwingWorker<Void, Void> worker = new javax.swing.SwingWorker<Void, Void>() {
			@Override
			public Void doInBackground() {
				try {
					ODEFileHandler.readWorkspaceFromURL(url, guiLink);

					// Status Bar Update
					statusBar.setStatus("Workspace Loaded.", false);
				} catch (IOException e) {
					GUI.statusBar.setStatus("There was an error reading the "
							+ "URL contents.", false);
				} catch (Exception e) {
					statusBar.setStatus("", false);
					e.printStackTrace();
				}
				return null;
			}

			@Override
			public void done() {
			}
		};

		worker.execute();
	}

	/**
	 * Close the program.
	 */
	public void exit() {
		System.exit(0);
	}

	/**
	 * Show the given dialog
	 * 
	 * @param d
	 *            the JDialog to show
	 */
	public void showDialog(JDialog d) {
		activeWorkspace.showDialog(d);
	}

	/**
	 * Create a dialog and show the given message
	 * 
	 * @param text
	 *            the text of the message
	 * @param header
	 *            the header for the dialog box
	 * @param flag
	 *            the flag of the message
	 */
	public void showMessage(String text, String header, int flag) {
		JOptionPane.showMessageDialog(this, text, header, flag);
	}

	/**
	 * Print the selected tab of the selected workspace.
	 */
	public void print() {
		activeWorkspace.print();
	}

	/**
	 * Export the selected tab of the selected workspace to Postscript.
	 */
	public void export() {
		activeWorkspace.exportPostscript();
	}
}
