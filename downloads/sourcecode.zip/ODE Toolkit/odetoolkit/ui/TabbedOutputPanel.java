/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.geom.Point2D.Double;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ui.outputpanels.ComponentGraphPanel;
import ui.outputpanels.DataPanel;
import ui.outputpanels.Graph3DPanel;
import ui.outputpanels.GraphPanel;
import ui.outputpanels.MultiGraphPanel;
import ui.outputpanels.ODEWorkspace;
import ui.outputpanels.OutputPanel;
import ui.outputpanels.PhaseGraphPanel;
import util.SolutionReadyListener;
import data.ODE;
import data.ODEVar;
import data.ODEVarVector;

/**
 * A TabbedOutputPanel contains the various graph panels for a specific ODE tab.
 * It also includes the Data panel, which displays a table of the internal data
 * points calculated. TabbedOutputPanel receives points from the solver and
 * calls the draw method on each graph. Individual graphs can also request
 * information such as variable lists or points. When a new ODE is entered,
 * replaceODE or overlayODE must be called to indicate the proper graphing
 * behavior. Currently an overlay is performed in the case of identical variable
 * lists.
 * 
 * Contrary to its name, TabbedOutputPanel does not extend the OutputPanel
 * class.
 * 
 * @author Aaron Becker, modified by Max Comstock
 * @version July 2013
 */
@SuppressWarnings("serial")
public class TabbedOutputPanel extends JTabbedPane implements
		SolutionReadyListener {
	/** The ODEWorkspace for this TabbedOutputPanel */
	private final ODEWorkspace owner;

	/** The active OutputPanel */
	private OutputPanel currentOutputPanel;
	/** The data tab */
	private DataPanel dataTab;

	/** The variables associated to this workspace */
	private ODEVarVector variables;
	
	/** List of previous ComponentGraphPanels to keep track of bounds */
	private ArrayList<ComponentGraphPanel> compList =
			new ArrayList<ComponentGraphPanel>();
	
	/** List of previous PhaseGraphPanels to keep track of bounds */
	private ArrayList<PhaseGraphPanel> phaseList =
			new ArrayList<PhaseGraphPanel>();
	
	/** The previous MultiGraphPanel to keep track of bounds */
	private MultiGraphPanel multiGraph;
	
	/** The number of variables in the previous ODE */
	private int oldVariableNum = 0;

	/**
	 * Constructor that creates a new TabbedOutputPanel according to the given
	 * ODEWorkspace
	 * 
	 * @param newOwner
	 *            The ODEWorkspace that owns this TabbedOutputPanel
	 */
	public TabbedOutputPanel(ODEWorkspace newOwner) {
		super(SwingConstants.BOTTOM);
		owner = newOwner;
		if (owner.getCurrentODE() == null)
			variables = null;
		else {
			variables = owner.getCurrentODEVarVector();
		}

		dataTab = new DataPanel(this);
		createGraphPanels();

		// If there are no graphs to create, make a default graph.
		// Without this, sizing is very wrong
		// Consider trying to remove this.
		if (getTabCount() == 0) {
			// Create blank graph, and make it unusable.
			ComponentGraphPanel tempPanel = new ComponentGraphPanel(this, null);
			setComponentEnabled(tempPanel, false);
			addTab("", tempPanel);
		}

		addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				for (int i = 0; i < getTabCount(); ++i)
					getComponentAt(i).setVisible(false);

				if (getSelectedIndex() != -1) {
					Component panel = getComponentAt(getSelectedIndex());
					panel.repaint();
					panel.setVisible(true);
					if (panel instanceof OutputPanel)
						currentOutputPanel = (OutputPanel) panel;
					else if (panel instanceof DataPanel)
						currentOutputPanel = (DataPanel) panel;
					currentOutputPanel.gainedFocus();
					MenuBar.updatePrintStatus(currentOutputPanel.canPrint());
				}
			}
		});
	}

	/**
	 * Creates panels for displaying the ode solution data. Currently it creates
	 * a component graph for each dependent variable, a phase plot for the first
	 * two variables defined, a multi-graph which can plot any number of
	 * variables against a given variable, and a data table. Eventually a 3D
	 * graph will be added. If the new ODE has the same number of variables as
	 * the previous ODE, the bounds of each graph will be preserved, although
	 * new GraphPanels will still be created.
	 */
	public void createGraphPanels() {
		removeAll();

		if (owner.getCurrentODE() == null)
			return;

		variables = owner.getCurrentODEVarVector();
		Vector<ODE> odes = owner.getODEs();
		boolean sameSize = (variables.size() == oldVariableNum);

		if (variables != null) {
			// Component Plots
			if (odes.size() == 1 || !sameSize) {
				compList.clear();
				for (int i = 1; i < variables.size(); ++i) {
					currentOutputPanel = new ComponentGraphPanel(this,
							variables.get(0), variables.get(i));
					String foo = ((ComponentGraphPanel) currentOutputPanel)
							.getTabName();
					addTab(foo, currentOutputPanel);
					compList.add((ComponentGraphPanel) currentOutputPanel);
				}
			}
			else {
				for (int i = 1; i < variables.size(); ++i) {
					double[] xRange = compList.get(i-1).getPlotState().
							getXRange();
					double[] yRange = compList.get(i-1).getPlotState().
							getYRange();
					boolean scale = compList.get(i-1).getPlotState().
							getAutoscale();
					currentOutputPanel = new ComponentGraphPanel(this,
							variables.get(0), variables.get(i), xRange[0],
							xRange[1], yRange[0], yRange[1]);
					String foo = ((ComponentGraphPanel) currentOutputPanel)
							.getTabName();
					addTab(foo, currentOutputPanel);
					((GraphPanel) currentOutputPanel).setAllAutoScale(scale);
					compList.remove(i-1);
					compList.add(i-1,
							(ComponentGraphPanel) currentOutputPanel);
				}
			}
			
			// Phase Plot
			if (variables.size() > 2) {
				if (odes.size() == 1 || !sameSize) {
					phaseList.clear();
					for (int i = 1; i < variables.size(); ++i) {
						for (int j = i + 1; j < variables.size(); ++j) {
							currentOutputPanel = new PhaseGraphPanel(this,
									variables.get(i), variables.get(j));
							addTab(currentOutputPanel.getTabName(),
									currentOutputPanel);
							phaseList.add(
									(PhaseGraphPanel) currentOutputPanel);
						}
					}
				}
				else {
					for (int i = 1; i < variables.size(); ++i) {
						for (int j = i + 1; j < variables.size(); ++j) {
							double[] xRange = phaseList.get(0).getPlotState().
										getXRange();
							double[] yRange = phaseList.get(0).getPlotState().
										getYRange();
							boolean scale = phaseList.get(0).getPlotState().
									getAutoscale();
							currentOutputPanel = new PhaseGraphPanel(this,
									variables.get(i), variables.get(j),
									xRange[0], xRange[1], yRange[0],
									yRange[1]);
							addTab(currentOutputPanel.getTabName(),
									currentOutputPanel);
							((PhaseGraphPanel) currentOutputPanel).
								setAllAutoScale(scale);
							phaseList.remove(0);
							phaseList.add(phaseList.size(),
									(PhaseGraphPanel) currentOutputPanel);
						}
					}
				}
				
				// 3D plot
				try {
					// 3D Plot using JMathTools
					if (variables.size() == 3)
						currentOutputPanel = new Graph3DPanel(this, variables,
								variables.get(0), variables.get(1),
								variables.get(2));
					else
						currentOutputPanel = new Graph3DPanel(this, variables,
								variables.get(1), variables.get(2),
								variables.get(3));
					addTab(currentOutputPanel.getTabName(),
							currentOutputPanel);
				} catch (Error e) {
					System.out.println("Creation of 3D GraphPanel failed.");
				}
			}

			// Multi-Graph
			if (odes.size() == 1 || !sameSize) {
				currentOutputPanel = new MultiGraphPanel(this,
						variables.get(0), variables);
				multiGraph = (MultiGraphPanel) currentOutputPanel;
			}
			else {
				double[] xRange = multiGraph.getPlotState().getXRange();
				double[] yRange = multiGraph.getPlotState().getYRange();
				boolean scale = multiGraph.getPlotState().getAutoscale();
				currentOutputPanel = new MultiGraphPanel(this,
						variables.get(0), variables, xRange[0], xRange[1],
						yRange[0], yRange[1]);
				multiGraph.setAllAutoScale(scale);
				multiGraph = (MultiGraphPanel) currentOutputPanel;
			}
			addTab(currentOutputPanel.getTabName(), currentOutputPanel);

			addTab(dataTab.getTabName(), dataTab);

			// Select the first graph panel
			oldVariableNum = variables.size();
			setSelectedIndex(0);
			setAllAutoScaleNeeded();
		}
	}

	/**
	 * Returns the ODEWorkspace owning this tabbed panel.
	 * 
	 * @return the ODEWorkspace owning this tabbed panel
	 */
	public ODEWorkspace getOwner() {
		return owner;
	}

	/**
	 * Returns the active ODE.
	 * 
	 * @return the active ODE
	 */
	public ODE getCurrentODE() {
		return owner.getCurrentODE();
	}

	/**
	 * Returns the list of ODEs in this workspace.
	 * 
	 * @return the list of ODEs in this workspace
	 */
	public Vector<ODE> getODEs() {
		return owner.getODEs();
	}

	/**
	 * Returns the number of ODE in the workspace.
	 * 
	 * @return the number of ODE
	 */
	public int getNumODEs() {
		return owner.getNumODEs();
	}

	/**
	 * Returns the variables in the workspace.
	 * 
	 * @return the variables in the workspace
	 */
	public ODEVarVector getVars() {
		return owner.getCurrentODEVarVector();
	}

	/**
	 * Check whether a direction field can be drawn for the given pair of
	 * variables.
	 * 
	 * @param xVar
	 *            The first variable
	 * @param yVar
	 *            The second variable
	 * @return true iff a direction field can be shown on the plot between the
	 *         given pair of variables
	 */
	public boolean isDirFieldPossible(ODEVar xVar, ODEVar yVar) {
		return getCurrentODE().isDirFieldPossible(xVar, yVar);
	}

	/**
	 * Check whether the current panel can be printed.
	 * 
	 * @return true iff the current panel can be printed
	 */
	public boolean canPrint() {
		return (getTabCount() > 1) && currentOutputPanel.canPrint();
	}

	/**
	 * Print the current panel
	 */
	public void print() {
		if (canPrint())
			currentOutputPanel.print();
	}

	/**
	 * Export the current panel
	 */
	public void exportPostscript() {
		if (currentOutputPanel.canPrint())
			currentOutputPanel.exportPostscript();
	}

	/**
	 * Store the initial condition for a variable.
	 * 
	 * @param var
	 *            the variable to store a new initial condition
	 * @param x
	 *            the initial condition for the given variable
	 */
	public void storeIC(ODEVar var, double x) {
		owner.storeIC(var, x);
	}

	/**
	 * Clear all displayed data in each sub-panel.
	 */
	public void clearAll() {
		System.out.println("clearing");
		for (int i = 0; i < getTabCount(); ++i) {
			OutputPanel panel = (OutputPanel) getComponentAt(i);
			panel.clear();
		}
	}

	/**
	 * Replace the graphs of the previous ode with a new ode's graphs.
	 * 
	 * @param newODE
	 */
	public void replaceODE(ODE newODE) {
		dataTab.addODE(newODE);
		createGraphPanels();
	}

	/**
	 * Remove all Curves and Equilibrium points
	 */
	public void clearAllPlotsObjects() {
		getOwner().clearAllPlotObjects();
	}

	/**
	 * Inform all GraphPanels that re-scaling is needed.
	 */
	public void setAllAutoScaleNeeded() {
		for (int i = 0; i < getTabCount(); ++i) {
			OutputPanel panel = (OutputPanel) getComponentAt(i);
			if (panel instanceof GraphPanel)
				((GraphPanel) panel).getPlotPanel().setAutoscaleNeeded();
		}
	}

	/**
	 * Recursively sets the "enabled" flag for a component (e.g., a panel).
	 * 
	 * @param container
	 *            the component who should be enabled/disabled
	 * @param enabled
	 *            true or false
	 */
	public static void setComponentEnabled(Container container, boolean enabled) {
		int controlCount = container.getComponentCount();
		Component component;

		for (int loop = 0; loop < controlCount; loop++) {
			component = container.getComponent(loop);
			if (component instanceof JLabel) {
				continue; // do nothing
			}

			component.setEnabled(enabled);

			// Set subcomponent.
			if (component instanceof JMenu) {
				JMenu mnu = (JMenu) component;
				for (int i = 0; i < mnu.getMenuComponentCount(); i++)
					setComponentEnabled((Container) mnu.getMenuComponent(i),
							enabled);
			} else if (component instanceof JTabbedPane) {
				JTabbedPane tp = (JTabbedPane) component;
				for (int i = 0; i < tp.getTabCount(); i++) {
					setComponentEnabled((Container) tp.getComponentAt(i),
							enabled);
				}
			} else if (component instanceof JTabbedPane) {
				JTabbedPane tp = (JTabbedPane) component;
				for (int i = 0; i < tp.getTabCount(); i++) {
					setComponentEnabled((Container) tp.getComponentAt(i),
							enabled);
				}
			} else if (component instanceof Container)
				setComponentEnabled((Container) component, enabled); // Recurse
			// Containers
		}
	}

	/**
	 * Update the point displayed on the status bar.
	 * 
	 * @param pt
	 *            the point to be displayed on the status bar
	 */
	public void updateStatusPoint(Double pt) {
		GUI.statusBar.updatePoint(pt.x, pt.y);
	}

	/**
	 * Display an arbitrary dialog. By doing things this way we get proper frame
	 * ownership, etc.
	 */
	public void showDialog(JDialog d) {
		owner.showDialog(d);
	}

	/**
	 * drawPoints invokes the point-drawing method in each of its panels,
	 * allowing them to render the points appropriately. For example, a
	 * component plot plots the appropriate variable versus t, and the data
	 * table adds the point to its table.
	 */
	private void drawPoints() {
		try {
			if (owner.getCurrentODE() == null) {
				System.out.println("Null ODE failure");
			} else {
				if (getSelectedComponent() != null) {
					System.out.println(((OutputPanel) getSelectedComponent())
							.getTabName());
					// System.out.println(((GraphPanel)
					// getSelectedComponent())._fillPlotNeeded);
					((OutputPanel) getSelectedComponent()).repaint();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Draws all current points when this tab is reloaded, e.g. when a file is
	 * read or a new ode in entered.
	 */
	public void drawAllPoints() {
		clearAll();

		if (owner.getWorkspace() == null)
			System.out.println("Null Workspace failure.");

		OutputPanel outPanel;
		for (int i = 0; i < getTabCount(); ++i) {
			outPanel = (OutputPanel) getComponentAt(i);
			outPanel.solutionReceived();
		}

		if (getSelectedComponent() != null)
			getSelectedComponent().repaint();
	}

	/**
	 * Make all tabs response to the new Equilibrium Point
	 */
	public void newEquilibrium() {
		OutputPanel outPanel;
		for (int i = 0; i < getTabCount(); ++i) {
			outPanel = (OutputPanel) getComponentAt(i);
			outPanel.equilibriumReceived();
		}

		drawPoints();

		System.out.println("Equilibrium Point Complete");
		GUI.statusBar.setStatus("Equilibrium Point Complete.", false);
	}

	/**
	 * Repaint the data panel.
	 */
	public void repaintDataPanel() {
		if (getTabCount() > 0) {
			OutputPanel lastPanel = (OutputPanel) getComponentAt(getTabCount() - 1);
			if (lastPanel instanceof DataPanel)
				lastPanel.repaint();
		}
	}

	@Override
	/**
	 * Overloaded default function to ensure that graphPanel is updated correctly.
	 * @param i the index of the panel to select
	 */
	public void setSelectedIndex(int i) {
		super.setSelectedIndex(i);
		currentOutputPanel = (OutputPanel) getComponentAt(getSelectedIndex());
		((OutputPanel) getSelectedComponent()).repaint();
	}

	/**
	 * When the last solution point is received, solutionReady is called, which
	 * draws all remaining points and starts a fresh curve.
	 * 
	 * @param sol
	 *            the 2D array representing the solution
	 */
	public void solutionReady(double[][] sol) {
		OutputPanel outPanel;
		for (int i = 0; i < getTabCount(); ++i) {
			outPanel = (OutputPanel) getComponentAt(i);
			outPanel.solutionReceived();
		}

		drawPoints();

		System.out.println("Solution Complete");
		GUI.statusBar.setStatus("Solution Complete.", false);
	}

	/**
	 * Required by the SolutionReadyListener interface. Never used by any type of
	 * GraphPanel.
	 * 
	 * @param ex
	 *            the exception to be handled
	 */
	public void errorCondition(Exception ex) {
		// Nothing to be done
	}

	/**
	 * Required by the SolutionReadyListener interface. Never used by any type of
	 * GraphPanel.
	 * 
	 * @param error
	 *            string describing error condition
	 */
	public void errorCondition(String error) {
		// Nothing to be done
	}
}
