/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.Component;
import java.awt.Dimension;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import ui.TabbedOutputPanel;
import data.Curve;
import data.Equilibrium;
import data.ODE;

/**
 * DataPanel displays the internal ODE curve point data.
 * 
 * The display consists of a split pane: on the left is a Java swing tree view
 * of the stored ODEs and their curves / equilibrium points, and on the right is
 * an Inspector panel, which displays the specific information about the
 * selected node.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */
@SuppressWarnings("serial")
public class DataPanel extends OutputPanel {
	/** The owner of this data tab */
	private TabbedOutputPanel owner;

	/** The panel for exploring ODEs */
	private ODEInspector odeInspectorPanel;
	/** The panel for exploring curves */
	private CurveInspector curveInspectorPanel;
	/** The panel for exploring Equilibrium points */
	private EquilibriumInspector eqInspectorPanel;

	/** The splitter between the workspace pane and the inspector panel */
	private javax.swing.JSplitPane splitPane;
	/** The scroll pane containing the tree representing workspace data */
	private javax.swing.JScrollPane workspaceScrollPane;
	/** The tree for workspace data */
	private javax.swing.JTree workspaceTree;
	/** The tree model for workspace data */
	private DefaultTreeModel treeModel;

	/** the width of the name field on the tree nodes */
	private static final int preferredTreeWidth = 150;

	/**
	 * This class is used to prevent the treeModel from cutting off the node
	 * names to too small width.
	 */
	public class FixedWidthCellRenderer extends DefaultTreeCellRenderer
			implements TreeCellRenderer {
		/**
		 * Create a renderer with specific minimal width on each node.
		 */
		public Component getTreeCellRendererComponent(JTree tree, Object value,
				boolean sel, boolean expanded, boolean leaf, int row,
				boolean hasFocus) {
			Component c = super.getTreeCellRendererComponent(tree, value, sel,
					expanded, leaf, row, hasFocus);
			c.setPreferredSize(new Dimension(preferredTreeWidth, (int) c
					.getPreferredSize().getHeight()));
			return c;
		}
	}

	/**
	 * Constructor that creates a new data panel corresponding to the given
	 * TabbedOutputPanel
	 * 
	 * @param owner
	 *            the owner of new data panel
	 */
	public DataPanel(TabbedOutputPanel owner) {
		super(owner);
		// Initialization
		this.owner = owner;
		loadData();
		initComponents();
		workspaceTree.setCellRenderer(new FixedWidthCellRenderer());
	}

	/**
	 * Returns the TabbedOutputPanel that this data panel lives in.
	 * 
	 * @return the TabbedOutputPanel that this data panel lives in
	 */
	public TabbedOutputPanel getOwner() {
		return owner;
	}

	@Override
	public void clear() {
		loadData();
		curveInspectorPanel.unfocusCurve();
		workspaceScrollPane.setViewportView(workspaceTree);
		expandAll(true);
		repaint();
	}

	@Override
	public void gainedFocus() {
		expandAll(true);
		repaint();
	}

	/**
	 * Load the data as a node is clicked.
	 */
	public void loadData() {
		workspaceTree = buildTree();

		workspaceTree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) workspaceTree
						.getLastSelectedPathComponent();

				if (node == null)
					return;

				Object nodeInfo = node.getUserObject();

				if (nodeInfo instanceof Curve) {
					DefaultMutableTreeNode parent = (DefaultMutableTreeNode) node
							.getParent();
					curveInspectorPanel.analyzeCurve((Curve) nodeInfo,
							(ODE) parent.getUserObject());
					splitPane.setRightComponent(curveInspectorPanel);
				} else if (nodeInfo instanceof Equilibrium) {
					DefaultMutableTreeNode parent = (DefaultMutableTreeNode) node
							.getParent();
					eqInspectorPanel.analyzeEquilibrium((Equilibrium) nodeInfo,
							(ODE) parent.getUserObject());
					splitPane.setRightComponent(eqInspectorPanel);
				} else {
					odeInspectorPanel.analyzeODE((ODE) nodeInfo);
					splitPane.setRightComponent(odeInspectorPanel);
				}
			}
		});
	}

	/**
	 * Construct the tree from the workspace data.
	 * 
	 * @return the tree constructed from the workspace data
	 */
	public JTree buildTree() {

		DefaultMutableTreeNode odeChild, elementChild;
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("ODEToolkit");

		Vector<ODE> odes = owner.getODEs();
		Vector<Curve> curves;
		Vector<Equilibrium> equilibria;

		ODE o;
		Curve c;
		Equilibrium eq;

		int numODEs = owner.getNumODEs();
		int numElements;

		for (int i = 0; i < numODEs; i++) {
			o = odes.elementAt(i);

			odeChild = new DefaultMutableTreeNode(o);
			root.add(odeChild);

			curves = o.getCurves();
			numElements = o.getNumCurves();
			for (int j = 0; j < numElements; j++) {
				c = curves.elementAt(j);
				elementChild = new DefaultMutableTreeNode(c);
				odeChild.add(elementChild);
			}

			equilibria = o.getEquilibria();
			numElements = o.getNumEquilibria();
			for (int j = 0; j < numElements; j++) {
				eq = equilibria.elementAt(j);
				elementChild = new DefaultMutableTreeNode(eq);
				odeChild.add(elementChild);
			}
		}

		treeModel = new DefaultTreeModel(root);
		JTree t = new JTree(treeModel);
		t.setRootVisible(false);
		t.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);

		return t;
	}

	/**
	 * Make the whole tree expanded or not expanded
	 * 
	 * @param expand
	 *            true iff the whole tree should be set to expanded
	 */
	public void expandAll(boolean expand) {
		TreeNode root = (TreeNode) workspaceTree.getModel().getRoot();
		expandAll(new TreePath(root), expand);
	}

	/**
	 * Make the whole subtree expanded or not expanded
	 * 
	 * @param parent
	 *            the parent of that subtree
	 * @param expand
	 *            true iff the whole tree should be set to expanded
	 */
	private void expandAll(TreePath parent, boolean expand) {
		// Traverse children
		TreeNode node = (TreeNode) parent.getLastPathComponent();
		if (node.getChildCount() >= 0) {
			for (Enumeration<?> e = node.children(); e.hasMoreElements();) {
				TreeNode n = (TreeNode) e.nextElement();
				TreePath path = parent.pathByAddingChild(n);
				expandAll(path, expand);
			}
		}

		// Expansion or collapse must be done bottom-up
		if (expand) {
			workspaceTree.expandPath(parent);
		} else {
			workspaceTree.collapsePath(parent);
		}
	}

	/**
	 * Initialize the interface
	 */
	private void initComponents() {
		splitPane = new javax.swing.JSplitPane();
		workspaceScrollPane = new javax.swing.JScrollPane();
		curveInspectorPanel = new CurveInspector(this, owner.getOwner());
		odeInspectorPanel = new ODEInspector(this, owner.getOwner());
		eqInspectorPanel = new EquilibriumInspector(this, owner.getOwner());

		workspaceScrollPane.setViewportView(workspaceTree);

		splitPane.setDividerLocation(200);
		splitPane.setLeftComponent(workspaceScrollPane);
		splitPane.setRightComponent(new javax.swing.JPanel());

		org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(
				this);
		this.setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(splitPane,
				org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 486,
				Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(
				org.jdesktop.layout.GroupLayout.TRAILING,
				layout.createSequentialGroup().add(splitPane,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 389,
						Short.MAX_VALUE)));
	}// </editor-fold>

	/**
	 * Returns the name that should be on this graph's tab
	 */
	@Override
	public String getTabName() {
		return "Data";
	}

	/**
	 * Add a new curve to the Data Panel
	 * 
	 * @param currentODE
	 *            the ODE to add a curve
	 * @param currentCurve
	 *            the curve to add
	 */
	void addCurve(ODE currentODE, Curve currentCurve) {
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel
				.getRoot();
		for (int i = 0; i < root.getChildCount(); i++) {
			DefaultMutableTreeNode odeNode = (DefaultMutableTreeNode) root
					.getChildAt(i);
			ODE thisODE = (ODE) odeNode.getUserObject();
			if (currentODE.equals(thisODE)) {
				// found ODE
				boolean curveExist = false;
				int lastCurveIndex = -1;
				for (int j = 0; j < odeNode.getChildCount(); j++) {
					DefaultMutableTreeNode elementNode = (DefaultMutableTreeNode) odeNode
							.getChildAt(j);
					Object element = elementNode.getUserObject();
					if (element instanceof Curve) {
						// keep track of the last curve index
						lastCurveIndex = j;
						if ((Curve) element == currentCurve)
							// already have this curve
							curveExist = true;
					}
				}
				if (!curveExist) {
					// add this curve is not already contained
					DefaultMutableTreeNode curveNode = new DefaultMutableTreeNode(
							currentCurve);
					treeModel.insertNodeInto(curveNode, odeNode,
							lastCurveIndex + 1);
				}
			}
		}
		odeInspectorPanel.cancelColorSelection(currentODE);
		expandAll(true);
		repaint();
	}

	/**
	 * Remove a curve from the Data Panel
	 * 
	 * @param currentODE
	 *            the ODE to remove a curve from
	 * @param currentCurve
	 *            the curve to be removed
	 */
	public void removeCurve(ODE currentODE, Curve currentCurve) {
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel
				.getRoot();
		for (int i = 0; i < root.getChildCount(); i++) {
			DefaultMutableTreeNode odeNode = (DefaultMutableTreeNode) root
					.getChildAt(i);
			ODE thisODE = (ODE) odeNode.getUserObject();
			if (currentODE.equals(thisODE)) {
				// correct ODE found
				for (int j = 0; j < odeNode.getChildCount(); j++) {
					DefaultMutableTreeNode elementNode = (DefaultMutableTreeNode) odeNode
							.getChildAt(j);
					Object obj = elementNode.getUserObject();
					if (obj instanceof Curve)
						if (currentCurve.equals((Curve) obj))
							// correct Curve found, so delete
							treeModel.removeNodeFromParent(elementNode);
				}
			}
		}
		expandAll(true);
		repaint();
	}

	/**
	 * Add a new equilibrium point to the Data Panel
	 * 
	 * @param currentODE
	 *            the ODE to add an equilibrium point
	 * @param currentEq
	 *            the equilibrium point to add
	 */
	void addEquilibrium(ODE currentODE, Equilibrium currentEq) {
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel
				.getRoot();
		for (int i = 0; i < root.getChildCount(); i++) {
			DefaultMutableTreeNode odeNode = (DefaultMutableTreeNode) root
					.getChildAt(i);
			ODE thisODE = (ODE) odeNode.getUserObject();
			if (currentODE.equals(thisODE)) {
				// found ODE
				boolean eqExist = false;
				for (int j = 0; j < odeNode.getChildCount(); j++) {
					DefaultMutableTreeNode elementNode = (DefaultMutableTreeNode) odeNode
							.getChildAt(j);
					Object element = elementNode.getUserObject();
					if ((element instanceof Equilibrium)
							&& ((Equilibrium) element) == currentEq)
						// already have this equilibrium
						eqExist = true;
				}
				if (!eqExist) {
					// add the equilibrium
					DefaultMutableTreeNode curveNode = new DefaultMutableTreeNode(
							currentEq);
					treeModel.insertNodeInto(curveNode, odeNode,
							odeNode.getChildCount());
				}
			}
		}
		odeInspectorPanel.cancelColorSelection(currentODE);
		expandAll(true);
		repaint();
	}

	/**
	 * Remove an equilibrium point from the Data Tab
	 * 
	 * @param currentODE
	 *            the ODE to remove an equilibrium point from
	 * @param currentEq
	 *            the equilibrium point to be removed
	 */
	public void removeEquilibrium(ODE currentODE, Equilibrium currentEq) {
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel
				.getRoot();
		for (int i = 0; i < root.getChildCount(); i++) {
			DefaultMutableTreeNode odeNode = (DefaultMutableTreeNode) root
					.getChildAt(i);
			ODE thisODE = (ODE) odeNode.getUserObject();
			if (currentODE.equals(thisODE)) {
				// found correct ODE
				for (int j = 0; j < odeNode.getChildCount(); j++) {
					DefaultMutableTreeNode elementNode = (DefaultMutableTreeNode) odeNode
							.getChildAt(j);
					Object obj = elementNode.getUserObject();
					if (obj instanceof Equilibrium)
						if (currentEq.equals((Equilibrium) obj))
							// found correct Equilibrium
							treeModel.removeNodeFromParent(elementNode);
				}
			}
		}
		expandAll(true);
		repaint();
	}

	/**
	 * Add a new ODE to the Data Panel
	 * 
	 * @param newODE
	 *            the new ODE to add
	 */
	public void addODE(ODE newODE) {
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel
				.getRoot();
		DefaultMutableTreeNode odeNode = new DefaultMutableTreeNode(newODE);
		treeModel.insertNodeInto(odeNode, root, root.getChildCount());
		expandAll(true);
		repaint();
	}

	@Override
	public void solutionReceived() {
		ODE currentODE = owner.getCurrentODE();
		if (currentODE != null) {
			if (!currentODE.getCurves().isEmpty()) {
				Curve currentCurve = currentODE.getCurves().lastElement();
				addCurve(currentODE, currentCurve);
			}
		}
	}

	@Override
	public void equilibriumReceived() {
		ODE currentODE = owner.getCurrentODE();
		if (currentODE != null) {
			if (!currentODE.getEquilibria().isEmpty()) {
				Equilibrium currentEq = currentODE.getEquilibria()
						.lastElement();
				addEquilibrium(currentODE, currentEq);
			}
		}
	}

	// Printing is not supported in DataPanel
	@Override
	public boolean canPrint() {
		return false;
	}

	@Override
	public void print() {
		// Nothing to be done here
	}

	@Override
	public void exportPostscript() {
		// Nothing to be done here
	}
}
