/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.BorderLayout;

import ui.TabbedOutputPanel;
import ui.dialogs.DirFieldDialog;
import ui.dialogs.LabelDialog;
import ui.dialogs.ScaleDialog;
import data.ODEVar;
import data.plotstates.SinglePlotState;

/**
 * This class extends GraphPanel, is specialized for plotting graphs with one
 * variable on each of the axis, where the x-axis represents the independent
 * variable t.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
@SuppressWarnings("serial")
public class ComponentGraphPanel extends GraphPanel {
	/**
	 * Constructor for a ComponentGraphPanel, with variables given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param xVar
	 *            the variable associated with x-axis
	 * @param yVar
	 *            the variable associated with y-axis
	 */
	public ComponentGraphPanel(TabbedOutputPanel owner, ODEVar xVar, ODEVar yVar) {
		this(owner, new SinglePlotState(owner.getODEs(), owner.getCurrentODE(),
				xVar, yVar));
	}
	
	/**
	 * Constructor for a ComponentGraphPanel, with variables and bounds given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param xVar
	 *            the variable associated with x-axis
	 * @param yVar
	 *            the variable associated with y-axis
	 * @param xMin
	 *            the lower bound for the x-axis
	 * @param xMax
	 *            the upper bound for the x-axis
	 * @param yMin
	 *            the lower bound for the y-axis
	 * @param yMax
	 *            the upper bound for the y-axis
	 */
	public ComponentGraphPanel(TabbedOutputPanel owner, ODEVar xVar,
			ODEVar yVar, double xMin, double xMax, double yMin,
			double yMax) {
		this(owner, new SinglePlotState(owner.getODEs(), owner.getCurrentODE(),
				xVar, yVar, xMin, xMax, yMin, yMax));
	}

	/**
	 * Constructor for a ComponentGraphPanel, with SinglePlotState given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param state
	 *            the state of the plot
	 */
	public ComponentGraphPanel(TabbedOutputPanel owner, SinglePlotState state) {
		super(owner);

		if (state != null) // the SinglePlotState is instantiated properly
		{
			plotPanel = new PlotPanel(this, state); // the Plot
			availableTools = new String[] { // Available mouse-action tools
			"Pick Initial Conditions", "Pan", "Zoom", };
			toolbar = new PlotToolbar(this); // Toolbar buttons

			popupMenu = new PlotPanelPopup(this); // Right-click menu options

			plotPanel.addPointClickedListener(this);
			plotPanel.addMouseListener(new PopupListener(popupMenu));

			// Layout
			setLayout(new BorderLayout());
			add(toolbar, "North");
			add(plotPanel);

			dirFieldDialog = new DirFieldDialog(this); // Direction Fields
			// Dialog Box
			labelDialog = new LabelDialog(this); // Change Labels Dialog Box
			scaleDialog = new ScaleDialog(this); // Scaling Dialog Box

			System.out.println("Making ComponentGraphPanel: plotting "
					+ state.getYVar().getName() + " with "
					+ state.getXVar().getName() + ".");
			System.out.println("Direction fields possible: "
					+ plotPanel.isDirFieldPossible());
		}
	}

	/**
	 * Returns the name that should be on this graph's tab
	 * 
	 * @return the name that should be on this graph's tab
	 */
	@Override
	public String getTabName() {
		return plotPanel.getYLabel() + "-" + plotPanel.getXLabel();
	}
}
