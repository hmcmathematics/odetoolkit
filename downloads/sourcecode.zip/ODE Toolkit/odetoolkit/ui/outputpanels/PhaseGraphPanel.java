/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.BorderLayout;
import java.awt.geom.Point2D;

import solver.EquilibriumFinder;
import solver.SolverParameters;
import ui.GUI;
import ui.TabbedOutputPanel;
import ui.dialogs.DirFieldDialog;
import ui.dialogs.LabelDialog;
import ui.dialogs.ScaleDialog;
import solver.MatrixOperations.MatrixException;
import data.ODEVar;
import data.ODEVarVector;
import data.plotstates.SinglePlotState;

/**
 * PhaseGraphPanels are GraphPanels that represent a graph of two of an ODE's
 * independent variables.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
@SuppressWarnings("serial")
public class PhaseGraphPanel extends GraphPanel {
	/**
	 * Constructor for a PhaseGraphPanel, with variables given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param xVar
	 *            the variable associated with x-axis
	 * @param yVar
	 *            the variable associated with y-axis
	 */
	public PhaseGraphPanel(TabbedOutputPanel owner, ODEVar xVar, ODEVar yVar) {
		this(owner, new SinglePlotState(owner.getODEs(), owner.getCurrentODE(),
				xVar, yVar));
	}
	
	/**
	 * Constructor for a PhaseGraphPanel, with variables and bounds given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param xVar
	 *            the variable associated with x-axis
	 * @param yVar
	 *            the variable associated with y-axis
	 * @param xMin
	 *            the lower bound for the x-axis
	 * @param xMax
	 *            the upper bound for the x-axis
	 * @param yMin
	 *            the lower bound for the y-axis
	 * @param yMax
	 *            the upper bound for the y-axis
	 */
	public PhaseGraphPanel(TabbedOutputPanel owner, ODEVar xVar, ODEVar yVar,
			double xMin, double xMax, double yMin, double yMax) {
		this(owner, new SinglePlotState(owner.getODEs(), owner.getCurrentODE(),
				xVar, yVar, xMin, xMax, yMin, yMax));
	}

	/**
	 * Constructor for a PhaseGraphPanel, with variables and title given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param t
	 *            the title of the graph
	 * @param xVar
	 *            the variable associated with x-axis
	 * @param yVar
	 *            the variable associated with y-axis
	 */
	public PhaseGraphPanel(TabbedOutputPanel owner, String t, ODEVar xVar,
			ODEVar yVar) {
		this(owner, new SinglePlotState(owner.getODEs(), owner.getCurrentODE(),
				t, xVar, yVar));
	}

	/**
	 * Constructor for a PhaseGraphPanel, with SinglePlotState given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param state
	 *            the state of the plot
	 */
	public PhaseGraphPanel(TabbedOutputPanel owner, SinglePlotState state) {
		super(owner);

		if (state != null) {
			plotPanel = new PlotPanel(this, state);
			if (isPlotOrbitPossible())
				availableTools = new String[] { // Available mouse-action tools
					"Pick Initial Conditions", "Pan", "Zoom", "Plot Orbit",
					"Find Equilibrium Point" };
			else
				availableTools = new String[] { "Pick Initial Conditions",
						"Pan", "Zoom" };

			toolbar = new PlotToolbar(this);

			popupMenu = new PlotPanelPopup(this);

			plotPanel.addPointClickedListener(this);
			plotPanel.addMouseListener(new PopupListener(popupMenu));
			if (isPlotOrbitPossible()) {
				plotPanel.setPlotOrbitMode();
			}
			toolbar.setToolMode();

			// Layout
			setLayout(new BorderLayout());
			add(toolbar, "North");
			add(plotPanel);

			dirFieldDialog = new DirFieldDialog(this);
			scaleDialog = new ScaleDialog(this);
			labelDialog = new LabelDialog(this);

			// When the first (dummy) graph is created, this fails, so we catch
			// exceptions.
			try {
				System.out.println("Making CGP: " + state.getXVar().getName()
						+ " " + state.getYVar().getName());
				boolean dirFieldAvailable = plotPanel.isDirFieldPossible();
				System.out.println("Possible = " + dirFieldAvailable);
			} catch (Exception e) {
			}
		}
	}

	/**
	 * Returns the name that should be on this graph's tab
	 * 
	 * @return the name that should be on this graph's tab
	 */
	@Override
	public String getTabName() {
		return plotPanel.getYLabel() + "-" + plotPanel.getXLabel();
	}

	/**
	 * Action function required by the PointClickedListener interface. If the
	 * PlotPanel is in 'Pick Initial Conditions' mode, it stores the point
	 * clicked as the new initial conditions and updates the status display with
	 * the new coordinates. If it is in 'Plot Orbit' mode, the program solves
	 * and plots the orbit, and updates the status display with the new
	 * coordinates. If it is in 'Find Equilibrium Point' mode, the program finds
	 * the nearest equilibrium point and updates the status display accordingly.
	 * 
	 * @param pt
	 *            the point that was clicked
	 */
	@Override
	public void pointClicked(Point2D.Double pt) {
		// 'Pick Initial Conditions' mode
		if (plotPanel.getICMode())
			storeIC(pt);

		// 'Plot Orbit' mode
		if (plotPanel.getPlotOrbitMode()) {
			tabbedOutputPanelOwner.getOwner().getInputPanel().storeParameters();
			tabbedOutputPanelOwner.getOwner().solveOrbit();
		}

		// 'Find Equilibrium Point' mode
		if (plotPanel.getEquMode()) {
			// find an equilibrium point and store it in the tmp array
			double tmp[] = null;
			SolverParameters sp = tabbedOutputPanelOwner.getOwner()
					.getParameters();
			try {
				double[] guess = new double[sp.getDimension() - 1];
				double[] ic = sp.getInitialConditions();
				ODEVarVector vars = sp.getVariables();
				for (int i = 1; i < vars.size(); i++) {
					if (plotPanel.getXVar().equals(vars.get(i))) // if the
																	// variable
																	// is found
						guess[i - 1] = pt.x;
					else if (plotPanel.getYVars().get(0).equals(vars.get(i))) // if
																				// the
																				// variable
																				// is
																				// found
						guess[i - 1] = pt.y;
					else
						guess[i - 1] = ic[i];
				}
				tmp = EquilibriumFinder.findEquilibrium(
						tabbedOutputPanelOwner.getCurrentODE(), guess);
			} catch (MatrixException e) {
				System.out.println("Error finding a equilibrium point.");
			}

			ODEVarVector eqVars = (ODEVarVector) sp.getVariables().clone();
			eqVars.remove(0);
			tabbedOutputPanelOwner.getCurrentODE().createEquilibrium(eqVars,
					tmp);
			tabbedOutputPanelOwner.newEquilibrium();
			// store the array as a new Point
			Point2D.Double equPt = new Point2D.Double(tmp[0], tmp[1]);

			// add the point to the equilibrium point array
			// plotPanel.addEquilibriumPoint(equPt);

			System.out.println("Equilibrium point found at (" + equPt.x + ", "
					+ equPt.y + ")");

			// display a status bar update to the user that a point was found
			GUI.statusBar.setMessage("Equilibrium point found at (" + equPt.x
					+ ", " + equPt.y + ")");
		}
		// Displays the clicked point on the status bar
		else
			tabbedOutputPanelOwner.updateStatusPoint(pt);
	}
}
