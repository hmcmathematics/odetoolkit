/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JPanel;

import solver.SolverParameters;
import ui.GUI;
import ui.InputPanel;
import ui.TabbedOutputPanel;

/**
 * This class keep track of all the UI/graphics-related content of the
 * ODEWorkspace.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */

public class GraphicsRep {

	/** the GUI of the program */
	private GUI gui;
	/** The ODEWorkspace that this graphics rep lives in */
	private ODEWorkspace parent;
	/** The input panel on the left side of the screen */
	private InputPanel odePanel;
	/** The graphs and data panels. */
	private TabbedOutputPanel tabbedGraphPanel;

	/**
	 * Constructor that creates a Graphics component of ODEWorkspace.
	 * 
	 * @param odews
	 *            the workspace that this component lives in
	 * @param ui
	 *            the reference to the GUI of the program
	 * @param p
	 *            the panel to show the result, on the right side of the screen
	 */
	public GraphicsRep(ODEWorkspace odews, GUI ui, JPanel p) {

		gui = ui;
		parent = odews;

		odePanel = new InputPanel(odews);
		tabbedGraphPanel = new TabbedOutputPanel(odews);

		// Layout

		p.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.ipadx = 2;
		c.ipady = 2;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.insets = new Insets(2, 2, 2, 2);
		c.anchor = GridBagConstraints.NORTHWEST;
		c.fill = GridBagConstraints.NONE;

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.insets = new Insets(0, 0, 0, 0);

		c.gridy++;
		c.gridwidth = 1;
		c.weighty = 1;
		c.weightx = 0;

		p.add(odePanel, c);
		odePanel.setMinimumSize(new Dimension(250, 600));
		odePanel.setBorder(BorderFactory.createEmptyBorder(6, 6, 13, 0));

		c.gridx++;
		c.weightx = 1;

		p.add(tabbedGraphPanel, c);

		odePanel.disableSolverButtons();
	}

	/**
	 * Returns the TabbedOutputPanel of this ODEWorkspace.
	 * 
	 * @return the TabbedOutputPanel of this ODEWorkspace
	 */
	public TabbedOutputPanel getTabbedGraphPanel() {
		return tabbedGraphPanel;
	}

	/**
	 * Returns the input panel of this ODEWorkspace.
	 * 
	 * @return the input panel of this ODEWorkspace
	 */
	public InputPanel getInputPanel() {
		return odePanel;
	}

	/**
	 * To get proper dialog positioning, each dialog uses this method to center
	 * itself on the main program frame. Even better would be setting the parent
	 * frame as the owner, but this requires a reference to the frame at the
	 * time that the dialog is created. This change should probably be made at
	 * some point, but it is low priority and will make some parts of the code
	 * very inelegant.
	 * 
	 * @param dialog
	 *            the dialog to show
	 */
	public void showDialog(JDialog dialog) {
		Rectangle r = gui.getBounds();
		int x = r.x + (r.width - dialog.getWidth()) / 2;
		int y = r.y + (r.height - dialog.getHeight()) / 2;

		dialog.setLocation(x, y);
		dialog.setVisible(true);
	}

	/**
	 * Set the solve components to be enabled or disabled
	 * 
	 * @param enabled
	 *            true iff set to enabled, false otherwise
	 */
	public void enableSolveComponents(boolean enabled) {
		odePanel.enableSolveComponents(enabled);
	}

	/**
	 * Update the solver parameters on the GUI.
	 */
	public void updateGUI_parameters() {
		odePanel.setParameters(parent.getParameters());
	}

	/**
	 * Update the parameters on the input panel.
	 * 
	 * @param params
	 *            the solver parameters to set to
	 */
	public void updateInputPanelParameters(SolverParameters params) {
		odePanel.setParameters(params);
	}

	/**
	 * Update the IC table on the input panel.
	 * 
	 * @param params
	 *            the solver parameters containing the IC to set to
	 */
	public void updateInputPanelIC(SolverParameters params) {
		odePanel.setIC(params);
	}

	/**
	 * Set the message and availability status on the status bar.
	 * 
	 * @param message
	 *            the message to show
	 * @param busy
	 *            true iff the bar should be shown as busy, false otherwise
	 */
	public void setStatusBar(String message, boolean busy) {
		GUI.statusBar.setStatus(message, busy);
	}

	/**
	 * Set the message on the status bar.
	 * 
	 * @param message
	 *            the message to show
	 */
	public void setStatusBar(String message) {
		GUI.statusBar.setMessage(message);
	}

	/**
	 * Remove all plots on all panels.
	 */
	public void clearPlots() {
		tabbedGraphPanel.clearAll();
	}

	/**
	 * Reload all information, create graph panels, and draw graphs.
	 */
	public void reload() {

		if (parent.getCurrentODE() != null) {
			odePanel.setName(parent.getCurrentODE().getName());
			odePanel.setDefinition(parent.getCurrentODE().getODEText());
		}
		updateGUI_parameters();

		tabbedGraphPanel.createGraphPanels();
		tabbedGraphPanel.drawAllPoints();
	}

	/**
	 * Request focus on the ODE Text.
	 */
	public void focusOnDefinition() {
		odePanel.focusOnDefinition();
	}
}
