/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import ui.dialogs.SolverOptionsPanel;
import util.ColorComboBox;
import util.ColorIcon;
import data.Curve;
import data.Equilibrium;
import data.ODE;

/**
 * ODEInspector defines the right pane of workspacePanel.
 * 
 * It consists of a panel displaying the definition of the ODE. The user can use
 * the buttons at the bottom to configure visual properties of the Curves and
 * Equilibriums in that ODE.
 * 
 * This class should support deleting or retrieving ODE as well, but it is not
 * implemented yet.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */

@SuppressWarnings("serial")
public class ODEInspector extends JPanel {
	/** The ODE to show information */
	ODE currentODE;
	/** The solver dialog for this data tab */
	private SolverOptionsPanel solverDialog;

	/** The panel containing the ODE information */
	private javax.swing.JPanel topPanel;
	/** The label for ODE definition */
	private javax.swing.JLabel definitionLabel;
	/** The text area containing ODE definition */
	private javax.swing.JTextArea definitionField;
	/** The scroll pane containing the ODE information */
	private javax.swing.JScrollPane definitionScrollPane;
	/** the panel for buttons at the bottom of the screen */
	private javax.swing.JPanel buttonPanel;
	/** label for ODE curves and equilibrium points color */
	private javax.swing.JLabel colorLabel;
	/** The color chooser for ODE curves and equilibrium points color */
	private ColorComboBox colorCombo;
	/** The button for showing all ODE curves and equilibrium points */
	private javax.swing.JButton showAll;
	/** The button for hiding all ODE curves and equilibrium points */
	private javax.swing.JButton hideAll;
	/** The view retrieve ODE button */
	private javax.swing.JButton retrieve;
	/** the delete button */
	private javax.swing.JButton delete;

	/**
	 * Constructor that creates a ODEInspector for the given ODEWorkspace
	 * 
	 * @param owner
	 *            the data panel that owns this inspector
	 * @param workspace
	 *            the ODEWorkspace associated to this inspector
	 */
	public ODEInspector(DataPanel owner, ODEWorkspace workspace) {
		solverDialog = new SolverOptionsPanel(workspace.getParameters(),
				workspace);
		solverDialog.disallowChanges();
		initComponents();
	}

	/**
	 * Prepare information about the selected ODE
	 * 
	 * @param o
	 *            the owner of the selected ODE
	 */
	public void analyzeODE(ODE o) {

		System.out.println("ODE selected: " + o);

		currentODE = o;

		if (o != null) {
			try {
				definitionField.setText(o.getODEText());
				showAll.setEnabled(true);
				hideAll.setEnabled(true);
				colorCombo.setSelectedIndex(0);
				colorCombo.setEnabled(true);
			} catch (Exception e) {

			}
		}
	}

	/**
	 * Stop showing information about the current ODE
	 */
	public void unfocusODE() {
		definitionField.setText("");
		delete.setEnabled(false);
		retrieve.setEnabled(false);
		colorCombo.setEnabled(false);
		showAll.setEnabled(false);
		hideAll.setEnabled(false);
	}

	/**
	 * Set the color selection to "no selection"
	 * 
	 * @param ode
	 *            the ODE to apply setting to
	 */
	public void cancelColorSelection(ODE ode) {
		if (currentODE == ode)
			colorCombo.setSelectedIndex(0);
	}

	/**
	 * Initialize the user interface
	 */
	private void initComponents() {
		// construct objects
		buttonPanel = new javax.swing.JPanel();
		delete = new javax.swing.JButton();
		topPanel = new javax.swing.JPanel();
		definitionLabel = new javax.swing.JLabel();
		definitionField = new javax.swing.JTextArea();
		definitionScrollPane = new javax.swing.JScrollPane();
		retrieve = new javax.swing.JButton();
		showAll = new javax.swing.JButton();
		hideAll = new javax.swing.JButton();
		colorLabel = new javax.swing.JLabel();

		// initial settings
		colorCombo = new ColorComboBox(true);
		showAll.setText("Show all");
		showAll.setEnabled(false);
		hideAll.setText("Hide all");
		hideAll.setEnabled(false);
		colorLabel.setText("Color");
		definitionField.setEditable(false);
		colorCombo.setEnabled(false);

		// delete and retrieve ODE are currently not supported,
		// so this is a place holder
		delete.setText("Delete ODE");
		delete.setEnabled(false);
		delete.setVisible(false);
		retrieve.setText("Retrieve ODE");
		retrieve.setEnabled(false);
		retrieve.setVisible(false);

		// delete button
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// This is not supported yet
			}
		});

		// retrieve ODE button
		retrieve.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// This is not supported yet
			}
		});

		// choose color
		colorCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentODE != null) {
					// for ODE, we change colors of both curves and equilibrium
					// points
					for (Curve c : currentODE.getCurves()) {
						Color newColor = ((ColorIcon) colorCombo
								.getSelectedItem()).getColor();
						if (newColor.getAlpha() > 0)
							c.getVisualProperties().setColor(newColor);
					}
					for (Equilibrium eq : currentODE.getEquilibria()) {
						Color newColor = ((ColorIcon) colorCombo
								.getSelectedItem()).getColor();
						if (newColor.getAlpha() > 0)
							eq.getVisualProperties().setColor(newColor);
					}
				}
			}
		});

		// button for showing all curves and equilibrium points
		showAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentODE != null) {
					for (Curve c : currentODE.getCurves())
						if (c != null)
							c.getVisualProperties().showHide(true);
					for (Equilibrium eq : currentODE.getEquilibria())
						if (eq != null)
							eq.getVisualProperties().showHide(true);
				}
			}
		});

		// button for hiding all curves and equilibrium points
		hideAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentODE != null) {
					for (Curve c : currentODE.getCurves())
						if (c != null)
							c.getVisualProperties().showHide(false);
					for (Equilibrium eq : currentODE.getEquilibria())
						if (eq != null)
							eq.getVisualProperties().showHide(false);
				}
			}
		});

		// code for constructing the interface generated by Netbeans
		javax.swing.GroupLayout buttonPanelLayout = new javax.swing.GroupLayout(
				buttonPanel);
		buttonPanel.setLayout(buttonPanelLayout);
		buttonPanelLayout
				.setHorizontalGroup(buttonPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								buttonPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																buttonPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				retrieve)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				91,
																				Short.MAX_VALUE)
																		.addComponent(
																				showAll)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				hideAll))
														.addGroup(
																buttonPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				delete)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				213,
																				Short.MAX_VALUE)
																		.addComponent(
																				colorLabel)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				colorCombo,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap()));
		buttonPanelLayout
				.setVerticalGroup(buttonPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								buttonPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(retrieve)
														.addComponent(hideAll)
														.addComponent(showAll))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(delete)
														.addComponent(
																colorCombo,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																colorLabel))
										.addContainerGap()));

		definitionLabel.setText("Definition");
		if (currentODE != null)
			definitionField.setText(currentODE.getODEText());
		definitionScrollPane.setViewportView(definitionField);

		org.jdesktop.layout.GroupLayout topPanelLayout = new org.jdesktop.layout.GroupLayout(
				topPanel);
		topPanel.setLayout(topPanelLayout);

		topPanelLayout.setHorizontalGroup(topPanelLayout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.LEADING,
						topPanelLayout.createSequentialGroup()
								.addContainerGap().add(definitionLabel)
								.addContainerGap(393, Short.MAX_VALUE))
				.add(definitionScrollPane,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 482,
						Short.MAX_VALUE));

		topPanelLayout.setVerticalGroup(topPanelLayout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(
				org.jdesktop.layout.GroupLayout.LEADING,
				topPanelLayout
						.createSequentialGroup()
						.addContainerGap()
						.add(definitionLabel)
						.addPreferredGap(
								org.jdesktop.layout.LayoutStyle.RELATED)
						.add(definitionScrollPane,
								org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
								168, Short.MAX_VALUE)));

		org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(
				this);
		this.setLayout(layout);

		layout.setHorizontalGroup(layout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(buttonPanel)
				.add(topPanel, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
						484, Short.MAX_VALUE));

		layout.setVerticalGroup(layout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.TRAILING,
						layout.createSequentialGroup()
								.add(topPanel,
										org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
										377, Short.MAX_VALUE)
								.addPreferredGap(
										org.jdesktop.layout.LayoutStyle.RELATED)
								.add(buttonPanel,
										org.jdesktop.layout.GroupLayout.PREFERRED_SIZE,
										org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
										org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)));
	}
}
