/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JPanel;
import javax.swing.table.AbstractTableModel;

import ui.dialogs.SolverOptionsPanel;
import util.ColorComboBox;
import util.ColorIcon;
import data.Curve;
import data.ODE;

/**
 * CurveInspector defines the right pane of workspacePanel.
 * 
 * It consists of a split panel, with the bottom displaying a data table for the
 * curve selected in the parent DataPanel and the top displaying initial
 * conditions;
 * 
 * The user can select points and copy them, but there is no menu item for the
 * copy command; the user must use the appropriate keystroke for his operating
 * system.
 * 
 * The user can use the buttons at the bottom to delete or configure visual
 * properties of the curve.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */
@SuppressWarnings("serial")
public class CurveInspector extends JPanel {

	/** The selected Curve */
	private Curve currentCurve;
	/** The selected ODE */
	private ODE currentODE;
	/** The solver dialog panel */
	private SolverOptionsPanel solverDialog;
	/** The reference to the ODEWorkspace */
	private ODEWorkspace workspace;
	/** The data panel that owns this inspector */
	private DataPanel owner;

	/** Constants for presentation */
	private static final double LARGEST_NON_SCIENTIFIC_NUMBER = 10000,
			SMALLEST_NON_SCIENTIFIC_NUMBER = 0.0001;
	/** Formatting */
	private DecimalFormat scientificformatter = new DecimalFormat("0.####E0"),
			normalformatter = new DecimalFormat("######.######");

	/** The panel at the top, containing initial conditions */
	private javax.swing.JPanel topPanel;
	/** the scroll pane containing ICTable */
	private javax.swing.JScrollPane icScrollPane;
	/** label for initial condition */
	private javax.swing.JLabel ICLabel;
	/** the table containing initial conditions */
	private javax.swing.JTable ICTable;
	/** table model for initial conditions */
	private ICTableModel icTableModel;
	/** the splitter between initial conditions and data points */
	private javax.swing.JSplitPane dataSplitPane;
	/** the panel on the bottom, containing data points */
	private javax.swing.JPanel bottomPanel;
	/** the scroll pane containing data points */
	private javax.swing.JScrollPane dataScrollPane;
	/** label for data points */
	private javax.swing.JLabel dataLabel;
	/** the data table */
	private javax.swing.JTable dataTable;
	/** table model for data points */
	private DataTableModel dataTableModel;
	/** the panel for buttons at the bottom of the screen */
	private javax.swing.JPanel buttonPanel;
	/** label for curve color */
	private javax.swing.JLabel colorLabel;
	/** The color chooser for curve color */
	private ColorComboBox colorCombo;
	/** The box for show/hide curve */
	private javax.swing.JCheckBox visible;
	/** The view solver parameters button */
	private javax.swing.JButton viewSolver;
	/** the delete button */
	private javax.swing.JButton delete;

	/**
	 * Constructor that creates a CurveInspector for the given ODEWorkspace
	 * 
	 * @param owner
	 *            the data panel that owns this inspector
	 * @param workspace
	 *            the ODEWorkspace associated to this curve inspector
	 */
	public CurveInspector(DataPanel owner, ODEWorkspace workspace) {
		this.owner = owner;
		this.workspace = workspace;
		solverDialog = new SolverOptionsPanel(workspace.getParameters(),
				workspace);
		solverDialog.disallowChanges();
		initComponents();
	}

	/**
	 * Prepare information about the selected curve
	 * 
	 * @param c
	 *            the selected curve
	 * @param o
	 *            the owner of the selected curve
	 */
	public void analyzeCurve(Curve c, ODE o) {

		System.out.println("Curve selected: " + c);

		currentCurve = c;
		currentODE = o;

		if (c != null) {
			try {
				// update information to that of c
				solverDialog.updateSolverParameters(c.getSolverParameters());
				icTableModel.updateSolverParameters(c.getSolverParameters());
				icTableModel.fireTableStructureChanged();
				icScrollPane.setViewportView(ICTable);
				viewSolver.setEnabled(true);
				delete.setEnabled(true);
				colorCombo.setSelectedItem(c.getVisualProperties().getColor());
				colorCombo.setEnabled(true);
				visible.setSelected(c.getVisualProperties().isShown());
				visible.setEnabled(true);
			} catch (Exception e) {

			}
		}

		dataTableModel.fireTableStructureChanged();
		dataScrollPane.setViewportView(dataTable);
	}

	/**
	 * Stop showing information about the current curve
	 */
	public void unfocusCurve() {
		viewSolver.setEnabled(false);
		delete.setEnabled(false);
		icTableModel.updateSolverParameters(null);
		icTableModel.fireTableStructureChanged();
		dataTableModel.fireTableStructureChanged();
		dataScrollPane.setViewportView(null);
		colorCombo.setEnabled(false);
		visible.setEnabled(false);
	}

	/**
	 * Initialize the user interface
	 */
	private void initComponents() {
		// construct objects
		buttonPanel = new javax.swing.JPanel();
		delete = new javax.swing.JButton();
		viewSolver = new javax.swing.JButton();
		colorCombo = new ColorComboBox();
		dataSplitPane = new javax.swing.JSplitPane();
		topPanel = new javax.swing.JPanel();
		ICLabel = new javax.swing.JLabel();
		icScrollPane = new javax.swing.JScrollPane();
		ICTable = new javax.swing.JTable();
		bottomPanel = new javax.swing.JPanel();
		dataLabel = new javax.swing.JLabel();
		dataScrollPane = new javax.swing.JScrollPane();
		dataTable = new javax.swing.JTable();
		visible = new javax.swing.JCheckBox();
		colorLabel = new javax.swing.JLabel();

		// delete button
		delete.setText("Delete Curve");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.removeCurve(currentODE, currentCurve);
				currentODE.removeCurve(currentCurve);
				currentCurve = null;
				unfocusCurve();
				owner.getOwner().setAllAutoScaleNeeded();
			}
		});

		// view solver parameters button
		viewSolver.setText("View Solver Parameters");
		viewSolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				workspace.showDialog(solverDialog);
			}
		});

		// set color box
		colorLabel.setText("Color");
		colorCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentCurve != null)
					currentCurve.getVisualProperties().setColor(
							((ColorIcon) colorCombo.getSelectedItem())
									.getColor());
			}
		});

		// set visibility box
		visible.setText("Visible");
		visible.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentCurve != null)
					currentCurve.getVisualProperties().showHide(
							visible.isSelected());
				owner.getOwner().setAllAutoScaleNeeded();
			}
		});

		// set initial status
		viewSolver.setEnabled(false);
		delete.setEnabled(false);
		colorCombo.setEnabled(false);
		visible.setEnabled(false);

		// code for constructing the interface generated by Netbeans
		javax.swing.GroupLayout buttonPanelLayout = new javax.swing.GroupLayout(
				buttonPanel);
		buttonPanel.setLayout(buttonPanelLayout);
		buttonPanelLayout
				.setHorizontalGroup(buttonPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								buttonPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																buttonPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				viewSolver)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				226,
																				Short.MAX_VALUE)
																		.addComponent(
																				visible))
														.addGroup(
																buttonPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				delete)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				213,
																				Short.MAX_VALUE)
																		.addComponent(
																				colorLabel)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				colorCombo,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap()));
		buttonPanelLayout
				.setVerticalGroup(buttonPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								buttonPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																viewSolver)
														.addComponent(visible))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(delete)
														.addComponent(
																colorCombo,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																colorLabel))
										.addContainerGap()));

		dataSplitPane.setDividerLocation(200);
		dataSplitPane.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
		ICLabel.setText("Initial Conditions");

		icTableModel = new ICTableModel(false);
		ICTable.setModel(icTableModel);
		icScrollPane.setViewportView(ICTable);

		org.jdesktop.layout.GroupLayout topPanelLayout = new org.jdesktop.layout.GroupLayout(
				topPanel);
		topPanel.setLayout(topPanelLayout);

		topPanelLayout.setHorizontalGroup(topPanelLayout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.LEADING,
						topPanelLayout.createSequentialGroup()
								.addContainerGap().add(ICLabel)
								.addContainerGap(393, Short.MAX_VALUE))
				.add(icScrollPane,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 482,
						Short.MAX_VALUE));

		topPanelLayout.setVerticalGroup(topPanelLayout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(
				org.jdesktop.layout.GroupLayout.LEADING,
				topPanelLayout
						.createSequentialGroup()
						.addContainerGap()
						.add(ICLabel)
						.addPreferredGap(
								org.jdesktop.layout.LayoutStyle.RELATED)
						.add(icScrollPane,
								org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
								168, Short.MAX_VALUE)));
		dataSplitPane.setTopComponent(topPanel);

		dataLabel.setText("Point Data");

		dataTableModel = new DataTableModel();
		dataTable.setModel(dataTableModel);
		dataScrollPane.setViewportView(dataTable);

		org.jdesktop.layout.GroupLayout bottomPanelLayout = new org.jdesktop.layout.GroupLayout(
				bottomPanel);
		bottomPanel.setLayout(bottomPanelLayout);

		bottomPanelLayout.setHorizontalGroup(bottomPanelLayout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.LEADING,
						bottomPanelLayout.createSequentialGroup()
								.addContainerGap().add(dataLabel)
								.addContainerGap(422, Short.MAX_VALUE))
				.add(dataScrollPane,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 482,
						Short.MAX_VALUE));

		bottomPanelLayout
				.setVerticalGroup(bottomPanelLayout
						.createParallelGroup(
								org.jdesktop.layout.GroupLayout.LEADING)
						.add(org.jdesktop.layout.GroupLayout.LEADING,
								bottomPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.add(dataLabel)
										.addPreferredGap(
												org.jdesktop.layout.LayoutStyle.RELATED)
										.add(dataScrollPane,
												org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
												140, Short.MAX_VALUE)));
		dataSplitPane.setRightComponent(bottomPanel);

		org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(
				this);
		this.setLayout(layout);

		layout.setHorizontalGroup(layout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(buttonPanel)
				.add(dataSplitPane,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 484,
						Short.MAX_VALUE));

		layout.setVerticalGroup(layout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.TRAILING,
						layout.createSequentialGroup()
								.add(dataSplitPane,
										org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
										377, Short.MAX_VALUE)
								.addPreferredGap(
										org.jdesktop.layout.LayoutStyle.RELATED)
								.add(buttonPanel,
										org.jdesktop.layout.GroupLayout.PREFERRED_SIZE,
										org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
										org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)));
	}

	/**
	 * The table model for data points
	 */
	public class DataTableModel extends AbstractTableModel {

		/**
		 * Returns the number of rows.
		 * 
		 * @return the number of rows
		 */
		public int getRowCount() {
			if (currentCurve == null) {
				return 0;
			}
			if (currentCurve.getPoints() == null
					|| currentCurve.getPoints().length == 0)
				return 0;

			if (currentCurve.getPoints()[0] == null)
				return 0;

			return currentCurve.getPoints()[0].length;
		}

		/**
		 * Returns the number of columns.
		 * 
		 * @return the number of columns
		 */
		public int getColumnCount() {
			// System.out.println("Looking for columns...");
			if (currentCurve == null) {
				return 0;
			}
			if (currentCurve.getVariables() == null)
				return 0;
			else {
				// System.out.println("Found variables: " +
				// currentCurve.variables.length);
				return currentCurve.getVariables().size();
			}
		}

		/**
		 * Returns the name of the column
		 * 
		 * @param columnIndex
		 *            the column index
		 * @return the name of the specified column
		 */
		public String getColumnName(int columnIndex) {
			return currentODE.getVariables().get(columnIndex);
		}

		/**
		 * Returns whether the cell is editable, which is false in data tab
		 * 
		 * @param rowIndex
		 *            the row index
		 * @param columnIndex
		 *            the column index
		 * @return true iff the specified cell is editable
		 */
		@Override
		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return false;
		}

		/**
		 * Returns the value at the specified cell
		 * 
		 * @param rowIndex
		 *            the row index
		 * @param columnIndex
		 *            the column index
		 * @return the value at the specified cell
		 */
		public Object getValueAt(int rowIndex, int columnIndex) {
			if (currentCurve.getPoints() == null
					|| currentCurve.getPoints().length <= columnIndex)
				return new Double(0);
			if (currentCurve.getPoints()[0] == null
					|| currentCurve.getPoints()[0].length <= rowIndex)
				return new Double(0);
			return pointToString(currentCurve.getPoints()[columnIndex][rowIndex]);
		}
	}

	/**
	 * Converts a double representing data point to a string
	 * 
	 * @param point
	 *            the double to convert
	 * @return the string corresponding to the given point
	 */
	public String pointToString(double point) {
		String text;
		Double magnitude = Math.abs(point);

		if (magnitude >= LARGEST_NON_SCIENTIFIC_NUMBER
				|| magnitude < SMALLEST_NON_SCIENTIFIC_NUMBER) {
			text = scientificformatter.format(point);
		} else {
			text = normalformatter.format(point);
		}
		if (text == "0E0") {
			return "0";
		}
		return text;
	}

}
