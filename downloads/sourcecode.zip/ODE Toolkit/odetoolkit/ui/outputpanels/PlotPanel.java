/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.awt.print.PrinterJob;
import java.io.FileOutputStream;
import java.util.Vector;

import javax.swing.JPanel;

import util.PointClickedListener;
import data.Axis;
import data.ODEVar;
import data.ODEVarVector;
import data.plotstates.MultiPlotState;
import data.plotstates.PlotState;
import data.plotstates.SinglePlotState;

/**
 * This class provides a labeled box within which to place a data plot. Zooming
 * in and out is supported, as is panning. When calling the methods, in most
 * cases the changes will not be visible until paint() has been called. To
 * request that this be done, call repaint().
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
@SuppressWarnings("serial")
public class PlotPanel extends JPanel {
	/** The owner of this Plot */
	private GraphPanel graphPanelOwner;
	/** The state of this plot */
	private PlotState state;
	/** Keep track of whether the option is being used */
	private boolean panning, zooming;
	/** Keep track of the current mode */
	private transient boolean zoomMode, panMode, icMode, equMode,
			plotOrbitMode = false;
	/** Keep track of whether there is a pop-up */
	private boolean _popupMode = false;

	/** Keep track of the mouse position when dragging */
	private transient Point mouseOrigin, mouseIntermediate;

	/** the actual area of the screen devoted to displaying the plot
	 * contents */
	private Rectangle viewingWindow;

	/** Buffer for drawing */
	private static Image buffer;

	/** The image of the plot */
	public static Image toDisplay;

	/** Listener for mouse action */
	private transient Vector<PointClickedListener> _pointClickedListeners =
			new Vector<PointClickedListener>();
	/** RenderingHints */
	private RenderingHints renderHints = new RenderingHints(
			RenderingHints.KEY_ANTIALIASING, RenderingHints.
			VALUE_ANTIALIAS_ON);

	// Magic Constants

	// Call setXORMode with a hardwired color because
	// _background does not work in an application,
	// and _foreground does not work in an applet
	/** Color constant */
	private static final Color ZOOM_BOX_COLOR = Color.GRAY;
	/** Color constant */
	private static final Color ZOOM_BOX_FILL_COLOR = new Color(0.29f, 0.133f,
			0.0f);
	/** Constant */
	public static final int GUIDE_BOX_SIDE = 15;

	/**
	 * Constructor that creates a plotpanel from a plotstate
	 * 
	 * @param owner
	 *            the GraphPanel that owns this plotpanel
	 * @param s
	 *            the state of the plot
	 */
	public PlotPanel(GraphPanel owner, PlotState s) {
		graphPanelOwner = owner;

		renderHints.put(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_SPEED);

		setLayout(new FlowLayout(FlowLayout.RIGHT));

		addMouseListener(new ZoomListener());
		addMouseMotionListener(new DragListener());
		state = s;

		// default starting mode is always Pick Initial Conditions.
		setICMode();

		// Just so this isn't null.
		viewingWindow = new Rectangle();
	}

	/**
	 * Just used by paint; checks to see if the buffer's size is incorrect
	 * 
	 * @return whether the buffer needs to be recreated
	 */
	private boolean needNewBuffer() {
		if (buffer == null)
			return true;
		boolean wrongWidth = (buffer.getWidth(null) != getWidth());
		boolean wrongHeight = (buffer.getHeight(null) != getHeight());
		return (wrongWidth || wrongHeight);
	}

	/**
	 * Paint the component contents.
	 * 
	 * @param graphics
	 *            The graphics context.
	 */
	@Override
	public void paint(Graphics graphics) {
		if (needNewBuffer()) {
			buffer = createImage(graphics.getClipBounds().width,
					graphics.getClipBounds().height);
		}

		// Return if size has not been set.
		if (!_popupMode && !zooming && !panning)
		// Panning, zooming and popups need to redraw differently
		{
			// Double buffer for maximally smooth rendering.

			Graphics2D gBuffer = (Graphics2D) buffer.getGraphics();

			gBuffer.setClip(graphics.getClipBounds());

			// draw the panel background
			super.paint(gBuffer);

			// This actually draws the various components of the plot panel
			viewingWindow = state.drawMe(gBuffer);
		}
		graphics.drawImage(buffer, 0, 0, null);
	}

	/**
	 * Removes all solution specific information from the plot and resets to
	 * initial ranges.
	 */
	public void clear() {
		state.clear();
	}

	/**
	 * Repaints and autoscales if autoscale is on.
	 */
	public synchronized void fillPlot() {
		state.setAutoscaleNeeded();
		repaint();
	}

	/**
	 * Prints the plot (on a printer)
	 */
	public void printPlot() {
		PrinterJob printJob = PrinterJob.getPrinterJob();
		printJob.setPrintable(state);
		if (printJob.printDialog()) {
			try {
				printJob.print();
			} catch (Exception e) {
				System.out.println("Error printing");
			}
		}
	}

	/**
	 * Add pointClickedListeners to be notified when a user clicks on the
	 * screen.
	 * 
	 * @param pcl
	 *            The PointClickedListener to notify.
	 */
	public void addPointClickedListener(PointClickedListener pcl) {
		_pointClickedListeners.add(pcl);
	}

	/**
	 * Notifies all the PointClickedListeners of a user clicking a point on the
	 * screen
	 * 
	 * @param point
	 *            A 2 element array of doubles containing the coordinates of the
	 *            point clicked.
	 */
	public void notifyPointClickedListeners(Point2D.Double point) {
		for (int i = 0; i < _pointClickedListeners.size(); i++)
			(_pointClickedListeners.elementAt(i)).pointClicked(point);
	}

	/**
	 * Changes the graph's title and repaints it.
	 * 
	 * @param s
	 */
	public void setTitle(String s) {
		state.setTitle(s);
		repaint();
	}

	/**
	 * Changes the graph's x-axis label and repaints it.
	 * 
	 * @param s
	 */
	public void setXLabel(String s) {
		state.setXLabel(s);
		repaint();
	}

	/**
	 * Changes the graph's y-axis label and repaints it.
	 * 
	 * @param s
	 */
	public void setYLabel(String s) {
		state.setYLabel(s);
		repaint();
	}

	/**
	 * Sets "find equilibrium" mode on. When in this mode the program attempts
	 * to find an equilibrium point from the conditions the user selects. Only
	 * valid for phased graphs.
	 */
	public void setEquMode() {
		equMode = true;
		panMode = false;
		plotOrbitMode = false;
		icMode = false;
		zoomMode = false;
	}

	/**
	 * Set the panning mode on. When we are in panning mode dragging the mouse
	 * along the plot moves the plot axis and redraws the plot. The default mode
	 * is to draw a zoom box.
	 */
	public void setPanMode() {
		equMode = false;
		panMode = true;
		plotOrbitMode = false;
		icMode = false;
		zoomMode = false;
	}

	/**
	 * Set the plot orbit mode on. When we are in plot orbit mode, the behavior
	 * is the same as initial condition mode except that the orbit for the
	 * chosen initial conditions is plotted after the user clicks (solves both
	 * forwards and backwards). Currently only valid for phase graphs.
	 */
	public void setPlotOrbitMode() {
		equMode = false;
		panMode = false;
		plotOrbitMode = true;
		icMode = true;
		/*
		 * THIS IS NOT LIKE THE OTHERS. Whenever _orbitsMode is true, so is
		 * _pointClickedMode.
		 */
		zoomMode = false;
	}

	/**
	 * Sets pick initial conditions mode on. When in this mode, when the user
	 * clicks the program sets initial conditions to that point on the graph.
	 */
	public void setICMode() {
		equMode = false;
		panMode = false;
		plotOrbitMode = false;
		icMode = true;
		zoomMode = false;
	}

	/**
	 * Set the zooming mode on or off. When we are in panning mode dragging the
	 * mouse along the plot moves the plot axis and redraws the plot. The
	 * default mode is to draw a zoom box. @param panning
	 */
	public void setZoomMode() {
		equMode = false;
		panMode = false;
		plotOrbitMode = false;
		icMode = false;
		zoomMode = true;
	}

	/**
	 * Returns whether graph is in plot orbit mode.
	 * 
	 * @return _plotOrbits.
	 */
	public boolean getPlotOrbitMode() {
		return plotOrbitMode;
	}

	/**
	 * Returns whether graph is in equilibrium finder mode.
	 * 
	 * @return _equMode.
	 */
	public boolean getEquMode() {
		return equMode;
	}

	/**
	 * Returns whether graph is in initial conditions mode.
	 * 
	 * @return _icMode
	 */
	public boolean getICMode() {
		return icMode;
	}

	/**
	 * Returns whether graph is in zoom mode.
	 * 
	 * @return _zoomMode
	 */
	public boolean getZoomMode() {
		return zoomMode;
	}

	/**
	 * Returns whether graph is in pan mode.
	 * 
	 * @return _panMode
	 */
	public boolean getPanMode() {
		return panMode;
	}

	/**
	 * Pan the graph based on where the mouse has moved since the button was
	 * clicked on the graph. The argument gives the lower right corner of the
	 * box.
	 * 
	 * @param pt
	 *            The endpoint of the translation started with click, also the
	 *            position that the mouse is now under.
	 */
	private synchronized void _pan(Point pt) {
		graphPanelOwner.setAllAutoScale(false);

		if (pt == null || viewingWindow == null)
			return;

		int deltaX = mouseOrigin.x - pt.x;
		int deltaY = mouseOrigin.y - pt.y;

		Graphics screen = buffer.getGraphics();
		// screen.setXORMode(Color.YELLOW);
		screen.setColor(Color.WHITE);
		screen.fillRect(viewingWindow.x, viewingWindow.y, viewingWindow.width,
				viewingWindow.height);
		screen.setColor(Color.BLACK);
		screen.setClip(viewingWindow);

		int transx = -(state.getExtraX() + deltaX);
		int transy = -(state.getExtraY() + deltaY);
		screen.translate(transx, transy);

		screen.drawImage(PlotPanel.toDisplay, viewingWindow.x, viewingWindow.y,
				null);

		repaint();
	}

	/**
	 * Zoom in or out based on the box that has been drawn. The argument gives
	 * the lower right corner of the box. @param x The final x position. @param
	 * y The final y position.
	 */
	private void _zoom(Point pt) {
		graphPanelOwner.setAllAutoScale(false);

		if (viewingWindow == null)
			return;

		zooming = false;
		Point upperLeftCorner, lowerRightCorner;
		Rectangle pseudoViewingWindow;

		if (pt.y > mouseOrigin.y) // if we are zooming in
		{
			upperLeftCorner = new Point(Math.min(pt.x, mouseOrigin.x),
					Math.min(pt.y, mouseOrigin.y));
			lowerRightCorner = new Point(Math.max(pt.x, mouseOrigin.x),
					Math.max(pt.y, mouseOrigin.y));

			pseudoViewingWindow = viewingWindow;
		} else // Zooming out
		{
			/*
			 * Here the psuedo window is the inner guide window drawn on the
			 * screen, and the uppperLeft and lowerRight points are the corners
			 * of the drawn box.
			 */
			pseudoViewingWindow = new Rectangle(mouseOrigin.x - GUIDE_BOX_SIDE,
					mouseOrigin.y - GUIDE_BOX_SIDE, 2 * GUIDE_BOX_SIDE,
					2 * GUIDE_BOX_SIDE);
			int xOffset = Math.abs(mouseOrigin.x - pt.x) + GUIDE_BOX_SIDE;
			int yOffset = mouseOrigin.y - pt.y + GUIDE_BOX_SIDE;
			upperLeftCorner = new Point(mouseOrigin.x - xOffset, mouseOrigin.y
					- yOffset);
			lowerRightCorner = new Point(mouseOrigin.x + xOffset, mouseOrigin.y
					+ yOffset);
		}
		state.zoomAxes(upperLeftCorner, lowerRightCorner, pseudoViewingWindow);

	}
	
	/**
	 * Zoom in or out based on vertical mouse movement
	 * 
	 * @param pt
	 *            The final position of the mouse
	 */
	private synchronized void _zoomDrag(Point pt) {
		if (pt == null || !viewingWindow.contains(pt)) {
			System.out.println("_zoomDrag called at inappropriate time");
			return;
		}
		
		Axis xAxis = state.getXAxis();
		Axis yAxis = state.getYAxis();
		
		int deltaY = mouseOrigin.y - pt.y;
		int xPix = xAxis.plotToPixelCoords(xAxis.getLength(),
				viewingWindow.width) - xAxis.plotToPixelCoords(0, 
						viewingWindow.width);
		int yPix = yAxis.plotToPixelCoords(yAxis.getLength(),
				viewingWindow.height) - yAxis.plotToPixelCoords(0,
						viewingWindow.height);
		double deltaX = ((((double) deltaY) / yPix) * xPix);
		
		Point2D.Double deltaPt = state.pixelToPlotCoords(
				new Point((int) Math.round(deltaX), deltaY), viewingWindow);
		Point2D.Double zeroPt = state.pixelToPlotCoords(
				new Point(), viewingWindow);
		
		double addX = (deltaPt.getX() - zeroPt.getX()) / 2;
		double addY = (deltaPt.getY() - zeroPt.getY()) / 2;
		
		double newXMin = xAxis.getRangeMin() + addX;
		double newYMin = yAxis.getRangeMin() - addY;
		double newXMax = xAxis.getRangeMax() - addX;
		double newYMax = yAxis.getRangeMax() + addY;
		
		Point upperLeft = state.plotToPixelCoords(
				new Point2D.Double(newXMin, newYMax), viewingWindow);
		Point lowerRight = state.plotToPixelCoords(
				new Point2D.Double(newXMax, newYMin), viewingWindow);
		
		int upperLeftX = upperLeft.x + state.getExtraX() - 59;
		int upperLeftY = upperLeft.y + state.getExtraY() - 40;
		int newWidth = lowerRight.x + state.getExtraX() - 59;
		int newHeight = lowerRight.y + state.getExtraY() - 40;
		
		int sx = viewingWindow.width + viewingWindow.x;
		int sy = viewingWindow.height + viewingWindow.y;
		
		Graphics screen = buffer.getGraphics();
		screen.setColor(Color.WHITE);
		screen.fillRect(viewingWindow.x, viewingWindow.y, viewingWindow.width,
				viewingWindow.height);
		screen.setColor(Color.BLACK);
		screen.setClip(viewingWindow);
		
		screen.drawImage(PlotPanel.toDisplay, viewingWindow.x, viewingWindow.y,
				sx, sy, upperLeftX, upperLeftY, newWidth, newHeight, null);
		repaint();
	}

	/**
	 * This function essentially forces the graph to do nothing the next time
	 * repaint is called, after which repaint behaves normally. This function
	 * should be called before displaying popups to prevent weird artifacts from
	 * displaying.
	 */
	public void setPopupMode(boolean b) {
		_popupMode = b;
	}

	/**
	 * Draw a box for an interactive zoom box. The starting point (the upper
	 * left corner of the box) is taken to be that specified by the startZoom()
	 * method. The argument gives the lower right corner of the box. If a
	 * previous box has been drawn, erase it first.
	 * 
	 * @param pt
	 *            The lower right corner of the box
	 */
	private synchronized void _zoomBox(Point pt) {
		// We make this method synchronized so that we can draw the drag
		// box properly. If this method is not synchronized, then
		// we could end up calling setXORMode, being interrupted
		// and having setPaintMode() called in another method.

		// NOTE: Due to a bug in JDK 1.1.7B, the BUTTON1_MASK does
		// not work on mouse drags, thus we have to use this variable
		// to determine whether we are actually zooming.

		// NOTE: This happens way too often when not in zoom mode. Need to be
		// fixed?
		if (!zooming || pt == null || !viewingWindow.contains(pt)) {
			System.out.println("_zoomBox called at inappropriate time");
			return;
		}

		Graphics graphics = buffer.getGraphics();
		if (mouseOrigin.y < pt.y) // Zooming in
		{
			// Draw a box with top left corner at minPt
			Point minPt = new Point(Math.min(mouseOrigin.x, pt.x), Math.min(
					mouseOrigin.y, pt.y));

			// With width and height equal to how far you've dragged
			int width = Math.abs(mouseOrigin.x - pt.x);
			int height = Math.abs(mouseOrigin.y - pt.y);

			// Paint the box over what is on the graph
			graphics.setXORMode(ZOOM_BOX_COLOR);
			graphics.drawRect(minPt.x, minPt.y, width, height);
			graphics.setXORMode(ZOOM_BOX_FILL_COLOR);
			if (height > 1 && width > 1) {
				graphics.fillRect(minPt.x + 1, minPt.y + 1, width - 1,
						height - 1);
			}
		} else {
			// The upper left corner of the box is a distance to the left of
			// the mouse origin equal to the distance between the mouse and the
			// mouse origin plus GUIDE_BOX_SIDE pixels.
			int boxLeftCorner = mouseOrigin.x - GUIDE_BOX_SIDE
					- Math.abs(mouseOrigin.x - pt.x);

			Point boxPt = new Point(boxLeftCorner, pt.y - GUIDE_BOX_SIDE);

			// (0,0) is in the upper left hand corner of the plot panel.
			// x gets larger as it goes to the right, y gets larger as it goes
			// down. width and height are therefore always positive.
			int width = 2 * (mouseOrigin.x - boxPt.x);
			int height = 2 * (mouseOrigin.y - boxPt.y);

			graphics.setXORMode(ZOOM_BOX_COLOR);

			// draw the "guide" box
			graphics.drawRect(mouseOrigin.x - GUIDE_BOX_SIDE, mouseOrigin.y
					- GUIDE_BOX_SIDE, 2 * GUIDE_BOX_SIDE, 2 * GUIDE_BOX_SIDE);

			// draw the main box
			graphics.drawRect(boxPt.x, boxPt.y, width, height);
			if (width > 1 && height > 1) {
				graphics.setXORMode(ZOOM_BOX_FILL_COLOR);
				graphics.fillRect(boxPt.x + 1, boxPt.y + 1, width - 1,
						height - 1);
			}
		}
		graphics.setPaintMode();
		repaint();
	}

	/**
	 * Informs program that it is no longer zooming or panning.
	 */
	private synchronized void _stopMode() {
		panning = false;
		zooming = false;
		mouseOrigin = null;
		mouseIntermediate = null;
	}

	/************************ inner classes *******************************/

	public class ZoomListener implements MouseListener {

		public void mouseClicked(MouseEvent event) {
		}

		public void mouseEntered(MouseEvent event) {
		}

		public void mouseExited(MouseEvent event) {
		}

		public void mousePressed(MouseEvent event) {
			if (!isEnabled() || viewingWindow == null) {
				return;
			}

			if ((event.getModifiers() & InputEvent.BUTTON1_MASK) != 0
					|| event.getModifiers() == 0) {
				
				if (event.isShiftDown()) {
					Point ptTemp = new Point(event.getX(), event.getY());
					if (viewingWindow.contains(ptTemp)) {
						zooming = true;
						mouseOrigin = ptTemp;
					}
				}

				else if (icMode || equMode || plotOrbitMode) {
					// notify all the pointClickedListeners with the point
					// that has been selected.

					Point clickedAt = new Point(event.getX(), event.getY());

					// Convert the java's graphic coordinates to
					// equation's coordinates.

					Point2D.Double point = new Point2D.Double();
					point = state.pixelToPlotCoords(clickedAt, viewingWindow);

					notifyPointClickedListeners(point);

					if (plotOrbitMode) {

					}
				}

				else if (panMode)
				// if we are in _panMode and we just clicked, we start panning
				// from the point we just clicked
				{
					Point ptTemp = new Point(event.getX(), event.getY());
					if (viewingWindow.contains(ptTemp)) {
						panning = true;
						mouseOrigin = ptTemp;
					}
				}

				else if (zoomMode)
				// if we are in _zoomMode and we just clicked, we start zooming
				// from the point we just clicked.
				{
					Point ptTemp = new Point(event.getX(), event.getY());
					if (viewingWindow.contains(ptTemp)) {
						zooming = true;
						mouseOrigin = ptTemp;
					}
				}

			}
		}

		public void mouseReleased(MouseEvent event) {
			Point ptTemp = new Point(event.getX(), event.getY());
			if ((zooming || panning) && event.isPopupTrigger()) {
				_stopMode();
				event.consume();
				return;
			}

			if ((event.getModifiers() & InputEvent.BUTTON1_MASK) != 0
					|| event.getModifiers() == 0) {
				if (event.isShiftDown()) {
					graphPanelOwner.setAllAutoScale(false);
					int deltaY = (mouseOrigin.y - ptTemp.y);
					state.zoomDrag(deltaY, viewingWindow);
				}
				else if (zooming) {
					_zoom(ptTemp);
				}

				else if (panning) {
					int xOffset = mouseOrigin.x - event.getX();
					int yOffset = mouseOrigin.y - event.getY();
					state.panAxes(xOffset, yOffset, viewingWindow);
				}
				_stopMode();

				if (!event.isPopupTrigger())
					repaint();
			}
		}
	}

	/**
	 * This class decides how to draw the zoom boxes and where to pan the graph.
	 */
	public class DragListener implements MouseMotionListener {
		public void mouseDragged(MouseEvent event) {
			Point eventPt = new Point(event.getX(), event.getY());
			if (!isEnabled()) {
				return;
			}

			if (panning && !event.isShiftDown()) {
				// need to use image buffer here: come back
				// The offscreen plot must be pasted on to the
				// graphics buffer, offset by the displacement between
				// our current mouse coordinate and the mouse origin.
				// probably uses getGraphics.drawImage
				_pan(mouseIntermediate);
				mouseIntermediate = eventPt;
				_pan(mouseIntermediate);
				return;
			}

			if (((event.getModifiers() & InputEvent.BUTTON1_MASK) != 0) && !event.isShiftDown()) {
				_zoomBox(mouseIntermediate);
				mouseIntermediate = eventPt;
				_zoomBox(mouseIntermediate);
			}
			
			if (((event.getModifiers() & InputEvent.BUTTON1_MASK) != 0) && event.isShiftDown()) {
				_zoomDrag(mouseIntermediate);
				mouseIntermediate = eventPt;
				_zoomDrag(mouseIntermediate);
			}

		}

		public void mouseMoved(MouseEvent event) {
		}
	}

	/**
	 * Returns the plot's title.
	 * 
	 * @return the plot's title
	 */
	public String getTitle() {
		return state.getTitle();
	}

	/**
	 * Returns the plot's x-axis label.
	 * 
	 * @return the plot's x-axis label
	 */
	public String getXLabel() {
		return state.getXLabel();
	}

	/**
	 * Returns the plot's y-axis label.
	 * 
	 * @return the plot's y-axis label
	 */
	public String getYLabel() {
		return state.getYLabel();
	}

	/**
	 * Toggles gridlines on or off.
	 * 
	 * @param on
	 *            true iff turn the gridlines on, false otherwise
	 */
	public void setGrid(boolean on) {
		state.setGrid(on);
	}

	/**
	 * Returns the range of the x-axis.
	 * 
	 * @return the range of the x-axis
	 */
	public double[] getXRange() {
		return state.getXRange();
	}

	/**
	 * Returns the range of the y-axis.
	 * 
	 * @return the range of the y-axis
	 */
	public double[] getYRange() {
		return state.getYRange();
	}

	/**
	 * sets x-axis log-scale on or off.
	 * 
	 * @param log
	 *            true iff set to on, false otherwise
	 */
	public void setLogscaleX(boolean log) {
		state.setLogscaleX(log);
		if (!log && getAutoScale())
			autoScaleAxis(0);
	}

	/**
	 * sets y-axis log-scale on or off.
	 * 
	 * @param log
	 *            true iff set to on, false otherwise
	 */
	public void setLogscaleY(boolean log) {
		state.setLogscaleY(log);
		if (!log && getAutoScale())
			autoScaleAxis(1);
	}

	/**
	 * Tells state it needs a new autoscale, and redraws the graph. Executes
	 * when a solution received event is triggered.
	 */
	public void solutionReceived() {
		setAutoscaleNeeded();
		setPopupMode(false);
		repaint();
	}

	/**
	 * Readjust the scale and repain when a new Equilibrium is received.
	 */
	public void equilibriumReceived() {
		setAutoscaleNeeded();
		setPopupMode(false);
		repaint();
	}

	/**
	 * Returns the plotstate.
	 * 
	 * @return the plotstate
	 */
	public PlotState getPlotState() {
		return state;
	}

	/**
	 * Returns whether the autoscale is on.
	 * 
	 * @return whether the autoscale is on
	 */
	public boolean getAutoScale() {
		return state.getAutoscale();
	}

	/**
	 * Sets auto-scaling on or off.
	 * 
	 * @param scale
	 *            true iff set to on, false otherwise
	 */
	public void setAutoscale(boolean scale) {
		state.setAutoscale(scale);
	}

	/**
	 * Tells the state that, if autoscale is on, the graph needs to be
	 * autoscaled.
	 */
	public void setAutoscaleNeeded() {
		state.setAutoscaleNeeded();
	}

	/**
	 * Auto-scales the specified axis.
	 * 
	 * @param axis
	 *            int representing the axis (0 for x, 1 for y)
	 */
	public void autoScaleAxis(int axis) {
		state.autoscale(axis);
	}

	/**
	 * Returns the variable plotted on the x-axis.
	 * 
	 * @return the variable plotted on the x-axis
	 */
	public ODEVar getXVar() {
		return state.getXVar();
	}

	/**
	 * @return all variables plotted on the y-axis
	 */
	public ODEVarVector getYVars() {
		ODEVarVector foo = new ODEVarVector();
		try {
			foo.add(((SinglePlotState) state).getYVar());
			return foo;
		} catch (Exception e) {
			try {
				return (((MultiPlotState) state).getYVars());
			} catch (Exception f) {
				return null;
			}
		}
	}

	/**
	 * Exports the graph to PostScript.
	 * 
	 * @param out
	 *            the output stream
	 */
	public void export(FileOutputStream out) {
		state.export(out, getWidth(), getHeight());
	}

	/**
	 * Forcibly autoscales the graph.
	 */
	public void scalePlotToFit() {
		setAutoscale(true);
		graphPanelOwner.setAllAutoScale(true);
		setAutoscaleNeeded();
		repaint();
	}

	/**
	 * Sets the autoscale and, if the autoscale is changed to on, forcibly
	 * autoscales the graph.
	 * 
	 * @param aS
	 *            true iff set to true, false otherwise
	 */
	public void updateAutoScale(boolean aS) {
		setAutoscale(aS);
		if (aS)
			fillPlot();
	}
	
	/**
	 * Zooms the plot out so that shapes are preserved.
	 */
	public void setZoomSquare() {
		state.zoomSquare(viewingWindow);
		repaint();
	}

	/**
	 * Sets the ranges of the axes.
	 * 
	 * @param xMin
	 *            the minimum value on x-axis
	 * @param xMax
	 *            the maximum value on x-axis
	 * @param yMin
	 *            the minimum value on y-axis
	 * @param yMax
	 *            the maximum value on y-axis
	 */
	public void setRange(double xMin, double xMax, double yMin, double yMax) {
		state.setXRange(xMin, xMax);
		state.setYRange(yMin, yMax);
		repaint();
	}

	/*
	 * Dir field functions--these are only applicable if state is a
	 * SinglePlotState and will fail with an error otherwise.
	 */

	/**
	 * returns whether or not the variables on this plot have a dir-field.
	 */
	public boolean isDirFieldPossible() {
		return state.isDirFieldPossible();
	}

	/**
	 * Turns dirFields on or off.
	 * 
	 * @param dirFieldOn
	 *            true iff turn on, false otherwise
	 */
	public void setDirFieldOn(boolean dirFieldOn) {
		try {
			((SinglePlotState) state).setDirectionFieldOn(dirFieldOn);
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
		}
	}

	/**
	 * Returns whether the graph's dirfield is on or off.
	 * 
	 * @return true iff the graph's dirfield is on, false otherwise
	 */
	public boolean getDirFieldOn() {
		try {
			return ((SinglePlotState) state).getDirectionFieldOn();
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Changes the color of dirfield arrows.
	 * 
	 * @param color
	 *            the new color of the direction field arrows
	 */
	public void setDirColor(Color color) {
		try {
			((SinglePlotState) state).getDirFieldSettings().setDirFieldColor(
					color);
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
		}
	}

	/**
	 * I believe this changes the length of dirfield arrows but am not sure
	 * 
	 * @param d
	 *            the new length of the dirfield arrows
	 */
	public void setDirScale(double d) {
		try {
			((SinglePlotState) state).getDirFieldSettings().setDirScale(d);
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
		}
	}

	/**
	 * Changes how the dirfield is displayed. Can be shown as an arrow, a line,
	 * or a line with a dot.
	 * 
	 * @param type
	 *            the new line type of the dirfield arrows
	 */
	public void setSlopeType(SinglePlotState.DirLineType type) {
		try {
			((SinglePlotState) state).getDirFieldSettings()
					.setDirLineType(type);
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
		}
	}

	/**
	 * Changes the number of arrows on the x-direction of the direction field.
	 * 
	 * @param value
	 *            the number of arrows on the x-direction
	 */
	public void setDirXCount(int value) {
		try {
			((SinglePlotState) state).getDirFieldSettings().setDirXCount(value);
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
		}
	}

	/**
	 * Changes the number of arrows on the y-direction of the direction field.
	 * 
	 * @param value
	 *            the number of arrows on the y-direction
	 */
	public void setDirYCount(int value) {
		try {
			((SinglePlotState) state).getDirFieldSettings().setDirYCount(value);
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
		}
	}

	/**
	 * Sets all dir field settings at once. Sets by value, not reference.
	 * 
	 * @param settings
	 *            the new settings of the direction field
	 */
	public void setDirFieldSettings(SinglePlotState.DirFieldSettings settings) {
		try {
			((SinglePlotState) state).setDirFieldSettings(settings);
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
		}
	}

	/**
	 * Returns the direction field's settings.
	 * 
	 * @return DirField's settings
	 */
	public SinglePlotState.DirFieldSettings getDfSettings() {
		try {
			return ((SinglePlotState) state).getDirFieldCopySettings();
		} catch (Exception e) {
			System.out
					.println("This plotpanel does not contain the wrong kind of PlotState");
			e.printStackTrace();
			return null;
		}
	}
}
