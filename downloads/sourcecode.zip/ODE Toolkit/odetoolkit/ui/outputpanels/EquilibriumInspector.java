/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.table.AbstractTableModel;

import util.ColorComboBox;
import util.ColorIcon;
import data.Equilibrium;
import data.ODE;

/**
 * EquilibriumInspector defines the right pane of workspacePanel.
 * 
 * It consists of a panel displaying the coordinates of the equilibrium point.
 * The user can use the buttons at the bottom to delete or configure visual
 * properties of the Equilibrium.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */

@SuppressWarnings("serial")
public class EquilibriumInspector extends JPanel {
	/** The selected ODE */
	ODE currentODE;
	/** The selected Equilibrium */
	Equilibrium currentEq;
	/** The data panel that owns this inspector */
	private DataPanel owner;

	/** The panel containing the equilibrium point information */
	private javax.swing.JPanel topPanel;
	/** The scroll pane containing the equilibrium point table */
	private javax.swing.JScrollPane eqScrollPane;
	/** The label for the equilibrium point table */
	private javax.swing.JLabel eqLabel;
	/** The equilibrium point table */
	private javax.swing.JTable eqTable;
	/** The model for the equilibrium point */
	private EqTableModel eqTableModel;
	/** the panel for buttons at the bottom of the screen */
	private javax.swing.JPanel buttonPanel;
	/** label for equilibrium color */
	private javax.swing.JLabel colorLabel;
	/** The color chooser for equilibrium color */
	private ColorComboBox colorCombo;
	/** The box for show/hide equilibrium */
	private javax.swing.JCheckBox visible;
	/** the delete button */
	private javax.swing.JButton delete;

	/**
	 * Constructor that creates a EquilibriumInspector for the given
	 * ODEWorkspace
	 * 
	 * @param owner
	 *            the data panel that owns this inspector
	 * @param workspace
	 *            the ODEWorkspace associated to this inspector
	 */
	public EquilibriumInspector(DataPanel owner, ODEWorkspace workspace) {
		this.owner = owner;
		initComponents();
	}

	/**
	 * Prepare information about the selected equilibrium
	 * 
	 * @param eq
	 *            the selected equilibrium
	 * @param ode
	 *            the owner of the selected equilibrium
	 */
	public void analyzeEquilibrium(Equilibrium eq, ODE ode) {

		System.out.println("Equilibrium selected: " + eq);

		currentEq = eq;
		currentODE = ode;

		if (eq != null) {
			try {
				eqTableModel.updateEquilibrium(eq);
				eqTableModel.fireTableStructureChanged();
				eqScrollPane.setViewportView(eqTable);
				delete.setEnabled(true);
				colorCombo.setSelectedItem(eq.getVisualProperties().getColor());
				colorCombo.setEnabled(true);
				visible.setSelected(eq.getVisualProperties().isShown());
				visible.setEnabled(true);
			} catch (Exception e) {

			}
		}
	}

	/**
	 * Stop showing information about the current equilibrium
	 */
	public void unfocusEquilibrium() {
		eqTableModel.updateEquilibrium(null);
		eqTableModel.fireTableStructureChanged();
		eqScrollPane.setViewportView(null);
		delete.setEnabled(false);
		colorCombo.setEnabled(false);
		visible.setEnabled(false);
	}

	/**
	 * Initialize the user interface
	 */
	private void initComponents() {
		// construct objects
		buttonPanel = new javax.swing.JPanel();
		delete = new javax.swing.JButton();
		colorCombo = new ColorComboBox();
		topPanel = new javax.swing.JPanel();
		eqLabel = new javax.swing.JLabel();
		eqTable = new javax.swing.JTable();
		eqScrollPane = new javax.swing.JScrollPane();
		visible = new javax.swing.JCheckBox();
		colorLabel = new javax.swing.JLabel();

		// delete button
		delete.setText("Delete equilibrium point");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.removeEquilibrium(currentODE, currentEq);
				currentODE.removeEquilibrium(currentEq);
				currentEq = null;
				unfocusEquilibrium();
				owner.getOwner().setAllAutoScaleNeeded();
			}
		});

		// set color box
		colorLabel.setText("Color");
		colorCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentEq != null)
					currentEq.getVisualProperties().setColor(
							((ColorIcon) colorCombo.getSelectedItem())
									.getColor());
			}
		});

		// set visibility box
		visible.setText("Visible");
		visible.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentEq != null)
					currentEq.getVisualProperties().showHide(
							visible.isSelected());
				owner.getOwner().setAllAutoScaleNeeded();
			}
		});

		// initialize other components
		eqLabel.setText("Equilibrium Point");
		colorCombo.setEnabled(false);
		visible.setEnabled(false);

		// create eqTable
		eqTableModel = new EqTableModel();
		eqTable.setModel(eqTableModel);
		eqScrollPane.setViewportView(eqTable);

		// code for constructing the interface generated by Netbeans
		javax.swing.GroupLayout buttonPanelLayout = new javax.swing.GroupLayout(
				buttonPanel);
		buttonPanel.setLayout(buttonPanelLayout);
		buttonPanelLayout
				.setHorizontalGroup(buttonPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								buttonPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																buttonPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				visible))
														.addGroup(
																buttonPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				delete)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				213,
																				Short.MAX_VALUE)
																		.addComponent(
																				colorLabel)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				colorCombo,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap()));
		buttonPanelLayout
				.setVerticalGroup(buttonPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								buttonPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(visible))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												buttonPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(delete)
														.addComponent(
																colorCombo,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																colorLabel))
										.addContainerGap()));

		org.jdesktop.layout.GroupLayout topPanelLayout = new org.jdesktop.layout.GroupLayout(
				topPanel);
		topPanel.setLayout(topPanelLayout);

		topPanelLayout.setHorizontalGroup(topPanelLayout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.LEADING,
						topPanelLayout.createSequentialGroup()
								.addContainerGap().add(eqLabel)
								.addContainerGap(393, Short.MAX_VALUE))
				.add(eqScrollPane,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 482,
						Short.MAX_VALUE));

		topPanelLayout.setVerticalGroup(topPanelLayout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(
				org.jdesktop.layout.GroupLayout.LEADING,
				topPanelLayout
						.createSequentialGroup()
						.addContainerGap()
						.add(eqLabel)
						.addPreferredGap(
								org.jdesktop.layout.LayoutStyle.RELATED)
						.add(eqScrollPane,
								org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
								168, Short.MAX_VALUE)));

		org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(
				this);
		this.setLayout(layout);

		layout.setHorizontalGroup(layout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(buttonPanel)
				.add(topPanel, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
						484, Short.MAX_VALUE));

		layout.setVerticalGroup(layout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.TRAILING,
						layout.createSequentialGroup()
								.add(topPanel,
										org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
										377, Short.MAX_VALUE)
								.addPreferredGap(
										org.jdesktop.layout.LayoutStyle.RELATED)
								.add(buttonPanel,
										org.jdesktop.layout.GroupLayout.PREFERRED_SIZE,
										org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
										org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)));
	}

	/**
	 * The table for Equilibrium Point
	 */
	public class EqTableModel extends AbstractTableModel {
		/** The equilibrium point that this table represents */
		private Equilibrium eq;

		/**
		 * Constructor - do nothing, set the point to null
		 */
		public EqTableModel() {
			eq = null;
		}

		/**
		 * Set the equilibrium to the given one.
		 * 
		 * @param e
		 *            the equilibirum to set to
		 */
		public void updateEquilibrium(Equilibrium e) {
			eq = e;
		}

		/**
		 * Returns the number of rows.
		 * 
		 * @return the number of rows
		 */
		public int getRowCount() {
			return eq.getVariables().size();
		}

		/**
		 * Returns the number of columns.
		 * 
		 * @return the number of columns
		 */
		public int getColumnCount() {
			return 2;
		}

		/**
		 * Returns the name of the column
		 * 
		 * @param columnIndex
		 *            the column index
		 * @return the name of the specified column
		 */
		@Override
		public String getColumnName(int columnIndex) {
			return "";
		}

		/**
		 * Returns the value at the specified cell
		 * 
		 * @param rowIndex
		 *            the row index
		 * @param columnIndex
		 *            the column index
		 * @return the value at the specified cell
		 */
		public Object getValueAt(int rowIndex, int columnIndex) {
			if (columnIndex == 0)
				return eq.getVariables().getName(rowIndex);
			else
				return eq.getPoint()[rowIndex];
		}
	}
}
