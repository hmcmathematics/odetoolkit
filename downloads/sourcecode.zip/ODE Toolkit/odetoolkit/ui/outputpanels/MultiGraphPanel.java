/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.BorderLayout;

import ui.TabbedOutputPanel;
import ui.dialogs.LabelDialog;
import ui.dialogs.ScaleDialog;
import data.ODEVar;
import data.ODEVarVector;
import data.plotstates.MultiPlotState;

/**
 * MultiGraphPanels draw plots of several variables against a single independent
 * variable.
 * 
 * They have contextual menus and toolbar buttons similar to those in
 * PhaseGraphPanel and ComponentGraphPanel. They have dialogs for changing the
 * plot variables, but this feature doesn't appear to work fully yet. Perhaps
 * the MultiPlot2D needs to be updated.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
@SuppressWarnings("serial")
public class MultiGraphPanel extends GraphPanel {

	/**
	 * Constructor for a ComponentGraphPanel, with variables given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param xVar
	 *            the variable associated with x-axis
	 * @param yVars
	 *            the variables to be shown on y-axis
	 */
	public MultiGraphPanel(TabbedOutputPanel owner, ODEVar xVar,
			ODEVarVector yVars) {
		this(owner,
				new MultiPlotState(owner.getODEs(), owner.getCurrentODE(),
						"New Multi-Graph", xVar, yVars, owner.getOwner()
								.getVarKeeper()));
	}
	
	/**
	 * Constructor for a ComponentGraphPanel, with variables and bounds given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param xVar
	 *            the variable associated with x-axis
	 * @param yVars
	 *            the variables to be shown on y-axis
	 * @param xMin
	 *            the lower bound for the x-axis
	 * @param xMax
	 *            the upper bound for the x-axis
	 * @param yMin
	 *            the lower bound for the y-axis
	 * @param yMax
	 *            the upper bound for the y-axis
	 */
	public MultiGraphPanel(TabbedOutputPanel owner, ODEVar xVar,
			ODEVarVector yVars, double xMin, double xMax, double yMin,
			double yMax) {
		this(owner,
				new MultiPlotState(owner.getODEs(), owner.getCurrentODE(),
						"New Multi-Graph", xVar, yVars, owner.getOwner()
								.getVarKeeper(), xMin, xMax, yMin, yMax));
	}

	/**
	 * Constructor for a ComponentGraphPanel, with MultiPlotState given.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owning this GraphPanel
	 * @param state
	 *            the state of the plot
	 */
	public MultiGraphPanel(TabbedOutputPanel owner, MultiPlotState state) {
		super(owner);

		if (state != null) {
			// Initialization
			plotPanel = new PlotPanel(this, state);
			availableTools = new String[] { // Available mouse-action tools
			"Pick Initial Conditions", "Pan", "Zoom", };
			toolbar = new PlotToolbar(this);

			popupMenu = new PlotPanelPopup(this);

			plotPanel.addPointClickedListener(this);
			plotPanel.addMouseListener(new PopupListener(popupMenu));

			// Layout
			setLayout(new BorderLayout());
			add(toolbar, "North");
			add(plotPanel);

			scaleDialog = new ScaleDialog(this);
			labelDialog = new LabelDialog(this);
		}
	}

	/**
	 * Set the visibility of the plot panel
	 */
	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);
		plotPanel.setVisible(visible);
	}

	/**
	 * Returns the name that should be on this graph's tab
	 */
	@Override
	public String getTabName() {
		return new String("Multi-Graph");
	}

	/**
	 * Clears the displayed data. Overriden because MultiGraphPanels don't have
	 * dirfields.
	 */
	@Override
	public void clear() {
		setAllAutoScale(false);
		plotPanel.clear();
		plotPanel.repaint();
	}
}
