/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import javax.swing.JPanel;

import ui.TabbedOutputPanel;

/**
 * Output panels are an abstract class, which can currently be either a graph
 * panel or a data panel.
 * 
 * @author Clinic 08-09
 */
@SuppressWarnings("serial")
public abstract class OutputPanel extends JPanel {
	/** The TabbedOutputPanel owner of this panel */
	protected TabbedOutputPanel tabbedOutputPanelOwner;

	/**
	 * Empty constructor for use by subclasses
	 */
	protected OutputPanel() {
	}

	/**
	 * Constructor using a given TabbedOutputPanel
	 * 
	 * @param owner
	 *            the TabbedOutputPanel owner for this panel
	 */
	public OutputPanel(TabbedOutputPanel owner) {
		this.tabbedOutputPanelOwner = owner;
	}

	/**
	 * Action to be done when gain focus - nothing for default.
	 */
	public void gainedFocus() {
	}

	/**
	 * Check whether this panel supports printing.
	 */
	public abstract boolean canPrint();

	/**
	 * Prints the panel, which in turn launches the printing dialog box.
	 */
	public abstract void print();

	/**
	 * Exports the panel to a postscript file.
	 */
	public abstract void exportPostscript();

	/**
	 * Clears the displayed data.
	 */
	public abstract void clear();

	/**
	 * Returns the name that should be on this graph's tab.
	 */
	public abstract String getTabName();

	/**
	 * Response when a new solution (Curve) is available.
	 */
	public abstract void solutionReceived();

	/**
	 * Response when a new Equilibrium is available.
	 */
	public abstract void equilibriumReceived();
}
