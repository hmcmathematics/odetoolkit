/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import javax.swing.table.AbstractTableModel;

import solver.SolverParameters;

@SuppressWarnings("serial")
public class ICTableModel extends AbstractTableModel {
	/** The solver parameters that contains the initial condition */
	private SolverParameters sparams;
	/** Keep whether the cell should be editable */
	boolean editable;

	/**
	 * Constructor that creates a new table model for initial condition
	 * 
	 * @param edit
	 *            whether the initial condition should be editable
	 */
	public ICTableModel(boolean edit) {
		this.sparams = null;
		editable = edit;
	}

	/**
	 * Update the solver parameters to the given one
	 * 
	 * @param params
	 *            the new solver paramters
	 */
	public void updateSolverParameters(SolverParameters params) {
		sparams = params;
	}

	/**
	 * Returns the number of rows.
	 * 
	 * @return the number of rows
	 */
	public int getRowCount() {
		if (this.sparams == null) {
			return 0;
		}
		try {
			return sparams.getVariables().size();
		} catch (Exception e) {
			return 0;
		}
	}

	/**
	 * Returns the number of columns, which is 2.
	 * 
	 * @return the number of columns
	 */
	public int getColumnCount() {
		return 2;
	}

	/**
	 * Returns the name of the column
	 * 
	 * @param columnIndex
	 *            the column index
	 * @return the name of the specified column
	 */
	@Override
	public String getColumnName(int columnIndex) {
		return "";
	}

	/**
	 * Returns whether the cell is editable, which is false in data tab
	 * 
	 * @param rowIndex
	 *            the row index
	 * @param columnIndex
	 *            the column index
	 * @return true iff the specified cell is editable
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return editable && columnIndex == 1;
	}

	/**
	 * Returns the value at the specified cell
	 * 
	 * @param rowIndex
	 *            the row index
	 * @param columnIndex
	 *            the column index
	 * @return the value at the specified cell
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {
		if (columnIndex == 0)
			return sparams.getVarName(rowIndex);
		else
			return sparams.getInitialConditions()[rowIndex];
	}

	/**
	 * Sets the value at the specified cell
	 * 
	 * @param text
	 *            the value to set to
	 * @param rowIndex
	 *            the row index
	 * @param columnIndex
	 *            the column index
	 */
	@Override
	public void setValueAt(Object text, int rowIndex, int columnIndex) {
		double value = sparams.getInitialConditions()[rowIndex];

		if (text instanceof Double)
			value = (Double) text;
		else if (text instanceof String) {
			try {
				value = Double.valueOf((String) text);
			} catch (NumberFormatException e) {
				System.out.println("Invalid initial condition");
			}
		}

		if (columnIndex == 1)
			sparams.setIC(sparams.getVar(rowIndex), value);
	}
}
