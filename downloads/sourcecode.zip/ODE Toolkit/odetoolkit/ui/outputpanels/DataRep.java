/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.io.File;

import javax.swing.JOptionPane;

import ui.GUI;
import data.ODE;
import data.ODEVarKeeper;
import data.WorkspaceData;

/**
 * This class keep track of the mathematical data, which are not directly
 * related to the solving process, of the ODEWorkspace. This includes the
 * WorkspaceData, the file, the ode text, and the variable keeper.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */

public class DataRep {

	ODEWorkspace parent;
	ODEVarKeeper varKeeper;
	WorkspaceData backendWorkspace;
	String oldODEText;
	File currentFile;

	/**
	 * Creates a new Data component of the ODEWorkspace.
	 * 
	 * @param odews
	 *            the ODEWorkspace containing this data component
	 * @param workspaceName
	 *            the name of the workspace
	 */
	public DataRep(ODEWorkspace odews, String workspaceName) {
		parent = odews;
		backendWorkspace = new WorkspaceData(workspaceName);
		backendWorkspace.setODEWorkspace(odews);
		varKeeper = new ODEVarKeeper();
	}

	/**
	 * Returns the WorkspaceData associated with this ODEWorkspace.
	 * 
	 * @return the WorkspaceData associated with this ODEWorkspace
	 */
	public WorkspaceData getWorkspace() {
		return backendWorkspace;
	}

	/**
	 * Returns the name of the workspace.
	 * 
	 * @return the name of the workspace
	 */
	public String getName() {
		return backendWorkspace.getName();
	}

	/**
	 * Set the name of the workspace.
	 * 
	 * @param name
	 *            the new name for the workspace
	 */
	public void setName(String name) {
		backendWorkspace.setName(name);
	}

	/**
	 * Returns the most recent ODE definition.
	 * 
	 * @return the most recent ODE definition
	 */
	public String getODEText() {
		return oldODEText;
	}

	/**
	 * Returns the file corresponding to this ODEWorkspace.
	 * 
	 * @return the file corresponding to this ODEWorkspace, or null if this
	 *         workspace is never saved.
	 */
	public File getFile() {
		return currentFile;
	}

	/**
	 * Set the file corresponding to this ODEWorkspace.
	 * 
	 * @param f
	 *            the file corresponding to this ODEWorkspace
	 */
	public void setFile(File f) {
		currentFile = f;
	}

	/**
	 * Returns the variable keeper of this ODEWorkspace.
	 * 
	 * @return the variable keeper of this ODEWorkspace
	 */
	public ODEVarKeeper getVarKeeper() {
		return varKeeper;
	}

	/**
	 * Set the variable keeper of thie ODEWorkspace.
	 * 
	 * @param keeper
	 *            the variable keeper to set to
	 */
	public void setVarKeeper(ODEVarKeeper keeper) {
		varKeeper = keeper;
	}

	/**
	 * Create a new ODE form the given ODE text if the text is updated at all
	 * 
	 * @param odeText
	 *            the new ODE text
	 * @param gui
	 *            the reference to GUI for showing dialog
	 * @return the new ODE
	 */
	public ODE createODEFromText(String odeText, GUI gui) {
		oldODEText = odeText;
		int odeNumber = parent.getWorkspace().getODENumber() + 1;
	
		ODE newODE = new ODE("ODE" + odeNumber);
	
		if (!newODE.setODEText(odeText + "\n")) {
			gui.showMessage(
					"Invalid input.  For help on entering ODEs and functions,"
							+ " see the tutorial or the help index.",
					"Invalid input", JOptionPane.ERROR_MESSAGE);
			return null;
		}
	
		parent.getWorkspace().updateODENumber();
		backendWorkspace.addODE(newODE);
		return newODE;
	}

	/**
	 * Remove all plot objects - Curves and Equilibrium points
	 */
	public void clearPlotObjectsData() {
		backendWorkspace.clearPlotObjects();
	}
}
