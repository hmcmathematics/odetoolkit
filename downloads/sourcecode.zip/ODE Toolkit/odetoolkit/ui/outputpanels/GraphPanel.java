/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ListIterator;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JToolBar;

import ui.GUI;
import ui.TabbedOutputPanel;
import ui.dialogs.DirFieldDialog;
import ui.dialogs.LabelDialog;
import ui.dialogs.ScaleDialog;
import util.ColorComboBox;
import util.ColorIcon;
import util.ExtensionFilter;
import util.PointClickedListener;
import data.ODEVar;
import data.ODEVarVector;
import data.plotstates.PlotState;

/**
 * GraphPanel is an abstract class defining one of two types of OutputPanels
 * inside a TabbedOutputPanel for an ODEWorkspace, the other class being a
 * DataPanel. GraphPanels are used for displaying a PlotPanel and providing
 * useful functionality to the user for editing the plot view and allowing the
 * user to interact with the graph.
 * 
 * All GraphPanels contain a toolbar and a PlotPanel, as well as a right-click
 * menu for the plot display, and a set of dialogs for modifying the labels,
 * direction fields, and scaling options of the graph.
 * 
 * There are three types of GraphPanels, each defined in a separate subclass:
 * 
 * ComponentGraphPanels are for displaying a single independent variable against
 * the dependent variable.
 * 
 * PhaseGraphPanels are for plotting a pair of independent variables against
 * each other, allowing for direction fields and other phase plot options, such
 * as plotting orbit lines and finding equilibrium points.
 * 
 * MultiGraphPanels are intended for plotting all the independent variables
 * against the dependent variable in a single PlotPanel.
 * 
 * @author Clinic 08-09, modified by Max Comstock 2013
 */
@SuppressWarnings("serial")
public abstract class GraphPanel extends OutputPanel implements
		PointClickedListener {
	/** The plot area of this graph panel */
	protected PlotPanel plotPanel;
	/** The list of tools available in mouse-action */
	protected String[] availableTools;
	/** The toolbar at the top */
	protected PlotToolbar toolbar;

	/** Direction Field Dialog Box */
	protected DirFieldDialog dirFieldDialog;
	/** Change Labels Dialog Box */
	protected LabelDialog labelDialog;
	/** Scaling Dialog Box */
	protected ScaleDialog scaleDialog;

	/** Right-click menu options */
	protected PlotPanelPopup popupMenu;

	/**
	 * Default Constructor, creates a new OutputPanel given a TabbedOutputPanel
	 * 
	 * @param owner
	 *            the TabbedOutputPanel to which the GraphPanel belongs
	 */
	public GraphPanel(TabbedOutputPanel owner) {
		super(owner);
	}

	/**
	 * Accessor function for the PlotPanel associated with this GraphPanel.
	 * 
	 * @return the PlotPanel associated with this GraphPanel
	 */
	public PlotPanel getPlotPanel() {
		return plotPanel;
	}

	/**
	 * Accessor function for the PlotState associated with this GraphPanel.
	 * 
	 * @return the PlotState associated with this GraphPanel
	 */
	public PlotState getPlotState() {
		return plotPanel.getPlotState();
	}

	/**
	 * Stores the point clicked on the plot into the initial conditions table.
	 * First the horizontal coordinate is stored, and then the function iterates
	 * through any possible vertical variables, storing coordinates for any
	 * variable that shows up in that particular PlotPanel.
	 * 
	 * @param initialConditions
	 *            point with the coordinates clicked by the user
	 */
	protected void storeIC(Point2D.Double initialConditions) {
		// store horizontal coordinate
		tabbedOutputPanelOwner
				.storeIC(plotPanel.getXVar(), initialConditions.x);
	
		// store any vertical coordinates
		ODEVar var;
		ODEVarVector yVars = plotPanel.getYVars();
		ListIterator<ODEVar> iter = yVars.listIterator();
		while (iter.hasNext()) // iterate through vertical variables
		{
			var = iter.next();
			tabbedOutputPanelOwner.storeIC(var, initialConditions.y);
		}
	}

	/**
	 * Returns whether the PlotPanel allows a direction field.
	 */
	public boolean isDirFieldPossible() {
		return plotPanel.isDirFieldPossible();
	}

	/**
	 * Returns whether the PlotPanel allows a Plot Orbit and Find Eq Points.
	 */
	public boolean isPlotOrbitPossible() {
		return (this instanceof PhaseGraphPanel);
	}

	/**
	 * This function is called any time auto-scaling is toggled. It updates the
	 * status of auto-scaling in the toolbar and the PlotPanel's right-click
	 * menu, and activates/de-activates the PlotPanel's auto-scaling feature.
	 * 
	 * @param autoScaleOn
	 *            the on/off state of the auto-scaling feature
	 */
	public void setAllAutoScale(boolean autoScaleOn) {
		plotPanel.updateAutoScale(autoScaleOn);
		toolbar.graphOptionsPopup.setAutoScale(autoScaleOn);
		toolbar.setAutoFit(autoScaleOn);
		popupMenu.setAutoScale(autoScaleOn);
		// scaleDialog.setAutoScale(autoScaleOn);
	}

	/**
	 * This function is called any time direction fields are enabled/disabled.
	 * It updates the status of direction fields in the toolbar and the
	 * PlotPanel's right-click menu, and activates/de-activates the PlotPanel's
	 * direction field.
	 * 
	 * @param selected
	 *            true if direction fields are enabled, false otherwise
	 */
	public void setAllDirField(boolean selected) {
		plotPanel.setDirFieldOn(selected);
		toolbar.graphOptionsPopup.setDirField(selected);
		popupMenu.setDirField(selected);

		plotPanel.setPopupMode(false);
		plotPanel.repaint();
	}

	/**
	 * This function is called any time the scaling for the horizontal axis is
	 * changed. It updates the scaling of the horizontal axis in the toolbar and
	 * the PlotPanel's right-click menu, and enables/disables logarithmic
	 * scaling for the PlotPanel's horizontal axis.
	 * 
	 * @param xLogScaleOn
	 *            true if the horizontal axis is log-scaled
	 */
	public void setXLogScale(boolean xLogScaleOn) {
		plotPanel.setLogscaleX(xLogScaleOn);
		toolbar.graphOptionsPopup.setXLog(xLogScaleOn);
		popupMenu.setXLog(xLogScaleOn);

		plotPanel.repaint();
	}

	/**
	 * This function is called any time the scaling for the vertical axis is
	 * changed. It updates the scaling of the vertical axis in the toolbar and
	 * the PlotPanel's right-click menu, and enables/disables logarithmic
	 * scaling for the PlotPanel's vertical axis.
	 * 
	 * @param yLogScaleOn
	 *            true if the vertical axis is log-scaled
	 */
	public void setYLogScale(boolean yLogScaleOn) {
		plotPanel.setLogscaleY(yLogScaleOn);
		toolbar.graphOptionsPopup.setYLog(yLogScaleOn);
		popupMenu.setYLog(yLogScaleOn);

		plotPanel.repaint();
	}

	/**
	 * This function is called any time the grid lines are toggled. It updates
	 * the grid lines checkmark in the toolbar and the PlotPanel's right-click
	 * menu, and enables/disables the visibility of grid lines in the PlotPanel.
	 * 
	 * @param gridOn
	 *            true if grid lines are set to on
	 */
	public void setAllGrid(boolean gridOn) {
		plotPanel.setGrid(gridOn);
		toolbar.graphOptionsPopup.setGrid(gridOn);

		plotPanel.repaint();
	}

	/**
	 * This function is called any time the mouse action tool is changed. It
	 * updates the tool selector in the toolbar and the radio buttons in the
	 * PlotPanel's right-click menu.
	 */
	public void updateTool() {
		toolbar.setToolMode();
		popupMenu.setToolMode();
	}

	/**
	 * This function updates the label dialog with the current labels; it is
	 * called after labels are loaded when the user opens a .ode file.
	 */
	public void updateLabelDialog() {
		labelDialog.storeLabels();
	}

	/**
	 * This function updates the scaling dialog with the current range values;
	 * it is called after ranges are loaded when the user opens a .ode file.
	 */
	public void updateScaleDialog() {
		scaleDialog.updateFields();
	}

	/**
	 * As of right now all GraphPanels can print.
	 */
	@Override
	public boolean canPrint() {
		return true;
	}

	/**
	 * Prints the graph, which in turn launches the printing dialog box.
	 */
	@Override
	public void print() {
		plotPanel.printPlot();
	}

	/**
	 * Clears the displayed data, resets the scale settings to default, and
	 * empties the PlotPanel and PlotState.
	 */
	@Override
	public void clear() {
		plotPanel.clear();
		plotPanel.repaint();
	}

	/**
	 * Paints the GraphPanel, and repaints the PlotPanel.
	 * @param g
	 *            Graphics object corresponding to panel display.
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		plotPanel.repaint();
	}

	/**
	 * Exports the PlotPanel to a postscript file.
	 */
	@Override
	public void exportPostscript() {
		JFileChooser chooser = new JFileChooser();
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.setFileFilter(new ExtensionFilter("Postscript files (*.ps)",
				".ps"));
		chooser.setMultiSelectionEnabled(false);
	
		// display default title
		chooser.setSelectedFile(new File(chooser.getCurrentDirectory()
				.getAbsolutePath(), GUI.activeWorkspace.getName()));
	
		int result = chooser.showSaveDialog(getRootPane());
		if (result == JFileChooser.APPROVE_OPTION) {
			File selectedFile = chooser.getSelectedFile();
			if (selectedFile != null)
				try {
					FileOutputStream out = new FileOutputStream(
							io.ODEFileHandler.appendExtension(
									chooser.getSelectedFile(), ".ps"));
					plotPanel.export(out);
					out.close();
				} catch (Exception ex) {
					System.out.println("Error exporting to PostScript.");
				}
		}
	}

	/**
	 * This function is called any time a new solution is to be painted on the
	 * PlotPanel. It triggers a method in the PlotPanel class that resets the
	 * auto-scaling and redraws the graph given the updated set of curves.
	 */
	@Override
	public void solutionReceived() {
		plotPanel.solutionReceived();

		// store new ranges for scaling dialog
		scaleDialog.storeOriginalRanges();
	}

	@Override
	public void equilibriumReceived() {
		plotPanel.equilibriumReceived();
	}

	/**
	 * Action function required by the PointClickedListener interface. If the
	 * PlotPanel is in 'Pick Initial Conditions' mode, it stores the point
	 * clicked as the new initial conditions and updates the status display with
	 * the new coordinates.
	 * 
	 * @param pt
	 *            the point being clocked
	 */
	public void pointClicked(Point2D.Double pt) {
		if (plotPanel.getICMode())
			storeIC(pt);

		// Displays the clicked point on the status bar
		tabbedOutputPanelOwner.updateStatusPoint(pt);
	}

	/**
	 * Required by the PointClickedListener interface. Never used by any type of
	 * GraphPanel.
	 * 
	 * @param ex
	 *            the exception to be handled
	 */
	public void errorCondition(Exception ex) {
	}

	/**
	 * Required by the PointClickedListener interface. Never used by any type of
	 * GraphPanel.
	 * 
	 * @param error
	 *            string describing error condition
	 */
	public void errorCondition(String error) {
	}

	/**
	 * This class is responsible for the toolbar displayed above a PlotPanel. It
	 * contains a popup menu for graph options, a tool selector box for
	 * selecting the behavior of the mouse on the plot, and easy-access buttons
	 * for fitting the graph to the window and clearing all data.
	 */
	protected class PlotToolbar extends JToolBar {
		/** The owner of this toolbar */
		private GraphPanel graphOwner;

		/** Graph Options Popup Menu Button */
		private JButton graphOptions;
		/** Graph Options Popup */
		private GraphOptionsPopup graphOptionsPopup;

		/** Tool Selector Pull-Down Menu */
		private ToolSelector toolSelector;

		/** 'AutoFit' button */
		private JCheckBox autoFit;
		/** 'ZoomSquare' button */
		private JButton zoomSquare;
		/** 'Clear All' button */
		private JButton clearAll;
		/** 'Color Select' box */
		private ColorComboBox colorCombo;
		
		/** Tool Tip text for the mouse click options */
		private String toolSelectorTips =
				"<html>Pick Initial Conditions:<br>" +
				"Set the initial conditions for the next curve by<br>" +
				"clicking on the graph with the mouse. The selected<br>" +
				"point will be set as the initial condition.<br><br>" +
		
				"Pan:<br>" +
				"Move the graph around within the window by clicking<br>" +
				"and dragging any point on the graph.<br><br>" +
		
				"Zoom:<br>" +
				"Zoom in on part of the graph by clicking and dragging<br>" +
				"the mouse right and down. The window will zoom so that<br>" +
				"it contains the box. Zoom out from the current part of<br>" +
				"the graph by clicking and dragging the mouse up and<br>" +
				"left. The window will zoom out in proportion to the<br>" +
				"relative sizes of the selected region and the black<br>" +
				"box.<br><br>" +
		
				"Plot Orbit:<br>" +
				"Clicking on a point on the graph will set that point as<br>" +
				"the initial condition and automatically solve to find a<br>" +
				"complete orbit on the graph. (Not always availible)<br><br>" +
		
				"Find Equilibrium Point:<br>" +
				"Clicking on a point on the graph will find the<br>" +
				"associated equilibrium point. (Not always availible)<br><br>" +
		
				"Shift-click at any time to zoom.</html>";

		/**
		 * Constructor for the toolbar displayed in a GraphPanel.
		 * 
		 * @param graphPanelOwner
		 *            the GraphPanel containing this toolbar
		 */
		public PlotToolbar(GraphPanel graphPanelOwner) {
			graphOwner = graphPanelOwner;

			initializeComponents(); // Initialize menu items
			addListeners(); // Add listeners
			addComponents(); // Builds the plot panel's toolbar
			setFloatable(false); // Disallows detachment of the toolbar
		}

		/**
		 * Initializes all the components in the GraphPanel's toolbar.
		 */
		@SuppressWarnings("unchecked")
		private void initializeComponents() {
			// Graph Options Menu
			graphOptions = new JButton("Graph Options");
			graphOptionsPopup = new GraphOptionsPopup(graphOwner);

			// Tool Selector Pull-Down Menu
			toolSelector = new ToolSelector();
			toolSelector.setToolTipText(toolSelectorTips);

			// Autofit and Clear buttons
			autoFit = new JCheckBox("AutoFit", true);
			zoomSquare = new JButton("ZoomSquare");
			clearAll = new JButton("Clear All");
			
			// Color selection box
			colorCombo = new ColorComboBox();
			colorCombo.setSelectedIndex(1);
			// Sets the maximum width to be that of the largest color icon
			colorCombo.setPrototypeDisplayValue(colorCombo.getItemAt(5));
			colorCombo.setMaximumSize(colorCombo.getPreferredSize());

			// Disallow focus so that the toolbar buttons don't appear selected
			// whenever they are used.
			graphOptions.setFocusable(false);
			toolSelector.setFocusable(false);
			autoFit.setFocusable(false);
			zoomSquare.setFocusable(false);
			clearAll.setFocusable(false);
			colorCombo.setFocusable(false);
		}

		/**
		 * Adds the listeners for the toolbar buttons. Note: The ToolSelector
		 * class is responsible for listening to the tool selection box.
		 */
		private void addListeners() {
			graphOptions.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					graphOptionsPopup.getPopupMenu().show(graphOptions, 0,
							graphOptions.getHeight());
				}
			});

			autoFit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAllAutoScale(autoFit.isSelected());
				}
			});
			
			zoomSquare.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotPanel.setZoomSquare();
					plotPanel.setPopupMode(false); // necessary to repaint
				}
			});

			clearAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tabbedOutputPanelOwner.clearAllPlotsObjects();
				}
			});
			
			colorCombo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					graphOwner.getPlotState().getCurrentODE().setColor(
							((ColorIcon) colorCombo.getSelectedItem())
							.getColor());
				}
			});
		}

		/**
		 * Adds all the components to the GraphPanel's toolbar.
		 */
		private void addComponents() {
			add(Box.createRigidArea(new Dimension(5, 0)));
			add(graphOptions);

			add(Box.createRigidArea(new Dimension(2, 0)));
			addSeparator();

			add(Box.createRigidArea(new Dimension(2, 0)));
			JLabel mouseActionLabel = new JLabel("Mouse Action:");
			mouseActionLabel.putClientProperty("JComponent.sizeVariant",
					"small");
			add(mouseActionLabel);

			add(Box.createRigidArea(new Dimension(2, 0)));
			add(toolSelector);

			add(Box.createHorizontalGlue());

			add(autoFit);
			add(Box.createRigidArea(new Dimension(7, 0)));
			add(zoomSquare);
			add(Box.createRigidArea(new Dimension(7, 0)));
			add(clearAll);
			add(Box.createRigidArea(new Dimension(7, 0)));
			add(colorCombo);
			add(Box.createRigidArea(new Dimension(5, 0)));
		}

		/**
		 * This function is called whenever another part of the program, such as
		 * the PlotPanel's right-click menu, changes the active tool. It updates
		 * the tool selector box in the toolbar to the appropriate tool.
		 */
		public void setToolMode() {
			// Determine the active tool
			int tool = 0;
			if (plotPanel.getICMode())
				tool = 0;
			if (plotPanel.getPanMode())
				tool = 1;
			if (plotPanel.getZoomMode())
				tool = 2;
			if (plotPanel.getPlotOrbitMode())
				tool = 3;
			if (plotPanel.getEquMode())
				tool = 4;

			// Set the Tool Selector to correct tool
			toolSelector.setSelectedIndex(tool);
		}
		
		/**
		 * Sets the check mark for AutoFit to the correct value when another
		 * part of the program activates or deactivates it.
		 * 
		 * @param autoFitOn
		 *            True if AutoFit is activated
		 */
		public void setAutoFit(boolean autoFitOn) {
			autoFit.setSelected(autoFitOn);
		}
	}

	/**
	 * This class describes the menu activated whenever the 'Graph Options'
	 * button is pressed on the GraphPanel's toolbar. It gives the user the
	 * ability to change the direction field and scaling settings, change
	 * labels, and turn on or off grid lines in the PlotPanel display.
	 */
	protected class GraphOptionsPopup extends JMenu {
		// Graph Options menu
		/** Menu for scaling the graph */
		private JMenu scaling;
		/** Menu for direction field options */
		private JMenu dirField;
		/** Menu for labels of the graph */
		private JMenuItem labels;
		/** Menu for grid lines in the graph */
		private JMenuItem gridLines;

		// Scaling sub-menu
		/** The check box for auto-scaling */
		private JCheckBoxMenuItem autoScaling;
		/** The menu for setting the ranges of the graph */
		private JMenuItem ranges;
		/** The menu for log-scaling settings */
		private JMenu logScaling;

		// Log Scaling sub-menu
		/** The log-scale option for x-axis */
		private JMenuItem logScaleX;
		/** The log-scale option for y-axis */
		private JMenuItem logScaleY;

		// Direction Field sub-menu
		/** The check box for turning direction field on-off */ 
		private JCheckBoxMenuItem dirFieldOn;
		/** Advanced direction field options */
		private JMenuItem dirFieldOptions;

		/**
		 * Constructor for the 'Graph Options' popup menu in the toolbar.
		 * 
		 * @param owner
		 *            the GraphPanel containing this GraphOptionsPopup
		 */
		public GraphOptionsPopup(GraphPanel owner) {
			super("Graph Options"); // Construct a new JMenu titled
			initializeMenuItems(); // Initialize menu items
			addListeners(); // Add listeners
			addMenuItems(); // Build the popup menu
			enableDirFields(); // Enable/disable the direction field
			// menu items
		}

		/**
		 * Initializes all the menu items in the 'Graph Options' menu.
		 */
		private void initializeMenuItems() {
			// Graph Options menu
			scaling = new JMenu("Scaling");
			dirField = new JMenu("Direction Field");
			labels = new JMenuItem("Labels...");
			gridLines = new JCheckBoxMenuItem("Grid Lines", true);

			// Scaling sub-menu
			autoScaling = new JCheckBoxMenuItem("Auto Scaling", true);
			ranges = new JMenuItem("Set Window Ranges...");
			logScaling = new JMenu("Logarithmic Scaling");

			// Log Scaling sub-menu
			logScaleX = new JCheckBoxMenuItem("x-axis", false);
			logScaleY = new JCheckBoxMenuItem("y-axis", false);

			// Direction Field sub-menu
			dirFieldOn = new JCheckBoxMenuItem("Enabled", false);
			dirFieldOptions = new JMenuItem("Options...");

		}

		/**
		 * Adds listeners for all the menu items in the 'Graph Options' menu.
		 */
		private void addListeners() {
			autoScaling.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAllAutoScale(autoScaling.isSelected());
				}
			});

			labels.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (labelDialog == null)
						labelDialog = new LabelDialog(toolbar.graphOwner);
					labelDialog.storeLabels();
					tabbedOutputPanelOwner.showDialog(labelDialog);
					System.out.println("Label dialog box opened.");
				}
			});

			gridLines.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAllGrid(gridLines.isSelected());
				}
			});

			ranges.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scaleDialog.storeOriginalRanges();
					scaleDialog.updateFields();
					tabbedOutputPanelOwner.showDialog(scaleDialog);
					System.out.println("Scaling dialog box opened.");
				}
			});

			logScaleX.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setXLogScale(logScaleX.isSelected());
				}
			});

			logScaleY.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setYLogScale(logScaleY.isSelected());
				}
			});

			dirFieldOn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAllDirField(dirFieldOn.isSelected());
				}
			});

			dirFieldOptions.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tabbedOutputPanelOwner.showDialog(dirFieldDialog);
				}
			});

		}

		/**
		 * Adds the menu items to the 'Graph Options' menu.
		 */
		private void addMenuItems() {
			// Graph Options menu
			add(scaling);
			add(dirField);
			// if (graphOwner instanceof ComponentGraphPanel)
			// add(chooseColor);
			add(labels);
			add(gridLines);

			// Scaling sub-menu
			scaling.add(autoScaling);
			scaling.addSeparator();
			scaling.add(ranges);
			scaling.addSeparator();
			scaling.add(logScaling);

			// Log Scaling sub-menu
			logScaling.add(logScaleX);
			logScaling.add(logScaleY);

			// Direction Field sub-menu
			dirField.add(dirFieldOn);
			dirField.add(dirFieldOptions);

		}

		/**
		 * Grays out the direction field menu items if direction fields cannot
		 * be enabled in this GraphPanel.
		 */
		private void enableDirFields() {
			dirFieldOn.setEnabled(plotPanel.isDirFieldPossible());
			dirFieldOptions.setEnabled(plotPanel.isDirFieldPossible());
		}

		/**
		 * Sets the check mark for auto-scaling to the correct state when
		 * another part of the program activates or de-activates the auto-
		 * scaling setting.
		 * 
		 * @param autoScaleOn
		 *            true if auto-scaling is activated
		 */
		public void setAutoScale(boolean autoScaleOn) {
			autoScaling.setSelected(autoScaleOn);
		}

		/**
		 * Sets the 'Enabled' check mark in the direction field sub-menu when
		 * another part of the program activates or deactivates direction
		 * fields.
		 * 
		 * @param dirFieldSelected
		 *            true if direction fields are turned on
		 */
		public void setDirField(boolean dirFieldSelected) {
			dirFieldOn.setSelected(dirFieldSelected);
		}

		/**
		 * Sets the check mark for grid lines to the correct state when another
		 * part of the program activates or de-activates grid lines.
		 * 
		 * @param gridOn
		 *            true if grid lines are turned on
		 */
		public void setGrid(boolean gridOn) {
			gridLines.setSelected(gridOn);
		}

		/**
		 * Sets the check mark for the 'x-axis' menu item in the logarithmic
		 * scaling sub-menu to the correct state when another part of the
		 * program changes the scaling setting of the horizontal axis.
		 * 
		 * @param xLogScaleOn
		 *            true if the horizontal axis is logarithmically scaled
		 */
		public void setXLog(boolean xLogScaleOn) {
			logScaleX.setSelected(xLogScaleOn);
		}

		/**
		 * Sets the check mark for the 'y-axis' menu item in the logarithmic
		 * scaling sub-menu to the correct state when another part of the
		 * program changes the scaling setting of the vertical axis.
		 * 
		 * @param yLogScaleOn
		 *            true if the vertical axis is logarithmically scaled
		 */
		public void setYLog(boolean yLogScaleOn) {
			logScaleY.setSelected(yLogScaleOn);
		}
	}

	/**
	 * This class describes the tool selector box found in the toolbar of a
	 * GraphPanel. It allows for the selection of one of any of the applicable
	 * tools for the GraphPanel, including picking initial conditions, panning,
	 * zooming, plotting orbits, and finding equilibrium points.
	 */
	@SuppressWarnings("rawtypes")
	protected class ToolSelector extends JComboBox {
		/**
		 * Default constructor. Initializes the selectable tool items, adds the
		 * selection listener, and enables/disables the selectable tools
		 */
		@SuppressWarnings("unchecked")
		public ToolSelector() {
			// Construct Tool Options list
			super(availableTools);

			// Fix the width of the selection box to fit all strings
			String prototypeValue = "XXXXXXXXXXXXXXXXXX";
			this.setPrototypeDisplayValue(prototypeValue);
			this.setMaximumSize(getPreferredSize());

			setSelectedIndex(0); // default to Pick Initial Conditions

			// Add listeners to the tool selector
			addListeners();
		}

		/**
		 * Adds the listener to the tool selector box, setting the appropriate
		 * mode given the selected tool.
		 */
		private void addListeners() {
			this.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// Set the mouse action mode to the selected tool
					int selection = getSelectedIndex();
					System.out.println(selection);
					switch (selection) {
					case 0:
						plotPanel.setICMode();
						break;
					case 1:
						plotPanel.setPanMode();
						break;
					case 2:
						plotPanel.setZoomMode();
						break;
					case 3:
						plotPanel.setPlotOrbitMode();
						break;
					case 4:
						plotPanel.setEquMode();
						break;
					default:
						System.out.println("Invalid Mouse Action Selection");
						break;
					}

					// Update Toolbar and popup menu
					updateTool();
				}
			});
		}
	}

	/**
	 * This class is responsible for the menu that appears when the user right-
	 * clicks on the PlotPanel. It contains a selection of options that are
	 * useful to have at the user's control when interacting with the graph.
	 */
	protected class PlotPanelPopup extends JPopupMenu {
		/** The owner of this options popup */
		private GraphPanel graphOwner;

		// Graph Options menu
		/** Menu for scaling the graph */
		private JMenu scaling;

		// Scaling sub-menu
		/** The check box for auto-scaling */
		private JCheckBoxMenuItem autoScaling;
		/** The menu for setting the ranges of the graph */
		private JMenuItem ranges;
		/** The menu for log-scaling settings */
		private JMenu logScaling;

		// Log Scaling sub-menu
		/** The log-scale option for x-axis */
		private JMenuItem logScaleX;
		/** The log-scale option for y-axis */
		private JMenuItem logScaleY;

		// Direction Field sub-menu
		/** The check box for turning direction field on-off */ 
		private JCheckBoxMenuItem dirFieldOn;
		/** Advanced direction field options */
		private JMenuItem dirFieldOptions;

		// Tools
		/** The button group containing all tools */
		private ButtonGroup tools;
		/** Mouse-action choice for picking initial condition mode */
		private JRadioButtonMenuItem pickICsMode;
		/** Mouse-action choice for panning mode */
		private JRadioButtonMenuItem panMode;
		/** Mouse-action choice for zooming mode */
		private JRadioButtonMenuItem zoomMode;
		/** Mouse-action choice for plotting orbits mode */
		private JRadioButtonMenuItem plotOrbitMode;
		/** Mouse-action choice for finding equilibrium points mode */
		private JRadioButtonMenuItem findEquilPtMode;

		// Print and export options
		/** Menu for printing the panel */
		private JMenuItem print;
		/** Menu for exporting the panel to a postscript file */
		private JMenuItem export;

		/**
		 * Constructor for the right-click menu of the PlotPanel.
		 * @param owner
		 *            the GraphPanel containing this GraphOptionsPopup
		 */
		public PlotPanelPopup(GraphPanel owner) {
			graphOwner = owner;
			initializeMenuItems(); // Initialize menu items
			addListeners(); // Add listeners to menu items
			addMenuItems(); // Build the right-click menu
			enablePhaseTools(); // Gray out non-usable items
		}

		/**
		 * Initializes all the items in the right-click menu.
		 */
		private void initializeMenuItems() {
			// Scaling options
			scaling = new JMenu("Scaling");

			// Scaling sub-menu
			autoScaling = new JCheckBoxMenuItem("Auto Scaling", true);
			ranges = new JMenuItem("Set Window Ranges...");
			logScaling = new JMenu("Logarithmic Scaling");

			// Log Scaling sub-menu
			logScaleX = new JCheckBoxMenuItem("x-axis");
			logScaleY = new JCheckBoxMenuItem("y-axis");

			// Tools
			pickICsMode = new JRadioButtonMenuItem("Pick Initial Conditions",
					true);
			panMode = new JRadioButtonMenuItem("Pan");
			zoomMode = new JRadioButtonMenuItem("Zoom");
			plotOrbitMode = new JRadioButtonMenuItem("Plot Orbit");
			findEquilPtMode = new JRadioButtonMenuItem("Find Equilibrium Point");

			// Add tools to the same button group
			tools = new ButtonGroup();
			tools.add(pickICsMode);
			tools.add(panMode);
			tools.add(zoomMode);
			tools.add(plotOrbitMode);
			tools.add(findEquilPtMode);

			// Direction Field sub-menu
			dirFieldOn = new JCheckBoxMenuItem("Enable Direction Field");
			dirFieldOptions = new JMenuItem("Direction Field Options...");

			// Print and export options
			print = new JMenuItem("Print Graph");
			export = new JMenuItem("Export Graph to Postscript");
		}

		/**
		 * Adds listeners for all the items in the right-click menu.
		 */
		private void addListeners() {
			autoScaling.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAllAutoScale(autoScaling.isSelected());
					plotPanel.setPopupMode(false); // necessary to repaint
				}
			});

			ranges.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scaleDialog.storeOriginalRanges();
					scaleDialog.setAutoScale(graphOwner.getPlotState()
							.getAutoscale());
					scaleDialog.updateFields();
					tabbedOutputPanelOwner.showDialog(scaleDialog);
					System.out.println("Scaling dialog box opened.");
					plotPanel.setPopupMode(false); // necessary to repaint
				}
			});

			logScaleX.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setXLogScale(logScaleX.isSelected());
					plotPanel.setPopupMode(false); // necessary to repaint
				}
			});

			logScaleY.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setYLogScale(logScaleY.isSelected());
					plotPanel.setPopupMode(false); // necessary to repaint
				}
			});

			pickICsMode.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotPanel.setICMode();
					updateTool();
				}
			});

			panMode.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotPanel.setPanMode();
					updateTool();
				}
			});

			zoomMode.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotPanel.setZoomMode();
					updateTool();
				}
			});

			plotOrbitMode.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotPanel.setPlotOrbitMode();
					updateTool();
				}
			});

			findEquilPtMode.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotPanel.setEquMode();
					updateTool();
				}
			});

			dirFieldOn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAllDirField(dirFieldOn.isSelected());
				}
			});

			dirFieldOptions.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tabbedOutputPanelOwner.showDialog(dirFieldDialog);
				}
			});

			print.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotPanel.printPlot();
				}
			});

			export.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					exportPostscript();
				}
			});

		}

		/**
		 * Adds the menu items to the right-click menu.
		 */
		private void addMenuItems() {
			// Right-click menu
			add(scaling);
			addSeparator();
			add(pickICsMode);
			add(panMode);
			add(zoomMode);
			add(plotOrbitMode);
			add(findEquilPtMode);
			addSeparator();
			add(dirFieldOn);
			add(dirFieldOptions);
			addSeparator();
			add(print);
			add(export);

			// Scaling sub-menu
			scaling.add(autoScaling);
			scaling.addSeparator();
			scaling.add(ranges);
			scaling.addSeparator();
			scaling.add(logScaling);

			// Log Scaling sub-menu
			logScaling.add(logScaleX);
			logScaling.add(logScaleY);
		}

		/**
		 * Grays out the phase plot tools when they're not appropriate. This
		 * method is only called from the PlotPanelPopup constructor.
		 */
		private void enablePhaseTools() {
			// Enable/disable direction field options
			dirFieldOn.setEnabled(isDirFieldPossible());
			dirFieldOptions.setEnabled(isDirFieldPossible());

			// Enable/disable 'Plot Orbit' and 'Find Equilibrium Point' modes.
			plotOrbitMode.setEnabled(isPlotOrbitPossible());
			findEquilPtMode.setEnabled(isPlotOrbitPossible());
			if (isPlotOrbitPossible()) {
				plotOrbitMode.setSelected(true);
			}
		}

		/**
		 * Sets the check mark for auto-scaling to the correct state when
		 * another part of the program activates or deactivates the auto-
		 * scaling setting.
		 * 
		 * @param autoScaleOn
		 *            true if auto-scaling is activated
		 */
		public void setAutoScale(boolean autoScaleOn) {
			autoScaling.setSelected(autoScaleOn);
		}

		/**
		 * Sets the check mark for 'Enable Direction Field' to the correct state
		 * when another part of the program activates or de-activates direction
		 * fields.
		 * 
		 * @param dirFieldEnabled
		 *            true if direction fields are turned on
		 */
		public void setDirField(boolean dirFieldEnabled) {
			dirFieldOn.setSelected(dirFieldEnabled);
		}

		/**
		 * Sets the check mark for the 'x-axis' menu item in the logarithmic
		 * scaling sub-menu to the correct state when another part of the
		 * program changes the scaling setting of the horizontal axis.
		 * 
		 * @param xLogScaleOn
		 *            true if the horizontal axis is logarithmically scaled
		 */
		public void setXLog(boolean xLogScaleOn) {
			logScaleX.setSelected(xLogScaleOn);
		}

		/**
		 * Sets the check mark for the 'y-axis' menu item in the logarithmic
		 * scaling sub-menu to the correct state when another part of the
		 * program changes the scaling setting of the vertical axis.
		 * 
		 * @param yLogScaleOn
		 *            true if the vertical axis is logarithmically scaled
		 */
		public void setYLog(boolean yLogScaleOn) {
			logScaleY.setSelected(yLogScaleOn);
		}

		/**
		 * Sets the radio buttons in the right-click menu to whatever mode the
		 * PlotPanel is currently in. This method is called whenever another
		 * part of the program changes the tool.
		 */
		public void setToolMode() {
			pickICsMode.setSelected(plotPanel.getICMode());
			panMode.setSelected(plotPanel.getPanMode());
			zoomMode.setSelected(plotPanel.getZoomMode());
			plotOrbitMode.setSelected(plotPanel.getPlotOrbitMode());
			findEquilPtMode.setSelected(plotPanel.getEquMode());
		}

		/**
		 * Simple wrapper function called by the PopupListener to allow for
		 * calling show() (which displays the popup menu at the position (x,y)
		 * in the coordinate space of the component invoker) using a Point
		 * instead of a pair of coordinates.
		 * 
		 * @param pt
		 *            the Point where the user clicked
		 */
		protected void show(Point pt) {
			super.show(plotPanel, pt.x, pt.y);
		}
	}

	/**
	 * This class defines the mouse listeners for the PlotPanel's popup menu. It
	 * overrides the behavior for mouse actions involving the right mouse
	 * button, including clicking, pressing, or releasing
	 */
	protected class PopupListener extends MouseAdapter {
		/** the popup menu that mouse events are being described for */
		private PlotPanelPopup popup;
		
		/**
		 * Default constructor. Sets the pop-up menu to the given menu.
		 * @param menu the pop-up menu associated to this listener
		 */
		public PopupListener(PlotPanelPopup menu) {
			popup = menu;
		}

		/**
		 * Specifies the behavior upon pressing and holding the right mouse
		 * button.
		 * @param e
		 *            the MouseEvent that is caught
		 */
		@Override
		public void mousePressed(MouseEvent e) {
			PlotPanel parent = (PlotPanel) e.getComponent();
			parent.setPopupMode(false);
			popup.setVisible(false);
			maybeShowPopup(e);
		}

		/**
		 * Specifies the behavior upon releasing the right mouse button.
		 * @param e
		 *            the MouseEvent that is caught
		 */
		@Override
		public void mouseReleased(MouseEvent e) {
			maybeShowPopup(e);
		}

		/**
		 * Specifies the display of the popup menu if the right mouse button is
		 * clicked and released. See the Popuplistener documentation of the Java
		 * API for more information.
		 * 
		 * @param e
		 *            the MouseEvent that is caught
		 */
		private void maybeShowPopup(MouseEvent e) {
			PlotPanel parent = (PlotPanel) e.getComponent();
			if (!e.getComponent().isEnabled()) {
				parent.setPopupMode(false);
				popup.setVisible(false);
				e.consume();
				popup.setEnabled(false);
				return;
			}

			if (e.isPopupTrigger() && !e.isConsumed()) {
				parent.setPopupMode(true);
				popup.show(new Point(e.getX(), e.getY()));
			}

			if (e.isConsumed()) {
				parent.setPopupMode(false);
				parent.repaint();
			}
		}
	}
}
