/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.BorderLayout;
import java.io.File;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JPanel;

import solver.SolverParameters;
import ui.GUI;
import ui.InputPanel;
import ui.TabbedOutputPanel;
import data.ODE;
import data.ODEVar;
import data.ODEVarKeeper;
import data.ODEVarVector;
import data.WorkspaceData;

/**
 * This class contains all information about a workspace, which also covers the
 * same amount of information as an ode save file. It is divided into three
 * parts: the Data, Graphics, and Solver representations, corresponding to the
 * Model-View-Controller paradigm. I provides ODEWorkspce level functions, as
 * well as working as an intermediate for the three representations.
 * 
 * @author Clinic 10-11, modified from Clinic 08-09
 */

@SuppressWarnings("serial")
public class ODEWorkspace extends JPanel {

	/** The GUI of the program */
	private GUI parent;
	/** The data representation */
	private DataRep dataRep;
	/** The graphics representation */
	private GraphicsRep graphicsRep;
	/** The solver representation */
	private SolverRep solverRep;

	/**
	 * Constructor that creates a new, blank ODEWorkspace, given the name and
	 * the reference to the main GUI.
	 * 
	 * @param gui
	 *            the GUI of the program
	 * @param name
	 *            the name for this new ODEWorkspace
	 */
	public ODEWorkspace(GUI gui, String name) {

		parent = gui;
		dataRep = new DataRep(this, name);

		solverRep = new SolverRep(this);

		JPanel p = new JPanel();
		graphicsRep = new GraphicsRep(this, gui, p);
		setLayout(new BorderLayout());
		add(p);

		reload();
	}

	/**
	 * Returns the WorkspaceData of this ODEWorkspace.
	 * 
	 * @return the WorkspaceData of this ODEWorkspace
	 */
	public WorkspaceData getWorkspace() {
		return dataRep.getWorkspace();
	}

	/**
	 * Returns the file corresponding to this ODEWorkspace.
	 * 
	 * @return the file corresponding to this ODEWorkspace, or null if this
	 *         workspace is never saved.
	 */
	public File getFile() {
		return dataRep.getFile();
	}

	/**
	 * Set the file corresponding to this ODEWorkspace.
	 * 
	 * @param f
	 *            the file corresponding to this ODEWorkspace
	 */
	public void setFile(File f) {
		dataRep.setFile(f);
	}

	/**
	 * Returns the name of the ODEworkspace.
	 * 
	 * @return the name of the ODEWorkspace
	 */
	public String getName() {
		return dataRep.getName();
	}

	/**
	 * Returns the TabbedOutputPanel of this ODEWorkspace.
	 * 
	 * @return the TabbedOutputPanel of this ODEWorkspace
	 */
	public TabbedOutputPanel getTabbedGraphPanel() {
		return graphicsRep.getTabbedGraphPanel();
	}

	/**
	 * Returns the input panel of this ODEWorkspace.
	 * 
	 * @return the input panel of this ODEWorkspace
	 */
	public InputPanel getInputPanel() {
		return graphicsRep.getInputPanel();
	}

	/**
	 * Returns the active ODE of this ODEWorkspace.
	 * 
	 * @return the active ODE of this ODEWorkspace
	 */
	public ODE getCurrentODE() {
		return solverRep.getCurrentODE();
	}

	/**
	 * Returns the current solver parameters.
	 * 
	 * @return the current solver parameters
	 */
	public SolverParameters getParameters() {
		return solverRep.getParameters();
	}

	/**
	 * Returns the vector of all ODEs in the ODEWorkspace.
	 * 
	 * @return the vector of all ODEs in the ODEWorkspace
	 */
	public Vector<ODE> getODEs() {
		return getWorkspace().getODEs();
	}

	/**
	 * Returns the number of ODEs in the ODEWorkspace.
	 * 
	 * @return the number of ODEs in the ODEWorkspace
	 */
	public int getNumODEs() {
		return getWorkspace().getNumODEs();
	}

	/**
	 * Returns the variable keeper of this ODEWorkspace.
	 * 
	 * @return the variable keeper of this ODEWorkspace
	 */
	public ODEVarKeeper getVarKeeper() {
		return dataRep.getVarKeeper();
	}

	/**
	 * Set the variable keeper of thie ODEWorkspace.
	 * 
	 * @param keeper
	 *            the variable keeper to set to
	 */
	public void setVarKeeper(ODEVarKeeper keeper) {
		dataRep.setVarKeeper(keeper);
	}

	/**
	 * Returns the ODEVarVector for the current ODE.
	 * 
	 * @return the ODEVarVector for the current ODE
	 */
	public ODEVarVector getCurrentODEVarVector() {
		return getVarKeeper().createVarVector(getCurrentODE().getVariables());
	}

	/**
	 * Store/Rename the name of the ODE.
	 * 
	 * @param name
	 *            the name of the ODE
	 */
	public void storeName(String name) {
		dataRep.setName(name);
		GUI.workspaces.setTitleAt(GUI.workspaces.getSelectedIndex(), name);
	}

	/**
	 * Stores the new initial condition and update the GUI.
	 * 
	 * @param var
	 *            the variable to change the initial condition
	 * @param val
	 *            the new initial condition to change to
	 */
	public void storeIC(ODEVar var, double val) {
		solverRep.setIC(var, val);
		updateGUI_IC();
	}

	/**
	 * EnterODE takes a string and uses the parser to extract useful a valid
	 * ode. In the event of an error, a message is displayed. Otherwise, new
	 * graphs, initial condition variables etc. are created based on the
	 * variables of the new ODE and solving becomes available. If the variables
	 * of the new ode match those of the current ode, the new ode is overlaid
	 * upon the old. Otherwise, the new replaces the old.
	 * 
	 * @param odeText
	 *            the definition of the ODE input by user
	 */
	/*
	 * 1.03.2006 - Martin Hunt Now parameter replace must be false in order for
	 * an overlay to proceed This makes overlays more difficult for users to
	 * accomplish in the main ODE entry area - they must use the Data tab for
	 * this functionality
	 */
	public boolean storeDefinition(String odeText) {
		if (!odeText.equals(dataRep.getODEText())) {

			ODE newODE = dataRep.createODEFromText(odeText, parent);
			if (newODE == null)
				return false;
			solverRep.updateODE(newODE);

			updateGUI_parameters();
			// default option is to replace ODE
			System.out.println("Replacing ODE. . .");
			getTabbedGraphPanel().replaceODE(newODE);
			enableSolveComponents(true);
		}
		return true;
	}

	/**
	 * Update the initial conditions on the GUI.
	 */
	public void updateGUI_IC() {
		graphicsRep.updateInputPanelIC(solverRep.getParameters());
	}

	/**
	 * Set the solver parameters.
	 * 
	 * @param params
	 *            the solver parameters to set to
	 */
	public void setParameters(SolverParameters params) {
		solverRep.setParameters(params);
	}

	/**
	 * Update the solver parameters on the GUI.
	 */
	public void updateGUI_parameters() {
		graphicsRep.updateInputPanelParameters(solverRep.getParameters());
	}

	/**
	 * Set the message and availability status on the status bar.
	 * 
	 * @param message
	 *            the message to show
	 * @param busy
	 *            true iff the bar should be shown as busy, false otherwise
	 */
	public void setStatusBar(String message, boolean busy) {
		graphicsRep.setStatusBar(message, busy);
	}

	/**
	 * Set the message on the status bar.
	 * 
	 * @param message
	 *            the message to show
	 */
	public void setStatusBar(String message) {
		graphicsRep.setStatusBar(message);
	}

	/**
	 * Clears the curves and equilibrium points of all ODE.
	 */
	public void clearAllPlotObjects() {
		dataRep.clearPlotObjectsData();
		solverRep.resetSolveSpan();
		graphicsRep.clearPlots();
	}

	/**
	 * Set the solve components to be enabled or disabled
	 * 
	 * @param enabled
	 *            true iff set to enabled, false otherwise
	 */
	public void enableSolveComponents(boolean enabled) {
		graphicsRep.enableSolveComponents(enabled);
	}

	/**
	 * Solve forward for a curve.
	 */
	public void solveForward() {
		solverRep.solveForward();
	}

	/**
	 * Solve backward for a curve.
	 */
	public void solveBackward() {
		solverRep.solveBackward();
	}

	/**
	 * Solve orbit for 2 curves, one forward, and one backward.
	 */
	public void solveOrbit() {
		solverRep.solveOrbit();
	}

	/**
	 * Stop the solver.
	 */
	public void stopSolve() {
		solverRep.stopSolve();
	}

	/**
	 * Reload the workspace.
	 */
	public void reload() {
		solverRep.reload();
		graphicsRep.reload();
	}

	/**
	 * Shows a dialog
	 * 
	 * @param dialog
	 *            the dialog to show
	 */
	public void showDialog(JDialog dialog) {
		graphicsRep.showDialog(dialog);
	}

	/**
	 * Request focus on the ODE Text.
	 */
	public void focusODEText() {
		graphicsRep.focusOnDefinition();
	}

	/**
	 * Print the selected tab.
	 */
	public void print() {
		getTabbedGraphPanel().print();
	}

	/**
	 * Export the selected tab to postscript.
	 */
	public void exportPostscript() {
		getTabbedGraphPanel().exportPostscript();
	}
}
