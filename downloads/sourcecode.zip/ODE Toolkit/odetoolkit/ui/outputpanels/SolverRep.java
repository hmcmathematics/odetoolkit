/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.util.Arrays;

import javax.swing.JOptionPane;

import solver.Solver;
import solver.SolverParameters;
import ui.GUI;
import ui.TabbedOutputPanel;
import util.SolutionReadyListener;
import data.ODE;
import data.ODEVar;
import data.ODEVarVector;

public class SolverRep implements SolutionReadyListener {
	/** The ODEWorkspace owning this Solver Component */
	private ODEWorkspace parent;

	/** The old initial condition, for comparison purpose */
	private double[] oldICs;

	/** The solver thread */
	private Solver solverThread;
	/** The current set of solver parameters */
	private SolverParameters currentParams;
	/** The previous set of solver parameters, for comparison purpose */
	private SolverParameters oldParams;

	/** The active ODE to be solved */
	private ODE currentODE;

	/** Keeps the span for forward direction */
	private double forwardSpan;
	/** Keeps the span for backward direction */
	private double backwardSpan;

	/** Keeps whether we are solving for orbit or just a curve */
	private boolean solveOrbit;
	/** Keeps whether the solution goes out of range */
	private boolean outOfRange;

	/** Keeps the status of whether the solver is available or not */
	private boolean solverAvailable;

	/**
	 * Constructor for creating an new Solver component.
	 * 
	 * @param odews
	 *            the ODEWorkspace owning this Solver Component
	 */
	public SolverRep(ODEWorkspace odews) {

		parent = odews;

		forwardSpan = 10;
		backwardSpan = 10;

		currentParams = new SolverParameters();
		solverAvailable = true;
	}

	/**
	 * Returns the active ODE.
	 * 
	 * @return the active ODE
	 */
	public ODE getCurrentODE() {
		return currentODE;
	}

	/**
	 * Returns the current solver parameters.
	 * 
	 * @return the current solver parameters
	 */
	public SolverParameters getParameters() {
		return currentParams;
	}

	/**
	 * Set the current solver parameters to the given one.
	 * 
	 * @param params
	 *            the solver parameters to set to
	 */
	public void setParameters(SolverParameters params) {
		currentParams = params;
	}

	/**
	 * Update to a new ODE.
	 * 
	 * @param newODE
	 *            the new ODE to set to
	 */
	public void updateODE(ODE newODE) {

		ODEVarVector vars = parent.getVarKeeper().createVarVector(
				newODE.getVariables());
		currentParams.setVariables(vars);

		currentODE = newODE;

		forwardSpan = currentParams.getSolveSpan();
		backwardSpan = currentParams.getSolveSpan();
	}

	/**
	 * Set an initial condition of a variable.
	 * 
	 * @param var
	 *            the variable to set the initial condition
	 * @param val
	 *            the value to set to
	 */
	public void setIC(ODEVar var, double val) {
		currentParams.setIC(var, val);
	}

	/**
	 * Set both solve spans to 0.
	 */
	public void resetSolveSpan() {
		forwardSpan = 0;
		backwardSpan = 0;
	}

	/**
	 * Solve uses the current ode and solving parameters to generate a solution.
	 * Points come to interested components (such as the graphs) via the point-
	 * and solutionReadyListener interfaces. The solve runs in its own thread in
	 * the backend, needing no further input from us.
	 */
	public boolean solve() {
		if (currentODE != null) {

			parent.updateGUI_parameters();
			double[] newICs = currentParams.getInitialConditions();

			if (oldICs != null)
				System.out.println("Solve(): 0) oldICs: " + oldICs[0] + ", "
						+ oldICs[1] + "; newICs: " + newICs[0] + ", "
						+ newICs[1]);

			// re-solve to extend
			if (!Arrays.equals(oldICs, currentParams.getInitialConditions())
					|| !oldParams.sameSolverOptions(currentParams)) {
				forwardSpan = 0;
				backwardSpan = 0;
				System.out.println("Solve spans reset (new ICs).");
			}

			oldICs = currentParams.getInitialConditions().clone();
			oldParams = new SolverParameters(currentParams);

			System.out.println("Solve(): 1) forwardSpan = " + forwardSpan
					+ "; backwardSpan = " + backwardSpan);

			double baseSolveSpan = currentParams.getSolveSpan();
			if (currentParams.getSolveDirection()) {
				forwardSpan += currentParams.getSolveSpan();
				currentParams.setSolveSpan(forwardSpan);
			} else {
				backwardSpan += currentParams.getSolveSpan();
				currentParams.setSolveSpan(backwardSpan);
			}

			System.out.println("Solve(): 2) forwardSpan = " + forwardSpan
					+ "; backwardSpan = " + backwardSpan);

			// Debug Info
			System.out.print("\nODE: ");
			System.out.println(currentODE.info());
			System.out.print("Params: ");
			System.out.println(currentParams.toString());

			try {
				if (currentODE == null || currentParams == null)
					GUI.statusBar.setMessage("Null ODE or parameters.");

				currentParams.printMe();

				solverThread = parent.getWorkspace().solve(currentODE,
						currentParams);

				if (solverThread == null) {
					// This error often pops up under testing conditions.
					// The cause isn't yet known.
					GUI.statusBar.setMessage("Null Solver Error");
					System.out.println("NULL SOLVER");

					// restore base solve span
					currentParams.setSolveSpan(baseSolveSpan);

					return false;
				}
				TabbedOutputPanel tabbedGraphPanel = parent
						.getTabbedGraphPanel();
				if (tabbedGraphPanel != null) {
					// Graphs need to know when the solution is done
					solverThread.addSolutionReadyListener(tabbedGraphPanel);
					solverThread.addSolutionReadyListener(this);
				}

				solverAvailable = false;
				parent.enableSolveComponents(false);
				GUI.statusBar.setStatus("Solve in progress...", true);

				solverThread.start();

			} catch (Exception e) {
				GUI.statusBar.setStatus("Solve Failed", false);
				e.printStackTrace();
				parent.enableSolveComponents(true);
				solverAvailable = true;
				return false;
			}

			// restore base solve span
			currentParams.setSolveSpan(baseSolveSpan);

			System.out.println("Solve(): 3) baseSolveSpan = " + baseSolveSpan);

			return true;
		} else {
			System.out.print("Null ODE");
			return false;
		}
	}

	/**
	 * Solve forward for a curve.
	 */
	public void solveForward() {
		outOfRange = false;
		if (!solverAvailable) {
			System.err.println("Solve called when solver is unavailable.");
			return;
		}
		solverAvailable = false;
		parent.enableSolveComponents(false);
		currentParams.setSolveDirection(true);
		solve();
	}

	/**
	 * Solve backward for a curve.
	 */
	public void solveBackward() {
		outOfRange = false;
		if (!solverAvailable) {
			System.err.println("Solve called when solver is unavailable.");
			return;
		}
		solverAvailable = false;
		parent.enableSolveComponents(false);
		currentParams.setSolveDirection(false);
		solve();
	}

	/**
	 * Solve for an orbit, which is one curve forward, one backward.
	 */
	public void solveOrbit() {
		solveOrbit = true;
		solveForward();
	}

	/**
	 * If a current solver thread is running, cancelSolve kills it, ending the
	 * solve. This may cause problems in underlying data structures, but
	 * eventually we should not have this problem.
	 */
	public void stopSolve() {
		if (solverThread != null)
			solverThread.kill();

		// In older version of the code, we are supposed to pass solution ready
		// listeners a [0][0] array.
		// Clinic 10-11 believes we have fixed it in a different way, however.

		parent.enableSolveComponents(true);
		solverAvailable = true;
		GUI.statusBar.setStatus("Error: Stopped solve.", false);
	}

	/**
	 * Reload the ODEWorkspace, so reset some values
	 */
	public void reload() {
		if (parent.getWorkspace().getNumODEs() > 0) {
			currentODE = parent.getWorkspace().getODEs().lastElement();
			if (currentODE.getNumCurves() > 0) {
				currentParams = currentODE.getCurves().lastElement()
						.getSolverParameters();
			}
		}
		forwardSpan = currentParams.getSolveSpan();
		backwardSpan = currentParams.getSolveSpan();
	}

	/**
	 * Respond when solving is done - probably solve backward if we are in orbit
	 * mode, or simply enable buttons on input panel.
	 */
	public void solutionReady(double[][] sol) {
		solverAvailable = true;
		if (solveOrbit) {
			System.out.println("Going Backwards for an orbit...");
			solveOrbit = false;
			solveBackward();
		}
		if (outOfRange)
			parent.setStatusBar("Solution went to infinity");
		solverAvailable = true;
		parent.enableSolveComponents(true);
	}

	/**
	 * Error handling for solution ready listeners, and send appropriate
	 * messages to users.
	 * 
	 * @param e
	 *            the exception to be handled
	 */
	public void errorCondition(Exception e) {
		// e.printStackTrace();
		if (e.getMessage().matches("Infinity.*")
				|| !e.getMessage().matches(".*singularity.*"))
			outOfRange = true;
		{
			// owner.setMessage("An error occured during the solve. The solver
			// reported:\n" + e.getMessage());
			JOptionPane.showMessageDialog(null,
					"An error occured during the solve. The solver reported:\n"
							+ e.getMessage(), "Solver Error",
					JOptionPane.ERROR_MESSAGE);
		}
		solverAvailable = true;
		parent.enableSolveComponents(true);
		GUI.statusBar.setStatus("Solve Failed", false);
	}

	/**
	 * Error handling for solution ready listeners, and send appropriate
	 * messages to users.
	 * 
	 * @param e
	 *            string describing error condition
	 */
	public void errorCondition(String e) {
		// System.out.println(e);
		if (e.matches("Infinity.*") || e.matches(".*singularity.*"))
			outOfRange = true;
		else {
			// owner.setMessage("An error occured during the solve. The solver
			// reported:\n" + e);
			JOptionPane.showMessageDialog(null,
					"An error occured during the solve. The solver reported:\n"
							+ e, "Solver Error", JOptionPane.ERROR_MESSAGE);
		}
		solverAvailable = true;
		parent.enableSolveComponents(true);
		GUI.statusBar.setStatus("Solve Failed", false);
	}
}
