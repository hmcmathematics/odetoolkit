/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.outputpanels;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;

import org.math.plot.Plot3DPanel;
import org.math.plot.canvas.PlotCanvas;

import ui.TabbedOutputPanel;
import ui.dialogs.Label3DDialog;
import ui.dialogs.Scale3DDialog;
import data.ODEVar;
import data.ODEVarVector;
import data.plotstates.Plot3DState;

/**
 * This class defines the GraphPanel that allows for a 3D plot of three
 * variables
 * 
 * Features not support yet: PopupListener and Popup menu, Zoom box, print,
 * export
 * 
 * @author Andres Perez 09, modified by Clinic 10-11
 */
@SuppressWarnings("serial")
public class Graph3DPanel extends OutputPanel {
	/** TabbedOutputPanel containing this and other output panels */
	private TabbedOutputPanel tabbedOutputPanelOwner;

	/** String array listing the tools that appear in the tool selector menu */
	private String[] availableTools;

	/** Toolbar containing menus and buttons for interacting with the graph */
	private Plot3DToolbar toolbar;

	/** Panel containing the 3D plot display */
	private Plot3DPanel plot;

	/** Plot state containing information about the 3D plot */
	private Plot3DState plotState;

	/** Dialog box for changing axis labels */
	private Label3DDialog labelDialog;

	/** Dialog box for setting the plot ranges */
	private Scale3DDialog scaleDialog;

	/** Variable list */
	private ODEVarVector currentVar;

	/** The label for the title of the graph */
	private JLabel titleLabel;

	/**
	 * Constructor that creates a new OutputPanel given a TabbedOutputPanel.
	 * Instantiates a toolbar and plot panel, as well as dialogs for changing
	 * the labels and scaling the window ranges.
	 * 
	 * @param owner
	 *            the TabbedOutputPanel to which the GraphPanel belongs
	 * @param current
	 *            the ODEVarVector for the current ODE
	 * @param x
	 *            the variable to display on x-axis, initially
	 * @param y
	 *            the variable to display on y-axis, initially
	 * @param z
	 *            the variable to display on z-axis, initially
	 */
	public Graph3DPanel(TabbedOutputPanel owner, ODEVarVector current,
			ODEVar x, ODEVar y, ODEVar z) {
		super(owner);

		currentVar = current;
		tabbedOutputPanelOwner = owner;
		availableTools = new String[] { // Available mouse-action tools
		"Rotate", "Pan", "Zoom", };
		toolbar = new Plot3DToolbar(this); // Toolbar buttons

		plot = new Plot3DPanel("SOUTH");
		plot.setBorder(new CompoundBorder(new MatteBorder(9, 9, 9, 9,
				new Color(232, 232, 232)), new EtchedBorder()));
		plot.removeLegend(); // Remove JMathTools legend
		plot.removePlotToolBar(); // Remove JMathTools toolbar
		plot.setName("New 3D Plot");

		plotState = new Plot3DState(this, owner.getODEs(), currentVar, x, y, z);

		labelDialog = new Label3DDialog(this); // Change Labels Dialog Box
		scaleDialog = new Scale3DDialog(this); // Scaling Dialog Box

		// Layout
		setLayout(new BorderLayout());
		add(toolbar, "North");
		add(plot, "Center");

		titleLabel = new JLabel();
		titleLabel.setText(plot.getName());
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		plot.add(titleLabel, "North");

		System.out.println("Making Graph3DPanel.");
		System.out.println("Direction fields possible: false");
	}

	/**
	 * Returns the variables of the current ODE.
	 * 
	 * @return the variables of the current ODE
	 */
	public ODEVarVector getVariables() {
		return currentVar;
	}

	/**
	 * Returns the ODEVar corresponding to the given axis index.
	 * 
	 * @param axis
	 *            the axis index - 0 for x, 1 for y, and 2 for z
	 * @return the ODEVar corresponding to the given axis index
	 */
	public ODEVar getVar(int axis) {
		return plotState.getVar(axis);
	}

	/**
	 * Set the variable on the axis corresponding to the given axis index.
	 * 
	 * @param axis
	 *            the axis index - 0 for x, 1 for y, and 2 for z
	 * @param index
	 *            the index of the variable to be shown on that axis
	 */
	public void setVar(int axis, int index) {
		plotState.setVar(axis, index);
	}

	/**
	 * Returns the plot panel contained in this Graph3DPanel.
	 * 
	 * @return the Plot3DPanel associated with this Graph3DPanel
	 */
	public Plot3DPanel getPlot3DPanel() {
		return plot;
	}

	/**
	 * Returns the plot state that represents this Graph3DPanel's plot panel.
	 * 
	 * @return the Plot3DState representing the inner plot panel.
	 */
	public Plot3DState getPlot3DState() {
		return plotState;
	}

	/**
	 * This function is called any time auto-scaling is toggled. It updates the
	 * status of auto-scaling in the toolbar and the Plot3DPanel's right-click
	 * menu, and activates/de-activates the auto-scaling feature.
	 * 
	 * @param autoScaleState
	 *            true if auto-scaling is set to on, false otherwise
	 */
	public void setAllAutoScale(boolean autoScaleState) {
		plotState.setAutoScale(autoScaleState);
		toolbar.graphOptionsPopup.setAutoScale(autoScaleState);
		scaleDialog.setAutoScale(autoScaleState);
	}

	/**
	 * This function is called any time grid lines are toggled. It updates the
	 * status of grid lines in the toolbar and activates/de-activates the grid
	 * in the plot panel.
	 * 
	 * @param gridOn
	 *            true if grid lines are set to visible, false otherwise
	 */
	public void setAllGrid(boolean gridOn) {
		plotState.setGrid(gridOn);

		// Set the check-mark
		toolbar.graphOptionsPopup.setGrid(gridOn);
	}

	/**
	 * Sets the desired axis to logarithmic scaling, then updates the toolbar.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @param logScaleOn
	 *            true if the axis is log-scaled
	 */
	public void setAxisLogScale(int axis, boolean logScaleOn) {
		plotState.setAxisLogScale(axis, logScaleOn);

		// Set the check-mark
		toolbar.graphOptionsPopup.setLog(axis, logScaleOn);
	}

	/**
	 * Updates the label dialog according to its options
	 */
	public void updateDialogs() {
		labelDialog.reloadOptions();
	}

	/**
	 * This function is called any time the mouse action tool is changed. It
	 * updates the tool selector in the toolbar and the radio buttons in the
	 * Plot3DPanel's right-click menu.
	 */
	public void updateTool() {
		toolbar.setToolMode();
		// popupMenu.setToolMode();
	}

	/**
	 * Clears the displayed data, resets the scale settings to default, and
	 * empties the Plot3DPanel.
	 */
	@Override
	public void clear() {
		// setAllAutoScale(true);
		// setAxisLogScale(0, false);
		// setAxisLogScale(1, false);
		// setAxisLogScale(2, false);
		labelDialog.reloadOptions();
		plot.removeAllPlots();
	}

	/**
	 * Paints the GraphPanel, and repaints the PlotPanel.
	 * 
	 * @param g
	 *            Graphics object corresponding to panel display.
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		titleLabel.setText(plot.getName());
		plotState.repaint();
	}

	/**
	 * When the 3D plot tab is clicked, redraw the plot.
	 */
	public void gainedFocus() {
		repaint();
	}

	/**
	 * This function is called any time a new solution is to be painted on the
	 * Plot3DPanel. It calls the appropriate drawing methods through the plot
	 * state and stores new ranges for the scaling dialog.
	 */
	@Override
	public void solutionReceived() {
		// draw the solution curves
		plotState.repaint();

		// store new ranges for scaling dialog
		scaleDialog.storeOriginalRanges();
	}

	/**
	 * Returns the name that should be on this graph's tab
	 */
	@Override
	public String getTabName() {
		return "3D";
	}

	/**
	 * Returns whether this Graph3DPanel can print. For now, 3D does not support
	 * printing or exporting.
	 * 
	 * @return true iff this Graph3DPanel can print
	 */
	@Override
	public boolean canPrint() {
		return false;
	}

	@Override
	public void print() {
		// Not supported for now
	}

	@Override
	public void exportPostscript() {
		// Not supported for now

	}

	/**
	 * This class is responsible for the toolbar displayed above a PlotPanel. It
	 * contains a popup menu for graph options, a tool selector box for
	 * selecting the behavior of the mouse on the plot, and easy-access buttons
	 * for fitting the graph to the window and clearing all data.
	 */
	protected class Plot3DToolbar extends JToolBar {
		/** Graph3DPanel that contains this toolbar */
		private Graph3DPanel graphOwner;

		/** Graph Options Popup Menu Button */
		private JButton graphOptions;

		/** Graph Options Popup */
		private GraphOptionsPopup graphOptionsPopup;

		/** Tool Selector Pull-Down Menu */
		private ToolSelector toolSelector;

		/** Button for auto-scaling the graph */
		private JButton autoFit;

		/** Button for clearing ODE data and plot display */
		private JButton clearAll;

		/**
		 * Constructor for the toolbar displayed in a GraphPanel.
		 * 
		 * @param graph3DPanelOwner
		 *            the Graph3DPanel containing this toolbar
		 */
		public Plot3DToolbar(Graph3DPanel graph3DPanelOwner) {
			graphOwner = graph3DPanelOwner;

			initializeComponents(); // Initialize menu items
			addListeners(); // Add listeners
			addComponents(); // Builds the plot panel's toolbar
			setFloatable(false); // Disallows detachment of the toolbar
		}

		/**
		 * Initializes all the components in the GraphPanel's toolbar.
		 */
		private void initializeComponents() {
			// Graph Options Menu
			graphOptions = new JButton("Graph Options");
			graphOptionsPopup = new GraphOptionsPopup(graphOwner);

			// Tool Selector Pull-Down Menu
			toolSelector = new ToolSelector();

			// Autofit and Clear buttons
			autoFit = new JButton("AutoFit");
			clearAll = new JButton("Clear All");

			// Disallow focus so that the toolbar buttons don't appear selected
			// whenever they are used.
			graphOptions.setFocusable(false);
			toolSelector.setFocusable(false);
			autoFit.setFocusable(false);
			clearAll.setFocusable(false);
		}

		/**
		 * Adds the listeners for the toolbar buttons. Note: The ToolSelector
		 * class is responsible for listening to the tool selection box.
		 */
		private void addListeners() {
			graphOptions.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					graphOptionsPopup.getPopupMenu().show(graphOptions, 0,
							graphOptions.getHeight());
				}
			});

			autoFit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						plot.plotCanvas.setAutoBounds();
					} catch (IllegalArgumentException iae) {
						System.out.println("Log-scaling axes with negative "
								+ "values caused an error.");
					}
				}
			});

			clearAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// Clearing the 3D plot first prevents log-scaling errors.
					tabbedOutputPanelOwner.clearAllPlotsObjects();
					// graphOwner.plotState.clear();
				}
			});
		}

		/**
		 * Adds all the components to the GraphPanel's toolbar.
		 */
		private void addComponents() {
			add(Box.createRigidArea(new Dimension(5, 0)));
			add(graphOptions);

			add(Box.createRigidArea(new Dimension(2, 0)));
			addSeparator();

			add(Box.createRigidArea(new Dimension(2, 0)));
			JLabel mouseActionLabel = new JLabel("Mouse Action:");
			mouseActionLabel.putClientProperty("JComponent.sizeVariant",
					"small");
			add(mouseActionLabel);

			add(Box.createRigidArea(new Dimension(2, 0)));
			add(toolSelector);

			// Space between left- and right-justified buttons
			add(Box.createHorizontalGlue());

			add(autoFit);
			add(Box.createRigidArea(new Dimension(7, 0)));
			add(clearAll);
			add(Box.createRigidArea(new Dimension(5, 0)));
		}

		/**
		 * This function is called whenever another part of the program, such as
		 * the PlotPanel's right-click menu, changes the active tool. It updates
		 * the tool selector box in the toolbar to the appropriate tool.
		 */
		public void setToolMode() {
			// Determine the active tool
			int tool = 0;
			if (plot.plotCanvas.ActionMode == 2)
				tool = 0;
			if (plot.plotCanvas.ActionMode == PlotCanvas.TRANSLATION)
				tool = 1;
			if (plot.plotCanvas.ActionMode == PlotCanvas.ZOOM)
				tool = 2;

			// Set the Tool Selector to correct tool
			toolSelector.setSelectedIndex(tool);
		}
	}

	/**
	 * This class describes the menu activated whenever the 'Graph Options'
	 * button is pressed on the GraphPanel's toolbar. It gives the user the
	 * ability to change the scaling settings, change the curve color and plot
	 * labels, and turn on or off grid lines in the plot panel.
	 */
	protected class GraphOptionsPopup extends JMenu {
		// Graph Options menu
		/** Menu for scaling the graph */
		private JMenu scaling;
		/** Menu for direction field options */
		private JMenu dirField;
		/** Menu for labels of the graph */
		private JMenuItem labels;
		/** Menu for grid lines in the graph */
		private JMenuItem gridLines;

		// Scaling sub-menu
		/** The check box for auto-scaling */
		private JCheckBoxMenuItem autoScaling;
		/** The menu for fitting the graph */
		private JMenuItem fitGraph;
		/** The menu for setting the ranges of the graph */
		private JMenuItem ranges;
		/** The menu for log-scaling settings */
		private JMenu logScaling;

		// Log Scaling sub-menu
		/** The log-scale option for x-axis */
		private JMenuItem logScaleX;
		/** The log-scale option for y-axis */
		private JMenuItem logScaleY;
		/** The log-scale option for z-axis */
		private JMenuItem logScaleZ;

		// Direction Field sub-menu
		/** The check box for turning direction field on-off */
		private JCheckBoxMenuItem dirFieldOn;
		/** Advanced direction field options */
		private JMenuItem dirFieldOptions;

		/**
		 * Constructor for the 'Graph Options' popup menu in the toolbar.
		 * 
		 * @param owner
		 *            the GraphPanel containing this GraphOptionsPopup
		 */
		public GraphOptionsPopup(Graph3DPanel owner) {
			super("Graph Options"); // Construct a new JMenu titled
			// "Graph Options"
			initializeMenuItems(); // Initialize menu items
			addListeners(); // Add listeners
			addMenuItems(); // Build the popup menu
			disable2DTools(); // Enable/disable the direction field
			// menu items
		}

		/**
		 * Initializes all the menu items in the 'Graph Options' menu.
		 */
		private void initializeMenuItems() {
			// Graph Options menu
			scaling = new JMenu("Scaling");
			dirField = new JMenu("Direction Field");
			// chooseColor = new JMenu("Set Color");
			labels = new JMenuItem("Labels...");
			gridLines = new JCheckBoxMenuItem("Grid Lines", true);

			// Scaling sub-menu
			autoScaling = new JCheckBoxMenuItem("Auto Scaling", true);
			fitGraph = new JMenuItem("Fit Graph to Window");
			ranges = new JMenuItem("Set Window Ranges...");
			logScaling = new JMenu("Logarithmic Scaling");

			// Log Scaling sub-menu
			logScaleX = new JCheckBoxMenuItem("x-axis", false);
			logScaleY = new JCheckBoxMenuItem("y-axis", false);
			logScaleZ = new JCheckBoxMenuItem("z-axis", false);
			logScaleX.setEnabled(false);
			logScaleY.setEnabled(false);
			logScaleZ.setEnabled(false);

			// Direction Field sub-menu
			dirFieldOn = new JCheckBoxMenuItem("Enabled", false);
			dirFieldOptions = new JMenuItem("Options...");
		}

		/**
		 * Adds listeners for all the menu items in the 'Graph Options' menu.
		 */
		private void addListeners() {
			autoScaling.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAllAutoScale(autoScaling.isSelected());
				}
			});

			labels.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (labelDialog == null)
						labelDialog = new Label3DDialog(toolbar.graphOwner);
					labelDialog.storeOptions();
					tabbedOutputPanelOwner.showDialog(labelDialog);
					System.out.println("3D label dialog box opened.");
				}
			});

			gridLines.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotState.setGrid(gridLines.isSelected());
				}
			});

			fitGraph.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					plotState.repaint();
				}
			});

			ranges.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scaleDialog.storeOriginalRanges();
					scaleDialog.updateFields();
					tabbedOutputPanelOwner.showDialog(scaleDialog);
					System.out.println("3D scaling dialog box opened.");
				}
			});

			logScaleX.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAxisLogScale(0, logScaleX.isSelected());
				}
			});

			logScaleY.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAxisLogScale(1, logScaleY.isSelected());
				}
			});

			logScaleZ.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setAxisLogScale(2, logScaleZ.isSelected());
				}
			});
		}

		/**
		 * Adds the menu items to the 'Graph Options' menu.
		 */
		private void addMenuItems() {
			// Graph Options menu
			add(scaling);
			add(dirField);
			add(labels);
			add(gridLines);

			// Scaling sub-menu
			scaling.add(autoScaling);
			scaling.addSeparator();
			scaling.add(fitGraph);
			scaling.add(ranges);
			scaling.addSeparator();
			scaling.add(logScaling);

			// Log Scaling sub-menu
			logScaling.add(logScaleX);
			logScaling.add(logScaleY);
			logScaling.add(logScaleZ);

			// Direction Field sub-menu
			dirField.add(dirFieldOn);
			dirField.add(dirFieldOptions);
		}

		/**
		 * Grays out the direction field menu items since direction fields
		 * cannot be enabled in a Graph3DPanel.
		 */
		private void disable2DTools() {
			dirFieldOn.setEnabled(false);
			dirFieldOptions.setEnabled(false);
		}

		/**
		 * Sets the check mark for auto-scaling to the correct state when
		 * another part of the program activates or de-activates the auto-
		 * scaling setting.
		 * 
		 * @param autoScaleState
		 *            true if auto-scaling is activated
		 */
		public void setAutoScale(boolean autoScaleState) {
			autoScaling.setSelected(autoScaleState);
		}

		/**
		 * Sets the check mark for grid lines to the correct state when another
		 * part of the program activates or de-activates grid lines.
		 * 
		 * @param gridOn
		 *            true if grid lines are turned on
		 */
		public void setGrid(boolean gridOn) {
			gridLines.setSelected(gridOn);
		}

		/**
		 * Sets the log-scaling check mark for the specified axis in the
		 * logarithmic scaling sub-menu to the correct state when another part
		 * of the program changes the scaling setting of an axis.
		 * 
		 * @param axis
		 *            int representing the axis (0 = x, 1 = y, and 2 = z)
		 * @param logScaleOn
		 *            boolean for log-scaling, true for log, false for linear
		 */
		public void setLog(int axis, boolean logScaleOn) {
			if (axis == 0)
				logScaleX.setSelected(logScaleOn);
			else if (axis == 1)
				logScaleY.setSelected(logScaleOn);
			else
				logScaleZ.setSelected(logScaleOn);
		}
	}

	/**
	 * This class describes the tool selector box found in the toolbar of a
	 * Graph3DPanel. It allows for the selection of any of the applicable tools
	 * for the plot panel, including rotating, panning, and zooming.
	 */
	protected class ToolSelector extends JComboBox {
		/**
		 * Default constructor. Initializes the selectable tool items, adds the
		 * selection listener, and enables/disables the selectable tools
		 */
		public ToolSelector() {
			// Construct Tool Options list
			super(availableTools);

			// Fix the width of the selection box to fit all strings
			String prototypeValue = "XXXXXXXXXXXXXXXXXX";
			this.setPrototypeDisplayValue(prototypeValue);
			this.setMaximumSize(getPreferredSize());

			// default to Rotate
			setSelectedIndex(0);

			// Add listeners to the tool selector
			addListeners();
		}

		/**
		 * Adds the listener to the tool selector box, setting the appropriate
		 * mode given the selected tool.
		 */
		private void addListeners() {
			this.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// Set the mouse action mode to the selected tool
					int selection = getSelectedIndex();
					switch (selection) {
					case 0:
						plot.plotCanvas.ActionMode = 2;
						break; // ROTATE = 2
					case 1:
						plot.plotCanvas.ActionMode = PlotCanvas.TRANSLATION;
						break;
					case 2:
						plot.plotCanvas.ActionMode = PlotCanvas.ZOOM;
						break;
					default:
						System.out.println("Invalid Mouse Action Selection");
						break;
					}

					// Update Toolbar and popup menu
					updateTool();
				}
			});
		}
	}

	/**
	 * Draw the Equilibrium points when new Equilibrium point is received.
	 */
	@Override
	public void equilibriumReceived() {
		// draw the solution curves
		plotState.repaint();
	}
}
