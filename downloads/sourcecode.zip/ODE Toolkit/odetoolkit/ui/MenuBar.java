/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui;

import java.awt.AWTException;
import java.awt.Component;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.filechooser.FileFilter;
import javax.swing.text.DefaultEditorKit;

import ui.dialogs.AboutBox;
import ui.dialogs.OpenURLDialog;
import ui.outputpanels.ODEWorkspace;
import util.BareBonesBrowserLaunch;
import util.ExtensionFilter;

/**
 * The MenuBar class describes the menu bar for ODE Toolkit and defines the
 * behaviors of the menu items. It defines File, Edit, Library, and Help menus.
 * 
 * Note: the code for library is commented out, but not removed as this
 * functionality may be added back.
 * 
 * @author Clinic 10-11, modified from Andres Perez 09
 */
@SuppressWarnings("serial")
public class MenuBar extends JMenuBar {
	/** The GUI for which to create a menu bar */
	private GUI gui;

	/** Top-level Menu */
	private JMenu fileMenu, editMenu, libraryMenu, helpMenu;

	/** File menu */
	private JMenuItem newODE, open, openURL, close, save, saveAs, exit;
	/** Static file menu */
	private static JMenuItem print, export;

	/** Edit menu */
	private JMenuItem cut, copy, paste, delete, selectAll;
	/** Static edit menu */
	private static JMenuItem undo, redo;

	/** Library menu */
	private JMenuItem library;

	/** Help menu */
	private JMenuItem help, about;

	/** The URL to the documentation page */
	private static final String ODE_HELP = "http://odetoolkit.hmc.edu/documentation.html";
	/** The URL to the library page */
	private static final String ODE_LIBRARY = "http://odetoolkit.hmc.edu/library.html";

	// the removed code for saving to library
	// private static final String LIBRARY = currentDir.getAbsolutePath() +
	// "/library/";

	/**
	 * Constructor, defines the menu bar items for ODE Toolkit's menu bar and
	 * adds the appropriate listeners to the menu items.
	 * 
	 * @param owner
	 *            GUI for which to create a menu bar
	 */
	public MenuBar(GUI owner) {
		gui = owner; // Set the associated GUI
		initializeMenuItems(); // Initialize dialog box items
		setAccelerators(); // Set accelerator keystrokes
		addListeners(); // Add listeners
		addMenuItems(); // Build the menu bar
	}

	/**
	 * Initializes all the menu bar items and sets the keyboard mnemonics.
	 */
	private void initializeMenuItems() {
		// Menus
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		editMenu = new JMenu("Edit");
		fileMenu.setMnemonic(KeyEvent.VK_E);
		libraryMenu = new JMenu("Library");
		fileMenu.setMnemonic(KeyEvent.VK_L);
		helpMenu = new JMenu("Help");
		fileMenu.setMnemonic(KeyEvent.VK_H);

		// File menu
		newODE = new JMenuItem("New Workspace", KeyEvent.VK_N);
		open = new JMenuItem("Open...", KeyEvent.VK_O);
		openURL = new JMenuItem("Open From Web...", KeyEvent.VK_U);
		close = new JMenuItem("Close", KeyEvent.VK_C);
		save = new JMenuItem("Save", KeyEvent.VK_S);
		saveAs = new JMenuItem("Save As...");
		print = new JMenuItem("Print...", KeyEvent.VK_P);
		export = new JMenuItem("Export...");
		exit = new JMenuItem("Exit");

		// Edit menu
		undo = new JMenuItem("Undo", KeyEvent.VK_Z);
		redo = new JMenuItem("Redo", KeyEvent.VK_Z);
		cut = new JMenuItem(new DefaultEditorKit.CutAction());
		cut.setText("Cut");
		copy = new JMenuItem(new DefaultEditorKit.CopyAction());
		copy.setText("Copy");
		paste = new JMenuItem(new DefaultEditorKit.PasteAction());
		paste.setText("Paste");
		delete = new JMenuItem("Delete");
		selectAll = new JMenuItem("Select All");

		// Library menu
		library = new JMenuItem("Show Library...");
		// saveToLibrary = new JMenuItem("Save current ODE to library...");

		// Help menu
		about = new JMenuItem("About ODE Toolkit...");
		help = new JMenuItem("Online Tutorial");
	}

	/**
	 * Adds the menu items to the menu bar.
	 */
	private void addMenuItems() {
		// Add menus
		add(fileMenu);
		add(editMenu);
		add(libraryMenu);
		add(helpMenu);

		// Add file menu items
		fileMenu.add(newODE);
		fileMenu.add(open);
		fileMenu.add(openURL);
		fileMenu.add(close);
		fileMenu.addSeparator();
		fileMenu.add(save);
		fileMenu.add(saveAs);
		fileMenu.addSeparator();
		fileMenu.add(print);
		fileMenu.add(export);
		if (!GUI.osName.startsWith("Mac OS")) {
			fileMenu.addSeparator();
			fileMenu.add(exit);
		}

		// Add edit menu items
		editMenu.add(undo);
		editMenu.add(redo);
		editMenu.addSeparator();
		editMenu.add(cut);
		editMenu.add(copy);
		editMenu.add(paste);
		editMenu.add(delete);
		editMenu.addSeparator();
		editMenu.add(selectAll);

		// Add library menu items
		libraryMenu.add(library);
		// removed save to library code
		// libraryMenu.add(saveToLibrary);

		// Add help menu items
		helpMenu.add(help);
		helpMenu.addSeparator();
		helpMenu.add(about);
	}

	/**
	 * Sets the accelerator keystrokes for all the menu items that use a
	 * keyboard shortcut.
	 */
	private void setAccelerators() {
		// File menu
		KeyStroke ctrlNKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_N,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		newODE.setAccelerator(ctrlNKeyStroke);

		KeyStroke ctrlOKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_O,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		open.setAccelerator(ctrlOKeyStroke);

		KeyStroke shiftCtrlOKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_O,
				(java.awt.event.InputEvent.SHIFT_MASK | (Toolkit
						.getDefaultToolkit().getMenuShortcutKeyMask())));
		openURL.setAccelerator(shiftCtrlOKeyStroke);

		KeyStroke ctrlWKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_W,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		close.setAccelerator(ctrlWKeyStroke);

		KeyStroke ctrlSKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_S,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		save.setAccelerator(ctrlSKeyStroke);

		KeyStroke shiftCtrlSKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_S,
				(java.awt.event.InputEvent.SHIFT_MASK | (Toolkit
						.getDefaultToolkit().getMenuShortcutKeyMask())));
		saveAs.setAccelerator(shiftCtrlSKeyStroke);

		KeyStroke ctrlPKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_P,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		print.setAccelerator(ctrlPKeyStroke);

		KeyStroke ctrlEKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_E,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		export.setAccelerator(ctrlEKeyStroke);

		KeyStroke ctrlZKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		undo.setAccelerator(ctrlZKeyStroke);

		KeyStroke shiftCtrlZKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				(java.awt.event.InputEvent.SHIFT_MASK | (Toolkit
						.getDefaultToolkit().getMenuShortcutKeyMask())));
		redo.setAccelerator(shiftCtrlZKeyStroke);

		KeyStroke ctrlXKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_X,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		cut.setAccelerator(ctrlXKeyStroke);

		KeyStroke ctrlCKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_C,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		copy.setAccelerator(ctrlCKeyStroke);

		KeyStroke ctrlVKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_V,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		paste.setAccelerator(ctrlVKeyStroke);

		KeyStroke deleteKeyStroke = KeyStroke.getKeyStroke("DELETE");
		delete.setAccelerator(deleteKeyStroke);

		KeyStroke ctrlAKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_A,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		selectAll.setAccelerator(ctrlAKeyStroke);

		// Library menu
		KeyStroke ctrlLKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_L,
				(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		library.setAccelerator(ctrlLKeyStroke);
	}

	/**
	 * Adds listeners to all the menu items.
	 */
	private void addListeners() {
		// Define keys for Edit menu listeners
		int ctrlInput = KeyEvent.VK_CONTROL;
		if (GUI.osName.startsWith("Mac OS"))
			ctrlInput = KeyEvent.VK_META;
		final int ctrl = ctrlInput;
		final int shift = KeyEvent.VK_SHIFT;

		// File menu
		newODE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.addWorkspace();
			}
		});

		open.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
				chooser.setAcceptAllFileFilterUsed(false);
				chooser.setFileFilter(new FileFilter() {
					@Override
					public boolean accept(File f) {
						if (f.isDirectory()) {
							return true;
						}
						String name = f.getName().toLowerCase();
						return name.endsWith(".ode");
					}

					@Override
					public String getDescription() {
						return "ODE Workspace files";
					}
				});

				int returnVal = chooser.showOpenDialog(gui);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File selectedFile = chooser.getSelectedFile();
					if (!alreadyOpened(selectedFile, null)) {
						try {
							gui.openWorkspace(selectedFile);
						} catch (InterruptedException e1) {
						}
					}
				}
			}
		});

		openURL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.showDialog(new OpenURLDialog(gui));
			}
		});

		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.removeWorkspace();
			}
		});

		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File f = GUI.activeWorkspace.getFile();
				if (f == null) // save-as functionality
				{
					chooseAndSaveFile();
				} else
					gui.saveWorkspace(f);
			}
		});

		saveAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chooseAndSaveFile();
			}
		});

		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.print();
			}
		});

		export.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.export();
			}
		});

		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.exit();
			}
		});

		// Edit Menu
		undo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Robot r = new Robot();
					r.keyPress(ctrl);
					r.keyPress(KeyEvent.VK_Z);
					r.keyRelease(KeyEvent.VK_Z);
					r.keyRelease(ctrl);
				} catch (AWTException awt) {
				}
			}
		});

		redo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Robot r = new Robot();
					r.keyPress(ctrl);
					r.keyPress(shift);
					r.keyPress(KeyEvent.VK_Z);
					r.keyRelease(KeyEvent.VK_Z);
					r.keyRelease(shift);
					r.keyRelease(ctrl);
				} catch (AWTException awt) {
				}
			}
		});

		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Robot r = new Robot();
					r.keyPress(KeyEvent.VK_BACK_SPACE);
				} catch (AWTException awt) {
				}
			}
		});

		selectAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Robot r = new Robot();
					r.keyPress(KeyEvent.VK_META);
					r.keyPress(KeyEvent.VK_A);
					r.keyRelease(KeyEvent.VK_A);
					r.keyRelease(KeyEvent.VK_META);
				} catch (AWTException awt) {
				}
			}
		});

		// Library menu
		library.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BareBonesBrowserLaunch.openURL(MenuBar.ODE_LIBRARY);
				// Old code for opening local library.
				/*
				 * ODELibraryDialog lib = new ODELibraryDialog(gui, true);
				 * GUI.activeWorkspace.showDialog(lib); File f = lib.getFile();
				 * if (f != null) try { gui.openWorkspace(f); } catch
				 * (InterruptedException e1) { }
				 */}
		});

		/*
		 * the removed save to library code saveToLibrary.addActionListener(new
		 * ActionListener() { public void actionPerformed(ActionEvent e) {
		 * JFileChooser saveAsDialog = new JFileChooser("LIBRARY");
		 * saveAsDialog.setFileFilter(new ExtensionFilter(
		 * "ODE Toolkit Workspaces (*.ode)", ".ode"));
		 * saveAsDialog.setMultiSelectionEnabled(false);
		 * saveFileFromChooser(saveAsDialog); } });
		 */

		// Help menu
		help.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BareBonesBrowserLaunch.openURL(MenuBar.ODE_HELP);
			}
		});

		about.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.showDialog(new AboutBox());
			}
		});
	}

	/**
	 * Create a JFileChooser for choosing a file to save, and suggest a default
	 * name.
	 */
	void chooseAndSaveFile() {
		JFileChooser chooser = new JFileChooser();
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.setFileFilter(new ExtensionFilter(
				"ODE Workspace files (*.ode)", ".ode"));
		chooser.setMultiSelectionEnabled(false);

		// display default title
		String suggestedName = GUI.activeWorkspace.getName();
		if (suggestedName.startsWith("NewWorkspace"))
			suggestedName = suggestedName.substring(3);
		if (suggestedName.endsWith(".ode"))
			suggestedName = suggestedName.substring(0,
					suggestedName.length() - 4);
		chooser.setSelectedFile(new File(chooser.getCurrentDirectory()
				.getAbsolutePath(), suggestedName));
		saveFileFromChooser(chooser);
	}

	/**
	 * Save file at the location specified by the file chooser
	 * 
	 * @param chooser
	 *            the file chooser used to specify the file
	 */
	void saveFileFromChooser(JFileChooser chooser) {
		int result = chooser.showSaveDialog(gui);
		if (result == JFileChooser.APPROVE_OPTION) {
			File selectedFile = chooser.getSelectedFile();
			if (selectedFile != null) {
				File renamedFile = io.ODEFileHandler.appendExtension(
						selectedFile, ".ode");
				if (alreadyOpened(renamedFile, GUI.activeWorkspace)) {
					gui.showMessage(
							"The specified Workspace file is opened in other tab.",
							"error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				GUI.activeWorkspace.storeName(renamedFile.getName());
				gui.saveWorkspace(renamedFile);
				GUI.activeWorkspace.setFile(renamedFile);
			}
		}
	}

	/**
	 * Check whether the given file is already opened any workspace except for
	 * the excluded one
	 * 
	 * @param exclude
	 *            the ODEWorkspace to be excluded from this check
	 * @return true iff the file is opened in other workspace
	 */
	boolean alreadyOpened(File file, ODEWorkspace exclude) {
		for (Component odews : GUI.workspaces.getComponents()) {
			File currentFile = ((ODEWorkspace) odews).getFile();
			if (odews != exclude && currentFile != null
					&& currentFile.equals(file)) {
				GUI.workspaces.setSelectedComponent(odews);
				return true;
			}
		}
		return false;
	}

	/**
	 * Enables or disables the print and export items in the File menu,
	 * depending on the state of the current workspace. If a plot panel is not
	 * in view, for example, than the print/export options are grayed out.
	 * 
	 * @param canPrint
	 *            true if printing/exporting is possible
	 */
	public static void updatePrintStatus(boolean canPrint) {
		print.setEnabled(canPrint);
		export.setEnabled(canPrint);
	}

	/**
	 * Enables or disables the undo item in the Edit menu. This method is called
	 * by the InputPanel to update the menu bar every time the UndoManager is
	 * updated.
	 * 
	 * @param canUndo
	 *            true if undo edits are possible
	 */
	public static void updateUndoStatus(boolean canUndo) {
		if (canUndo)
			undo.setText("Undo");
		else
			undo.setText("Can't Undo");
		undo.setEnabled(canUndo);
	}

	/**
	 * Enables or disables the redo item in the Edit menu. This method is called
	 * by the InputPanel to update the menu bar every time the UndoManager is
	 * updated.
	 * 
	 * @param canRedo
	 *            true if redo edits are possible
	 */
	public static void updateRedoStatus(boolean canRedo) {
		if (canRedo)
			redo.setText("Redo");
		else
			redo.setText("Can't Redo");
		redo.setEnabled(canRedo);
	}
}
