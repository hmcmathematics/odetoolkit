/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui;

import java.awt.BorderLayout;
import java.text.DecimalFormat;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 * The StatusBar class is responsible for displaying the small bar at the bottom
 * of the program window. It displays the most recent initial conditions found
 * by the user by clicking on the plot, a message window for communicating
 * important messages or status updates to the user, and a progress bar to be
 * enabled whenever the program is running a significantly long operation.
 * 
 * The StatusBar class has methods to change the message display and activate/
 * de-activate the (indeterminate) progress bar, as well as for updating the
 * point display.
 * 
 * @author Clinic 08-09
 */
@SuppressWarnings("serial")
public class StatusBar extends JPanel {
	/** The point selected by the user */
	private JLabel graphPoint;
	/** The status message */
	private JLabel message;
	/** Program activity indicator */
	private JProgressBar progressBar;

	/**
	 * Default Constructor, constructs a status bar for the bottom of the
	 * program window, containing a display of the point clicked by the user, a
	 * message label for communicating program activity to the user, and an
	 * indeterminate progress bar to indicate program activity.
	 */
	public StatusBar() {
		graphPoint = new JLabel("(0,0)");
		graphPoint.setBorder(BorderFactory.createEmptyBorder(0, 7, 7, 0));

		message = new JLabel();
		message.setHorizontalAlignment(SwingConstants.RIGHT);
		message.setBorder(BorderFactory.createEmptyBorder(0, 7, 7, 7));

		progressBar = new JProgressBar();
		progressBar.setBorder(BorderFactory.createEmptyBorder(0, 0, 7, 7));

		setLayout(new BorderLayout()); // required for customizing the layout

		add(new JSeparator(), BorderLayout.NORTH); // separate from the
		// interface above.
		add(graphPoint, BorderLayout.WEST);
		add(message, BorderLayout.CENTER);
		add(progressBar, BorderLayout.EAST);
	}

	/**
	 * Returns the status of the progress bar.
	 * 
	 * So that multiple-step operations display a smooth progress bar animation,
	 * this method gives a process the ability to leave the progress bar as it
	 * was when one sub-process is finished.
	 * 
	 * @return true iff the status of the progress bar is set to busy
	 */
	public boolean isBusy() {
		return progressBar.isEnabled();
	}

	/**
	 * Enables/disables the progress bar. The progress bar is always set to
	 * indeterminate to indicate that the program is working, but no completion
	 * percentage will be shown.
	 * 
	 * @param busy
	 *            whether the progress bar shown be shown as busy
	 */
	public void setBusy(boolean busy) {
		progressBar.setEnabled(busy);
		progressBar.setIndeterminate(busy);
	}

	/**
	 * Setter for the message display.
	 * 
	 * @param msg
	 *            the message to display
	 */
	public void setMessage(String msg) {
		message.setText(msg);
	}

	/**
	 * This method allows for the program to update the status display (message
	 * + progress bar) in a one line-call.
	 * 
	 * @param msg
	 *            the message to display
	 * @param busy
	 *            whether the progress bar should be shown as busy
	 */
	public void setStatus(String msg, boolean busy) {
		message.setText(msg);
		progressBar.setEnabled(busy);
		progressBar.setIndeterminate(busy);
	}

	/**
	 * When the user clicks on the graph, this function is called to update the
	 * point displayed on the status bar.
	 * 
	 * Note that this does not support scientific notation.
	 * 
	 * @param x
	 *            the x-coordinate of the initial condition set
	 * @param y
	 *            the y-coordinate of the initial condition set
	 */
	public void updatePoint(double x, double y) {
		DecimalFormat df = new DecimalFormat("#.0###");
		String shortX = df.format(x); // truncate x
		String shortY = df.format(y); // truncate y

		graphPoint.setText("(" + shortX + "," + shortY + ")");
	}
}
