/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/* This class is currently unused, but it contains dialog for opening local
   library that may be useful if this feature is added back.

package ui.dialogs;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import util.FileSystemModel;

// @author mhunt
@SuppressWarnings("serial")
public class ODELibraryDialog extends javax.swing.JDialog implements
TreeSelectionListener {
	public ODELibraryDialog(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		initComponents();
	}

	// <editor-fold defaultstate="collapsed" desc=" Generated Code ">
	private void initComponents() {
		filePanel = new javax.swing.JScrollPane();
		fileModel = new FileSystemModel("./library/");

		fileTree = new javax.swing.JTree(fileModel) {
			@Override
			public String convertValueToText(Object value, boolean selected,
					boolean expanded, boolean leaf, int row, boolean hasFocus) {
				String filename = ((File) value).getName();
				if (filename.toLowerCase().endsWith(".ode"))
					return filename.substring(0, filename.length() - 4);
				return filename;
			}
		};
		fileTree.addTreeSelectionListener(this);
		fileTree.addMouseListener(new MouseListener() {
			public void mouseClicked(MouseEvent evt) {
				if (evt.getClickCount() == 2 && valueIsFile())
					loadActionPerformed();
			}

			public void mousePressed(MouseEvent arg0) {
			}

			public void mouseReleased(MouseEvent arg0) {
			}

			public void mouseEntered(MouseEvent arg0) {
			}

			public void mouseExited(MouseEvent arg0) {
			}
		});
		mainPanel = new javax.swing.JPanel();
		previewTextScrollPane = new javax.swing.JScrollPane();
		previewText = new javax.swing.JTextPane();
		previewLabel = new javax.swing.JLabel();
		buttonPanel = new javax.swing.JPanel();
		load = new javax.swing.JButton();
		cancel = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		filePanel.setViewportView(fileTree);

		previewTextScrollPane.setViewportView(previewText);

		previewLabel.setText("Preview:");

		load.setText("Load");
		load.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				if(valueIsFile())
					loadActionPerformed();
			}
		});

		cancel.setText("Cancel");
		cancel.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				cancelActionPerformed(evt);
			}
		});

		org.jdesktop.layout.GroupLayout buttonPanelLayout = new org.jdesktop.layout.GroupLayout(
				buttonPanel);
		buttonPanel.setLayout(buttonPanelLayout);
		buttonPanelLayout.setHorizontalGroup(buttonPanelLayout
				.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
				.add(org.jdesktop.layout.GroupLayout.TRAILING, load,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 73,
						Short.MAX_VALUE).add(cancel,
								org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 73,
								Short.MAX_VALUE));
		buttonPanelLayout
		.setVerticalGroup(buttonPanelLayout
				.createParallelGroup(
						org.jdesktop.layout.GroupLayout.LEADING)
						.add(
								buttonPanelLayout
								.createSequentialGroup()
								.add(load)
								.addPreferredGap(
										org.jdesktop.layout.LayoutStyle.RELATED)
										.add(cancel).addContainerGap(64,
												Short.MAX_VALUE)));

		org.jdesktop.layout.GroupLayout mainPanelLayout = new org.jdesktop.layout.GroupLayout(
				mainPanel);
		mainPanel.setLayout(mainPanelLayout);
		mainPanelLayout
		.setHorizontalGroup(mainPanelLayout
				.createParallelGroup(
						org.jdesktop.layout.GroupLayout.LEADING)
						.add(
								mainPanelLayout
								.createSequentialGroup()
								.add(
										mainPanelLayout
										.createParallelGroup(
												org.jdesktop.layout.GroupLayout.LEADING)
												.add(
														mainPanelLayout
														.createSequentialGroup()
														.addContainerGap()
														.add(
																previewLabel))
																.add(
																		previewTextScrollPane,
																		org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
																		454,
																		Short.MAX_VALUE))
																		.addPreferredGap(
																				org.jdesktop.layout.LayoutStyle.RELATED)
																				.add(
																						buttonPanel,
																						org.jdesktop.layout.GroupLayout.PREFERRED_SIZE,
																						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
																						org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
																						.addContainerGap()));
		mainPanelLayout.setVerticalGroup(mainPanelLayout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(
						mainPanelLayout.createSequentialGroup().add(previewLabel)
						.addPreferredGap(
								org.jdesktop.layout.LayoutStyle.RELATED).add(
										previewTextScrollPane,
										org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
										96, Short.MAX_VALUE)).add(buttonPanel,
												org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
												org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(mainPanel,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
						org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.add(filePanel, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
								543, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				org.jdesktop.layout.GroupLayout.LEADING).add(
						org.jdesktop.layout.GroupLayout.TRAILING,
						layout.createSequentialGroup().add(filePanel,
								org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 186,
								Short.MAX_VALUE).addPreferredGap(
										org.jdesktop.layout.LayoutStyle.RELATED).add(mainPanel,
												org.jdesktop.layout.GroupLayout.PREFERRED_SIZE,
												org.jdesktop.layout.GroupLayout.DEFAULT_SIZE,
												org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)));
		pack();
	}// </editor-fold>

	private void loadActionPerformed() {
		doLoad = true;
		this.dispose();
	}

	private void cancelActionPerformed(ActionEvent evt) {
		doLoad = false;
		this.dispose();
	}

	public File getFile() {
		if (doLoad) {
			return new File(selectedFilename);
		}
		return null;
	}

	public boolean valueIsFile() {
		File f = new File(selectedFilename);
		if (!f.isFile() || f == null)
			return false;
		return true;
	}

	// Possible improvement: Change to SAX implementation for speed
	public void valueChanged(TreeSelectionEvent arg0) {
		selectedFilename = fileTree.getLastSelectedPathComponent().toString();
		if (!valueIsFile())
			return;
		DOMParser parser = new DOMParser();

		try {
			parser.parse(selectedFilename);

		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		Document document = parser.getDocument();
		Element root;
		String workspaceName;

		root = document.getDocumentElement();
		workspaceName = getTextValue(root, "workspaceName");

		previewText.setText(workspaceName);
	}

	private String getTextValue(Element ele, String tagName) {
		String textVal = null;
		NodeList nl = ele.getElementsByTagName(tagName);
		if (nl != null && nl.getLength() > 0) {
			Element el = (Element) nl.item(0);
			textVal = el.getFirstChild().getNodeValue();
		}

		return textVal;
	}

	// Variables declaration - do not modify
	private javax.swing.JPanel buttonPanel;
	private javax.swing.JButton cancel;
	private javax.swing.JScrollPane filePanel;
	private javax.swing.JTree fileTree;
	private FileSystemModel fileModel;
	private javax.swing.JButton load;
	private javax.swing.JPanel mainPanel;
	private javax.swing.JLabel previewLabel;
	private javax.swing.JTextPane previewText;
	private javax.swing.JScrollPane previewTextScrollPane;
	private String selectedFilename;
	private boolean doLoad = false;
	// End of variables declaration
}

*/