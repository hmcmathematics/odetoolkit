/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.GridLayout;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.TitledBorder;

/**
 * This class holds the dialog box that allows the user to change solver choice.
 * It contains radio buttons for users to choose solver.
 *
 * @author Clinic 10-11, modified from Clinic 08-09, modified by Max Comstock
 * 2013
 */

@SuppressWarnings("serial")
public class SolverChoicePanel extends JPanel {

	/** Solver choices */
	public JRadioButton rbButton, rkButton, eulerButton;
	/** Solver descriptions */
	public JLabel rbDescription, rkDescription, eulerDescription;

	/** the button group for solver choices */
	private ButtonGroup solverButtonGroup;
	
	private String rbInfo =
			"<html>The Rosenbrock solver is an improvement to the<br>" +
			"Runge-Kutta solver that is capable of solving stiff<br>" +
			"differential equations. This means that it can solve more<br>" +
			"differential equations accurately than the Runge-Kutta<br>" +
			"solver. However, it requires more computation, and takes<br>" +
			"longer to find solutions as they approach infinity.</html>";
	
	private String rkInfo =
			"<html>The Runge-Kutta method is one of the most common ways<br>" +
			"of finding numerical solutions to differential equations.<br>" +
			"Rather than taking a single approximation for each step,<br>" +
			"the solution is estimated at the beginning, end, and two<br>" +
			"midpoints of the step. This allows for greater accuracy,<br>" +
			"since the error at each step is fifth-order and the total<br>" +
			"error is fourth-order. This version has an adaptive step<br>" +
			"size method, meaning that it will take smaller steps if<br>" +
			"the estimated accuracy is too low, and larger steps<br>" +
			"otherwise for improved speed.</html>";
	
	private String eulerInfo =
			"<html>The Euler solver uses Euler's method to find an <br>" +
			"approximation of the solution to a differential equation.<br>" +
			"This method simply takes the numerical derivative at each<br>" +
			"step and approximates the step as a segment of the tangent<br>" +
			"line. This method is not particularly accurate, but is very<br>" +
			"fast and reliable.";

	/** Constructs a new SolverChoicePanel. */
	public SolverChoicePanel() {
		// Note that action listening is handled within the SolverOptionPanel

		setBorder(new TitledBorder("Current Solver"));
		setLayout(new GridLayout(6, 1));

		rbButton = new JRadioButton("Rosenbrock Solver");
		rbButton.setToolTipText(rbInfo);
		rbDescription = new JLabel(
				"       adaptive, semi-implicit, multi-stage method");
		rkButton = new JRadioButton("Runge-Kutta-Fehlberg (4/5) Solver");
		rkButton.setToolTipText(rkInfo);
		rkDescription = new JLabel(
				"       adaptive, explicit, multi-stage method");
		eulerButton = new JRadioButton("Euler Solver");
		eulerButton.setToolTipText(eulerInfo);
		eulerDescription = new JLabel("       explicit, first order method");

		solverButtonGroup = new ButtonGroup();
		solverButtonGroup.add(rbButton);
		solverButtonGroup.add(rkButton);
		solverButtonGroup.add(eulerButton);

		add(rbButton);
		add(rbDescription);
		add(rkButton);
		add(rkDescription);
		add(eulerButton);
		add(eulerDescription);
	}

	/**
	 * Disallow changes to the buttons and descriptions, used in data tab.
	 */
	public void disallowChanges() {
		rbButton.setEnabled(false);
		rbDescription.setEnabled(false);
		rkButton.setEnabled(false);
		rkDescription.setEnabled(false);
		eulerButton.setEnabled(false);
		eulerDescription.setEnabled(false);
	}

}
