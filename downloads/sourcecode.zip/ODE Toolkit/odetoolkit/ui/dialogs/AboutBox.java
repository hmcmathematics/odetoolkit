/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import ui.GUI;


/**
 * The AboutBox class defines a dialog box containing information about ODE
 * Toolkit, which appears when the user selects "About ODE Toolkit..." in the
 * Help menu. It contains an image of the ODE Toolkit icon and a text area
 * describing those who are/were involved with the project.
 * 
 * @author Clinic 10-11, modified from Andres Perez 2009
 */
@SuppressWarnings("serial")
public class AboutBox extends JDialog {
	/** The panel containing the ODEToolkit icon */
	private JPanel iconPanel;
	/** The panel containing the ODEToolkit information */
	private JPanel aboutPanel;
	/** The panel containing the ok buton */
	private JPanel buttonPanel;

	/** ODE Toolkit icon */
	private JLabel toolkitIcon; 
	/** About the project */
	private JTextArea aboutInfo;
	/** 'OK' button */
	private JButton okButton; 

	/**
	 * The constructor initializes and adds all the components to the dialog box
	 * using a simple BorderLayout, and adds a listener to the 'OK' button for
	 * closing the window.
	 */
	public AboutBox() {
		initializeComponents(); // Initialize dialog box items
		addListeners(); // Add listeners
		addComponents(); // Build the dialog box
	}

	/**
	 * Initializes the components of the About box.
	 */
	private void initializeComponents() {
		iconPanel = new JPanel();
		aboutPanel = new JPanel();
		buttonPanel = new JPanel();

		toolkitIcon = new JLabel(new ImageIcon(GUI.class
				.getResource("images/ODEToolkit.png")));

		aboutInfo = new JTextArea(
				"ODE Toolkit is a free application that makes it easy to numerically solve"
				+ "\nsystems of ordinary differential equations."
				+ "\n\n"
				+ "It was developed at Harvey Mudd College by the following people:"
				+ "\nSupervisors: Professors Robert Borrelli, Courtney Coleman and Darryl Yong"
				+ "\nProgrammer (alpha 1.4): Max Comstock"
				+ "\nProgrammers (alpha 1.0-1.05 and 1.2-1.3): Beky Kotcon, Samantha Mesuro,"
				+ "\nDaniel Rozenfeld, Anak Yodpinyanee" 
				+ "\nProgrammers (alpha 1.0-1.2): Andres Perez"
				+ "\nProgrammers (alpha 0.9-1.0): Eric Doi, Andres Perez, Richard Mehlinger,"
				+ "\nSteven Ehrlich"
				+ "\nProgrammers (alpha 0.9): Martin Hunt, George Tucker"
				+ "\nProgrammers (alpha 0.6-0.8): Martin Hunt, Peter Scherpelz, George Tucker"
				+ "\nProgrammers (alpha version 0.0-0.6): Aaron Becker, Eric Harley, Chris Moore"
				+ "\n\n"
				+ "For more information on ODE Toolkit, please see"
				+ "\nhttp://odetoolkit.hmc.edu");

		okButton = new JButton("OK");
	}

	/**
	 * Adds a listener to the 'OK' button for closing the window.
	 */
	private void addListeners() {
		// 'OK' button listener
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}

	/**
	 * Adds all the components to the dialog and defines the layout.
	 */
	private void addComponents() {
		// Window settings
		setTitle("About ODE Toolkit");
		setResizable(false);
		setModal(true);

		// Add icon panel to dialog box
		add(iconPanel, BorderLayout.NORTH);

		// Icon panel layout
		toolkitIcon.setBorder(new EmptyBorder(10, 0, 0, 0));

		// Add icon panel components
		iconPanel.add(toolkitIcon);

		// Add about panel to dialog box
		add(aboutPanel, BorderLayout.CENTER);

		// About panel layout
		aboutPanel.setBorder(new EmptyBorder(0, 5, 0, 5));
		Border titleBorder = new TitledBorder(ui.GUI.ODETOOLKIT_VERSION);
		Border margin = new EmptyBorder(10, 10, 10, 10);
		aboutInfo.setBorder(new CompoundBorder(titleBorder, margin));
		aboutInfo.setBackground(new java.awt.Color(236, 236, 236));
		aboutInfo.setEditable(false);

		// Add about panel components
		aboutPanel.add(aboutInfo);

		// Add button panel to dialog box
		add(buttonPanel, BorderLayout.SOUTH);

		// Add button panel components
		buttonPanel.add(okButton);

		// This line maps the 'OK' button to the Enter key
		getRootPane().setDefaultButton(okButton);

		pack();
	}
}
