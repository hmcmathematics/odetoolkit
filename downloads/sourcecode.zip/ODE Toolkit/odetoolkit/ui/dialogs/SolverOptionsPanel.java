/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.border.TitledBorder;

import solver.SolverParameters;
import ui.outputpanels.ODEWorkspace;

/**
 * The solver options panel. Options such as step size and resolution are set in
 * this panel by the user. It controls all solver types.
 * 
 * @author Max Comstock 2013, 
 * modified from Clinic 10-11, Aaron Becker, Martin Hunt
 */
@SuppressWarnings("serial")
public class SolverOptionsPanel extends JDialog implements FocusListener {

	/** Panel for choosing solver */
	private SolverChoicePanel solverChoicePanel;

	/** The panel for this dialog box */
	private Container basePanel;

	/** RK Solver panel */
	RKPanel rkPanel;
	/** Euler Solver panel */
	EulerPanel eulerPanel;
	/** RB Solver panel */
	RBPanel rbPanel;

	/** Button for resetting parameters for current solver */
	private JButton resetCurrent;
	/** Button for resetting parameters for all solvers */
	private JButton resetAll;
	/** Close button */
	private JButton closeButton;

	/** Reference to current solver panel */
	private SolverPanel currentSolverPanel;

	/** Layout constraints */
	private GridBagConstraints c, solverOptionsLocation;

	/** Current solver parameters */
	private SolverParameters params;

	/**
	 * Constructs a new solver options panel associated with the given
	 * ODEWorkspace. Currently Euler, RK and RB solvers are supported.
	 * 
	 * @param owner
	 *            The ODEWorkspace associated with these solvers.
	 */
	public SolverOptionsPanel(SolverParameters p, ODEWorkspace owner) {
		super();
		params = p;

		// Initialization

		solverChoicePanel = new SolverChoicePanel();

		rkPanel = new RKPanel();
		rkPanel.setBorder(new TitledBorder("Runge-Kutta-Fehlberg (4/5) Options"));

		eulerPanel = new EulerPanel();
		eulerPanel.setBorder(new TitledBorder("Euler Options"));

		rbPanel = new RBPanel();
		rbPanel.setBorder(new TitledBorder("Rosenbrock Options"));

		// Layout
		basePanel = getContentPane();

		closeButton = new JButton("Close");
		resetAll = new JButton("Reset All");
		resetCurrent = new JButton("Reset");
		resetCurrent.setToolTipText("Reset current solver values to defaults");
		resetAll.setToolTipText("Reset all solver values to defaults");

		/*
		 * JPanel p = new JPanel(); p.setLayout(new GridBagLayout());
		 * GridBagConstraints c = new GridBagConstraints( 0, 0, 1, 1, 0, 0,
		 * GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new
		 * Insets(2, 2, 2, 2), 2, 2); getContentPane().add(p);
		 */
		
		// This option sets the default solver
		solverChoicePanel.rbButton.setSelected(true);

		if (solverChoicePanel.rkButton.isSelected())
			currentSolverPanel = rkPanel;
		else if (solverChoicePanel.rbButton.isSelected())
			currentSolverPanel = rbPanel;
		else if (solverChoicePanel.eulerButton.isSelected())
			currentSolverPanel = eulerPanel;

		basePanel.setLayout(new GridBagLayout());

		solverOptionsLocation = new GridBagConstraints();
		solverOptionsLocation.weightx = 4;
		solverOptionsLocation.weighty = 0;
		solverOptionsLocation.gridwidth = 4;
		solverOptionsLocation.fill = GridBagConstraints.HORIZONTAL;
		solverOptionsLocation.anchor = GridBagConstraints.NORTH;
		add(solverChoicePanel, solverOptionsLocation);

		solverOptionsLocation.gridy = 1;
		add(currentSolverPanel, solverOptionsLocation);

		c = new GridBagConstraints();
		c.gridwidth = 3;
		c.weightx = 2;
		c.gridy = 2;
		c.gridx = 0;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.SOUTH;
		add(resetCurrent, c);

		c.gridx++;
		c.anchor = GridBagConstraints.SOUTH;
		add(resetAll, c);

		c.gridx++;
		c.anchor = GridBagConstraints.SOUTH;
		add(closeButton, c);

		pack();

		// ActionListeners

		// Solver Panel

		// When a new solver is selected, remove the current solver option
		// panel and replace it with the appropriate panel, updating the
		// currentSolverPanel reference. repaint and validate are called
		// to ensure harmonious redrawing of the panels.
		solverChoicePanel.rkButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				remove(currentSolverPanel);
				add(rkPanel, solverOptionsLocation);
				currentSolverPanel = rkPanel;

				repaint();
				validate();
				pack();
			}
		});

		solverChoicePanel.rbButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				remove(currentSolverPanel);
				add(rbPanel, solverOptionsLocation);
				currentSolverPanel = rbPanel;

				repaint();
				validate();
				pack();
			}
		});

		solverChoicePanel.eulerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				remove(currentSolverPanel);
				add(eulerPanel, solverOptionsLocation);
				currentSolverPanel = eulerPanel;

				repaint();
				validate();
				pack();
			}
		});

		// Base Panel

		// When a reset button is pressed, set the appropriate panels back
		// to their default values.
		resetAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				eulerPanel.setDefaults();
				rkPanel.setDefaults();
				rbPanel.setDefaults();
			}
		});

		resetCurrent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (solverChoicePanel.rkButton.isSelected())
					rkPanel.setDefaults();
				else if (solverChoicePanel.rbButton.isSelected())
					rbPanel.setDefaults();
				else if (solverChoicePanel.eulerButton.isSelected())
					eulerPanel.setDefaults();
			}
		});

		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		addWindowFocusListener(new WindowFocusListener() {
			public void windowGainedFocus(WindowEvent arg0) {
			}

			@SuppressWarnings("deprecation")
			public void windowLostFocus(WindowEvent arg0) {
				if (!checkAll())
					show();
			}
		});
	}

	/**
	 * Check that the parameters are valid for the current solver.
	 * @return true iff the parameters for the current solver is valid
	 */
	public boolean checkAll() {
		boolean ok = false;
		if (solverChoicePanel.rkButton.isSelected())
			ok = rkPanel.check();
		else if (solverChoicePanel.rbButton.isSelected())
			ok = rbPanel.check();
		else if (solverChoicePanel.eulerButton.isSelected())
			ok = eulerPanel.check();
		return ok;
	}

	/**
	 * Set the controlling ODEWorkapce's solver parameters according to the
	 * current solver options. The workspace is responsible for resetting
	 * initial conditions to the appropriate values, as we have no access to
	 * them here.
	 * 
	 * @param p the SolverParameters to be set
	 */
	public void setParameters(SolverParameters p) {
		// Get parameters from the appropriate panel.
		params = p;

		if (solverChoicePanel.rkButton.isSelected())
			rkPanel.setParameters(params);
		else if (solverChoicePanel.rbButton.isSelected())
			rbPanel.setParameters(params);
		else if (solverChoicePanel.eulerButton.isSelected())
			eulerPanel.setParameters(params);
		else
			System.out.println("Error setting parameters.");
	}

	/**
	 * Update the option panel to match the given parameter.
	 * @param p the parameter to set to
	 */
	public void updateSolverParameters(SolverParameters p) {
		params = p;
		SolverPanel temp = rkPanel;
		if (params.getSolver().equals("RK")) {
			solverChoicePanel.rkButton.setSelected(true);
			rkPanel.updateParameters(params);
			temp = rkPanel;
		} else if (params.getSolver().equals("RB")) {
			solverChoicePanel.rbButton.setSelected(true);
			rbPanel.updateParameters(params);
			temp = rbPanel;
		} else if (params.getSolver().equals("EULER")) {
			solverChoicePanel.eulerButton.setSelected(true);
			eulerPanel.updateParameters(params);
			temp = eulerPanel;
		}
		remove(currentSolverPanel);
		add(temp, solverOptionsLocation);
		currentSolverPanel = temp;

		repaint();
		validate();
		pack();
	}

	/**
	 * Disallow changes to the buttons and descriptions, used in data tab.
	 */
	public void disallowChanges() {
		resetAll.setEnabled(false);
		resetCurrent.setEnabled(false);
		solverChoicePanel.disallowChanges();
		rkPanel.disallowChanges();
		eulerPanel.disallowChanges();
		rbPanel.disallowChanges();
	}

	/*
	 * FocusListener interface required methods
	 */
	public void focusGained(FocusEvent e) {

	}

	public void focusLost(FocusEvent e) {

	}

}
