/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ui.outputpanels.GraphPanel;
import ui.outputpanels.PlotPanel;

/**
 * The LabelDialog class is responsible for the dialog box that appears when the
 * user selects the "Labels..." option in the Graph Options menu. It contains
 * text fields for editing the labels of the plot title and the axis labels. Key
 * listeners are implemented to cause the graph to update in real- time as the
 * user edits the label fields
 * 
 * @author Andres Perez 2009
 */
@SuppressWarnings("serial")
public class LabelDialog extends JDialog implements WindowListener {
	/** PlotPanel for which to edit the labels */
	private PlotPanel plotOwner;

	/** Old labels stored in case of dialog cancellation */ 
	private String oldTitleLabel, oldXLabel, oldYLabel;

	/** Labels panel */
	private JPanel labelsPanel;
	/** "Plot Title" label */
	private JLabel titleLabel;
	/** "Vertical Axis:" label */
	private JLabel verticalLabel;
	/** ""Horizontal Axis:" label */
	private JLabel horizontalLabel;
	/** plot title input field */
	private JTextField titleField;
	/** vertical axis input field */
	private JTextField verticalField;
	/** horizontal axis input field */
	private JTextField horizontalField;

	/** Buttons panel */
	private JPanel buttonPanel;
	/** 'OK' button */
	private JButton okButton;
	/** 'Cancel' button */
	private JButton cancelButton;

	/**
	 * The constructor sets the PlotPanel owner, and then initializes all the
	 * elements in the dialog box, adds change listeners to the input fields,
	 * adds the listeners for the 'OK' and 'Cancel' buttons, and then adds the
	 * components to the dialog box using a GridLayout.
	 * 
	 * @param graphPanelOwner
	 *            the GraphPanel associated with the scale dialog
	 */
	public LabelDialog(GraphPanel graphPanelOwner) {
		// Set the associated Plot Panel
		plotOwner = graphPanelOwner.getPlotPanel();

		initializeComponents(); // Initialize dialog box items
		addListeners(); // Add listeners
		addComponents(); // Build the dialog box
		storeLabels(); // Store copy of labels
		addWindowListener(this); // Perform appropriate closing action
	}

	/**
	 * Initializes the components of the label dialog box.
	 */
	private void initializeComponents() {
		labelsPanel = new JPanel();

		titleLabel = new JLabel("Plot Title:");
		titleField = new JTextField(plotOwner.getTitle());

		verticalLabel = new JLabel("Vertical Axis:");
		verticalField = new JTextField(plotOwner.getYLabel());

		horizontalLabel = new JLabel("Horizontal Axis:");
		horizontalField = new JTextField(plotOwner.getXLabel());

		buttonPanel = new JPanel();

		okButton = new JButton("OK");
		cancelButton = new JButton("Cancel");
	}

	/**
	 * Adds key listeners to the input fields. Also adds listeners for the 'OK'
	 * and 'Cancel' buttons.
	 */
	private void addListeners() {
		// Title label key listener
		titleField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				plotOwner.setTitle(titleField.getText());
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// Vertical label key listener
		verticalField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				plotOwner.setYLabel(verticalField.getText());
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// Horizontal label key listener
		horizontalField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				plotOwner.setXLabel(horizontalField.getText());
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// 'OK' button listener
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		// 'Cancel' button listener
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restoreLabels();
				dispose();
				System.out.println("Label dialog box closed.");
			}
		});
	}

	/**
	 * Adds all the components to the label dialog box.
	 */
	private void addComponents() {
		// Window settings
		setTitle("Labels");
		setResizable(false);
		setModal(true);

		// Label fields layout
		GridLayout labelsPanelLayout = new GridLayout(3, 2);
		labelsPanelLayout.setHgap(5);
		labelsPanelLayout.setVgap(5);
		labelsPanelLayout.setColumns(1);
		labelsPanel.setLayout(labelsPanelLayout);

		// Add label panel to dialog box
		add(labelsPanel, BorderLayout.CENTER);
		labelsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		// Add label panel components
		labelsPanel.add(titleLabel);
		labelsPanel.add(titleField);
		labelsPanel.add(verticalLabel);
		labelsPanel.add(verticalField);
		labelsPanel.add(horizontalLabel);
		labelsPanel.add(horizontalField);

		// 'OK' and 'Cancel' buttons layout
		FlowLayout buttonPanelLayout = new FlowLayout();
		buttonPanelLayout.setAlignment(FlowLayout.RIGHT);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		buttonPanel.setLayout(buttonPanelLayout);

		// Add 'OK' and 'Cancel' buttons to buttons panel
		buttonPanel.add(okButton);
		buttonPanel.add(cancelButton);

		// Equalize the size of the buttons
		okButton.setPreferredSize(new Dimension(86, 29));
		cancelButton.setPreferredSize(new Dimension(86, 29));

		pack();

		// This line maps the 'OK' button to the Enter key
		getRootPane().setDefaultButton(okButton);

		System.out.println("Created label dialog box.");
	}

	/**
	 * This function stores a copy of the current labels. It is called whenever
	 * a LabelDialog is instantiated so that the labels can be restored upon
	 * hitting 'Cancel' in the dialog box.
	 */
	public void storeLabels() {
		oldTitleLabel = plotOwner.getTitle();
		oldXLabel = plotOwner.getXLabel();
		oldYLabel = plotOwner.getYLabel();
	}

	/**
	 * This function restores the labels to the values of the stored copy. It is
	 * called whenever the user hits 'Cancel' in the dialog box in order to
	 * "undo" the changes made while the dialog box was open.
	 */
	private void restoreLabels() {
		// Restore the text fields
		titleField.setText(oldTitleLabel);
		verticalField.setText(oldYLabel);
		horizontalField.setText(oldXLabel);

		// Restore the axis labels on the plot
		plotOwner.setTitle(oldTitleLabel);
		plotOwner.setYLabel(oldYLabel);
		plotOwner.setXLabel(oldXLabel);
	}

	/*
	 * WindowListener interface required methods
	 */

	public void windowActivated(WindowEvent arg0) {
	}

	public void windowClosed(WindowEvent arg0) {
	}

	public void windowClosing(WindowEvent arg0) {
		restoreLabels();
		System.out.println("Label dialog box closed.");
	}

	public void windowDeactivated(WindowEvent arg0) {
	}

	public void windowDeiconified(WindowEvent arg0) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}
}
