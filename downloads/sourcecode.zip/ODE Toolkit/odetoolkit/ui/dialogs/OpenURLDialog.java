/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ui.GUI;


/**
 * The OpenURLDialog class is responsible for the dialog box that appears when
 * the user selects 'Open from Web...' from the File menu in ODE Toolkit. It
 * contains a text field for entering the URL of a .ode file, and displays a
 * status message indicating the validity of the URL, which enables/disables the
 * 'OK' button. Upon the pressing of the 'OK' button, the dialog box calls the
 * openWorkspace method in the GUI for opening the .ode file contained in the
 * URL.
 * 
 * @author Andres Perez 2009
 */
@SuppressWarnings("serial")
public class OpenURLDialog extends JDialog {
	/** the GUI owning this dialog */
	private GUI gui;
	/** The URL stored in this dialog */
	private URL url;

	/** Panel showing message about the URL */
	private JPanel messagePanel;
	/** Panel for inputting the URL */
	private JPanel urlInputPanel;
	/** Panel containing the buttons */
	private JPanel buttonPanel;

	/** The message asking user to input URL */
	private JLabel message;
	/** The message telling user whether the URL is valid */
	private JLabel validityMessage;

	/** TextField for entering URL */
	private JTextField urlInput;

	/** The OK button */
	private JButton okButton;
	/** The cancel button */
	private JButton cancelButton;

	/**
	 * Constructor. Sets the GUI parent for opening the workspace, initializes
	 * and adds the components, and adds listeners to the text field and 'OK'
	 * and 'Cancel' buttons.
	 */
	public OpenURLDialog(GUI owner) {
		gui = owner;

		initializeComponents(); // Initialize dialog box items
		addListeners(); // Add listeners
		addComponents(); // Build the dialog box
	}

	/**
	 * Initializes all the components of the 3D scaling dialog box
	 */
	private void initializeComponents() {
		messagePanel = new JPanel();
		urlInputPanel = new JPanel();
		buttonPanel = new JPanel();

		message = new JLabel("Enter the URL address of a .ode file");
		validityMessage = new JLabel("Valid URL.");

		urlInput = new JTextField();

		okButton = new JButton("OK");
		cancelButton = new JButton("Cancel");
	}

	/**
	 * Adds a key listener to the URL input field to check for URL validity.
	 * Also adds listeners to the 'OK' and 'Cancel' buttons.
	 */
	private void addListeners() {
		// urlInput field key listeners
		urlInput.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				storeURL();
				checkInput();
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// 'OK' button listener
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Load .ode file (done in different thread)
				try {
					gui.openWorkspace(url);
				} catch (InterruptedException e1) {
					System.out.println("Error opening from URL.");
				}
				dispose();
				System.out.println("'Open from URL...' dialog box closed.");
			}
		});

		// 'Cancel' button listener
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				System.out.println("'Open from URL...' dialog box closed.");
			}
		});
	}

	/**
	 * Sets the dialog box title, size, and settings, and then adds all the
	 * components to the dialog box.
	 */
	private void addComponents() {
		// Window settings
		setTitle("Open from URL...");
		setResizable(false);
		setModal(true);

		// Add message panel
		add(messagePanel, BorderLayout.NORTH);

		// message panel layout
		FlowLayout messagePanelLayout = new FlowLayout();
		messagePanelLayout.setAlignment(FlowLayout.LEFT);
		messagePanel.setLayout(messagePanelLayout);
		messagePanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));

		// add message panel components
		messagePanel.add(message);

		// Add URL input panel
		add(urlInputPanel, BorderLayout.CENTER);

		// URL input panel layout
		urlInputPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));

		// Add URL input components
		urlInputPanel.add(urlInput);
		urlInput.setText("http://");
		urlInput.setPreferredSize(new java.awt.Dimension(400, 28));

		// Add buttons panel
		add(buttonPanel, BorderLayout.SOUTH);

		// Buttons panel layout
		FlowLayout buttonPanelLayout = new FlowLayout();
		buttonPanelLayout.setAlignment(FlowLayout.RIGHT);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 0));
		buttonPanel.setLayout(buttonPanelLayout);

		// Add buttons panel components
		buttonPanel.add(validityMessage);
		validityMessage.setIcon(new ImageIcon(GUI.class
				.getResource("images/yes.png")));
		validityMessage.setVisible(false);
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.add(okButton);
		okButton.setPreferredSize(new Dimension(86, 29));
		okButton.setEnabled(false);
		buttonPanel.add(cancelButton);
		cancelButton.setPreferredSize(new Dimension(86, 29));

		pack();
		
		// Presses 'OK' upon hitting Enter
		getRootPane().setDefaultButton(okButton);

		System.out.println("Created 'Open from URL...' dialog box.");
	}

	/**
	 * Checks the input for a valid URL. If the URL is valid and contains a .ode
	 * file, then the 'OK' button is enabled, otherwise, the validity message is
	 * updated appropriately.
	 */
	private void checkInput() {
		int response = 0;

		try {
			URLConnection connection = url.openConnection();
			if (connection instanceof HttpURLConnection) {
				HttpURLConnection httpConnection = (HttpURLConnection) connection;
				httpConnection.connect();
				response = httpConnection.getResponseCode();
				InputStream is = httpConnection.getInputStream();
				byte[] buffer = new byte[256];
				while (is.read(buffer) != -1) {
				}
				is.close();
				if (!(response >= 300) // no redirection, error, or server error
						&& urlInput.getText().trim().endsWith(".ode")) {
					setMessage("Valid URL.", true);
					okButton.setEnabled(true);
					return;
				}
			}
		} catch (IOException e) {
		}
		if (response >= 300)
			setMessage("Not a Valid URL", false);
		else if (!urlInput.getText().trim().endsWith(".ode"))
			setMessage("Not a .ode file", false);
		okButton.setEnabled(false);
	}

	/**
	 * Stores the input from the text field as a url.
	 */
	private void storeURL() {
		String input = urlInput.getText();
		// Construct url, adding http prefix if not already present
		// if no host is specified or input is empty/does not start with a
		// letter, add a dummy character to avoid null host errors
		if (input.equals("http://") // blank
				|| input.equals("") // blank
				|| !Character.isLetter(input.charAt(0)) // invalid host
				|| (input.startsWith("http://") // invalid host
						&& !Character.isLetter(input.charAt(7))))
			try {
				url = new URL("http://_");
			} catch (MalformedURLException e) {
			}

			else if (!input.startsWith("http://"))
				try {
					url = new URL(("http://" + input).trim());
				} catch (MalformedURLException e) {
				}

				else
					try {
						url = new URL(input.trim());
					} catch (MalformedURLException e) {
					}
	}

	/**
	 * Sets the message at the bottom of the window and displays a check or x
	 * icon indicating whether the URL is valid.
	 * 
	 * @param message
	 *            String containing message to the user
	 * @param valid
	 *            true to display check mark, false to display x
	 */
	private void setMessage(String message, boolean valid) {
		validityMessage.setVisible(true);
		validityMessage.setText(message);
		if (valid)
			validityMessage.setIcon(new ImageIcon(GUI.class
					.getResource("images/yes.png")));
		else
			validityMessage.setIcon(new ImageIcon(GUI.class
					.getResource("images/no.png")));
	}
}
