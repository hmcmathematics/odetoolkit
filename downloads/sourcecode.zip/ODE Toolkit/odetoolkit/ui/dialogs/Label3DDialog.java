/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.JDialog;

import org.math.plot.Plot3DPanel;

import ui.outputpanels.Graph3DPanel;

/**
 * The Label3DDialog class is responsible for the dialog box that appears when
 * the user selects the "Labels..." option in the Graph Options menu while
 * inside a 3D Graph Panel. It contains text fields for editing the labels of
 * each of the axes. Key listeners are implemented to cause the graph to update
 * in real-time as the user edits the label fields.
 * 
 * @author Clinic 10-11, modified from Andres Perez 2009
 */
@SuppressWarnings("serial")
public class Label3DDialog extends JDialog implements WindowListener {
	/** Plot3DPanel for which to edit the labels */
	private Plot3DPanel plotOwner;
	/** Reference back to its Graph3DPanel */
	private Graph3DPanel graphOwner;

	/** Old labels stored in case of dialog cancellation */
	private String oldXLabel, oldYLabel, oldZLabel, oldTitleLabel;
	/** Old indices of variables in case of dialog cancellation */
	private int oldXIndex, oldYIndex, oldZIndex; 

	/** button on the panel */
    private javax.swing.JButton okButton, cancelButton;
    /** combo box for choosing variable to show */
    private javax.swing.JComboBox xCombo, yCombo, zCombo;
    /** axis name (x, y, z) label */
    private javax.swing.JLabel xLabel, yLabel, zLabel;
    /** "axis" label */
    private javax.swing.JLabel axisLabel;
    /** "variable to display" label */
    private javax.swing.JLabel varLabel;
    /** "label" label */
    private javax.swing.JLabel labelLabel;
    /** text field for inputting axis label */
    private javax.swing.JTextField xField, yField, zField;
    /** panel containing all contents */
	private javax.swing.JPanel contentPanel;
	/** "plot title" label */
	private javax.swing.JLabel titleLabel;
	/** text field for inputting plot title */
    private javax.swing.JTextField titleField;
    
	/**
	 * The constructor sets the PlotPanel owner, and then initializes all the
	 * elements in the dialog box, adds key listeners to the input fields, adds
	 * the listeners for the 'OK' and 'Cancel' buttons, and then adds the
	 * components to the dialog box using a GridLayout.
	 * 
	 * @param graphPanelOwner
	 *            the Graph3DPanel associated with the scale dialog
	 */
	public Label3DDialog(Graph3DPanel graphPanelOwner) {
		// Set the associated Plot Panel
		graphOwner = graphPanelOwner;
		plotOwner = graphPanelOwner.getPlot3DPanel();

		initializeComponents(); // Initialize dialog box items
		addListeners(); // Add listeners
		addComponents(); // Build the dialog box
		storeOptions(); // Store copy of labels
		addWindowListener(this); // Perform appropriate closing action
	}

	/**
	 * Initializes the components of the label dialog box.
	 */
	private void initializeComponents() {
		// create objects
		contentPanel = new javax.swing.JPanel();
        xLabel = new javax.swing.JLabel();
        yLabel = new javax.swing.JLabel();
        zLabel = new javax.swing.JLabel();
        xCombo = new javax.swing.JComboBox();
        yCombo = new javax.swing.JComboBox();
        zCombo = new javax.swing.JComboBox();
        axisLabel = new javax.swing.JLabel();
        varLabel = new javax.swing.JLabel();
        labelLabel = new javax.swing.JLabel();
        xField = new javax.swing.JTextField();
        yField = new javax.swing.JTextField();
        zField = new javax.swing.JTextField();
        okButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        titleLabel = new javax.swing.JLabel();;
        titleField = new javax.swing.JTextField();

        // set labels
        xLabel.setText("X-Axis:");
        yLabel.setText("Y-Axis:");
        zLabel.setText("Z-Axis:");
        titleLabel.setText("Plot Title:");

        // set variable choices
        xCombo.setModel(new javax.swing.DefaultComboBoxModel(graphOwner.getVariables().getNames()));
        xCombo.setSelectedItem(graphOwner.getVar(0).getName());
        yCombo.setModel(new javax.swing.DefaultComboBoxModel(graphOwner.getVariables().getNames()));
        yCombo.setSelectedItem(graphOwner.getVar(1).getName());
        zCombo.setModel(new javax.swing.DefaultComboBoxModel(graphOwner.getVariables().getNames()));
        zCombo.setSelectedItem(graphOwner.getVar(2).getName());

        // set labels
        axisLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        axisLabel.setText("Variable to display");
        varLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        varLabel.setText("Axis");
        labelLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelLabel.setText("Label");

        // set initial texts
        xField.setText(plotOwner.plotCanvas.getGrid().getAxis(0).getLegend());
        yField.setText(plotOwner.plotCanvas.getGrid().getAxis(1).getLegend());
        zField.setText(plotOwner.plotCanvas.getGrid().getAxis(2).getLegend());
        titleField.setText(plotOwner.getName());

        // set buttons
        okButton.setText("OK");
        cancelButton.setText("Cancel");

        // code for constructing the UI generated by Netbeans
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(contentPanel);
        contentPanel.setLayout(layout);

        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(titleLabel)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(titleField, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(zLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(yLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(xLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(varLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(axisLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(xCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(yCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(zCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addComponent(okButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(cancelButton, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                                .addComponent(xField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                                .addComponent(yField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                                .addComponent(zField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                                .addComponent(labelLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE))))
                    .addContainerGap())
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(titleLabel)
                        .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(varLabel)
                        .addComponent(axisLabel)
                        .addComponent(labelLabel))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(xLabel)
                        .addComponent(xCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(xField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(yLabel)
                        .addComponent(yCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(yField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(zLabel)
                        .addComponent(zCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(zField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cancelButton)
                        .addComponent(okButton))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
	}
	
	/**
	 * Adds key listeners to the input fields. Also adds listeners for the 'OK'
	 * and 'Cancel' buttons.
	 */
	private void addListeners() {
		// X-Axis text field key listeners
		xField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				plotOwner.plotCanvas.setAxisLabel(0, xField.getText());
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// Y-Axis text field key listeners
		yField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				plotOwner.plotCanvas.setAxisLabel(1, yField.getText());
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// Z-Axis text field key listeners
		zField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				plotOwner.plotCanvas.setAxisLabel(2, zField.getText());
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});
		
		titleField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				plotOwner.setName(titleField.getText());
				graphOwner.repaint();
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});
		
		xCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				graphOwner.setVar(0, xCombo.getSelectedIndex());
			}
		});
		
		yCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				graphOwner.setVar(1, yCombo.getSelectedIndex());
			}
		});
		
		zCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				graphOwner.setVar(2, zCombo.getSelectedIndex());
			}
		});
		
		// 'OK' button listener
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		// 'Cancel' button listener
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restoreLabels();
				dispose();
				System.out.println("3D label dialog box closed.");
			}
		});
	}

	/**
	 * Adds all the components to the label dialog box.
	 */
	private void addComponents() {
		// Window settings
		setTitle("3D Axis Options");
		setResizable(false);
		setModal(true);
		
		add(contentPanel, BorderLayout.CENTER);
		contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		pack();
		
		// This line maps the 'OK' button to the Enter key
		getRootPane().setDefaultButton(okButton);

		System.out.println("Created 3D label dialog box.");
	}

	/**
	 * This function stores a copy of the current axis labels. It is called
	 * whenever a Label3DDialog is instantiated so that the labels can be
	 * restored upon hitting 'Cancel' in the dialog box.
	 */
	public void storeOptions() {
		oldXLabel = plotOwner.plotCanvas.getGrid().getAxis(0).getLegend();
		oldYLabel = plotOwner.plotCanvas.getGrid().getAxis(1).getLegend();
		oldZLabel = plotOwner.plotCanvas.getGrid().getAxis(2).getLegend();
		oldTitleLabel = plotOwner.getName();
		oldXIndex = xCombo.getSelectedIndex();
		oldYIndex = yCombo.getSelectedIndex();
		oldZIndex = zCombo.getSelectedIndex();
	}

	/**
	 * This function restores the axis labels to the values of the stored copy.
	 * It is called whenever the user hits 'Cancel' in the dialog box in order
	 * to "undo" the changes made while the dialog box was open.
	 */
	private void restoreLabels() {
		// Restore the text fields
		xField.setText(oldXLabel);
		yField.setText(oldYLabel);
		zField.setText(oldZLabel);
		titleField.setText(oldTitleLabel);

		// Restore the axis labels on the plot
		plotOwner.plotCanvas.setAxisLabel(0, oldXLabel);
		plotOwner.plotCanvas.setAxisLabel(1, oldYLabel);
		plotOwner.plotCanvas.setAxisLabel(2, oldZLabel);
		plotOwner.setName(oldTitleLabel);
		
		// Restore the combo box
		xCombo.setSelectedIndex(oldXIndex);
		yCombo.setSelectedIndex(oldYIndex);
		zCombo.setSelectedIndex(oldZIndex);

		// Restore the axis choice
		graphOwner.setVar(0, xCombo.getSelectedIndex());
		graphOwner.setVar(1, yCombo.getSelectedIndex());
		graphOwner.setVar(2, zCombo.getSelectedIndex());
	}

	public void reloadOptions(){
        xCombo.setSelectedItem(graphOwner.getVar(0).getName());
        yCombo.setSelectedItem(graphOwner.getVar(1).getName());
        zCombo.setSelectedItem(graphOwner.getVar(2).getName());
        xField.setText(plotOwner.plotCanvas.getGrid().getAxis(0).getLegend());
        yField.setText(plotOwner.plotCanvas.getGrid().getAxis(1).getLegend());
        zField.setText(plotOwner.plotCanvas.getGrid().getAxis(2).getLegend());
        titleField.setText(plotOwner.getName());
        storeOptions();
	}
	
	/*
	 * WindowListener interface required methods
	 */

	public void windowActivated(WindowEvent arg0) {
	}

	public void windowClosed(WindowEvent arg0) {
	}

	public void windowClosing(WindowEvent arg0) {
		restoreLabels();
		System.out.println("3D label dialog box closed.");
	}

	public void windowDeactivated(WindowEvent arg0) {
	}

	public void windowDeiconified(WindowEvent arg0) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}
}
