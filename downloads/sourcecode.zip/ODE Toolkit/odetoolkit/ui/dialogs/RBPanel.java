/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JLabel;
import javax.swing.border.TitledBorder;

import solver.SolverParameters;
import util.JDoubleTextField;
import util.ServerRequest;

/**
 * RBPanel is the solver panel for setting options meaningful to the Rosenbrock
 * solver. Specifically, you can set: resolution
 * 
 * @see SolverPanel
 * @see SolverOptionsPanel
 * 
 * @author Clinic 10-11
 */
@SuppressWarnings("serial")
public class RBPanel extends SolverPanel {

	/** Construct a new RBPanel with default parameters. */
	public RBPanel() {
		// Initialization

		atolTextField = new JDoubleTextField(false);
		rtolTextField = new JDoubleTextField(false);
		minInternalStepTextField = new JDoubleTextField(false);
		maxInternalStepTextField = new JDoubleTextField(false);

		// Layout

		setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		setBorder(new TitledBorder("Rosenbrock Options"));

		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.ipadx = 2;
		c.ipady = 2;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.insets = new Insets(2, 2, 2, 2);
		c.anchor = GridBagConstraints.NORTHWEST;
		c.fill = GridBagConstraints.NONE;
		c.gridy = GridBagConstraints.RELATIVE;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.anchor = GridBagConstraints.NORTHWEST;

		add(new JLabel("Absolute Tol:"), c);
		add(new JLabel("Relative Tol:"), c);
		add(new JLabel("Min Step Size: "), c);
		add(new JLabel("Max Step Size: "), c);

		c.gridx = 1;
		c.weightx = 1.0;
		c.anchor = GridBagConstraints.NORTHEAST;
		c.fill = GridBagConstraints.HORIZONTAL;

		add(atolTextField, c);
		add(rtolTextField, c);
		add(minInternalStepTextField, c);
		add(maxInternalStepTextField, c);

		setDefaults();
	}

	public void setParameters(SolverParameters p) {
		p.setSolver(ServerRequest.SOLVER_RB);
		p.setAbsoluteTolerance(atolTextField.getDouble());
		p.setRelativeTolerance(rtolTextField.getDouble());
		p.setMinStepSize(minInternalStepTextField.getDouble());
		p.setMaxStepSize(maxInternalStepTextField.getDouble());
		p.setResolution(1/minInternalStepTextField.getDouble());

		System.out.println("Rosenbrock parameters ok.");
	}

	public void updateParameters(SolverParameters p) {
		atolTextField.setDouble(p.getAbsoluteTolerance());
		rtolTextField.setDouble(p.getRelativeTolerance());
		minInternalStepTextField.setDouble(p.getMinStepSize());
		maxInternalStepTextField.setDouble(p.getMaxStepSize());
	}
}
