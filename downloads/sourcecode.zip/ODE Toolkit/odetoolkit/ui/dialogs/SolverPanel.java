/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import solver.SolverParameters;
import util.JDoubleTextField;
import util.JIntTextField;

/**
 * SolverPanel is the parent of all solver option panels. It records default
 * values for the various parameters and facilitates setting and restoring these
 * defaults. Reasonable values for the variables are ensured by using data-type
 * specific textfields. Additional checking is done by the child panels.
 * 
 * @see JDoubleTextField
 * @see JIntTextField
 * @see EulerPanel
 * @see RKPanel
 * @see RBPanel
 * 
 * @author Clinic 10-11, modified from Aaron Becker
 */
@SuppressWarnings("serial")
public abstract class SolverPanel extends JPanel {

	/** Text fields to contain the solver parameters. */
	protected JDoubleTextField resolutionTextField, atolTextField, rtolTextField,
			minInternalStepTextField, maxInternalStepTextField,
			solveSpanTextField;
	/** Text fields to contain the solver parameters. */
	protected JIntTextField maxStepsTextField;

	/** Default values for each solver parameter. */
	private static final double minInternalStepDefault = 1.0E-12,
			maxInternalStepDefault = 0.1, resolutionDefault = 500.0,
			absTolDefault = 1.0E-10, relTolDefault = 1.0E-7;
	/** Default values for each solver parameter. */
	private static final int maxStepsDefault = 500;

	/**
	 * Constuct a solver panel. Default values should be set using setDefaults
	 * after constructing the appropriate text boxes.
	 */
	public SolverPanel() {
		
	}

	/**
	 * Checks for valid solver parameters. If there are errors, they are
	 * displayed in a warning dialog. The function returns true if no errors
	 * occured.
	 * @return true iff the parameters are valid
	 */
	public boolean check() {
		String[] messages = new String[6];
		boolean errors = false;
	
		if (rtolTextField != null)
			if (rtolTextField.getDouble() <= 0.0) {
				messages[0] = "Please ensure that the relative tolerance is a"
						+ " positive number.";
				errors = true;
			}
		if (atolTextField != null)
			if (atolTextField.getDouble() <= 0.0) {
				messages[1] = "Please ensure that the absolute tolerance is a"
						+ " positive number.";
				errors = true;
			}
		if (resolutionTextField != null)
			if (resolutionTextField.getDouble() <= 0.0) {
				messages[2] = "Please ensure that the absolute tolerance is a"
						+ " positive number.";
				errors = true;
			}
		if (maxStepsTextField != null)
			if (maxStepsTextField.getInt() <= 0.0) {
				messages[3] = "The maximum number of steps must be positive.";
				errors = true;
			}
	
		if (minInternalStepTextField != null)
			if (minInternalStepTextField.getDouble() < 0.0) {
				messages[4] = "Please ensure that the minimum step size is a"
						+ " non-negative number.";
				errors = true;
			}
		if (maxInternalStepTextField != null)
			if (maxInternalStepTextField.getDouble() < minInternalStepTextField
					.getDouble()) {
				messages[5] = "Please ensure that the maximum step size is"
						+ " no smaller than the minimum step size.";
				errors = true;
			}
	
		if (errors)
			JOptionPane.showMessageDialog(null, messages,
					"Solver Parameter Error", JOptionPane.ERROR_MESSAGE);
	
		return !errors;
	}

	/**
	 * Set all initialized text fields to their default values.
	 */
	public void setDefaults() {
		if (resolutionTextField != null)
			resolutionTextField.setText(Double.toString(resolutionDefault));
		if (minInternalStepTextField != null)
			minInternalStepTextField.setText(Double
					.toString(minInternalStepDefault));
		if (maxInternalStepTextField != null)
			maxInternalStepTextField.setText(Double
					.toString(maxInternalStepDefault));
		if (atolTextField != null)
			atolTextField.setText(Double.toString(absTolDefault));
		if (rtolTextField != null)
			rtolTextField.setText(Double.toString(relTolDefault));
		if (maxStepsTextField != null)
			maxStepsTextField.setText(Integer.toString(maxStepsDefault));
	}

	/**
	 * Disallow all changes to the parameters - used in Data tab.
	 */
	public void disallowChanges() {
		if (resolutionTextField != null)
			resolutionTextField.setEditable(false);
		if (minInternalStepTextField != null)
			minInternalStepTextField.setEditable(false);
		if (maxInternalStepTextField != null)
			maxInternalStepTextField.setEditable(false);
		if (atolTextField != null)
			atolTextField.setEditable(false);
		if (rtolTextField != null)
			rtolTextField.setEditable(false);
		if (maxStepsTextField != null)
			maxStepsTextField.setEditable(false);
	}

	/**
	 * Update the parameters according to the given SolverParameters
	 * 
	 * @param p
	 *            the parameters to set to
	 */
	public abstract void updateParameters(SolverParameters p);

	/**
	 * Get a SolverParameters object associated with these solver options.
	 * 
	 * @param p
	 *            the parameters to be set
	 */
	public abstract void setParameters(SolverParameters p);
}
