/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ui.outputpanels.GraphPanel;
import ui.outputpanels.PlotPanel;
import util.ColorComboBox;
import util.ColorIcon;
import data.plotstates.SinglePlotState;
import data.plotstates.SinglePlotState.DirFieldSettings;

/**
 * The DirFieldDialog class is responsible for the dialog box that appears when
 * the user selects "Options..." in the Direction Field sub-menu of the Graph
 * Options menu. It contains sliders for adjusting the length and density of
 * slope field lines, a color selection box, and a radio group for customizing
 * the appearance of the lines (arrows, lines with dots, and plain lines). It
 * updates the PlotPanel in real-time to give the user a preview of their
 * customized view.
 * 
 * @author Andres Perez 2009
 */
@SuppressWarnings("serial")
public class DirFieldDialog extends JDialog {
	/** PlotPanel calling the dialog box */
	private PlotPanel plotOwner;

	/** Original settings in case user cancels dialog */
	private DirFieldSettings oldSettings;

	/** contains the direction field settings */ 
	private JPanel dirFieldPanel; 

	/** labels panel */
	private JPanel lineOptionLabels;
	/** "Length" label */
	private JLabel lengthLabel;
	/** "Density" Label */
	private JLabel densityLabel;
	/** "Color" label */
	private JLabel colorLabel;

	/** panel with sliders and color selector */
	private JPanel lineOptions;
	/** direction field arrow length slider */
	private JSlider lengthSlider;
	/** density of arrows slider */
	private JSlider densitySlider;
	/** color selection for slope lines */
	private ColorComboBox colorCombo;

	/** line type panel */
	private JPanel lineType;
	/** line type radio group */
	private ButtonGroup lineTypeRadios;
	/** Arrow line type selection */
	private JRadioButton arrowRadio;
	/** Dot line type selection */
	private JRadioButton dotRadio;
	/** Plain line type selection */
	private JRadioButton lineRadio;

	/** buttons panel */
	private JPanel buttonPanel;
	/** 'OK' button */
	private JButton okButton;
	/** 'Cancel' button */
	private JButton cancelButton; 

	/**
	 * The constructor sets the PlotPanel owner, and then initializes all the
	 * elements in the dialog box, adds change listeners to the components, adds
	 * the listeners for the 'OK' and 'Cancel' buttons, and then adds the
	 * components to the dialog box using a GridLayout.
	 * 
	 * @param graphPanelOwner
	 *            the GraphPanel associated with the Direction Field dialog
	 */
	public DirFieldDialog(GraphPanel graphPanelOwner) {
		// Set the associated Plot Panel
		plotOwner = graphPanelOwner.getPlotPanel();

		initializeComponents(); // Initialize dialog box items
		addListeners(); // Add listeners
		addComponents(); // Build the dialog box
	}

	/**
	 * Initializes the components of the direction field dialog box.
	 */
	private void initializeComponents() {
		oldSettings = plotOwner.getDfSettings();

		dirFieldPanel = new JPanel();

		lineOptionLabels = new JPanel();
		lengthLabel = new JLabel("Length");
		densityLabel = new JLabel("Density");
		colorLabel = new JLabel("Color");

		lineOptions = new JPanel();
		lengthSlider = new JSlider(1, 50, 10);
		densitySlider = new JSlider(0, 100, 20);
		colorCombo = new ColorComboBox();
		colorCombo.setSelectedItem(oldSettings.getDirFieldColor());

		lineType = new JPanel();
		lineTypeRadios = new ButtonGroup();
		arrowRadio = new JRadioButton("Arrows", true);
		dotRadio = new JRadioButton("Dots");
		lineRadio = new JRadioButton("Lines");

		buttonPanel = new JPanel();
		okButton = new JButton("OK");
		cancelButton = new JButton("Cancel");
	}

	/**
	 * Adds change listeners to the sliders, color selector, and radio buttons.
	 * Also adds listeners for the 'OK' and 'Cancel' buttons.
	 */
	private void addListeners() {
		lengthSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				plotOwner.setDirScale(((double) lengthSlider.getValue()) / 10);
				plotOwner.setPopupMode(false);
				plotOwner.repaint();
			}
		});

		densitySlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				plotOwner.setDirXCount(densitySlider.getValue());
				plotOwner.setDirYCount(densitySlider.getValue());
				plotOwner.setPopupMode(false);
				plotOwner.repaint();
			}
		});

		colorCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plotOwner
				.setDirColor(((ColorIcon) colorCombo.getSelectedItem())
						.getColor());
				plotOwner.setPopupMode(false);
				plotOwner.repaint();
			}
		});

		arrowRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plotOwner.setSlopeType(SinglePlotState.DirLineType.ARROW);
				plotOwner.setPopupMode(false);
				plotOwner.repaint();
			}
		});

		dotRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plotOwner.setSlopeType(SinglePlotState.DirLineType.LINE_DOT);
				plotOwner.setPopupMode(false);
				plotOwner.repaint();
			}
		});

		lineRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plotOwner.setSlopeType(SinglePlotState.DirLineType.LINE);
				plotOwner.setPopupMode(false);
				plotOwner.repaint();
			}
		});

		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Reset old settings to current settings
				oldSettings = plotOwner.getDfSettings();
				dispose();
			}
		});

		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Restore old settings
				plotOwner.setDirFieldSettings(oldSettings);

				// Reset dialog box components to old settings
				lengthSlider.setValue((int) oldSettings.getDirScale() * 10);
				densitySlider.setValue(oldSettings.getDirXCount());
				colorCombo.setSelectedItem(oldSettings.getDirFieldColor());
				arrowRadio
				.setSelected(oldSettings.getDirLineType() == data.plotstates.SinglePlotState.DirLineType.ARROW);
				dotRadio
				.setSelected(oldSettings.getDirLineType() == data.plotstates.SinglePlotState.DirLineType.LINE_DOT);
				lineRadio
				.setSelected(oldSettings.getDirLineType() == data.plotstates.SinglePlotState.DirLineType.LINE);

				plotOwner.repaint();
				dispose();
				System.out.println("Scaling dialog box closed.");
			}
		});
	}

	/**
	 * Adds all components to the direction field dialog box.
	 */
	private void addComponents() {
		// Window settings
		setTitle("Direction Field Options");
		setResizable(false);
		setModal(true);

		// Add direction field settings panel
		add(dirFieldPanel, BorderLayout.CENTER);
		dirFieldPanel.setBorder(BorderFactory.createEmptyBorder(2, 6, 0, 4));

		// Add line option labels to direction field settings panel
		dirFieldPanel.add(lineOptionLabels);

		// Line option labels layout
		GridLayout lineOptionLabelsLayout = new GridLayout(3, 1);
		lineOptionLabelsLayout.setHgap(5);
		lineOptionLabelsLayout.setVgap(5);
		lineOptionLabelsLayout.setRows(3);
		lineOptionLabels.setLayout(lineOptionLabelsLayout);
		lineOptionLabels.setPreferredSize(new java.awt.Dimension(48, 107));

		// Add line option labels components
		lineOptionLabels.add(lengthLabel);
		lineOptionLabels.add(densityLabel);
		lineOptionLabels.add(colorLabel);

		// Add line options panel to direction field settings panel
		dirFieldPanel.add(lineOptions);

		// Line options panel layout
		GridLayout lineOptionsLayout = new GridLayout(3, 2);
		lineOptionsLayout.setHgap(5);
		lineOptionsLayout.setVgap(5);
		lineOptions.setLayout(lineOptionsLayout);
		lineOptions.setPreferredSize(new java.awt.Dimension(190, 107));
		lineOptions.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));

		// Add line options components
		lineOptions.add(lengthSlider);
		lineOptions.add(densitySlider);
		lineOptions.add(colorCombo);
		colorCombo.setBorder(BorderFactory.createEmptyBorder(0, 9, 0, 9));

		// Add line type panel to direction field settings panel
		dirFieldPanel.add(lineType);

		// Line type panel layout
		GridLayout lineTypeLayout = new GridLayout(3, 1);
		lineTypeLayout.setHgap(5);
		lineTypeLayout.setVgap(5);
		lineType.setLayout(lineTypeLayout);
		lineType.setBorder(BorderFactory.createTitledBorder("Line Type"));
		lineType.setPreferredSize(new java.awt.Dimension(88, 107));

		// Add line type components
		lineType.add(arrowRadio);
		lineType.add(dotRadio);
		lineType.add(lineRadio);

		// Build line type radio group
		lineTypeRadios.add(arrowRadio);
		lineTypeRadios.add(dotRadio);
		lineTypeRadios.add(lineRadio);

		// Add tool tips to radio buttons
		arrowRadio.setToolTipText("Draws each slope line with an arrow head "
				+ "indicating direction");
		dotRadio.setToolTipText("Draws each slope line with a dot "
				+ "indicating direction");
		lineRadio.setToolTipText("Draws slopes line with as pure lines, "
				+ "without indicating direction");

		// Add buttons panel
		add(buttonPanel, BorderLayout.SOUTH);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));

		// buttons panel layout
		FlowLayout buttonPanelLayout = new FlowLayout();
		buttonPanelLayout.setAlignment(FlowLayout.RIGHT);
		buttonPanelLayout.setHgap(0);
		buttonPanel.setLayout(buttonPanelLayout);
		buttonPanel.setPreferredSize(new java.awt.Dimension(346, 39));

		// Add 'OK' and 'Cancel' buttons
		buttonPanel.add(okButton);
		buttonPanel.add(cancelButton);

		// Equalize the size of the buttons
		okButton.setPreferredSize(new java.awt.Dimension(86, 29));
		cancelButton.setPreferredSize(new java.awt.Dimension(86, 29));

		pack();

		// This line maps the 'OK' button to the Enter key
		getRootPane().setDefaultButton(okButton);

		System.out.println("Created dirfield options dialog box.");
	}
}
