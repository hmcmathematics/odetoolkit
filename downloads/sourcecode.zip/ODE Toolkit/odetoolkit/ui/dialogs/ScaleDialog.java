/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui.dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;

import ui.outputpanels.GraphPanel;
import ui.outputpanels.PlotPanel;
import util.JDoubleTextField;

/**
 * The ScaleDialog class is responsible for the dialog box that appears when the
 * user selects the 'Change Window Ranges...' option in the Graph Options menu.
 * It prompts the user for the minimum and maximum range values for the vertical
 * and horizontal axes, and then makes the appropriate changes to the
 * PlotPanel's ranges. Key listeners are implemented to cause the graph to
 * update in real-time as the user edits the range values
 * 
 * @author Andres Perez 2009
 */
@SuppressWarnings("serial")
public class ScaleDialog extends JDialog implements WindowListener {
	/** GraphPanel calling the dialog box */
	GraphPanel graphOwner;

	/** PlotPanel for which to configure the scaling */
	PlotPanel plotOwner;

	/** Information stored in case the 'Cancel' button is pressed */
	private boolean originalAutoScaleState;
	/** Information stored in case the 'Cancel' button is pressed */
	private double originalXMin, originalXMax, originalYMin, originalYMax;

	/** input is stored in case auto-scaling is enabled */
	private double oldXMin, oldXMax, oldYMin, oldYMax;

	/** last functioning values stored in case auto-scaling is enabled */
	private double oldXMinInput, oldXMaxInput, oldYMinInput, oldYMaxInput;

	/** auto-scaling panel */
	private JPanel autoScalingPanel;
	/** set ranges panel */
	private JPanel rangesPanel;
	/** x-axis panel */
	private JPanel xAxisPanel;
	/** y-axis panel */
	private JPanel yAxisPanel;
	/** panel for 'OK' and 'Cancel' buttons */
	private JPanel buttonPanel;

	/** 'Enable Auto-Scaling' check box */
	private JCheckBox autoScalingCheckBox;

	/** "X-Axis" label */
	private JLabel xAxisLabel;
	/** "Min:" label for x-axis */
	private JLabel xMinLabel;
	/** "Max:" label for x-axis */
	private JLabel xMaxLabel;
	/** "Y-Axis" label */
	private JLabel yAxisLabel;
	/** "Min:" label for y-axis */
	private JLabel yMinLabel;
	/** "Max:" label for y-axis */
	private JLabel yMaxLabel;

	/** Text field for inputting ranges */
	private JDoubleTextField xMinField, xMaxField, yMinField, yMaxField;

	/** axis-specific autoFit buttons */
	JButton autoFitX, autoFitY;
	/** OK button */
	private JButton okButton;
	/** cancel button */
	private JButton cancelButton;

	/**
	 * The constructor sets the graph and plot panel owner, and then initializes
	 * all the elements in the dialog box, adds the listeners, and adds the
	 * components to the dialog box using a GridLayout, and adds a Window
	 * Listener to the dialog box window.
	 * 
	 * @param graphPanelOwner
	 *            the GraphPanel associated with the scale dialog
	 */
	public ScaleDialog(GraphPanel graphPanelOwner) {
		graphOwner = graphPanelOwner;
		plotOwner = graphPanelOwner.getPlotPanel();

		initializeComponents(); // Initialize dialog box items
		addListeners(); // Add listeners
		addComponents(); // Build the dialog box
		storeOriginalRanges(); // Store copy of ranges (in case of cancel)
		addWindowListener(this); // Perform appropriate closing action
	}

	/**
	 * Initializes all the components of the scaling dialog box
	 */
	private void initializeComponents() {
		autoScalingPanel = new JPanel();
		rangesPanel = new JPanel();
		xAxisPanel = new JPanel();
		yAxisPanel = new JPanel();
		buttonPanel = new JPanel();

		autoScalingCheckBox = new JCheckBox("Enable Auto-Scaling");

		xAxisLabel = new JLabel("X-Axis");
		yAxisLabel = new JLabel("Y-Axis");
		xMinLabel = new JLabel("Min:");
		yMinLabel = new JLabel("Min:");
		xMaxLabel = new JLabel("Max:");
		yMaxLabel = new JLabel("Max:");

		xMinField = new JDoubleTextField();
		xMaxField = new JDoubleTextField();
		yMinField = new JDoubleTextField();
		yMaxField = new JDoubleTextField();

		autoFitX = new JButton("AutoFit");
		autoFitY = new JButton("AutoFit");
		okButton = new JButton("OK");
		cancelButton = new JButton("Cancel");
	}

	/**
	 * Adds key listeners to the input fields. Also adds listeners for the
	 * auto-scaling check box, the autofit buttons for each axis, and the 'OK'
	 * and 'Cancel' buttons.
	 */
	private void addListeners() {
		// Auto-scaling check box listener
		autoScalingCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// store input fields if enabling auto-scaling
				if (autoScalingCheckBox.isSelected())
					storeRanges();

				graphOwner.setAllAutoScale(autoScalingCheckBox.isSelected());
				setAutoScale(autoScalingCheckBox.isSelected());
			}
		});

		// X-Axis minimum field key listeners
		xMinField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				checkInput();
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// X-Axis maximum field key listeners
		xMaxField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				checkInput();
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// Y-Axis minimum field key listeners
		yMinField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				checkInput();
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// Y-Axis maximum field key listeners
		yMaxField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				checkInput();
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// AutoFit x-axis button listener
		autoFitX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plotOwner.autoScaleAxis(0);
				updateFields();
				plotOwner.repaint();
			}
		});

		// AutoFit y-axis button listener
		autoFitY.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plotOwner.autoScaleAxis(1);
				updateFields();
				plotOwner.repaint();
			}
		});

		// 'OK' button listener
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				System.out.println("Scaling dialog box closed.");
				plotOwner.repaint();
			}
		});

		// 'Cancel' button listener
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restoreOriginalRanges();
				dispose();
				System.out.println("Scaling dialog box closed.");
				plotOwner.repaint();
			}
		});
	}

	/**
	 * Sets the dialog box title, size, and settings, and then adds all the
	 * components to the dialog box.
	 */
	private void addComponents() {
		// Window settings
		setTitle("Set Window Ranges");
		setResizable(false);
		setModal(true);

		// Add auto-scaling panel
		add(autoScalingPanel, BorderLayout.NORTH);

		// Auto-scaling panel layout
		FlowLayout autoScalingPanelLayout = new FlowLayout();
		autoScalingPanelLayout.setAlignment(FlowLayout.LEFT);
		autoScalingPanel.setLayout(autoScalingPanelLayout);
		autoScalingPanel.setBorder(BorderFactory.createEmptyBorder(3, 0, 0, 0));

		// Add auto-scaling panel components
		autoScalingPanel.add(autoScalingCheckBox);
		autoScalingCheckBox.setHorizontalTextPosition(SwingConstants.LEADING);

		// Add ranges panel
		add(rangesPanel, BorderLayout.CENTER);

		// Ranges panel layout
		GridLayout rangesPanelLayout = new GridLayout(2, 1);
		rangesPanelLayout.setHgap(5);
		rangesPanelLayout.setVgap(5);
		rangesPanelLayout.setColumns(1);
		rangesPanelLayout.setRows(2);
		rangesPanel.setLayout(rangesPanelLayout);
		rangesPanel.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 0));

		// Add x-axis panel
		rangesPanel.add(xAxisPanel);

		// X-axis panel layout
		FlowLayout xAxisPanelLayout = new FlowLayout();
		xAxisPanelLayout.setAlignment(FlowLayout.LEFT);
		xAxisPanel.setLayout(xAxisPanelLayout);

		// Add x-axis panel components
		xAxisPanel.add(xAxisLabel);
		xAxisLabel.setPreferredSize(new java.awt.Dimension(50, 16));
		xAxisPanel.add(xMinLabel);
		xAxisPanel.add(xMinField);
		xMinField.setPreferredSize(new java.awt.Dimension(135, 28));
		xAxisPanel.add(xMaxLabel);
		xAxisPanel.add(xMaxField);
		xMaxField.setPreferredSize(new java.awt.Dimension(135, 28));
		xAxisPanel.add(autoFitX);
		autoFitX.setFocusable(false);

		// Add y-axis panel
		rangesPanel.add(yAxisPanel);

		// Y-axis panel layout
		FlowLayout yAxisPanelLayout = new FlowLayout();
		yAxisPanelLayout.setAlignment(FlowLayout.LEFT);
		yAxisPanel.setLayout(yAxisPanelLayout);

		// Add y-axis panel components
		yAxisPanel.add(yAxisLabel);
		yAxisLabel.setPreferredSize(new java.awt.Dimension(50, 16));
		yAxisPanel.add(yMinLabel);
		yAxisPanel.add(yMinField);
		yMinField.setPreferredSize(new java.awt.Dimension(135, 28));
		yAxisPanel.add(yMaxLabel);
		yAxisPanel.add(yMaxField);
		yMaxField.setPreferredSize(new java.awt.Dimension(135, 28));
		yAxisPanel.add(autoFitY);
		autoFitY.setFocusable(false);

		// Add buttons panel
		add(buttonPanel, BorderLayout.SOUTH);

		// Buttons panel layout
		FlowLayout buttonPanelLayout = new FlowLayout();
		buttonPanelLayout.setAlignment(FlowLayout.RIGHT);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
		buttonPanel.setLayout(buttonPanelLayout);

		// Add buttons panel components
		buttonPanel.add(okButton);
		okButton.setPreferredSize(new Dimension(86, 29));
		buttonPanel.add(cancelButton);
		cancelButton.setPreferredSize(new Dimension(86, 29));

		pack();

		// This line maps the 'OK' button to the Enter key
		getRootPane().setDefaultButton(okButton);

		System.out.println("Created scaling dialog box.");
	}

	/**
	 * Checks that the ranges are valid. It enables or disables the 'OK' button
	 * depending on whether the maximum values are greater than the minimum
	 * values. This function also calls the checkRange function to update the
	 * colors of the input fields to alert the user of an invalid range.
	 */
	private void checkInput() {
		boolean validRanges = (xMinField.getDouble() < xMaxField.getDouble())
				&& (yMinField.getDouble() < yMaxField.getDouble());

		// enable/disable 'OK' button
		if (validRanges)
			okButton.setEnabled(true);
		else
			okButton.setEnabled(false);

		// update visual cues for input fields
		checkRange(0);
		checkRange(1);
	}

	/**
	 * This function checks the range of the given axis and sets it if possible.
	 * Otherwise, it highlights the min and max input fields to alert the user
	 * of the invalid range.
	 * 
	 * @param axis
	 *            int representing the axis being checked (0 = x, 1 = y)
	 */
	private void checkRange(int axis) {
		if (axis == 0) // x-axis
		{
			if (xMinField.getDouble() < xMaxField.getDouble()) {
				// set new x-axis range
				plotOwner.setRange(xMinField.getDouble(),
						xMaxField.getDouble(), plotOwner.getYRange()[0],
						plotOwner.getYRange()[1]);
				// set the min and max fields to normal border
				xMinField.setBorder(UIManager.getBorder("TextField.border"));
				xMaxField.setBorder(UIManager.getBorder("TextField.border"));
			} else {
				// set the min and max fields to RED
				xMinField.setBorder(new LineBorder(Color.RED, 2, true));
				xMaxField.setBorder(new LineBorder(Color.RED, 2, true));
			}
		} else // y-axis
		{
			if (yMinField.getDouble() < yMaxField.getDouble()) {
				// set new y-axis range
				plotOwner.setRange(plotOwner.getXRange()[0],
						plotOwner.getXRange()[1], yMinField.getDouble(),
						yMaxField.getDouble());
				// set the min and max fields to normal border
				yMinField.setBorder(UIManager.getBorder("TextField.border"));
				yMaxField.setBorder(UIManager.getBorder("TextField.border"));
			} else {
				// set the min and max fields to RED
				yMinField.setBorder(new LineBorder(Color.RED, 2, true));
				yMaxField.setBorder(new LineBorder(Color.RED, 2, true));
			}
		}
	}

	/**
	 * This function stores a copy of all the ranges. It is called whenever the
	 * dialog box is opened so that the values are able to be returned upon
	 * canceling the dialog.
	 */
	public void storeOriginalRanges() {
		// first update the fields
		updateFields();

		// store auto-scale state
		originalAutoScaleState = plotOwner.getAutoScale();

		// store ranges
		originalXMin = plotOwner.getXRange()[0];
		originalXMax = plotOwner.getXRange()[1];
		originalYMin = plotOwner.getYRange()[0];
		originalYMax = plotOwner.getYRange()[1];

		// whenever the original ranges are stored, the auto-scaling backup
		// ranges should be stored too.
		storeRanges();
	}

	/**
	 * This function stores a copy of all the ranges, as well as the input field
	 * values (which will differ when the user specifies invalid ranges). It is
	 * called whenever auto-scaling is enabled and the input fields are
	 * disabled, so that upon disabling auto-scaling, the values are able to be
	 * returned.
	 */
	private void storeRanges() {
		// store last functioning range values
		oldXMin = plotOwner.getXRange()[0];
		oldXMax = plotOwner.getXRange()[1];
		oldYMin = plotOwner.getYRange()[0];
		oldYMax = plotOwner.getYRange()[1];

		// store input field values
		oldXMinInput = xMinField.getDouble();
		oldXMaxInput = xMaxField.getDouble();
		oldYMinInput = yMinField.getDouble();
		oldYMaxInput = yMaxField.getDouble();
	}

	/**
	 * This function is called when the dialog box is closed or canceled. It
	 * restores the ranges to their values before the dialog box was opened.
	 */
	private void restoreOriginalRanges() {
		// restore auto-scale state
		graphOwner.setAllAutoScale(originalAutoScaleState);

		// restore original ranges
		plotOwner.setRange(originalXMin, originalXMax, originalYMin,
				originalYMax);

		// update input fields
		updateFields();

		// check fields for validity
		checkInput();
	}

	/**
	 * This function is called when the user un-checks the auto-scaling check
	 * box. It restores the ranges to their values before checking auto-scale.
	 */
	private void restoreRanges() {
		// restore original ranges before checking auto-scale
		plotOwner.setRange(oldXMin, oldXMax, oldYMin, oldYMax);

		// restore input fields
		xMinField.setDouble(oldXMinInput);
		xMaxField.setDouble(oldXMaxInput);
		yMinField.setDouble(oldYMinInput);
		yMaxField.setDouble(oldYMaxInput);

		// check fields for validity
		checkInput();
	}

	/**
	 * This function updates the range values for the dialog box's input. It is
	 * called any time the ranges are changed by anything other than the input
	 * fields. It sets the values to the current ranges of the PlotPanel.
	 */
	public void updateFields() {
		xMinField.setDouble(plotOwner.getXRange()[0]);
		xMaxField.setDouble(plotOwner.getXRange()[1]);
		yMinField.setDouble(plotOwner.getYRange()[0]);
		yMaxField.setDouble(plotOwner.getYRange()[1]);
	}

	/**
	 * Updates the status of auto-scaling in the dialog box. If set to on, the
	 * check box is selected, the manual ranges are stored (in case the user
	 * activates auto-scaling from the dialog), and the input fields are
	 * disabled. If set to off, the check box is de-selected, the manual ranges
	 * are restored (in case the user de-activates auto-scaling from the
	 * dialog), and the input fields are enabled.
	 * 
	 * @param autoScaleOn
	 *            true if auto-scaling is activated
	 */
	public void setAutoScale(boolean autoScaleOn) {
		if (autoScaleOn) {
			autoScalingCheckBox.setSelected(true);

			// update input fields
			updateFields();

			// disable ranges panel
			xMinField.setEnabled(false);
			xMaxField.setEnabled(false);
			yMinField.setEnabled(false);
			yMaxField.setEnabled(false);
			autoFitX.setEnabled(false);
			autoFitY.setEnabled(false);

			// check input to enable 'OK' and turn off red border-alerts
			checkInput();
		} else {
			autoScalingCheckBox.setSelected(false);

			// restore input fields
			restoreRanges();

			// enable ranges panel
			xMinField.setEnabled(true);
			xMaxField.setEnabled(true);
			yMinField.setEnabled(true);
			yMaxField.setEnabled(true);
			autoFitX.setEnabled(true);
			autoFitY.setEnabled(true);

			// check ranges for validity
			checkInput();
		}
	}

	/*
	 * WindowListener interface required methods
	 */

	public void windowActivated(WindowEvent e) {
	}

	public void windowClosed(WindowEvent e) {
	}

	public void windowClosing(WindowEvent e) {
		restoreOriginalRanges();
		System.out.println("Scaling dialog box closed.");
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}
}
