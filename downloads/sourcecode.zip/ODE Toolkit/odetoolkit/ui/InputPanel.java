/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package ui;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.EventObject;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolTip;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import solver.SolverParameters;
import ui.dialogs.SolverOptionsPanel;
import ui.outputpanels.ICTableModel;
import ui.outputpanels.ODEWorkspace;
import util.JDoubleTextField;

/**
 * The InputPanel class describes the left-most panel in ODE Toolkit. It
 * contains the entry fields for the ODE name, definition, initial conditions,
 * and solve span, as well as solver buttons.
 * 
 * The InputPanel is present upon launching the program and maintains its size
 * and location at all times.
 * 
 * @author Andres Perez 09, modified by Max Comstock 2013
 */
@SuppressWarnings("serial")
public class InputPanel extends JPanel {
	/** ODEWorkspace that owns this InputPanel */
	private ODEWorkspace workspaceOwner;

	/** solver parameters for the current ODE */
	private SolverParameters parameters;

	/** solver options dialog box */
	private SolverOptionsPanel solverDialog;

	/** Label "Name:" */
	private JLabel nameLabel;
	/** Label "Define ODE:" */
	private JLabel definitionLabel;
	/** Label "Initial Conditions:" */
	private JLabel icLabel;
	/** Label "Solve Span:" */
	private JLabel solveSpanLabel;

	/** Scroll Pane text field for entering equations */
	private JScrollPane definitionScrollPane;
	/** Scroll Pane containing IC table */
	private JScrollPane icScrollPane;

	/** Text field for ODE's name */
	private JTextField nameField;
	/** Text field for entering equations */
	private JTextArea definitionField;
	/** Text field for entering solver span */
	private JDoubleTextField solveSpanField;

	/** Initial Conditions table */
	private ICTable icTable;
	/** The model for IC table */
	private ICTableModel icModel;

	/** Button "Enter ODE" */
	private JButton enterODEButton;
	/** Button "Solve Forward" */
	private JButton solveForwardButton;
	/** Button "Solve Backward" */
	private JButton solveBackwardButton;
	/** Button "Stop Solve" */
	private JButton stopSolveButton;
	/** Button "Solver Options" */
	private JButton solverOptionsButton;
	
	/** ToolTip for definitionField  */
	private String ops =
			"<html>Operators:" + "<br>" +
			"Addition:       +" + "<br>" +
			"Subtraction:    -" + "<br>" +
			"Multiplication: *" + "<br>" +
			"Division:       /" + "<br>" +
			"Exponentiation: ^" + "<br>" +
			"Modulus:        %" + "<br>" +
			"Equals:         =" + "<br><br>" +
			"Functions:" + "<br>" +
			"Sine:                       sin(x)" + "<br>" +
			"Cosine:                     cos(x)" + "<br>" +
			"Tangent:                    tan(x)" + "<br>" +
			"Cotangent:                  cot(x)" + "<br>" +
			"Inverse sine:               asin(x)" + "<br>" +
			"Inverse cosine:             acos(x)" + "<br>" +
			"Inverse tangent:            atan(x)" + "<br>" +
			"Hyperbolic cosine:          cosh(x)" + "<br>" +
			"Hyperbolic sine:            sinh(x)" + "<br>" +
			"Hyperbolic tangent:         tanh(x)" + "<br>" +
			"Inverse hyperbolic cosine:  acosh(x)" + "<br>" +
			"Inverse hyperbolic sine:    asinh(x)" + "<br>" +
			"e raised to a power:        exp(x)" + "<br>" +
			"Natural logarithm:          ln(x)" + "<br>" +
			"Base-10 logarithm:          log(x)" + "<br>" +
			"x raised to the power of y: pow(x, y)" + "<br>" +
			"Square root:                sqrt(x)" + "<br>" +
			"Absolute value:             abs(x)" + "<br><br>" +
			"Enter ODEs as a system of first-order differntial equations." +
			"</html>";

	/**
	 * Constructor. Sets the ODEWorkspace owner, parameters, and solver options
	 * dialog, initializes and builds the UI components, and adds listeners.
	 * 
	 * @param owner
	 *            ODEWorkspace that owns this InputPanel
	 */
	public InputPanel(ODEWorkspace owner) {
		workspaceOwner = owner;
		parameters = owner.getParameters();
		solverDialog = new SolverOptionsPanel(parameters, owner);

		initializeComponents(); // Initialize dialog box items
		buildICTable(); // Construct the initial conditions table
		addListeners(); // Add listeners
		addComponents(); // Build the dialog box
	}

	/**
	 * Returns the current solver parameters.
	 * 
	 * @return the current solver parameters
	 */
	public SolverParameters getParameters() {
		return parameters;
	}

	/**
	 * Initializes all the components of the InputPanel.
	 */
	private void initializeComponents() {
		nameLabel = new JLabel("Name:");
		definitionLabel = new JLabel("Define ODE:");
		icLabel = new JLabel("Initial Conditions:");
		solveSpanLabel = new JLabel("Solve Span:");

		nameField = new JTextField("");
		definitionField = new JTextArea();
		definitionField.setToolTipText(ops);
		solveSpanField = new JDoubleTextField(10.0);

		definitionScrollPane = new JScrollPane();
		definitionScrollPane.setViewportView(definitionField);
		icScrollPane = new JScrollPane();

		icTable = new ICTable();
		icModel = new ICTableModel(true);

		enterODEButton = new JButton("Enter ODE");
		solveForwardButton = new JButton("Solve Forward");
		solveBackwardButton = new JButton("Solve Backward");
		stopSolveButton = new JButton("Stop Solve");
		solverOptionsButton = new JButton("Solver Options");
	}

	/**
	 * Builds the table of initial conditions using ICTable, a custom JTable
	 * designed for editing intial conditions in ODE Toolkit.
	 */
	private void buildICTable() {
		icScrollPane.setViewportView(icTable);
		icScrollPane.setMinimumSize(new java.awt.Dimension(0, 88));
		icModel.updateSolverParameters(parameters);
		icTable.setModel(icModel);
	}

	/**
	 * Adds a key listener to the name field which stores the name in the
	 * workspace tab, an undo/redo listener to the definition field, a table
	 * model listener to the initial conditions table, and button listeners for
	 * each of the buttons in the InputPanel.
	 */
	private void addListeners() {
		// Name field key listeners
		nameField.addKeyListener(new KeyListener() {
			public void keyReleased(KeyEvent e) {
				storeName();
				workspaceOwner.getTabbedGraphPanel().repaintDataPanel();
			}

			public void keyPressed(KeyEvent e) {
			}

			public void keyTyped(KeyEvent e) {
			}
		});

		// Definition Field undoable edit listener
		final UndoManager undo = new UndoManager();
		Document doc = definitionField.getDocument();

		doc.addUndoableEditListener(new UndoableEditListener() {
			public void undoableEditHappened(UndoableEditEvent evt) {
				undo.addEdit(evt.getEdit());
				// Update Edit > Undo
				MenuBar.updateUndoStatus(undo.canUndo());
			}
		});

		definitionField.getActionMap().put("Undo", new AbstractAction("Undo") {
			public void actionPerformed(ActionEvent evt) {
				try {
					if (undo.canUndo()) {
						undo.undo();
						// Update Edit > Undo
						MenuBar.updateUndoStatus(undo.canUndo());
						// Update Edit > Redo
						MenuBar.updateRedoStatus(undo.canRedo());
					}
				} catch (CannotUndoException e) {
				}
			}
		});

		definitionField
				.getInputMap()
				.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
						(Toolkit.getDefaultToolkit().getMenuShortcutKeyMask())),
						"Undo");

		definitionField.getActionMap().put("Redo", new AbstractAction("Redo") {
			public void actionPerformed(ActionEvent evt) {
				try {
					if (undo.canRedo()) {
						undo.redo();
						// Update Edit > Undo
						MenuBar.updateUndoStatus(undo.canUndo());
						// Update Edit > Redo
						MenuBar.updateRedoStatus(undo.canRedo());
					}
				} catch (CannotRedoException e) {
				}
			}
		});

		definitionField
				.getInputMap()
				.put(KeyStroke
						.getKeyStroke(
								KeyEvent.VK_Z,
								(java.awt.event.InputEvent.SHIFT_MASK | (Toolkit
										.getDefaultToolkit()
										.getMenuShortcutKeyMask()))),
						"Redo");

		// Definition Field Focus Manager
		definitionField.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				MenuBar.updateUndoStatus(undo.canUndo());
				MenuBar.updateRedoStatus(undo.canRedo());
			}

			public void focusLost(FocusEvent e) {
				MenuBar.updateUndoStatus(false);
				MenuBar.updateRedoStatus(false);
			}
		});

		// Initial conditions table model listener
		icModel.addTableModelListener(new TableModelListener() {
			public void tableChanged(TableModelEvent e) {
				adjustColumnWidth(icTable, 0, 4);
			}
		});

		// 'Enter ODE' button listener
		enterODEButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				storeParameters();
				storeDefinition();
			}
		});

		// 'Solve Forward' button listener
		solveForwardButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				storeParameters();
				workspaceOwner.solveForward();
			}
		});

		// 'Solve Backward' button listener
		solveBackwardButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				storeParameters();
				workspaceOwner.solveBackward();
			}
		});

		// 'Stop Solve' button listener
		stopSolveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				workspaceOwner.stopSolve();
			}
		});

		// 'Solver Options' button listener
		solverOptionsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				workspaceOwner.showDialog(solverDialog);
			}
		});

		// 'Solve Span' field listener
		solveSpanField.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
				storeParameters();
			}

			public void focusGained(FocusEvent e) {
				// Nothing to be done here
			}
		});
	}

	/**
	 * Sets the layout for the InputPanel, and adds all the components using a
	 * GridBag layout. It also sets additional properties to the components,
	 * including line wrap and button styles.
	 */
	private void addComponents() {
		// Set the layout for the InputPanel
		GridBagLayout thisLayout = new GridBagLayout();
		thisLayout.rowWeights = new double[] { 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
				0.0, 0.0, 0.0, 0.0, 0.0 };
		thisLayout.rowHeights = new int[] { 7, 9, 11, 178, 7, 84, 7, 7, 7, 7, 7 };
		thisLayout.columnWeights = new double[] { 0.0, 0.0, 0.0 };
		thisLayout.columnWidths = new int[] { 55, 70, 44 };
		this.setLayout(thisLayout);

		// Add components to the InputPanel
		add(nameLabel, new GridBagConstraints(0, 0, 2, 1, 0.0, 0.0,
				GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5,
						7, 5, 5), 0, 0));
		add(nameField, new GridBagConstraints(0, 1, 3, 1, 0.0, 0.0,
				GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
				new Insets(5, 5, 5, 5), 0, 0));
		add(definitionLabel, new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0,
				GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5,
						7, 5, 5), 0, 0));
		add(definitionScrollPane, new GridBagConstraints(0, 3, 3, 1, 0.0, 1.0,
				GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(5,
						8, 5, 8), 0, 0));
		add(icLabel, new GridBagConstraints(0, 4, 2, 1, 0.0, 0.0,
				GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE,
				new Insets(5, 7, 5, 5), 0, 0));
		add(enterODEButton, new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0,
				GridBagConstraints.NORTHEAST, GridBagConstraints.NONE,
				new Insets(5, 5, 5, 4), 0, 0));
		add(icScrollPane, new GridBagConstraints(0, 5, 3, 1, 0.0, 0.0,
				GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
				new Insets(5, 8, 5, 8), 0, 0));
		add(solveSpanLabel, new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0,
				GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5,
						7, 5, 5), 0, 0));
		add(solveSpanField, new GridBagConstraints(1, 6, 2, 1, 0.0, 0.0,
				GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
				new Insets(5, 5, 5, 5), 0, 0));
		add(solveForwardButton, new GridBagConstraints(0, 7, 3, 1, 0.0, 0.0,
				GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
				new Insets(2, 4, 1, 4), 0, 0));
		add(solveBackwardButton, new GridBagConstraints(0, 8, 3, 1, 0.0, 0.0,
				GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
				new Insets(2, 4, 1, 4), 0, 0));
		add(stopSolveButton, new GridBagConstraints(0, 9, 3, 1, 0.0, 0.0,
				GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
				new Insets(2, 4, 1, 4), 0, 0));
		add(solverOptionsButton, new GridBagConstraints(0, 10, 3, 1, 0.0, 0.0,
				GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
				new Insets(2, 4, 2, 4), 0, 0));

		// Add line wrap to the definition field
		definitionField.setLineWrap(true);

		// Set the button styles to gradient
		enterODEButton.putClientProperty("JButton.buttonType", "gradient");
		solveForwardButton.putClientProperty("JButton.buttonType", "gradient");
		solveBackwardButton.putClientProperty("JButton.buttonType", "gradient");
		stopSolveButton.putClientProperty("JButton.buttonType", "gradient");
		solverOptionsButton.putClientProperty("JButton.buttonType", "gradient");
	}

	/**
	 * Enables the solver buttons and definition field, and disables the 'Stop
	 * Solve' button. This method is called by the ODEWorkspace after the ODE
	 * solution is ready.
	 * 
	 * @param enabled
	 *            true to enable the solver buttons and definition field, false
	 *            to disable
	 */
	public void enableSolveComponents(boolean enabled) {
		solveForwardButton.setEnabled(enabled);
		solveBackwardButton.setEnabled(enabled);
		stopSolveButton.setEnabled(!enabled);
		solverOptionsButton.setEnabled(enabled);
		definitionField.setEnabled(enabled);
		solveSpanField.setEnabled(enabled);
	}

	/**
	 * Disables the solver buttons. This method is only called when initializing
	 * an ODEWorkspace, to disable solving until an ODE has been entered.
	 */
	public void disableSolverButtons() {
		solveForwardButton.setEnabled(false);
		solveBackwardButton.setEnabled(false);
		stopSolveButton.setEnabled(false);
		solverOptionsButton.setEnabled(false);
		solveSpanField.setEnabled(false);
	}

	/**
	 * Stores the solver parameters, and updates the initial conditions and
	 * solve span displays, as well as the solver options dialog.
	 * 
	 * @param params
	 *            solver parameters passed from the ODEWorkspace
	 */
	public void setParameters(SolverParameters params) {
		parameters = params;
		System.out.println("GUI: Solve span set to: "
				+ parameters.getSolveSpan());

		solveSpanField.setDouble(params.getSolveSpan());
		solverDialog.setParameters(parameters);
		icModel.updateSolverParameters(parameters);
		icModel.fireTableStructureChanged();
		adjustColumnWidth(icTable, 0, 4);
	}

	/**
	 * Stores the initial conditions, and updates the initial conditions and
	 * initial conditions displays.
	 * 
	 * @param params
	 *            solver parameters passed from the ODEWorkspace
	 */
	public void setIC(SolverParameters params) {
		parameters = params;
		icModel.updateSolverParameters(parameters);
		icModel.fireTableStructureChanged();
		adjustColumnWidth(icTable, 0, 4);
	}

	/**
	 * Returns the name of the InputPanel.
	 * 
	 * @return name of the InputPanel
	 */
	@Override
	public String getName() {
		return nameField.getText();
	}

	/**
	 * Sets the name field to the given string. This method is only called when
	 * loading/re-loading an ODEWorkspace.
	 * 
	 * @param name
	 *            String to assign to the name field
	 */
	@Override
	public void setName(String name) {
		nameField.setText(name);
	}

	/**
	 * Returns the ODE definition of the InputPanel.
	 * 
	 * @return ODE definition of the InputPanel
	 */
	public String getDefinition() {
		return definitionField.getText();
	}

	/**
	 * Sets the definition text field to the given string. This method is only
	 * called when loading/re-loading an ODEWorkspace.
	 * 
	 * @param definition
	 *            String to assign to the definition field
	 */
	public void setDefinition(String definition) {
		definitionField.setText(definition);
	}

	/**
	 * Sets the focus to the name field. This is called whenever a workspace is
	 * loaded/switched to.
	 */
	public void focusOnDefinition() {
		definitionField.requestFocus();
	}

	/**
	 * Assigns the input from the name field to the current ODE name.
	 */
	private void storeName() {
		workspaceOwner.getCurrentODE().setName(nameField.getText());
	}

	/**
	 * Stores the input from the definition text field as an ODE definition in
	 * the ODEWorkspace. Also update the workspace name on the nameField.
	 */
	private void storeDefinition() {
		if (workspaceOwner.storeDefinition(definitionField.getText()))
			nameField.setText(workspaceOwner.getCurrentODE().getName());
	}

	/**
	 * Stores the initial conditions and solve span into the ODEWorkspace.
	 * Before storing the solve span, the method checks for a valid input, and
	 * resets the solve span to 10.0 (default) if it is invalid.
	 */
	public void storeParameters() {
		if (solveSpanField.getDouble() > 0)
			parameters.setSolveSpan(solveSpanField.getDouble());
		else {
			System.out.println("Invalid solve span: Setting to 10.0");
			solveSpanField.setDouble(10.0);
			parameters.setSolveSpan(10.0);
		}

		icTable.ceaseEditing();
	}

	/**
	 * Adjusts the preferred width of the column specified to the width of the
	 * longest text plus a small margin. This method is called whenever the
	 * initial conditions table is modified in order to allocate the maximum
	 * possible width to the initial conditions column, by minimizing the space
	 * used by the variables column. Currently, the width is increased by 30
	 * pixels as well, which should be deleted if the column alignment can be
	 * properly fixed, since the margins are not added to both the left and
	 * right.
	 * 
	 * @param table
	 *            the table whose columns are to be packed
	 * @param vColIndex
	 *            the index of the column to be packed
	 * @param margin
	 *            the horizontal padding to give to the packed column
	 */
	private void adjustColumnWidth(JTable table, int vColIndex, int margin) {
		DefaultTableColumnModel colModel = (DefaultTableColumnModel) table
				.getColumnModel();
		TableColumn col = colModel.getColumn(vColIndex);
		int width = 0;

		// Get width of column header
		TableCellRenderer renderer = col.getHeaderRenderer();
		if (renderer == null) {
			renderer = table.getTableHeader().getDefaultRenderer();
		}
		Component comp = renderer.getTableCellRendererComponent(table,
				col.getHeaderValue(), false, false, 0, 0);
		width = comp.getPreferredSize().width;

		// Get maximum width of column data
		for (int r = 0; r < table.getRowCount(); r++) {
			renderer = table.getCellRenderer(r, vColIndex);
			comp = renderer.getTableCellRendererComponent(table,
					table.getValueAt(r, vColIndex), false, false, r, vColIndex);
			width = Math.max(width, comp.getPreferredSize().width);
		}

		// Add margin
		width += 2 * margin;
		width += 30; // Delete if enabling method

		System.out
				.println("Column " + vColIndex + " packed to " + width + "px");

		// Set the width
		col.setMaxWidth(width);
	}

	/**
	 * The ICTable class provides a specialized JTable whose format fits the
	 * needs of the initial conditions table in the InputPanel.
	 */
	protected class ICTable extends JTable {
		/**
		 * Shifts focus to the initial conditions cell when any cell in a row is
		 * selected.
		 * 
		 * @param row
		 *            row selected
		 * @param column
		 *            column selected
		 * @param toggle
		 *            flag that determines cell selection behavior
		 * @param extend
		 *            if true, extend the current selection
		 */
		@Override
		public void changeSelection(final int row, final int column,
				boolean toggle, boolean extend) {
			// change selected column index to 1
			super.changeSelection(row, 1, toggle, extend);

			// enables editing of the initial condition cell
			if (editCellAt(row, 1))
				getEditorComponent().requestFocusInWindow();
		}

		/**
		 * Returns true if the cell specified cell is being edited. As a side-
		 * effect, the method selects all the text in the cell for editing upon
		 * selection.
		 * 
		 * 
		 * @param row
		 *            the row to be edited
		 * @param column
		 *            the column to be edited
		 * @param e
		 *            event to pass into <code>shouldSelectCell</code>; note
		 *            that as of Java 2 platform v1.2, the call to
		 *            <code>shouldSelectCell</code> is no longer made
		 * @return false if for any reason the cell cannot be edited, or if the
		 *         indices are invalid
		 */
		@Override
		public boolean editCellAt(int row, int column, EventObject e) {
			boolean result = super.editCellAt(row, column, e);
			final Component editor = getEditorComponent();

			if (editor != null && editor instanceof JTextComponent) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						((JTextComponent) editor).selectAll();
					}
				});
			}
			return result;
		}

		/**
		 * Ceases editing for the currently editable cell. This is called any
		 * time the solver parameters are passed from the InputPanel to the
		 * ODEWorkspace.
		 */
		private void ceaseEditing() {
			int row = this.getEditingRow();
			int col = this.getEditingColumn();
			if (row != -1 && col != -1) // if cell is being edited
				this.getCellEditor(row, col).stopCellEditing();
		}
	}
}
