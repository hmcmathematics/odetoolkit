/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package parser.functions;

import parser.ParserInterface;

/**
 * Implements the triangle wave function
 */
public class TrwFunction extends Function {

	public TrwFunction() {
		super(3);
	}

	/*
	 * public double evaluate(double[] data, ParserInterface p) { if(data[0] >=
	 * 0) { if(Math.abs(data[0]) % data[2] < (data[1] / 100.0 data[2]) / 2.0)
	 * return Math.abs(data[0]) % data[2] (2.0/ (data[1] / 100.0 data[2]));
	 * if(Math.abs(data[0]) % data[2] < data[1] / 100.0 data[2]) return 1.0 +
	 * (Math.abs(data[0]) % data[2] -
	 * (data[1]/100.0data[2])/2)(-2.0/(data[1]/100.0 data[2])); return 0; } else
	 * { if(Math.abs(data[0]) % data[2] < (data[1] / 100.0 data[2]) / 2.0)
	 * return (data[2] - data[0] % data[2]) (2.0/ (data[1] / 100.0 data[2]));
	 * if(Math.abs(data[0]) % data[2] < data[1] / 100.0 data[2]) return 1.0 +
	 * (data[2] - Math.abs(data[0]) % data[2] -
	 * (data[1]/100.0data[2])/2)(-2.0/(data[1]/100.0 data[2])); return 0; } }
	 */

	@Override
	public double evaluate(double[] data, ParserInterface p) {
		if (data[0] < 0)
			data[0] = Math.abs(data[0]) + (data[2] * data[1] / 100.0);
		double temp = (data[0] % data[2]) / ((data[1] * data[2]) / 200.0);
		if (temp > 2.0)
			return 0.0;
		else
			return 1 - Math.abs(temp - 1);
	}

}
