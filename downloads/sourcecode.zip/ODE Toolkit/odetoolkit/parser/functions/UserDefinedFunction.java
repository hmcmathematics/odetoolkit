/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package parser.functions;

import java.util.Vector;

import parser.ParseException;
import parser.ParserInterface;
import parser.nodes.SimpleNode;

/**
 * Stores information about a user-defined function: its arguments and a stack
 * that can be used to evaluate it with arbitrary arguments
 */
public class UserDefinedFunction extends Function {

	// a vector of strings listing the arguments to be passed to the function
	private Vector<String> args;

	private SimpleNode expression;

	// make sure that no invalid identifiers were used in this function
	/*
	 * public void checkIdentifiers(Hashtable consts, Hashtable funcs) throws
	 * ParseException {
	 * 
	 * Object o;
	 * 
	 * evalStack.toTop(); while(!evalStack.atBottom()) { o = evalStack.pop();
	 * if(o instanceof String) { if(!ParserInterface.isOperator((String)o) &&
	 * !consts.containsKey((String)o) && !funcs.containsKey((String)o) &&
	 * !args.contains((String)o)) throw new
	 * ParseException("invalid identifier: "+(String)o); } } }
	 */

	@Override
	public double evaluate(double data[], ParserInterface p)
	throws ParseException {

		if (data == null || data.length != args.size())
			throw new ParseException("Null array or incorrect number of args");
		p.pushSymbolMap(args, data);
		double ret = expression.evaluate(p);
		p.popSymbolMap();
		return ret;
	}

	public String evaluate(String data[], ParserInterface p)
	throws ParseException {
		return new String("0");

	}

	public Vector<String> getArgs() {
		return args;
	}

	public UserDefinedFunction(Vector<String> args, SimpleNode n) {

		super(args.size());

		this.args = args;
		this.expression = n;
	}

	public SimpleNode getExpression() {
		return expression;
	}

}
