/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package parser;

import java.awt.geom.Point2D;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;
import java.util.Vector;

import parser.functions.AbsFunction;
import parser.functions.AcosFunction;
import parser.functions.AcoshFunction;
import parser.functions.AsinFunction;
import parser.functions.AsinhFunction;
import parser.functions.AtanFunction;
import parser.functions.AtanhFunction;
import parser.functions.CeilFunction;
import parser.functions.Constant;
import parser.functions.CosFunction;
import parser.functions.CoshFunction;
import parser.functions.CotFunction;
import parser.functions.DataFunction;
import parser.functions.ExpFunction;
import parser.functions.FactFunction;
import parser.functions.FloorFunction;
import parser.functions.Function;
import parser.functions.HeavisideFunction;
import parser.functions.LnFunction;
import parser.functions.LogFunction;
import parser.functions.MaxFunction;
import parser.functions.MinFunction;
import parser.functions.PowFunction;
import parser.functions.SignFunction;
import parser.functions.SinFunction;
import parser.functions.SincFunction;
import parser.functions.SinhFunction;
import parser.functions.SqpFunction;
import parser.functions.SqrtFunction;
import parser.functions.SqwFunction;
import parser.functions.StairFunction;
import parser.functions.SwpFunction;
import parser.functions.SwwFunction;
import parser.functions.TanFunction;
import parser.functions.TanhFunction;
import parser.functions.TrpFunction;
import parser.functions.TrwFunction;
import parser.functions.UserDefinedFunction;
import parser.nodes.Node;
import parser.nodes.SimpleNode;
import data.ODEVar;
import data.ODEVarVector;

/**
 * ParserInterface talks directly to a Parser object to compile text from the
 * input pane. It performs some additional error checking on the input and
 * contains methods to manage arguments to user-defined functions as they are
 * called.
 * 
 * Author: Max Comstock 2013, modified from Chris Moore Created: 6/19/02
 */
public class ParserInterface {

	// Constants used in the class ASTOperatorNode
	public static final short ADD = 1;

	public static final short SUBTRACT = 2;

	public static final short MULTIPLY = 3;

	public static final short DIVIDE = 4;

	public static final short REMAINDER = 5;

	public static final short POWER = 6;

	// public static final short FACTORIAL = 7;
	public static final short NEGATION = 8;

	// Constants used in the class ASTBooleanOperatorNode
	public static final short AND = 9;

	public static final short OR = 10;

	// Constants used in the class ASTRelationalNode
	public static final short GREATER = 11;

	public static final short GREATER_OR_EQUAL = 12;

	public static final short LESS = 13;

	public static final short LESS_OR_EQUAL = 14;

	public static final short EQUAL = 15;

	public static final short NOT_EQUAL = 16;

	// what are we using as the independent variable?
	public static String _independentVariable = new String("t");

	// pointer to the parser, which tokenizes user input, ensures that it fits
	// the grammar, and adds the data in an appropriate form to the appropriate
	// structure in ParserInterface
	private Parser _parser;

	@SuppressWarnings("unchecked")
	private Hashtable _dataFuncs;

	// a Hashtable of Constants
	@SuppressWarnings("unchecked")
	private Hashtable _consts;

	// a Hashtable of classes derived from Function
	private Hashtable<String, Function> _funcs;

	// a Vector of Strings storing the dependent first order ODE variables
	// ex: if the system x'=w*t w' = t^2 is entered, firstOrderVars would
	// contain ["x", "w"]
	private Vector<String> _firstOrderVars;

	// same as firstOrderVars except that the first element is the independent
	// variable
	// used for efficienty reasons in some methods
	private Vector<String> _firstOrderVarsWithIndepVar;

	// a Vector of Nodes corresponding to the root nodes of the syntax trees
	// of the 1st order ODEs
	private Vector<Node> _firstOrderExpressions;

	// a Vector of Strings storing the exact text that the user entered to
	// specify each ODE
	private Vector<String> _firstOrderStrings;

	// the exact text that was entered into the InputPanel
	String _initialText;

	// Stacks used when evaluating user-defined functions and ODEs:
	// symbolNames should contain elements that are Vectors of Strings
	// symbolValues should contain elements that are arrays of doubles
	// Evaluating user-defined functions works as follows:
	// UserDefinedFunction::evaluate() is called with a vector of doubles
	// containing the values of the arguments to that function. The
	// method then calls the pushSymbolMap() method in the ParserInterface
	// object that it was given, specifying as parameters the Vector
	// of Strings, argNames, stored in that instance of
	// UserDefinedFunction, and the array of doubles, argValues, that it
	// was passed. It then calls the evaluate() method on the root node
	// of its syntax tree to evaluate the function at the specified point.
	// If evaluate() is called in an ASTIdentifierNode, the node will call
	// getSymbolDoubleValue() in the ParserInterface it was given,
	// specifying its name as the symbol, and return the value given
	// by getSymbolDoubleValue()
	private Stack<Vector<String>> _symbolNames;
	private Stack<double[]> _symbolValues;

	// the value of the independent variable
	private double _independentValue;

	// a Vector of Strings storing the valid identifiers (in adition to
	// functions and constants) in a given context
	// Identifier checking is performed as follows:
	// validIdentifiers is filled in with all of the identifiers
	// (except function and constant names) that would be valid in a given
	// context (see methods below)... then checkIdentifiers is called on
	// the root
	// node of the function or ODE of interest. In nodes other than
	// ASTIdentifierNodes, checkIdentifiers() simply calls
	// checkIdentifiers() on all of the node's children. If the node
	// corresponds to an identifier (is of type ASTIdentifierNode),
	// calls the isValidIdentifier() method in the ParserInterface that
	// it was given, supplying its name as the argument.
	// isValidIdentifier() returns true iff the identifier corresponds to
	// a function, constant, or a String that is in validIdentifiers. If
	// isValidIdentifier() returns false, ASTIdentifierNode throws a
	// ParseException. Otherwise it just returns
	private Vector<String> _validIdentifiers;

	// primeAllowed is also used when checking identifiers
	// if an identifier is primed, it checks to make sure that this is true and
	// throws a ParseException if it is not
	private boolean _primeAllowed;

	@SuppressWarnings("unused")
	private ParseException _parserError;

	public ParserInterface(String text) throws ParseException {
		_initialText = new String(text);
		parse(text);
	}

	public ParserInterface() {
		_parser = null;
	}

	// Parses the string "text," filling in the approptiate data structures
	// clears all of the data from the previous parse (consts, funcs,
	// and all of the ODE data) if there was one
	@SuppressWarnings("unchecked")
	private void parse(String text) throws ParseException {
		_initialText = text;
		text.toLowerCase();

		StringReader strReader = new StringReader(text);

		// if we haven't parsed anything before, create a new parser
		// otherwise reinitialize the current one with the new string
		if (_parser == null)
			_parser = new Parser(strReader);
		else
			_parser.ReInit(strReader);

		// reses constHash and funcHash so that they only contain the
		// predefined constants and functions
		resetConstants();
		resetFunctions();

		_dataFuncs = new Hashtable();

		_symbolNames = new Stack();
		_symbolValues = new Stack();

		_firstOrderVars = new Vector<String>();
		_firstOrderExpressions = new Vector<Node>();
		_firstOrderStrings = new Vector<String>();

		_validIdentifiers = null;

		// tells the actual parser to parse the given string, adding any
		// user-defined functions and constants to funcs and consts, and
		// filling firstOrderVars, firstOrderStacks, firstOrderOriginals,
		// secondOrderVars, secondOrderStacks, and secondOrderOriginals
		// NOTE: because of the way data functions are entered (similar to
		// the way constants are), the consts hash will contain both
		// constants and data functions after this call... the data
		// functions are moved to the dataFuncs hashtable by the method
		// evaluateConstantsAndMoveDataFuncs() (called from
		// checkUnrecognizedIdentifiers())
		_parser.Parse(this);

		_firstOrderVarsWithIndepVar = new Vector<String>(
				_firstOrderVars.size() + 1);
		_firstOrderVarsWithIndepVar.add(_independentVariable);
		_firstOrderVarsWithIndepVar.addAll(_firstOrderVars);

		// do some post-parse processing and identifier checking
		checkUnrecognizedIdentifiers();

	}

	// Evaluates the function the name "fName" at the point given by "args"
	public synchronized double evaluateFunction(String fName, double[] args)
	throws ParseException {

		Function f = _funcs.get(fName);
		if (f == null)
			throw new ParseException("Invalid function name specified");
		return f.evaluate(args, this);
	}

	// Evaluates the data function with name "name" at the point specified by
	// "vals," where the first entry in vals is the value of the independent
	// variable
	public double evaluateDataFunction(String name, double[] vals)
	throws ParseException {
		DataFunction f = (DataFunction) _dataFuncs.get(name);
		if (f == null)
			throw new ParseException(name + " is not a data function");
		pushSymbolMap(_firstOrderVarsWithIndepVar, vals);
		return f.evaluate(this);
	}

	// Get the numerical values of all the constants and move any data
	// functions to dataFuncs
	// If something in consts was found that is not a constant (a
	// ParseException is thrown when we try to evaluate the constant), move it
	// to dataFuncs (NOTE: this means that identifier-checking should be
	// preformed before this method is called as it assumes that any
	// ParseExceptions throwm when evaluating "constants" are due to the use
	// of ODE state variables in the constant definition => the "constant"
	// is really a dataFunction)
	@SuppressWarnings("unchecked")
	private void evaluateConstantsAndMoveDataFuncs() {
		Enumeration elements = _consts.elements();
		Enumeration keys = _consts.keys();
		Constant c;
		String id;
		_validIdentifiers = null;

		while (elements.hasMoreElements()) {
			c = (Constant) elements.nextElement();
			id = (String) keys.nextElement();
			try {
				c.evaluate(this);
			} catch (Exception e) {
				_dataFuncs.put(id, new DataFunction(c));
				_consts.remove(id);
			}
		}
	}

	// Given values for the independent variable and all of the dependent
	// variables of the system, computes the derivatives of all of the
	// variables
	// After execution, yDot contains the derivatives
	// Assumes that y.length = yDot.length = numEquations()
	public synchronized void evaluateODEs(double t, double[] y, double[] yDot)
	throws ParseException {

		pushSymbolMap(_firstOrderVars, y);
		setIndependentValue(t);
		for (int i = 0; i < _firstOrderExpressions.size(); i++) {
			yDot[i] = ((SimpleNode) _firstOrderExpressions.elementAt(i))
			.evaluate(this);
		}
		popSymbolMap();
	}

	// Make sure that all the identifiers given are valid
	// Identifier checking is performed as follows:
	// validIdentifiers is filled in with all of the identifiers
	// (except function and constant names) that would be valid in a given
	// context (see below)... then checkIdentifiers is called on the root
	// node of the function or ODE of interest. In nodes other than
	// ASTIdentifierNodes, checkIdentifiers() simply calls
	// checkIdentifiers() on all of the node's children. If the node
	// corresponds to an identifier (is of type ASTIdentifierNode),
	// calls the isValidIdentifier() method in the ParserInterface that
	// it was given, supplying its name as the argument.
	// isValidIdentifier() returns true iff the identifier corresponds to
	// a function, constant, or a String that is in validIdentifiers. If
	// isValidIdentifier() returns false, ASTIdentifierNode throws a
	// ParseException. Otherwise it just returns
	@SuppressWarnings("unchecked")
	private void checkUnrecognizedIdentifiers() throws ParseException {

		_validIdentifiers = _firstOrderVarsWithIndepVar;
		_primeAllowed = true;
		Enumeration e = _consts.elements();
		Constant c;
		while (e.hasMoreElements()) {
			c = (Constant) e.nextElement();
			if (c.getExpression() != null)
				c.getExpression().checkIdentifiers(this);
		}

		// Get the numerical values of all the constants
		evaluateConstantsAndMoveDataFuncs();

		// Make sure that no unrecognized identifiers were used in specifying
		// ODEs: valid identifiers in an ODE are functions, constants, and the
		// dependent and independent ODE variables of the system
		_validIdentifiers = _firstOrderVarsWithIndepVar;
		_primeAllowed = false;

		// Call checkIdentifiers() on the root nodes of all of the ODEs
		// checkIdentifiers() will throw a ParseException if any invalid
		// identifiers were used

		for (int i = 0; i < _firstOrderVars.size(); i++)
			(_firstOrderExpressions.elementAt(i)).checkIdentifiers(this);

		// Make sure that no unrecognized identifiers were used when specifying
		// functions: valid identifiers in a function definition are other
		// functions, constants, and argument names to that function
		e = _funcs.elements();
		Function f;
		_primeAllowed = false;

		// For each function definition, we want to set validIdentifiers to the
		// Vector of argument names to that function and call checkIdentifiers
		// on the root node of the syntax tree representing the function
		while (e.hasMoreElements()) {
			f = (Function) e.nextElement();
			if (f instanceof UserDefinedFunction) {
				_validIdentifiers = ((UserDefinedFunction) f).getArgs();
				((UserDefinedFunction) f).getExpression()
				.checkIdentifiers(this);
			}
		}

		_validIdentifiers = null;
	}

	// Can we draw a direction field for the 2 specified variables?
	// We can if the right hand sides of the ODE expressions for the specified
	// variables contain references to no additional variables other than
	// var1 and var2
	// ex: we could draw a direction field for x and y given the system
	// x'=sin(y) y'=x but not for the system x'=sin(y)*t y'=x
	public boolean isDirFieldPossible(ODEVar odeVar1, ODEVar odeVar2) {
		String var1 = odeVar1.getName();
		String var2 = odeVar2.getName();

		var1.toLowerCase();
		var2.toLowerCase();

		if ((!_firstOrderVars.contains(var1) && !_independentVariable
				.equals(var1))
				|| (!_firstOrderVars.contains(var2) && !_independentVariable
						.equals(var2)))
			return false;

		if (var1.equals(var2))
			return true;

		// In this context, the valid identifiers, on top of functions and
		// constants, would only be var1 and var2
		_validIdentifiers = new Vector<String>();
		_validIdentifiers.add(var1);
		_validIdentifiers.add(var2);
		_primeAllowed = false;

		if (!var1.equals(_independentVariable)) {
			try {
				(_firstOrderExpressions
						.elementAt(_firstOrderVars.indexOf(var1)))
						.checkIdentifiers(this);
			} catch (Exception e) {
				return false;
			}
		}
		if (!var2.equals(_independentVariable)) {
			try {
				(_firstOrderExpressions
						.elementAt(_firstOrderVars.indexOf(var2)))
						.checkIdentifiers(this);
			} catch (Exception e) {
				return false;
			}
		}
		return true;

	}

	// Returns true if id is a function, constant, or contained in the
	// validIdentifiers vector
	public boolean isValidIdentifier(String id) {
		id.toLowerCase();
		if (_funcs.containsKey(id) || _consts.containsKey(id))
			return true;
		if (_validIdentifiers != null) {
			if (_validIdentifiers.contains(id))
				return true;
		}
		return false;
	}

	// Returns true if the entered system is autonomous
	public boolean isAutonomous() {

		// If a system is autonomous, the only valid identifiers it will have
		// are defined functions, constants, and the dependent ODE vars (no t)
		_validIdentifiers = _firstOrderVars;
		_primeAllowed = false;
		for (int i = 0; i < getNumEquations(); i++) {
			try {
				(_firstOrderExpressions.elementAt(i)).checkIdentifiers(this);
			} catch (Exception e) {
				return false;
			}
		}
		return true;
	}

	public boolean hasConstantNamed(String c) {
		return _consts.containsKey(c);
	}

	public boolean hasFunctionNamed(String f) {
		return _funcs.containsKey(f);
	}

	public boolean hasODEVarNamed(String v) {
		return _firstOrderVars.contains(v);
	}

	// Returns true if one of the user-defined functions has an argument named
	public boolean hasFunctionWithArgNamed(String v) {
		Enumeration e = _funcs.elements();
		Function f;
		while (e.hasMoreElements()) {
			f = (Function) e.nextElement();
			if (f instanceof UserDefinedFunction)
				return ((UserDefinedFunction) f).getArgs().contains(v);
		}
		return false;
	}

	// Resets constHash so that it only contains the predefined constants
	@SuppressWarnings("unchecked")
	private void resetConstants() {

		_consts = new Hashtable();

		_consts.put("pi", new Constant(java.lang.Math.PI));
		// consts.put("e", new Constant(java.lang.Math.E));

	}

	// Resets funcHash so that it only contains the predefined functions
	private void resetFunctions() {

		_funcs = new Hashtable<String, Function>();

		// Standard stuff...
		_funcs.put("abs", new AbsFunction());
		_funcs.put("exp", new ExpFunction());
		_funcs.put("ln", new LnFunction());
		_funcs.put("log", new LogFunction());
		_funcs.put("sqrt", new SqrtFunction());
		_funcs.put("pow", new PowFunction());
		_funcs.put("max", new MaxFunction());
		_funcs.put("min", new MinFunction());

		// Standard trig. functions
		_funcs.put("sin", new SinFunction());
		_funcs.put("cos", new CosFunction());
		_funcs.put("tan", new TanFunction());
		_funcs.put("cot", new CotFunction());

		// Inverse trig. functions
		_funcs.put("asin", new AsinFunction());
		_funcs.put("acos", new AcosFunction());
		_funcs.put("atan", new AtanFunction());

		// Hyperbolic trig. functions
		_funcs.put("cosh", new CoshFunction());
		_funcs.put("sinh", new SinhFunction());
		_funcs.put("tanh", new TanhFunction());

		// Inverse hyperbolic trig. functions
		_funcs.put("acosh", new AcoshFunction());
		_funcs.put("asinh", new AsinhFunction());
		_funcs.put("atanh", new AtanhFunction());

		// Step functions
		_funcs.put("floor", new FloorFunction());
		_funcs.put("ceil", new CeilFunction());
		_funcs.put("sign", new SignFunction());
		_funcs.put("heaviside", new HeavisideFunction());
		_funcs.put("step", new HeavisideFunction());

		_funcs.put("fact", new FactFunction());
		_funcs.put("factorial", new FactFunction());

		// Engineering functions
		_funcs.put("sqw", new SqwFunction());
		_funcs.put("trw", new TrwFunction());
		_funcs.put("sww", new SwwFunction());
		_funcs.put("sqp", new SqpFunction());
		_funcs.put("trp", new TrpFunction());
		_funcs.put("swp", new SwpFunction());
		_funcs.put("stair", new StairFunction());

		// Sinc Function
		_funcs.put("sinc", new SincFunction());

	}

	// The next two methods (getVarIndex and getSlope) are used by the plot
	// panel to compute slopefields. The panel should get the indices of the
	// 2 variables involved, then call getSlope once for each of the 2 vars
	// at each point at which it needs the slope. It can then compute the
	// slope to be drawn by dividing the values returned by getSlope.

	// Returns the position of var in the firstOrderVars vector
	// This index can then be passed to getSlope to evaluate the time
	// derivative of var
	public int getVarIndex(ODEVar var) {
		// This function and the following function used to convert the strings
		// to lower case, so the slope field lines would always have the vector
		// (1, 1) if there was a capitalized variable. I have removed this bug.
		return _firstOrderVars.indexOf(var.getName());
	}

	public int getVarIndex(String var) {
		return _firstOrderVars.indexOf(var);
	}

	// Given a list of variable names (vars) and values for those variables
	// (vals), computes the time derivative of the variable with the given
	// index (index) into firstOrderVars
	// Given a list of variable names (vars) and values for those variables
	// (vals), computes the time derivative of the variable with the given
	// index (index) into firstOrderVars
	public double getSlope(ODEVar var, ODEVarVector vars, Point2D.Double pt)
	throws Exception {
		int index = getVarIndex(var);
		double ret;
		// used in case the user requests the time derivative of the
		// independent variable (dt/dt = 1)
		// getVarIndex(independentVariable) will return -1, so if getSlope is
		// then called with this value, we assume the user wants dt/dt
		if (index == -1)
			return 1.0;

		pushSymbolMap(vars.getNames(), new double[] { pt.x, pt.y });

		try {
			ret = ((SimpleNode) _firstOrderExpressions.elementAt(index))
			.evaluate(this);
		} catch (ParseException p) {
			popSymbolMap();
			throw new Exception(p.getMessage());
		}
		popSymbolMap();
		return ret;
	}

	public double getSlopeUsingCurrentSymbolMap(int index) throws Exception {
		if (index == -1)
			return 1.0;
		try {
			return ((SimpleNode) _firstOrderExpressions.elementAt(index))
			.evaluate(this);
		} catch (ParseException p) {
			throw new Exception(p.getMessage());
		}
	}

	// Returns a vector containing all of the vars in the equations,
	// with the independent variable listed first, followed
	// by the dependent variables in the order that they were listed in
	// firstOrderVars
	public Vector<String> getVariables() {
		return new Vector<String>(_firstOrderVarsWithIndepVar);
	}

	public Vector<String> getEquations() {
		return _firstOrderStrings;
	}

	public void pushSymbolMap(Vector<String> names, double[] values) {
		_symbolNames.push(names);
		_symbolValues.push(values);
	}

	public void pushSymbolMap(Vector<String> names, Point2D.Double pt) {
		_symbolNames.push(names);
		_symbolValues.push(new double[] { pt.x, pt.y });
	}

	@SuppressWarnings("unchecked")
	public double getSymbolDoubleValue(String symbol) throws ParseException {
		Constant c = (Constant) _consts.get(symbol);
		if (c != null)
			return c.evaluate(this);

		int pos = ((Vector) _symbolNames.peek()).indexOf(symbol);
		if (pos != -1) {
			double[] vals = _symbolValues.peek();
			return vals[pos];
		}

		if (symbol.equals(_independentVariable))
			return _independentValue;

		throw new ParseException("Unrecognized identifier: " + symbol);
	}

	public void popSymbolMap() {
		_symbolNames.pop();
		_symbolValues.pop();
	}

	public int getNumArgsToFunction(String name) throws ParseException {
		Function f = _funcs.get(name);
		if (f == null)
			throw new ParseException("Undefined function: " + name);
		return f.numArgs;
	}

	@SuppressWarnings("unchecked")
	public void addConstant(String name, Constant c) {
		_consts.put(name, c);
	}

	public void addFunction(String name, Function f) {
		_funcs.put(name, f);
	}

	public void addFirstOrderODE(String var, String definition,
			SimpleNode expression) {
		_firstOrderVars.add(var);
		_firstOrderStrings.add(definition);
		_firstOrderExpressions.add(expression);
	}

	public void setIndependentValue(double val) {
		_independentValue = val;
	}

	public Vector<String> getSingleVarUserdefinedFunctionNames() {
		Vector<String> ret = new Vector<String>();
		Enumeration<String> keys = _funcs.keys();
		Enumeration<Function> elements = _funcs.elements();
		Function f;
		while (keys.hasMoreElements()) {
			f = elements.nextElement();
			if (f instanceof UserDefinedFunction)
				ret.add(keys.nextElement());
			else
				keys.nextElement();
		}
		return ret;
	}

	public Vector<String> getSingleVarPredefinedFunctionNames() {
		Vector<String> ret = new Vector<String>();
		Enumeration<String> keys = _funcs.keys();
		Enumeration<Function> elements = _funcs.elements();
		Function f;
		while (keys.hasMoreElements()) {
			f = elements.nextElement();
			if (!(f instanceof UserDefinedFunction))
				ret.add(keys.nextElement());
			else
				keys.nextElement();
		}
		return ret;
	}

	@SuppressWarnings("unchecked")
	public Vector<String> getDataFunctionNames() {
		Enumeration<String> e = _dataFuncs.keys();
		Vector<String> ret = new Vector<String>();
		while (e.hasMoreElements())
			ret.add(e.nextElement());
		return ret;
	}

	@SuppressWarnings("unchecked")
	public Vector<String> getConstantNames() {
		Enumeration<String> e = _consts.keys();
		Vector<String> ret = new Vector<String>();
		while (e.hasMoreElements())
			ret.add(e.nextElement());
		return ret;
	}

	// return the number of ODE's found
	public int getNumEquations() {
		if (_firstOrderVars != null)
			return _firstOrderVars.size();
		else
			return 0;
	}

	public boolean setODEText(String initialText) {
		try {
			parse(initialText);
		} catch (Exception e) {
			if (e instanceof ParseException) {
				_parserError = (ParseException) e;
			} else {
				_parserError = null;
			}
			return false;
		}
		return true;
	}

	// returns the initial text
	public String getODEText() {
		return _initialText;
	}

	// getter for member var. primeAllowed
	public boolean getPrimeAllowed() {
		return _primeAllowed;
	}

}
