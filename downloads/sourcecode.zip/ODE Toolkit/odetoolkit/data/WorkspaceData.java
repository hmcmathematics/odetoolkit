/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * Author: Ken Dye - kdye@hmc.edu
 * summer 2002
 *
 * Raugh: "Hey everybody!  I spent all the clinic money on these magic beans!"
 */
package data;

import java.util.Enumeration;
import java.util.Vector;

import solver.Solver;
import solver.SolverInterface;
import solver.SolverParameters;
import ui.outputpanels.ODEWorkspace;

/**
 * Workspace holds all the ODEs. It tries to be the only class that the frontend
 * needs to deal with for the storage and retrieval of ODEs.
 * 
 * @author Clinic 10-11, modified from Workspace written by Clinic 08-09
 */
public class WorkspaceData {

	/** The name of this WorkspaceData */
	private String name;

	/** The ODEs contained in this WorkspaceData */
	private Vector<ODE> odes;

	/** The number of ODEs created in this WorkspaceData, used for naming */
	private int odeNumber = 0;

	/** The ODEWorkspace associated with this WorkspaceData */
	private ODEWorkspace frontendWorkspace;

	/** The comment associated with this WorkspaceData */
	private String comments;

	/**
	 * Constructor for creating a new WorkspaceData.
	 * 
	 * @param n
	 *            the name of the new WorkspaceData
	 */
	public WorkspaceData(String n) {
		name = n;
		comments = null;
		frontendWorkspace = null;
		removeAllODEs();
	}

	/**
	 * Set the comment for this WorkspaceData.
	 * 
	 * @param c
	 *            the new comment for this WorkspaceData
	 */
	public void setComments(String c) {
		comments = c;
	}

	/**
	 * Returns the comment for this WorkspaceData.
	 * 
	 * @return the comment for this WorkspaceData
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * Set the name of this WorkspaceData
	 * 
	 * @param n
	 *            the new name of this WorkspaceData
	 */
	public void setName(String n) {
		name = n;
	}

	/**
	 * Returns the name of this WorkspaceData.
	 * 
	 * @return the name of this WorkspaceData
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the ODEs in this WorkspaceData.
	 * 
	 * @return the ODEs in this WorkspaceData
	 */
	public Vector<ODE> getODEs() {
		return odes;
	}

	/**
	 * Return the ODE in this WorkspaceData with the given name.
	 * 
	 * @param name
	 *            the name of the desired ODE
	 * @return the ODE with the desired name
	 */
	public ODE getODE(String name) {
		ODE d = null;
		Enumeration<ODE> e = odes.elements();

		while (e.hasMoreElements()) {
			d = (e.nextElement());
			if (d.getName().equals(name))
				return d;
		}
		return null;
	}

	/**
	 * Add a new ODE to this WorkspaceData.
	 * 
	 * @param de
	 *            the new ODE to add
	 */
	public void addODE(ODE de) {
		odes.add(de);
	}

	/**
	 * Remove an ODE with the given name from this WorkspaceData.
	 * 
	 * @param name
	 *            the name of the ODE to remove
	 * @return true iff successfully removed the ODE with given name
	 */
	public boolean removeODE(String name) {
		ODE de = this.getODE(name);

		if (de != null)
			return odes.remove(de);
		return false;
	}

	/**
	 * Remove an ODE from this WorkspaceData.
	 * 
	 * @param de
	 *            the ODE to remove
	 * @return true iff successfully removed the specified ODE
	 */
	public boolean removeODE(ODE de) {
		return odes.remove(de);
	}

	/**
	 * Remove all ODEs in this WorkspaceData.
	 * 
	 * @return true iff successfully remove all ODEs
	 */
	public boolean removeAllODEs() {
		try {
			odes = new Vector<ODE>(5, 2);
			return true;
		} catch (Throwable e) {
			return false;
		}
	}

	/**
	 * Returns the number of ODE in the WorkspaceData.
	 * 
	 * @return the number of ODE in the WorkspaceData
	 */
	public int getNumODEs() {
		return odes.size();
	}

	/**
	 * Returns the number of ODE ever created in this WorkspaceData, used in
	 * naming.
	 * 
	 * @return the ODE number
	 */
	public int getODENumber() {
		return odeNumber;
	}

	/**
	 * Set the ODE number, used in naming.
	 * 
	 * @param num
	 *            the new ODE number
	 */
	public void setODENumber(int num) {
		odeNumber = num;
	}

	/**
	 * Increase the ODE number.
	 */
	public void updateODENumber() {
		++odeNumber;
	}

	/**
	 * Set the ODEWorkspace associated with this WorkspaceData.
	 * 
	 * @param odeWorkspace
	 *            the ODEWorkspace associated with this WorkspaceData
	 */
	public void setODEWorkspace(ODEWorkspace odeWorkspace) {
		frontendWorkspace = odeWorkspace;
	}

	/**
	 * Returns the ODEWorkspace associated with this WorkspaceData.
	 * 
	 * @return the ODEWorkspace associated with this WorkspaceData
	 */
	public ODEWorkspace getODEWorkspace() {
		return frontendWorkspace;
	}

	/**
	 * Remove all Curves and Equilibria in this WorkspaceData.
	 */
	public void clearPlotObjects() {
		for (int i = 0; i < odes.size(); i++) {
			odes.elementAt(i).clearCurves();
			odes.elementAt(i).clearEquilibria();
		}
	}

	/**
	 * Return a solver set up to solve the given ODE. The returned Solver just
	 * needs to be started.
	 * 
	 * @param de
	 *            the ODE to solve for a Curve
	 * @param sp
	 *            the SolverParameters used to solve for the Curve
	 * @return a solver set up to solve the given ODE
	 */
	public Solver solve(ODE de, SolverParameters sp) {
		if (de == null || sp == null)
			return null;
		return SolverInterface.solve(de, sp);
	}

	/**
	 * Return a solver set up to solve the given ODE name. The returned Solver
	 * just needs to be started.
	 * 
	 * @param which
	 *            the name of the ODE to solve for a Curve
	 * @param sp
	 *            the SolverParameters used to solve for the Curve
	 * @return a solver set up to solve the given ODE
	 */
	public Solver solve(String which, SolverParameters sp) {
		return solve(getODE(which), sp);
	}
}
