/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

/**
 * The ODEVar class contains the information of an ODE variable, including its
 * name and the index of the variable within the ODEVarKeeper. An ODEVarKeeper
 * contains one ODEVar for each variable that is parsed from all ODE definitions
 * ever inputted in the workspace
 * 
 * @author Richard Mehlinger 09, modified by Andres Perez 09 and Clinic 10-11
 */
public class ODEVar {
	/** Name of the variable */
	private String varName;

	/** Index of the variable's position within the ODEVarKeeper */
	private int varIndex;

	/**
	 * Sole Constructor, sets the variable's name as designated by the user, and
	 * stores the index of the variable within the ODE's ODEVarKeeper.
	 * 
	 * @param name
	 *            the name of this variable
	 * @param index
	 *            the index of this variable within the ODEVarKeeper
	 */
	public ODEVar(String name, int index) {
		varName = name;
		varIndex = index;
	}

	/**
	 * Returns the name of this ODEVar.
	 * 
	 * @return the name of this ODEVar
	 */
	public String getName() {
		return varName;
	}

	/**
	 * Returns the index of this ODEVar within the ODEVarKeeper
	 * 
	 * @return this ODEVar's index in the ODEVarKeeper
	 */
	public int getVarIndex() {
		return varIndex;
	}

	/**
	 * Returns true if the specified ODEVar is equal to this ODEVar by comparing
	 * their indices within the ODEVarKeeper.
	 * 
	 * @param var
	 *            the ODEVar to compare this ODEVar with
	 * @return true if the variables are the same
	 */
	public boolean equals(ODEVar var) {
		return var.getVarIndex() == getVarIndex();
	}
}
