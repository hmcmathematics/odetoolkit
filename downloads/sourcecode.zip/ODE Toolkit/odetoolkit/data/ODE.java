/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

import java.awt.Color;
import java.util.ListIterator;
import java.util.Vector;

import parser.ParserInterface;
import solver.Solver;
import solver.SolverParameters;
import util.ServerRequest;

/**
 * Represents an ODE system and the data curves that have been solved for it.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
public class ODE extends ParserInterface {
	/** Name of the ODE */
	private String name;

	/** Curves owned by this ODE */
	private Vector<Curve> curves;
	/** Equilibria owned by this ODE */
	private Vector<Equilibrium> equilibria;

	/** The most recently added Curve, which may not be fully computed */
	private Curve pendingCurve;

	/** The number of Curves ever created for this ODE, used for naming */
	private int curveNumber = 0;
	/** The number of Equilibria ever created for this ODE, used for naming */
	private int equilibriumNumber = 0;
	
	/** The visual properties of the next curve */
	private VisualProperties visualProps = new VisualProperties();

	/**
	 * Constructor that creates a new blank ODE
	 * 
	 * @param name
	 *            the name of this ODE
	 */
	public ODE(String name) {
		setName(name);
		clearCurves();
		clearEquilibria();
		pendingCurve = null;
	}

	/**
	 * Returns the name of the ODE.
	 * 
	 * @return the name of the ODE
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the name of the ODE.
	 * 
	 * @param name
	 *            the name for this ODE
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/** Set the color of the Curves in this ODE.
	 * 
	 * @param c
	 *            The color for the curves
	 */
	public void setColor(Color c) {
		visualProps.setColor(c);
	}
	
	/** Get the color of the Curves in this ODE.
	 * 
	 * @return c
	 *            The color for the curves
	 */
	public Color getColor() {
		return visualProps.getColor();
	}

	/**
	 * Returns the number of dimensions associated to this ODE.
	 * 
	 * @return the number of dimensions associated to this ODE
	 */
	public int getDimensions() {
		return getVariables().size();
	}

	/**
	 * Returns the Curves in this ODE.
	 * 
	 * @return the Curves in this ODE
	 */
	public Vector<Curve> getCurves() {
		return curves;
	}

	/**
	 * Returns the pending Curve.
	 * 
	 * @return the pending Curve
	 */
	public Curve getPendingCurve() {
		return pendingCurve;
	}

	/**
	 * Add a new Curve to this ODE.
	 * 
	 * @param c
	 *            a Curve to add
	 */
	public void addCurve(Curve c) {
		curves.addElement(c);
	}

	/**
	 * Remove a Curve from this ODE.
	 * 
	 * @param c
	 *            the Curve to delete
	 */
	public void removeCurve(Curve c) {
		curves.remove(c);
	}

	/**
	 * Removes all Curves from the ODE.
	 */
	public void clearCurves() {
		curves = new Vector<Curve>(5, 2);
	}

	/**
	 * Returns the number of Curves in this ODE.
	 * 
	 * @return the number of Curves in this ODE
	 */
	public int getNumCurves() {
		return curves.size();
	}

	/**
	 * Returns the number of Curves created for this ODE, used for naming.
	 * 
	 * @return the Curve number
	 */
	public int getCurveNumber() {
		return curveNumber;
	}

	/**
	 * Set the number of Curves created for this ODE, used for naming.
	 * 
	 * @param num
	 *            the new Curve number
	 */
	public void setCurveNumber(int num) {
		curveNumber = num;
	}

	/**
	 * Returns the Equilibria in this ODE.
	 * 
	 * @return the Equilibria in this ODE
	 */
	public Vector<Equilibrium> getEquilibria() {
		return equilibria;
	}

	/**
	 * Add a new Equilibrium to this ODE.
	 * 
	 * @param e
	 *            a Equilibrium to add
	 */
	public void addEquilibrium(Equilibrium e) {
		equilibria.addElement(e);
	}

	/**
	 * Create a new Equilibrium for this ODE
	 * 
	 * @param variables
	 *            the variables associated to this new Equilibrium
	 * @param pts
	 *            the point for this equilibrium
	 */
	public void createEquilibrium(ODEVarVector variables, double[] pts) {
		++equilibriumNumber;
		String eqName = "Eqpoint" + equilibriumNumber;

		Equilibrium eq = new Equilibrium(variables, eqName, pts);
		equilibria.add(eq);
	}

	/**
	 * Remove an Equilibrium from this ODE.
	 * 
	 * @param e
	 *            the Equilibrium to delete
	 */
	public void removeEquilibrium(Equilibrium e) {
		equilibria.remove(e);
	}

	/**
	 * Removes all Equilibria from the ODE.
	 */
	public void clearEquilibria() {
		equilibria = new Vector<Equilibrium>(5, 2);
	}

	/**
	 * Returns the number of Equilibria in this ODE.
	 * 
	 * @return the number of Equilibria in this ODE
	 */
	public int getNumEquilibria() {
		return equilibria.size();
	}

	/**
	 * Returns the number of Equilibria created for this ODE, used for naming.
	 * 
	 * @return the Equilibria number
	 */
	public int getEquilibriumNumber() {
		return equilibriumNumber;
	}

	/**
	 * Set the number of Equilibria created for this ODE, used for naming.
	 * 
	 * @param num
	 *            the new Equilibria number
	 */
	public void setEquilibriumNumber(int num) {
		equilibriumNumber = num;
	}

	/**
	 * Prepares this ODE to be solved by creating an empty curve and setting up
	 * the listeners appropriately so that the solutions will be put in the new
	 * curve.
	 * 
	 * @param sol
	 *            the solver thread for solving this curve
	 * @param sp
	 *            the SolverParameted used for solving this curve
	 * @return true iff no Curve is pending
	 */
	public boolean setupSolve(Solver sol, SolverParameters sp) {
		if (pendingCurve != null)
			return false;

		++curveNumber;
		String curveName = "curve" + curveNumber;
		pendingCurve = new Curve(sp, curveName, new VisualProperties(
				visualProps.getColor(), visualProps.isShown()));
		sol.setCurve(pendingCurve);

		return true;
	}

	/**
	 * Determines whether all curves associated with this ODE have received all
	 * their points.
	 * 
	 * @return true iff no Curve is pending
	 */
	public boolean curvesDone() {
		return pendingCurve == null;
	}

	/**
	 * Add the pendingCurve to the list of Curves as solving is done
	 */
	public void solveDone() {
		synchronized (this) {
			curves.addElement(pendingCurve);
		}
		pendingCurve = null;
	}

	/**
	 * Add the pendingCurve to the list of Curves as solving is terminated with
	 * an error, but there some points are successfully computed
	 */
	public void solveError() {
		if (pendingCurve != null && pendingCurve.getCurrentNumPoints() > 0) {
			synchronized (this) {
				curves.addElement(pendingCurve);
			}
		}
		pendingCurve = null;
	}

	/**
	 * Returns the name of the ODE as printing information.
	 * 
	 * @return the name of the ODE
	 */
	@Override
	public String toString() {
		return getName();
	}

	/*
	 * Everything about this ODE in the form the server can read. This is for
	 * creating a debugging message.
	 */
	public String info() {
		String rt = new String("");
		String[] equations = getEquations().toArray(
				new String[getEquations().size()]);
		Vector<String> variables = getVariables();
		ListIterator<String> iter = variables.listIterator();

		rt += ServerRequest.ODE_ORDER + equations.length
				+ ServerRequest.DELIMITER;

		rt += ServerRequest.ODES;
		for (int i = 0; i < equations.length; i++)
			rt += equations[i] + ";";
		rt += ServerRequest.DELIMITER;

		rt += ServerRequest.VARIABLES;
		while (iter.hasNext())
			rt += iter.next() + ";";
		rt += ServerRequest.DELIMITER;

		return rt;
	}
}
