/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

import java.util.Vector;

import drawer.Drawer;

/**
 * Defines a representation of a plot axis, with a value range, label, and
 * boolean for whether it is scaled logarithmically. Given the space on the
 * screen allotted for the axis, this class can convert pixel coordinates into
 * plot coordinates by considering its value range.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11
 */

public class Axis {
	/** Minimum range value of the axis */
	private Double rangeMin;

	/** Maximum range value of the axis */
	private Double rangeMax;

	/** True when the axis is scaled logarithmically */
	private boolean logScaleOn;

	/** Label for this axis */
	private String axisLabel;

	/** Value to bump plot up by if scaling logarithmically around zero */
	public static final double LOGVALBUMP = .01;

	/** Minimum orders of magnitude to view in a logarithmically scaled plot */
	public static final double MIN_LOG_QUOTIENT = 1000;

	/** Minimum value for logarithmically scaled axes */
	public static final double MIN_LOG_VAL = 1e-20;

	/** Maximum value for an axis */
	public static final double MAX_VAL = 1e20;

	/** Minimum range for an axis */
	public static final double MIN_RANGE = 1e-10;

	/**
	 * Constructor that creates a new axis with the given range values and
	 * label, and set to linear scale.
	 * 
	 * @param low
	 *            minimum range value of the axis
	 * @param high
	 *            maximum range value of the axis
	 * @param label
	 *            String to label axis
	 */
	public Axis(double low, double high, String label) {
		rangeMin = low;
		rangeMax = high;
		axisLabel = label;
		setLogscale(false);
	}

	/**
	 * Returns the label of the axis.
	 * 
	 * @return String containing the axis label
	 */
	public String getLabel() {
		return axisLabel;
	}

	/**
	 * Sets the label of the axis.
	 * 
	 * @param s
	 *            String to assign to axis label
	 */
	public void setLabel(String s) {
		axisLabel = s;
	}

	/**
	 * Returns the minimum value of the axis range.
	 * 
	 * @return the minimum range value of the axis
	 */
	public Double getRangeMin() {
		return rangeMin;
	}

	/**
	 * Returns the maximum value of the axis range.
	 * 
	 * @return the maximum range value of the axis
	 */
	public Double getRangeMax() {
		return rangeMax;
	}

	/**
	 * Sets the specified range for the axis.
	 * 
	 * @param low
	 *            the new range minimum
	 * @param high
	 *            the new range maximum
	 */
	public void setRange(double low, double high) {
		double min, max;
		// force the user to stay within some reasonable bounds.
		if (logScaleOn)
			min = Math.max(low, MIN_LOG_VAL);
		else
			min = Math.max(low, -MAX_VAL);
		max = Math.min(high, MAX_VAL);

		if (max - min >= MIN_RANGE) {
			rangeMin = min;
			rangeMax = max;
		}
		adjustLogScale();
	}

	/**
	 * Returns the state of log-scaling of the axis.
	 * 
	 * @return true if the axis is logarithmically scaled, false if linear
	 */
	public boolean isLogScaleOn() {
		return logScaleOn;
	}

	/**
	 * Sets the scaling of the axis to either logarithmic or linear.
	 * 
	 * @param logscale
	 *            true if setting to logarithmic scale, false if setting to
	 *            lienar
	 */
	public void setLogscale(boolean logscale) {
		logScaleOn = logscale;
		adjustLogScale();
	}

	/**
	 * Returns a string that textually represents an axis, with the format
	 * "LOW - HIGH".
	 * 
	 * @return the string represnting the axis
	 */
	@Override
	public String toString() {
		return rangeMin.toString() + " - " + rangeMax.toString();
	}

	/**
	 * Returns the length of the axis, calculated from the difference of the
	 * range bounds.
	 * 
	 * @return the total length of the axis
	 */
	public double getLength() {
		return rangeMax - rangeMin;
	}

	/**
	 * Returns the rate of increment on the axis scale at plotCoords position
	 * (constant for non-log-scaling), relative to the whole axis, where the
	 * whole axis is thought of as unit length
	 * 
	 * @param plotCoords
	 *            position to find the rate of increment
	 * @return the rate of increment
	 */
	public double getIncrementRate(double plotCoords) {
		if (logScaleOn) {
			// in log scale, rate depends on plotCoords
			return plotCoords * Math.log(rangeMax / rangeMin);
		} else {
			// in non-log scale, rate is constant
			return rangeMax - rangeMin;
		}
	}

	/**
	 * Takes the length of the axis in pixels as it is represented on the screen
	 * and the pixel coordinate whose "real" value we want, and returns that
	 * value. This method requires that both the minimum and maximum range
	 * values be positive if log-scaling is on.
	 * 
	 * @param pixelCoord
	 *            int representing the coordinate in pixels
	 * @param pixelAxisLength
	 *            int representing the length of the axis in pixels
	 * @return double representing the coordinate determined to be at the
	 *         specified pixel
	 */
	public double pixelToPlotCoords(int pixelCoord, int pixelAxisLength) {
		if (logScaleOn)
			return rangeMin
					* Math.pow(rangeMax / rangeMin, ((double) (pixelCoord))
							/ pixelAxisLength);

		return (getLength() * (pixelCoord) / pixelAxisLength + rangeMin);
	}

	/**
	 * Takes the length of the axis in pixels as it is represented on the screen
	 * and the "real" coordinate whose pixel value we want, and returns that
	 * value. This method requires that both the minimum and maximum range
	 * values be positive if log-scaling is on.
	 * 
	 * @param plotCoord
	 *            double representing the coordinate
	 * @param pixelAxisLength
	 *            int representing the length of the axis in pixels
	 * @return int representing the coordinate in pixels
	 */
	public int plotToPixelCoords(double plotCoord, int pixelAxisLength) {
		if (logScaleOn)
			return (int) ((Math.log(plotCoord / rangeMin)
					/ Math.log(rangeMax / rangeMin) * pixelAxisLength));

		return (int) ((plotCoord - rangeMin) / getLength() * pixelAxisLength);
	}

	/**
	 * Displaces the minimum and maximum range values by the appropriate amount
	 * given a pixel displacement. This method is used for settings the axis
	 * ranges after panning.
	 * 
	 * @param pixelDisplacement
	 *            int representing the displacement of the axis in pixels
	 * @param pixelAxisLength
	 *            int representing the length of the axis in pixels
	 */
	public void displace(int pixelDisplacement, int pixelAxisLength) {
		if (logScaleOn) {
			double ratio = Math.pow(rangeMax / rangeMin,
					((double) (pixelDisplacement)) / pixelAxisLength);
			rangeMin *= ratio;
			rangeMax *= ratio;
		}

		else {
			double real_disp = (double) pixelDisplacement / pixelAxisLength
					* getLength();
			rangeMax += real_disp;
			rangeMin += real_disp;
		}
	}

	/**
	 * Returns a Vector of Tick marks calculated using a heuristic. The current
	 * heuristic function is very naive, a better one might lead to more
	 * interesting displays. If the axis is horizontal, then this uses label
	 * width in its computations. If it is false, (i.e. if we are drawing on the
	 * vertical axis) it uses label height.
	 * 
	 * @param pixelAxisLength
	 *            int representing the length of the axis in pixels
	 * @return Vector containing the Tick marks determined by the method
	 *         heuristic
	 */
	public Vector<Tick> ComputeTickMarks(int pixelAxisLength) {
		int newPos, oldPos = Integer.MIN_VALUE;
		Vector<Tick> marks = new Vector<Tick>();
		double tickValue;
		double step = Math.pow(10.0,
				Math.floor(Math.log10(rangeMax - rangeMin)));

		if (!logScaleOn) {
			// Compute starting point so it is a multiple of step.
			tickValue = calculateStartingPt(step);
			step = adjustStepSize(pixelAxisLength, step, tickValue);
			tickValue = calculateStartingPt(step);
		} else
			tickValue = step = Math.pow(10.0, Math.floor(Math.log10(rangeMin)));

		while (tickValue < rangeMax) {
			newPos = plotToPixelCoords(tickValue, pixelAxisLength);

			// If log-scaling is on, only keep grid marks that are far enough
			// apart
			if (!logScaleOn
					|| (logScaleOn && Math.abs(newPos - oldPos) >= Drawer.MIN_GRID_SPACING)) {
				marks.add(new Tick(tickValue, newPos, step, logScaleOn));
				oldPos = newPos;
			}

			if (logScaleOn)
				tickValue *= 10;
			else
				tickValue += step;
		}

		return marks;
	}

	/**
	 * Returns an appropriate length for the interval lying in between two tick
	 * marks on a linearly-scaled axis.
	 * 
	 * @param pixelAxisLength
	 *            int representing the length of the axis in pixels
	 * @param step
	 *            the step size between tick marks
	 * @param start
	 *            the starting point
	 * @return double representing the appropriate length as described above
	 */
	private double adjustStepSize(int pixelAxisLength, double step, double start) {
		// The step should always be 1, 2, or 5 times a multiple of 10. This is
		// used to adjust the step size.
		int count1_2_5 = 0;

		double pixelStep = plotToPixelCoords(rangeMin + step, pixelAxisLength);

		while (pixelStep < Drawer.MIN_GRID_SPACING) {
			switch (count1_2_5 % 3) {
			case 0:
				step *= 2.0;
				break;
			case 1:
				step *= 2.5;
				break;
			case 2:
				step *= 2.0;
				break;
			}
			start = calculateStartingPt(step);
			++count1_2_5;
			pixelStep = plotToPixelCoords(rangeMin + step, pixelAxisLength);
		}

		while (pixelStep > Drawer.MAX_GRID_SPACING) {
			switch (count1_2_5 % 3) {
			case 0:
				step /= 2.0;
				break;
			case 1:
				step /= 2.5;
				break;
			case 2:
				step /= 2.0;
				break;
			}
			start = calculateStartingPt(step);
			++count1_2_5;
			pixelStep = plotToPixelCoords(rangeMin + step, pixelAxisLength);
		}

		return step;
	}

	/**
	 * Calculates the starting point coordinate.
	 * 
	 * @param step
	 *            the starting point
	 * @return the new starting point
	 */
	private double calculateStartingPt(double step) {
		return step * Math.ceil(rangeMin / step);
	}

	/**
	 * Sets the axis to only positive values if log-scaling is on.
	 */
	private void adjustLogScale() {
		if (logScaleOn) {
			if (rangeMin <= 0) {
				rangeMin = LOGVALBUMP;
				if (rangeMax < 0)
					rangeMax = LOGVALBUMP * MIN_LOG_QUOTIENT;
			}

			// We always keep rangeMax at least MIN_LOG_QUOT times as large as
			// rangeMin
			while (rangeMax / rangeMin < MIN_LOG_QUOTIENT) {
				if (rangeMin > MIN_LOG_VAL * 10) {
					if (rangeMax < MAX_VAL / 10) {
						rangeMin /= 10;
						rangeMax *= 10;
					} else
						rangeMin /= 100;
				} else
					rangeMax *= 100;
			}
		}
	}
}
