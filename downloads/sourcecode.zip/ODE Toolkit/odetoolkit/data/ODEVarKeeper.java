/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

/**
 * The ODEVarKeeper class keeps track and assign indices to each of the ODEVar
 * obtained from parsing all ODEs in a particular workspace. It is responsible
 * for generating variables, and providing information about variables to all
 * other methods.
 * 
 * @author Clinic 10-11
 */
public class ODEVarKeeper {

	/** The Map between variable names and indices */
	private Map<String, ODEVar> varMap;

	/** The vector of all ODEVar in the workspace */
	private ODEVarVector varVec;

	/** The number of variables contained in this ODEVarKeeper */
	private int length;

	/**
	 * Constructor that creates a blank ODEVarKeeper.
	 */
	public ODEVarKeeper() {
		varMap = new HashMap<String, ODEVar>();
		varVec = new ODEVarVector();
		length = 0;
	}

	/**
	 * Returns the number of variables contained in the ODEVarKeeper.
	 * 
	 * @return the number of variables contained in the ODEVarKeeper
	 */
	public int varCount() {
		return length;
	}

	/**
	 * Returns the ODEVar associated to the given index.
	 * 
	 * @param index
	 *            the index of the desired ODEVar
	 * @return the ODEVar associated to the given index, or null if not found
	 */
	public ODEVar getODEVar(int index) {
		if (index < 0 || index >= length)
			return varVec.get(index);
		return null;
	}

	/**
	 * Returns the ODEVar of the given name, and also create a new ODEVar if the
	 * ODEVar with that name is not yet created.
	 * 
	 * @param varName
	 *            the name of the variable
	 * @return the ODEVar with the desired name
	 */
	public ODEVar getVar(String varName) {
		if (varMap.containsKey(varName))
			return varMap.get(varName);
		ODEVar newVar = new ODEVar(varName, length);
		varVec.add(newVar);
		varMap.put(varName, newVar);
		++length;
		return newVar;
	}

	/**
	 * Create an ODEVarVector corresponding to the given collection of variable
	 * names, including create new ODEVars for ones that are not yet created.
	 * 
	 * @param varNames
	 *            the collection of names of the variables
	 * @return the ODEVarVector with the desired names
	 */
	public ODEVarVector createVarVector(Collection<String> varNames) {
		ODEVarVector vec = new ODEVarVector();
		for (String varName : varNames) {
			ODEVar var = getVar(varName);
			vec.add(var);
		}
		return vec;
	}

	/**
	 * Returns a copy of the ODEVarVector of all variables.
	 * 
	 * @return a copy of the ODEVarVector of all variables
	 */
	public ODEVarVector allVarVector() {
		return (ODEVarVector) varVec.clone();
	}

	/**
	 * Returns a vector of String with the names of all variables.
	 * 
	 * @return a vector of String with the names of all variables
	 */
	public Vector<String> getNames() {
		return varVec.getNames();
	}
}
