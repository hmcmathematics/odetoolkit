/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

/**
 * Stores the x and y range on for each ODEVar (representing each axis in 2D
 * plots.
 * 
 * @author Clinic 10-11
 */

public class Bounds {

	/** Variable associated to x-axis */
	private final ODEVar x;
	/** Variable associated to y-axis */
	private final ODEVar y;

	/** Minimum value on x-axis */
	private double xMin;
	/** Maximum value on x-axis */
	private double xMax;
	/** Minimum value on y-axis */
	private double yMin;
	/** Maximum value on y-axis */
	private double yMax;

	/**
	 * Constructor that creates a new Bounds with specified range.
	 * 
	 * @param xVar
	 *            ODEVar associated to x-axis
	 * @param yVar
	 *            ODEVar associated to y-axis
	 * @param xMn
	 *            double representing minimum value on x-axis of the bound
	 * @param xMx
	 *            double representing maximum value on x-axis of the bound
	 * @param yMn
	 *            double representing minimum value on y-axis of the bound
	 * @param yMx
	 *            double representing maximum value on y-axis of the bound
	 */
	public Bounds(ODEVar xVar, ODEVar yVar, double xMn, double xMx, double yMn,
			double yMx) {
		x = xVar;
		y = yVar;
		xMin = xMn;
		xMax = xMx;
		yMin = yMn;
		yMax = yMx;
	}

	/**
	 * Constructor that creates a new Bounds with empty range, which is
	 * represented by Double.NEGATIVE_INFINITY for maximum value, and
	 * Double.POSITIVE_INFINITY for minimum value.
	 * 
	 * @param xVar
	 *            ODEVar associated to x-axis
	 * @param yVar
	 *            ODEVar associated to y-axis
	 */
	public Bounds(ODEVar xVar, ODEVar yVar) {
		this(xVar, yVar, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY,
				Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY);
	}

	/**
	 * Returns the variable associated with x-axis.
	 * 
	 * @return the variable associated with x-axis
	 */
	public ODEVar getXVar() {
		return x;
	}

	/**
	 * Returns the variable associated with y-axis.
	 * 
	 * @return the variable associated with y-axis
	 */
	public ODEVar getYVar() {
		return y;
	}

	/**
	 * Returns the minimum value on x-axis.
	 * 
	 * @return the minimum value on x-axis
	 */
	public double getXMin() {
		return xMin;
	}

	/**
	 * Returns the maximum value on x-axis.
	 * 
	 * @return the maximum value on x-axis
	 */
	public double getXMax() {
		return xMax;
	}

	/**
	 * Returns the minimum value on y-axis.
	 * 
	 * @return the minimum value on y-axis
	 */
	public double getYMin() {
		return yMin;
	}

	/**
	 * Returns the maximum value on y-axis.
	 * 
	 * @return the maximum value on y-axis
	 */
	public double getYMax() {
		return yMax;
	}

	/**
	 * Set the minimum value on x-axis.
	 * 
	 * @param xMn
	 *            double representing new minimum value on x-axis of the bound
	 */
	public void setXMin(double xMn) {
		xMin = xMn;
	}

	/**
	 * Set the maximum value on x-axis.
	 * 
	 * @param xMx
	 *            double representing new maximum value on x-axis of the bound
	 */
	public void setXMax(double xMx) {
		xMax = xMx;
	}

	/**
	 * Set the minimum value on y-axis.
	 * 
	 * @param yMn
	 *            double representing new minimum value on y-axis of the bound
	 */
	public void setYMin(double yMn) {
		yMin = yMn;
	}

	/**
	 * Set the maximum value on y-axis.
	 * 
	 * @param yMx
	 *            double representing new maximum value on y-axis of the bound
	 */
	public void setYMax(double yMx) {
		yMax = yMx;
	}

	/**
	 * Create a new Bounds with x and y axis reversed.
	 * 
	 * @return new Bounds with x and y axis reversed
	 */
	public Bounds reverseBound() {
		return new Bounds(y, x, yMin, yMax, xMin, xMax);
	}
}
