/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data.plotstates;

import java.awt.Graphics;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.util.Vector;

import org.math.plot.Plot3DPanel;
import org.math.plot.plotObjects.Base;

import ui.GUI;
import ui.outputpanels.Graph3DPanel;
import data.Axis;
import data.Curve;
import data.Equilibrium;
import data.ODE;
import data.ODEVar;
import data.ODEVarVector;
import drawer.Drawer;

/**
 * Represents the data for a 3D plot. This is used by the Graph3DPanel class. It
 * contains all the data used in a Graph3DPanel not relating to the UI. It
 * stores the vector of ODEs, the vector of ODEVars, the parameters for grid
 * lines, auto-scaling, log-scaling, curve color, and the three current ODEVars
 * assigned to the axes. It contains functions for manipulating the settings of
 * all these parameters, and is responsible for calling the appropriate Drawer
 * functions, adjusting the axes for log-scaling, and printing/exporting.
 * 
 * @author Andres Perez 09, modified by Clinic 10-11
 */
public class Plot3DState implements Printable {
	/** Graph3DPanel associated with this plot state */
	Graph3DPanel graphOwner;

	/** Vector of ODEs containing all curves and points */
	protected Vector<ODE> odesVector;

	/** Vector containing the variables */
	protected ODEVarVector variables;

	/** ODE variables to map to the x-axis */
	protected ODEVar xVar;

	/** ODE variables to map to the y-axis */
	protected ODEVar yVar;

	/** ODE variables to map to the z-axis */
	protected ODEVar zVar;

	/** whether to draw a background grid */
	protected boolean gridLinesOn = true;

	/** controls whether automatic scaling is turned on */
	protected boolean autoScaleOn = true;

	/** state of log-scaling of the x-axis */
	protected boolean logScaleX = false;

	/** state of log-scaling of the y-axis */
	protected boolean logScaleY = false;

	/** state of log-scaling of the z-axis */
	protected boolean logScaleZ = false;

	/**
	 * Constructor that sets the Graph3DPanel owner and stores the vector of
	 * ODEs and the vector of ODEVars. It currently assigns the first three
	 * variables in the ODEVarVector to be the variables assigned to the axes.
	 * 
	 * @param owner
	 *            Graph3DPanel associated with this plot state
	 * @param odes
	 *            Vector of ODEs containing all curves and points
	 * @param odeVars
	 *            Vector containing all ODE variables
	 */
	public Plot3DState(Graph3DPanel owner, Vector<ODE> odes,
			ODEVarVector odeVars, ODEVar x, ODEVar y, ODEVar z) {
		graphOwner = owner;
		odesVector = odes;
		variables = odeVars;

		// set the first three variables to the axes
		xVar = x;
		yVar = y;
		zVar = z;

		// set the correct axis labels
		getPlotOwner().plotCanvas.setAxisLabel(0, xVar.getName());
		getPlotOwner().plotCanvas.setAxisLabel(1, yVar.getName());
		getPlotOwner().plotCanvas.setAxisLabel(2, zVar.getName());
	}

	/**
	 * Returns the Graph3DPanel that contains the Plot3DPanel this state
	 * represents.
	 * 
	 * @return the Graph3DPanel owner
	 */
	public Graph3DPanel getGraph3DPanel() {
		return graphOwner;
	}

	/**
	 * Returns the Plot3DPanel this state represents.
	 * 
	 * @return the Plot3DPanel represented by this state.
	 */
	public Plot3DPanel getPlotOwner() {
		return graphOwner.getPlot3DPanel();
	}

	/**
	 * Returns the ODEVar assigned to the specified axis.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @return the ODEVar represented by the specified axis
	 */
	public ODEVar getVar(int axis) {
		if (axis == 0)
			return xVar;
		else if (axis == 1)
			return yVar;
		else
			return zVar;
	}

	/**
	 * Assigns the given ODEVar to the specified axis.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @param varIndex
	 *            int representing the index of the desired variable (in the
	 *            ODEVarVector) to assign to the specified axis
	 */
	public void setVar(int axis, int varIndex) {
		if (axis == 0)
			xVar = variables.get(varIndex);
		else if (axis == 1)
			yVar = variables.get(varIndex);
		else
			zVar = variables.get(varIndex);
		draw3DSolutions();
	}

	/**
	 * Returns the state of auto-scaling, true if auto-scaling is on, false if
	 * scaling is set to manual.
	 * 
	 * @return boolean of auto-scaling, true if auto-scaling is turned on
	 */
	public boolean getAutoScale() {
		return autoScaleOn;
	}

	/**
	 * Sets the state of auto-scaling. If set to on, the plot is re-fit to the
	 * graph using the JMathTools auto-fitting methods. If set to off, the
	 * method has no side-effect.
	 * 
	 * @param autoScaleState
	 *            boolean of auto-scaling, set to true if auto- scaling is
	 *            toggled on
	 */
	public void setAutoScale(boolean autoScaleState) {
		autoScaleOn = autoScaleState;
		if (autoScaleOn)
			try {
				getPlotOwner().plotCanvas.setAutoBounds(); // AutoFit
			} catch (IllegalArgumentException e) {
				System.out
						.println("IllegalArgumentException, possibly caused by "
								+ "log-scaling with negative values.");
			}
	}

	/**
	 * Automatically resizes the plot window to span the auto-sized range for
	 * the specified axis.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 */
	public void autoFitAxis(int axis) {
		getPlotOwner().plotCanvas.setAutoBounds(axis);
	}

	/**
	 * Returns whether the grid lines are turned on in the plot.
	 * 
	 * @return boolean for grid lines, true if visible
	 */
	public boolean isGridOn() {
		return getPlotOwner().plotCanvas.getGrid().getVisible();
	}

	/**
	 * Sets the state of visibility of the grid lines on the plot.
	 * 
	 * @param gridOn
	 *            boolean of grid lines, true for visible
	 */
	public void setGrid(boolean gridOn) {
		getPlotOwner().plotCanvas.getGrid().setVisible(gridOn);
		repaint();
	}

	/**
	 * Retrieves the plot label of the specified axis.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @return String containing the label of the specified axis
	 */
	public String getAxisLabel(int axis) {
		return getPlotOwner().plotCanvas.getGrid().getAxis(axis).getLegend();
	}

	/**
	 * Sets the label of the specified axis on the plot.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @param label
	 *            String to set the axis label on the plot
	 */
	public void setAxisLabel(int axis, String label) {
		getPlotOwner().plotCanvas.setAxisLabel(axis, label);
	}

	/**
	 * Returns the range of the specified axis in a double array of size 2
	 * containing the minimum and maximum values.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @return double[] containing the min and max range values of the axis
	 */
	public double[] getAxisRange(int axis) {
		double min = getPlotOwner().plotCanvas.base.roundXmin[axis];
		double max = getPlotOwner().plotCanvas.base.roundXmax[axis];

		return new double[] { min, max };
	}

	/**
	 * Sets the specified axis to span the given range.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @param min
	 *            minimum range value
	 * @param max
	 *            maximum range value
	 */
	public void setAxisRange(int axis, double min, double max) {
		getPlotOwner().plotCanvas.setFixedBounds(axis, min, max);
	}

	/**
	 * Returns the log-scaling state of the specified axis, where true signifies
	 * logarithmic scaling.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @return boolean of log-scaling, true for logarithmic, false for linear
	 */
	public boolean isAxisLogScale(int axis) {
		if (axis == 0)
			return logScaleX;
		else if (axis == 1)
			return logScaleY;
		else
			return logScaleZ;
	}

	/**
	 * Sets the specified axis to the desired scaling. If logScaleOn is true,
	 * this function calls adjustLogScale to ensure the ranges are strictly
	 * positive, then sets the new bounds to allow for logarithmic scaling. If
	 * logScaleOn is false, the axis is set to linear scale, and re-scaled if
	 * auto-scaling is activated.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @param logScaleOn
	 *            true if the axis is log-scaled
	 */
	public void setAxisLogScale(int axis, boolean logScaleOn) {
		// update logscale state
		if (axis == 0)
			logScaleX = logScaleOn;
		else if (axis == 1)
			logScaleY = logScaleOn;
		else
			logScaleZ = logScaleOn;

		// if any axes are log-scaled with negative values, an exception will be
		// thrown
		try {
			if (logScaleOn) // setting to log
			{
				// find and set acceptable bounds
				double[] newRange = adjustLogScale(axis);
				getPlotOwner().plotCanvas.setFixedBounds(axis, newRange[0],
						newRange[1]);

				// change axis to logarithmic scaling
				try {
					getPlotOwner().plotCanvas.setAxiScale(axis, Base.LOGARITHM);
				} catch (IllegalArgumentException e) {
					// setting the bounds again after catching an exception
					// forces the change (the program can sometimes handle this)
					getPlotOwner().plotCanvas.setFixedBounds(axis, newRange[0],
							newRange[1]);
					// throw the exception to be caught by outer catch clause
					// containing the GUI status bar warning message.
					throw e;
				}
			} else if (autoScaleOn) // setting to linear, with auto-scaling
				getPlotOwner().plotCanvas.setAxiScale(axis, Base.LINEAR);
			else // setting to linear, without auto-scaling
			{
				// take current (logarithmic) ranges
				double min = getPlotOwner().plotCanvas.base.roundXmin[axis];
				double max = getPlotOwner().plotCanvas.base.roundXmax[axis];

				// linearize the ranges and set the new bounds
				getPlotOwner().plotCanvas.setAxiScale(axis, Base.LINEAR);
				getPlotOwner().plotCanvas.setFixedBounds(axis,
						Math.pow(min, 10), Math.pow(max, 10));
			}

			// re-fit grid lines
			getPlotOwner().plotCanvas.resetBase();

		} catch (IllegalArgumentException e) {
			System.out.println("IllegalArgumentException, possibly caused by "
					+ "log-scaling with negative values.");
		}

		if (logScaleX || logScaleY || logScaleZ)
			// Display negative value warning if any axes are log-scaled
			GUI.statusBar.setMessage("RANGE WARNING: Negative values may "
					+ "not display properly in logarithmic scaling");
		else
			// Clear status display if all axes are linear.
			GUI.statusBar.setMessage("");

		getPlotOwner().plotCanvas.repaint();
	}

	/**
	 * This function is called by the setAxisLogScale method when setting an
	 * axis to logarithmic scaling to ensure that the ranges are positive. This
	 * prevents errors from taking the logarithm of zero of negative values. If
	 * an axis spans negative values, this function sets the minimum values to a
	 * bit above zero, and the maximum value to at least three orders of
	 * magnitude above the minimum. The function then returns the adjusted
	 * range.
	 * 
	 * @param axis
	 *            int representing the axis (0 = x, 1 = y, and 2 = z)
	 * @return double array of length 2 containing the adjusted minimum and
	 *         maximum range values
	 */
	private double[] adjustLogScale(int axis) {
		double low = getPlotOwner().plotCanvas.base.roundXmin[axis];
		double high = getPlotOwner().plotCanvas.base.roundXmax[axis];

		// if negative, bump lower bound to above zero
		if (low <= 0) {
			low = Axis.LOGVALBUMP;
			if (high < 0)
				high = Axis.LOGVALBUMP * Axis.MIN_LOG_QUOTIENT;
		}

		// We always keep high at least MIN_LOG_QUOT times as large as low
		while (high / low < Axis.MIN_LOG_QUOTIENT) {
			if (low > Axis.MIN_LOG_VAL * 10) {
				if (high < Axis.MAX_VAL / 10) {
					low /= 10;
					high *= 10;
				} else
					low /= 100;
			} else
				high *= 100;
		}

		return new double[] { low, high };
	}

	/**
	 * Calls the JMathTools method that refreshes the plot image.
	 */
	public void repaint() {
		getPlotOwner().plotCanvas.resetBase();
		draw3DSolutions();
	}

	/**
	 * Function for printing 3D plot - NOT IMPLEMENTED
	 */
	public int print(Graphics g, PageFormat pageFormat, int page) {
		return NO_SUCH_PAGE;
	}

	/**
	 * Function for exporting 3D plot - NOT IMPLEMENTED
	 */
	public void export() {

	}

	/**
	 * First empties out the plot, then calls the 3D curve-drawing method in
	 * Drawer for each curve in each ODE of the ODEVector.
	 */
	public synchronized void draw3DSolutions() {
		// Clear all drawn curves
		getPlotOwner().removeAllPlots();

		// Draw each curve in each ODE of the ODE Vector
		for (int i = 0; i < odesVector.size(); i++) {
			for (int j = 0; j < odesVector.elementAt(i).getNumCurves(); j++) {
				Curve c = odesVector.elementAt(i).getCurves().elementAt(j);
				if (c.getVisualProperties().isShown())
					Drawer.draw3DCurve(this, c, xVar, yVar, zVar);
			}
			for (int j = 0; j < odesVector.elementAt(i).getNumEquilibria(); 
					j++) {
				Equilibrium e = odesVector.elementAt(i).getEquilibria()
						.elementAt(j);
				if (e.getVisualProperties().isShown())
					Drawer.draw3DEquilibrium(this, e, xVar, yVar, zVar);
			}
		}
	}
}
