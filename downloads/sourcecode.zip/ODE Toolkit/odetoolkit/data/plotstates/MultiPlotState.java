/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data.plotstates;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ListIterator;
import java.util.Vector;

import data.Bounds;
import data.Curve;
import data.Equilibrium;
import data.ODE;
import data.ODEVar;
import data.ODEVarKeeper;
import data.ODEVarVector;
import drawer.Drawer;

/**
 * Represents plots that graph multiple dependent variables against time.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
public class MultiPlotState extends PlotState {
	/** The vector containing all dependent variables */
	private ODEVarVector allYVars;
	/** The vector containing all dependent variables for the current ODE */
	private ODEVarVector currYVars;

	/** List of colors for each variable */
	private static final Color[] colors = { Color.blue, Color.red, Color.green,
		Color.black, Color.gray, Color.cyan, Color.orange, Color.magenta,
		Color.pink, Color.yellow };

	/**
	 * Constructor that generates a MultiPlotState from given parameters.
	 * @param odes the list of ODEs in this workspace
	 * @param current the current ODE for this workspace
	 * @param title the title of the plot
	 * @param xVar the variable corresponding to the x-axis
	 * @param yVars the variables to be shown on y-axis
	 * @param varKeeper the ODEVarKeeper for this workspace
	 */
	public MultiPlotState(Vector<ODE> odes, ODE current, String title,
			ODEVar xVar, ODEVarVector yVars, ODEVarKeeper varKeeper) {
		super(odes, current, title, xVar, "");
		currYVars = (ODEVarVector) yVars.clone(); // it will be modified later
		allYVars = varKeeper.allVarVector();
		allYVars.remove(xVar);
		currYVars.remove(xVar);
		setYLabel("");
	}

	/**
	 * Constructor that generates a MultiPlotState from given parameters.
	 * @param odes the list of ODEs in this workspace
	 * @param current the current ODE for this workspace
	 * @param title the title of the plot
	 * @param xVar the variable corresponding to the x-axis
	 * @param yVars the variables to be shown on y-axis
	 * @param varKeeper the ODEVarKeeper for this workspace
	 * @param xMin the lower bound for the x-axis
	 * @param xMax the upper bound for the x-axis
	 * @param yMin the lower bound for the y-axis
	 * @param yMax the upper bound for the y-axis
	 */
	public MultiPlotState(Vector<ODE> odes, ODE current, String title,
			ODEVar xVar, ODEVarVector yVars, ODEVarKeeper varKeeper,
			double xMin, double xMax, double yMin, double yMax) {
		super(odes, current, title, xVar, "", xMin, xMax, yMin, yMax);
		currYVars = (ODEVarVector) yVars.clone(); // it will be modified later
		allYVars = varKeeper.allVarVector();
		allYVars.remove(xVar);
		currYVars.remove(xVar);
		setYLabel("");
	}

	/**
	 * Returns the vector of all variables plotted in y-axis.
	 * @return the vector of all variables plotted in y-axis
	 */
	public ODEVarVector getYVars() {
		return currYVars;
	}

	/**
	 * Generate a color for the given variable.
	 * @param y the variable to find the color
	 * @return the color for the given variable
	 */
	protected Color getCurveColor(ODEVar y) {
		return colors[((allYVars.indexOf(y)) % allYVars.size()) 
		              % colors.length];
	}

	@Override
	public data.Bounds getAutoBounds(Curve c) {
		if(!c.getVisualProperties().isShown()) return null;
		Bounds maxBounds = c.computeAutoBounds(getXVar(), currYVars
				.get(0));
		Bounds temp;
		ODEVarVector cVars = c.getVariables();
		int len = cVars.size();
	
		for (int i = 1; i < len; i++) {
			// because the number of variables we could be working with can
			// change, we need to go by the curve's number of variables
			temp = c.computeAutoBounds(getXVar(), cVars.get(i));
			if (temp.getXMax() > maxBounds.getXMax())
				maxBounds.setXMax(temp.getXMax());
			if (temp.getYMax() > maxBounds.getYMax())
				maxBounds.setYMax(temp.getYMax());
			if (temp.getXMin() < maxBounds.getXMin())
				maxBounds.setXMin(temp.getXMin());
			if (temp.getYMin() < maxBounds.getYMin())
				maxBounds.setYMin(temp.getYMin());
		}
		return maxBounds;
	}

	@Override
	public boolean isDirFieldPossible() {
		return false;
	}

	@Override
	public Bounds getAutoBounds(Equilibrium eq) {
		return null;
	}

	@Override
	protected synchronized void drawMySolutions(Graphics offscreenPlot,
			Rectangle viewingWindow) {
		ODEVar y;
		ListIterator<ODE> odeInd = odes.listIterator();
		ODE currentOde;
		ODEVarVector vars;
		ListIterator<Curve> curveInd;
		Curve c;
	
		while (odeInd.hasNext()) {
			currentOde = odeInd.next();
			curveInd = currentOde.getCurves().listIterator();
			while (curveInd.hasNext()) {
				c = curveInd.next();
				vars = c.getVariables();
				for (int i = 1; i < vars.size(); i++) {
					y = vars.get(i);
					
					Color startColor = c.getVisualProperties().getColor();
					c.getVisualProperties().setColor(getCurveColor(y));
					if (c.getVisualProperties().isShown())
						Drawer.drawCurve(c, xVar, y,
							offscreenPlot, this, viewingWindow);
					
					//reset curve back to its original color
					c.getVisualProperties().setColor(startColor);				
				}
			}
		}
	}

	@Override
	protected synchronized void drawMyDirField(Graphics graphics, Rectangle viewingWindow) {
		// Do nothing - not applicable
	}

}
