/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data.plotstates;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ListIterator;
import java.util.Vector;

import data.Bounds;
import data.Curve;
import data.Equilibrium;
import data.ODE;
import data.ODEVar;
import drawer.Drawer;

/**
 * Represents a plot one variable on each axis. This is the most common type of
 * PlotState used, as all ComponentGraphPanels and PhaseGraphPanels use this
 * type of state to represent their plot.
 * 
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
public class SinglePlotState extends PlotState {
	/** Types of the direction field lines */
	public enum DirLineType {
		ARROW, LINE, LINE_DOT
	}

	/** Keep information whether the direction field is turned on */
	private boolean dirFieldOn = false;

	/** Settings for the direction field (initially set to default) */
	protected DirFieldSettings dfSettings = new DirFieldSettings(20, 20,
			Color.blue, 1.0, DirLineType.ARROW);

	/** Variable associated with y-axis */
	private ODEVar yVar;

	/**
	 * Constructor - create a SinglePlotState with given parameters.
	 * 
	 * @param o
	 *            Reference to the main vector of ODEs shared by the program.
	 * @param current
	 *            A reference to the active ODE in the program
	 * @param t
	 *            The title for the plot
	 * @param x
	 *            The variable associated with x-axis
	 * @param y
	 *            The variable associated with y-axis
	 */
	public SinglePlotState(Vector<ODE> o, ODE current, String t, ODEVar x,
			ODEVar y) {
		super(o, current, t, x, y.getName());
		yVar = y;
	}
	
	/**
	 * Constructor - create a SinglePlotState with given parameters.
	 * 
	 * @param o
	 *            Reference to the main vector of ODEs shared by the program.
	 * @param current
	 *            A reference to the active ODE in the program
	 * @param t
	 *            The title for the plot
	 * @param x
	 *            The variable associated with x-axis
	 * @param y
	 *            The variable associated with y-axis
	 * @param xMin
	 *            The lower bound for the x-axis
	 * @param xMax
	 *            The upper bound for the x-axis
	 * @param yMin
	 *            The lower bound for the y-axis
	 * @param yMax
	 *            The upper bound for the y-axis
	 */
	public SinglePlotState(Vector<ODE> o, ODE current, String t, ODEVar x,
			ODEVar y, double xMin, double xMax, double yMin, double yMax) {
		super(o, current, t, x, y.getName(), xMin, xMax, yMin, yMax);
		yVar = y;
	}

	/**
	 * Constructor - create a SinglePlotState with given parameters with
	 * auto-generated title.
	 * 
	 * @param o
	 *            Reference to the main vector of ODEs shared by the program.
	 * @param current
	 *            A reference to the active ODE in the program
	 * @param x
	 *            The variable associated with x-axis
	 * @param y
	 *            The variable associated with y-axis
	 */
	public SinglePlotState(Vector<ODE> o, ODE current, ODEVar x, ODEVar y) {
		this(o, current, y.getName() + "-" + x.getName(), x, y);
	}

	/**
	 * Constructor - create a SinglePlotState with given parameters with
	 * auto-generated title.
	 * 
	 * @param o
	 *            Reference to the main vector of ODEs shared by the program.
	 * @param current
	 *            A reference to the active ODE in the program
	 * @param x
	 *            The variable associated with x-axis
	 * @param y
	 *            The variable associated with y-axis
	 * @param xMin
	 *            The lower bound for the x-axis
	 * @param xMax
	 *            The upper bound for the x-axis
	 * @param yMin
	 *            The lower bound for the y-axis
	 * @param yMax
	 *            The upper bound for the y-axis
	 */
	public SinglePlotState(Vector<ODE> o, ODE current, ODEVar x, ODEVar y,
			double xMin, double xMax, double yMin, double yMax) {
		this(o, current, y.getName() + "-" + x.getName(), x, y, xMin, xMax,
				yMin, yMax);
	}

	/**
	 * Returns the ODEVar corresponding to the y-axis.
	 * 
	 * @return the ODEVar corresponding to the y-axis
	 */
	public ODEVar getYVar() {
		return yVar;
	}

	/**
	 * Returns whether the direction field is on.
	 * 
	 * @return true iff the direction field is on
	 */
	public boolean getDirectionFieldOn() {
		return dirFieldOn;
	}

	/**
	 * Set whether the direction field is on
	 * 
	 * @param fieldOn
	 *            true if set the direction field on, false otherwise
	 */
	public void setDirectionFieldOn(boolean fieldOn) {
		dirFieldOn = fieldOn;
	}

	@Override
	public Bounds getAutoBounds(Curve c) {
		if (c.hasVar(yVar) && c.getVisualProperties().isShown())
			return c.computeAutoBounds(xVar, yVar);
		return null;
	}

	@Override
	public Bounds getAutoBounds(Equilibrium eq) {
		if (eq.hasVar(yVar) && eq.getVisualProperties().isShown())
			return eq.computeImportantPoints(xVar, yVar);
		return null;
	}

	@Override
	public boolean isDirFieldPossible() {
		return currentODE.isDirFieldPossible(xVar, yVar);
	}

	/**
	 * Returns the settings of the direction field.
	 * 
	 * @return the settings of the direction field
	 */
	public DirFieldSettings getDirFieldSettings() {
		return dfSettings;
	}

	/**
	 * Creates another copy of the DirFieldSettings.
	 * 
	 * @return A copy of the DirFieldSettings
	 */
	public DirFieldSettings getDirFieldCopySettings() {
		return new DirFieldSettings(dfSettings.dirXCount, dfSettings.dirYCount,
				dfSettings.dirFieldColor, dfSettings.dirScale,
				dfSettings.dirLineType);
	}

	/**
	 * Set the DirFieldSettings object's members equal to those of the given
	 * DirFieldSettings object.
	 * 
	 * @param newSettings
	 *            The settings object to copy from
	 */
	public void setDirFieldSettings(DirFieldSettings newSettings) {
		dfSettings.dirXCount = newSettings.dirXCount;
		dfSettings.dirYCount = newSettings.dirYCount;
		dfSettings.dirFieldColor = newSettings.dirFieldColor;
		dfSettings.dirScale = newSettings.dirScale;
		dfSettings.dirLineType = newSettings.dirLineType;
	}

	@Override
	protected void drawMySolutions(Graphics offScreenPlot,
			Rectangle viewingWindow) {
		// Need to draw all curves
		// Looping over all curves
		ListIterator<ODE> odeInd = odes.listIterator();
		Curve c;
		Equilibrium e;
		while (odeInd.hasNext()) {
			ODE currentOde = odeInd.next();
			ListIterator<Curve> curveInd = currentOde.getCurves()
					.listIterator();
			while (curveInd.hasNext()) {
				c = curveInd.next();
				if (c.hasVar(yVar) && c.getVisualProperties().isShown())
					Drawer.drawCurve(c, xVar, yVar, offScreenPlot, this,
							viewingWindow);
			}
			ListIterator<Equilibrium> eqInd = currentOde.getEquilibria()
					.listIterator();
			while (eqInd.hasNext()) {
				e = eqInd.next();
				if (e.hasVar(xVar) && e.hasVar(yVar))
					Drawer.drawEquilibrium(e, xVar, yVar, offScreenPlot, this,
							viewingWindow);
			}
		}
	}

	@Override
	protected synchronized void drawMyDirField(Graphics graphics,
			Rectangle viewingWindow) {
		if (dirFieldOn)
			Drawer.drawDirField(graphics, this, viewingWindow);
	}

	/**
	 * Helper class to hold direction field settings.
	 */
	public static class DirFieldSettings {
		/** The number of arrows in x-direction */
		private int dirXCount;
		/** The number of arrows in y-direction */
		private int dirYCount;

		/** The color of the direction field */
		private Color dirFieldColor;
		/** The length of each arrow */
		private double dirScale;

		/** Type of the direction field lines */
		private DirLineType dirLineType;

		/**
		 * Constructor for direction field settings: create a direction field
		 * with given specifications.
		 * 
		 * @param xCount
		 *            the number of arrows in x-direction
		 * @param yCount
		 *            the number of arrows in y-direction
		 * @param fieldColor
		 *            the color of the direction field
		 * @param scale
		 *            the length of the arrows in the direction field
		 * @param lineType
		 *            the line type of the arrows in the direction field
		 */
		public DirFieldSettings(int xCount, int yCount, Color fieldColor,
				double scale, DirLineType lineType) {
			dirXCount = xCount;
			dirYCount = yCount;
			dirFieldColor = fieldColor;
			dirScale = scale;
			dirLineType = lineType;
		}

		/**
		 * Returns the number of arrows in x-direction.
		 * 
		 * @return the number of arrows in x-direction
		 */
		public int getDirXCount() {
			return dirXCount;
		}

		/**
		 * Set the number of arrows in x-direction
		 * 
		 * @param xCount
		 *            the number of arrows in x-direction
		 */
		public void setDirXCount(int xCount) {
			dirXCount = xCount;
		}

		/**
		 * Returns the number of arrows in y-direction.
		 * 
		 * @return the number of arrows in y-direction
		 */
		public int getDirYCount() {
			return dirYCount;
		}

		/**
		 * Set the number of arrows in y-direction
		 * 
		 * @param yCount
		 *            the number of arrows in y-direction
		 */
		public void setDirYCount(int yCount) {
			dirYCount = yCount;
		}

		/**
		 * Returns the color of the direction field.
		 * 
		 * @return the color of the direction field
		 */
		public Color getDirFieldColor() {
			return dirFieldColor;
		}

		/**
		 * Set the color of the direction field
		 * 
		 * @param fieldColor
		 *            the color of the direction field
		 */
		public void setDirFieldColor(Color fieldColor) {
			dirFieldColor = fieldColor;
		}

		/**
		 * Returns the length of the arrows in the direction field.
		 * 
		 * @return the length of the arrows in the direction field
		 */
		public double getDirScale() {
			return dirScale;
		}

		/**
		 * Set the length of the arrows in the direction field.
		 * 
		 * @param scale
		 *            the length of the arrows in the direction field
		 */
		public void setDirScale(double scale) {
			dirScale = scale;
		}

		/**
		 * Returns the line type of the arrows in the direction field.
		 * 
		 * @return the line type of the arrows in the direction field
		 */
		public DirLineType getDirLineType() {
			return dirLineType;
		}

		/**
		 * Set the line type of the arrows in the direction field
		 * 
		 * @param lineType
		 *            the line type of the arrows in the direction field
		 */
		public void setDirLineType(DirLineType lineType) {
			dirLineType = lineType;
		}
	}
}
