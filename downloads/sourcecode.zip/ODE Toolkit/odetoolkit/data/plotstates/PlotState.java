/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data.plotstates;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.io.OutputStream;
import java.util.Vector;

import ui.outputpanels.PlotPanel;
import data.Axis;
import data.Bounds;
import data.Curve;
import data.Equilibrium;
import data.ODE;
import data.ODEVar;
import drawer.Drawer;
import drawer.EPSGraphics;

/**
 * Defines an abstract representation of a generic plot.
 *
 * @author Clinic 08-09, modified by Clinic 10-11, Max Comstock 2013
 */
public abstract class PlotState implements Printable {
	/** The vector of odes containing all curves and points */
	protected Vector<ODE> odes;

	/** The currently active ODE, for drawing direction fields */
	protected ODE currentODE;

	/** The title string. */
	protected String title;

	/** Keep information whether to draw a background grid. */
	protected boolean grid = true;

	/** Keep information whether automatic scaling is turned on. */
	protected boolean autoscaleOn;

	/** Flag whether an autoscale is necessary. */
	protected boolean autoscaleNeeded = true;

	/** x-axis object */
	protected Axis xAxis;
	/** y-axis object */
	protected Axis yAxis;

	/** Variable associated with x-axis */
	protected ODEVar xVar;

	/** Information on x-axis for the buffer to make panning fast **/
	private int extraX = 0;
	/** Information on y-axis for the buffer to make panning fast **/
	private int extraY = 0;

	/** Default minimum x-value */
	static final double DEFAULT_MINX = -1.1;
	/** Default maximum x-value */
	static final double DEFAULT_MAXX = 1.1;
	/** Default minimum y-value */
	static final double DEFAULT_MINY = -1.1;
	/** Default maximum y-value */
	static final double DEFAULT_MAXY = 1.1;

	/**
	 * Constructor - create a PlotState with the given parameters.
	 * 
	 * @param o
	 *            Reference to the main vector of ODEs shared by the program.
	 * @param current
	 *            A reference to the active ODE in the program
	 * @param t
	 *            The title for the plot
	 * @param x
	 *            The variable associated with x-axis
	 * @param yLabel
	 *            The label for the y-axis
	 */
	public PlotState(Vector<ODE> o, ODE current, String t, ODEVar x,
			String yLabel) {
		odes = o;
		setCurrentODE(current);
		title = t;
		xVar = x;
		xAxis = new Axis(DEFAULT_MINX, DEFAULT_MAXX, x.getName());
		yAxis = new Axis(DEFAULT_MINY, DEFAULT_MAXY, yLabel);
		autoscaleOn = true;
	}
	
	/**
	 * Constructor - create a PlotState with the given parameters and bounds.
	 * 
	 * @param o
	 *            Reference to the main vector of ODEs shared by the program.
	 * @param current
	 *            A reference to the active ODE in the program
	 * @param t
	 *            The title for the plot
	 * @param x
	 *            The variable associated with x-axis
	 * @param yLabel
	 *            The label for the y-axis
	 * @param xMin
	 *            The lower bound for the x-axis
	 * @param xMax
	 *            The upper bound for the x-axis
	 * @param yMin
	 *            The lower bound for the y-axis
	 * @param yMax
	 *            The upper bound for the y-axis
	 */
	public PlotState(Vector<ODE> o, ODE current, String t, ODEVar x,
			String yLabel, double xMin, double xMax, double yMin,
			double yMax) {
		odes = o;
		setCurrentODE(current);
		title = t;
		xVar = x;
		xAxis = new Axis(xMin, xMax, x.getName());
		yAxis = new Axis(yMin, yMax, yLabel);
	}

	/**
	 * Returns the title of the plot.
	 * 
	 * @return the title of the plot
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Set the title of the plot.
	 * 
	 * @param t
	 *            the new title for the plot
	 */
	public void setTitle(String t) {
		title = t;
	}

	/**
	 * Returns whether the grid is turned on.
	 * 
	 * @return whether the grid is turned on
	 */
	public boolean getGrid() {
		return grid;
	}

	/**
	 * Set the grid on or off
	 * 
	 * @param gridOn
	 *            true for turning grid on, false otherwise
	 */
	public void setGrid(boolean gridOn) {
		grid = gridOn;
	}

	/**
	 * Returns whether auto-scaling is on.
	 * 
	 * @return whether auto-scaling is on
	 */
	public boolean getAutoscale() {
		return autoscaleOn;
	}

	/**
	 * Set the auto-scaling on or off
	 * 
	 * @param autoscale
	 *            true for turning auto-scaling on, false otherwise
	 */
	public void setAutoscale(boolean autoscale) {
		autoscaleOn = autoscale;
	}

	/**
	 * Indicate that the plot may need to be auto-scaled
	 */
	public void setAutoscaleNeeded() {
		autoscaleNeeded = true;
	}

	/**
	 * Returns the ODEVar corresponding to the x-axis.
	 * 
	 * @return the ODEVar corresponding to the x-axis
	 */
	public ODEVar getXVar() {
		return xVar;
	}

	/**
	 * Returns the x-axis.
	 * 
	 * @return the x-axis
	 */
	public Axis getXAxis() {
		return xAxis;
	}

	/**
	 * Returns the y-axis.
	 * 
	 * @return the y-axis
	 */
	public Axis getYAxis() {
		return yAxis;
	}

	/**
	 * Returns the minimum and maximum values on x-axis.
	 * 
	 * @return the minimum and maximum values on x-axis
	 */
	public double[] getXRange() {
		return new double[] { getXAxis().getRangeMin(),
				getXAxis().getRangeMax() };
	}

	/**
	 * Set the range of the x-axis
	 * 
	 * @param x1
	 *            the minimum value on x-axis
	 * @param x2
	 *            the maximum value on x-axis
	 */
	public void setXRange(double x1, double x2) {
		xAxis.setRange(x1, x2);
	}

	/**
	 * Returns the minimum and maximum values on y-axis.
	 * 
	 * @return the minimum and maximum values on y-axis
	 */
	public double[] getYRange() {
		return new double[] { getYAxis().getRangeMin(),
				getYAxis().getRangeMax() };
	}

	/**
	 * Set the range of the y-axis
	 * 
	 * @param y1
	 *            the minimum value on x-axis
	 * @param y2
	 *            the maximum value on y-axis
	 */
	public void setYRange(double y1, double y2) {
		yAxis.setRange(y1, y2);
	}

	/**
	 * Returns whether the log-scaling is turned on on x-axis.
	 * 
	 * @return whether the log-scaling is turned on on x-axis
	 */
	public boolean getLogscaleX() {
		return xAxis.isLogScaleOn();
	}

	/**
	 * Set the log-scale on x-axis on or off
	 * 
	 * @param logscale
	 *            true for turning log-scale on, false otherwise
	 */
	public void setLogscaleX(boolean logscale) {
		xAxis.setLogscale(logscale);
	}

	/**
	 * Returns whether the log-scaling is turned on on y-axis.
	 * 
	 * @return whether the log-scaling is turned on on y-axis
	 */
	public boolean getLogscaleY() {
		return yAxis.isLogScaleOn();
	}

	/**
	 * Set the log-scale on y-axis on or off
	 * 
	 * @param logscale
	 *            true for turning log-scale on, false otherwise
	 */
	public void setLogscaleY(boolean logscale) {
		yAxis.setLogscale(logscale);
	}

	/**
	 * Returns the label of the x-axis.
	 * 
	 * @return the label of the x-axis
	 */
	public String getXLabel() {
		return xAxis.getLabel();
	}

	/**
	 * Set the label of the x-axis.
	 * 
	 * @param label
	 *            the new label of the x-axis
	 */
	public void setXLabel(String label) {
		xAxis.setLabel(label);
	}

	/**
	 * Returns the label of the y-axis.
	 * 
	 * @return the label of the y-axis
	 */
	public String getYLabel() {
		return yAxis.getLabel();
	}

	/**
	 * Set the label of the y-axis.
	 * 
	 * @param label
	 *            the new label of the y-axis
	 */
	public void setYLabel(String label) {
		yAxis.setLabel(label);
	}

	/**
	 * Returns the extraX value to help with buffering for panning.
	 * 
	 * @return the extraX value to help with buffering for panning
	 */
	public int getExtraX() {
		return extraX;
	}

	/**
	 * Returns the extraY value to help with buffering for panning.
	 * 
	 * @return the extraY value to help with buffering for panning
	 */
	public int getExtraY() {
		return extraY;
	}

	/**
	 * Update the active ODE, and add this ODE to the workspace if the workspace
	 * does not contain this ODE yet.
	 * 
	 * @param ode
	 *            the ODE to be set to be active
	 */
	protected void setCurrentODE(ODE ode) {
		currentODE = ode;
		if (!odes.contains(currentODE))
			odes.add(currentODE);
	}

	/**
	 * Returns the active ODE.
	 * 
	 * @return the active ODE
	 */
	public ODE getCurrentODE() {
		return currentODE;
	}

	/**
	 * Returns the x-value of the specified ODE, Curve and point indices.
	 * 
	 * @param odeIndex
	 *            the index of the ODE
	 * @param curveIndex
	 *            the index of the Curve
	 * @param pointIndex
	 *            the index of the point
	 * @return the x-value of the specified ODE, Curve and point
	 */
	protected double getX(int odeIndex, int curveIndex, int pointIndex) {
		Curve theCurve = getCurve(odeIndex, curveIndex);
		return theCurve.getPoints()[theCurve.getVariables().indexOf(xVar)]
		                           [pointIndex];
	}

	/**
	 * Returns the curve specified by the indices of ODE and Curve.
	 * 
	 * @param odeIndex
	 *            the index of the ODE
	 * @param curveIndex
	 *            the index of the Curve
	 * @return the Curve specified by the indices of ODE and Curve
	 */
	protected Curve getCurve(int odeIndex, int curveIndex) {
		return odes.elementAt(odeIndex).getCurves().elementAt(curveIndex);
	}

	/**
	 * Returns the Equilibrium specified by the indices of ODE and Equilibrium.
	 * 
	 * @param odeIndex
	 *            the index of the ODE
	 * @param eqIndex
	 *            the index of the Curve
	 * @return the Equilibrium specified by the indices of ODE and Equilibrium
	 */
	protected Equilibrium getEquilibrium(int odeIndex, int eqIndex) {
		return odes.elementAt(odeIndex).getEquilibria().elementAt(eqIndex);
	}

	/**
	 * Returns the ODE specified by its index.
	 * 
	 * @param odeIndex
	 *            the index of the ODE
	 * @return the ODE corresponding to the given index
	 */
	protected ODE getODE(int odeIndex) {
		return odes.elementAt(odeIndex);
	}

	/**
	 * Returns the number of points of the curve with the specified indices of
	 * ODE and Curve.
	 * 
	 * @param odeIndex
	 *            the index of the ODE
	 * @param curveIndex
	 *            the index of the Curve
	 * @return the number of points in the specified Curve
	 */
	protected int getNumPoints(int odeIndex, int curveIndex) {
		Curve theCurve = getCurve(odeIndex, curveIndex);
		return theCurve.getPoints()
				[theCurve.getVariables().indexOf(xVar)].length;
	}

	/**
	 * Returns the number of Curves of the ODE specified by its index.
	 * 
	 * @param odeIndex
	 *            the index of the ODE
	 * @return the number of Curves in that ODE
	 */
	protected int getNumCurves(int odeIndex) {
		return odes.elementAt(odeIndex).getCurves().size();
	}

	/**
	 * Returns the number of Equilibria in the ode specified by its index.
	 * 
	 * @param odeIndex
	 *            the index of the ODE
	 * @return the number of Equilibria in that ODE
	 */
	protected int getNumEquilibria(int odeIndex) {
		return odes.elementAt(odeIndex).getEquilibria().size();
	}

	/**
	 * Returns the number of ODEs in the workspace.
	 * 
	 * @return the number of ODEs in the workspace
	 */
	protected int getNumODEs() {
		return odes.size();
	}

	/**
	 * Resets the plot parameters to their initial conditions. This includes the
	 * plot dimensions, grid/log settings, equilibrium points, etc. However, it
	 * does not change the title, the axis labels, or the variables associated
	 * with the ODEs.
	 */
	public void clear() {
		autoscaleNeeded = true;
	}

	/**
	 * Rescale so that the data that is currently plotted fits. "Smart"
	 * auto-scaling is used to try to avoid plotting parts of solutions that go
	 * to infinity. This overrides the base class method to ensure that the
	 * protected variables_xBottom, xTop, yBottom, and yTop are valid. This
	 * method calls repaint(), which eventually causes the display to be
	 * updated.
	 */
	protected void autoscale() {
		autoscaleNeeded = false; // once we autoscale, we don't need to keep
		// doing it

		// Tightest bounds possible to hold ALL curves.
		// Initialize to impossible values that will always be overridden.
		double lowestX = Double.POSITIVE_INFINITY;
		double highestX = -Double.POSITIVE_INFINITY;
		double lowestY = Double.POSITIVE_INFINITY;
		double highestY = -Double.POSITIVE_INFINITY;

		// Loop through all the sets of points, to detect the 'important'
		// parts to scale to in each.
		for (int odeIndex = 0; odeIndex < getNumODEs(); odeIndex++) {
			for (int curveIndex = 0; curveIndex < getNumCurves(odeIndex); 
					curveIndex++) {
				Bounds c = getAutoBounds(getCurve(odeIndex, curveIndex));

				if (c != null) {
					lowestX = Math.min(lowestX, c.getXMin());
					highestX = Math.max(highestX, c.getXMax());
					lowestY = Math.min(lowestY, c.getYMin());
					highestY = Math.max(highestY, c.getYMax());
				}
			}
			for (int eqIndex = 0; eqIndex < getNumEquilibria(odeIndex); 
					eqIndex++) {
				Bounds c = getAutoBounds(getEquilibrium(odeIndex, eqIndex));

				if (c != null) {
					lowestX = Math.min(lowestX, c.getXMin());
					highestX = Math.max(highestX, c.getXMax());
					lowestY = Math.min(lowestY, c.getYMin());
					highestY = Math.max(highestY, c.getYMax());
				}
			}
		}

		// If no important points were found, then use default range.
		if (lowestX == Double.POSITIVE_INFINITY) {
			lowestX = DEFAULT_MINX;
			highestX = DEFAULT_MAXX;
			lowestY = DEFAULT_MINY;
			highestY = DEFAULT_MAXY;
		} else {
			// Adjust the scales up a bit to catch a bit of free space/show the
			// boring part of the line
			lowestX -= .01 * (highestX - lowestX);
			highestX += .01 * (highestX - lowestX);

			lowestY -= .01 * (highestY - lowestY);
			highestY += .01 * (highestY - lowestY);

			// Create a decent scale if it would be empty otherwise,
			// e.g. a flat line plot
			if (lowestX == highestX) {
				lowestX += DEFAULT_MINX;
				highestX += DEFAULT_MAXX;
			}
			if (lowestY == highestY) {
				lowestY += DEFAULT_MINY;
				highestY += DEFAULT_MAXY;
			}
		}

		// Make the changes to the plot
		setXRange(lowestX, highestX);
		setYRange(lowestY, highestY);
	}

	/**
	 * Auto-scales just one of the axes.
	 * 
	 * @param axis
	 *            the index of the axis to scale (0 - x-axis, 1 - y-axis)
	 */
	public void autoscale(int axis) {
		if (axis == 0) {
			double lowestX = Double.POSITIVE_INFINITY;
			double highestX = -Double.POSITIVE_INFINITY;

			for (int odeIndex = 0; odeIndex < getNumODEs(); odeIndex++) {
				for (int curveIndex = 0; curveIndex < getNumCurves(odeIndex); 
						curveIndex++) {
					Bounds c = getAutoBounds(getCurve(odeIndex, curveIndex));

					if (c != null) {
						lowestX = Math.min(lowestX, c.getXMin());
						highestX = Math.max(highestX, c.getXMax());
					}
				}

				for (int eqIndex = 0; eqIndex < getNumEquilibria(odeIndex); 
						eqIndex++) {
					Bounds c = getAutoBounds(getEquilibrium(odeIndex, eqIndex));

					if (c != null) {
						lowestX = Math.min(lowestX, c.getXMin());
						highestX = Math.max(highestX, c.getXMax());
					}
				}
			}

			// If no important points were found, then use default range.
			if (lowestX == Double.POSITIVE_INFINITY) {
				lowestX = DEFAULT_MINX;
				highestX = DEFAULT_MAXX;
			} else {
				// Adjust the scales up a bit to catch a bit of free space/show
				// the
				// boring part of the line
				lowestX -= .01 * (highestX - lowestX);
				highestX += .01 * (highestX - lowestX);

				// Create a decent scale if it would be empty otherwise,
				// e.g. a flat line plot
				if (lowestX == highestX) {
					lowestX += DEFAULT_MINX;
					highestX += DEFAULT_MAXX;
				}
			}

			// Make the changes to the plot
			setXRange(lowestX, highestX);
		} else if (axis == 1) {
			double lowestY = Double.POSITIVE_INFINITY;
			double highestY = -Double.POSITIVE_INFINITY;

			// Loop through all the sets of points, to detect the 'important'
			// parts to scale to in each.
			for (int odeIndex = 0; odeIndex < getNumODEs(); odeIndex++) {
				for (int curveIndex = 0; curveIndex < getNumCurves(odeIndex); 
						curveIndex++) {
					Bounds c = getAutoBounds(getCurve(odeIndex, curveIndex));

					if (c != null) {
						lowestY = Math.min(lowestY, c.getYMin());
						highestY = Math.max(highestY, c.getYMax());
					}
				}
				for (int eqIndex = 0; eqIndex < getNumEquilibria(odeIndex); 
						eqIndex++) {
					Bounds c = getAutoBounds(getEquilibrium(odeIndex, eqIndex));

					if (c != null) {
						lowestY = Math.min(lowestY, c.getYMin());
						highestY = Math.max(highestY, c.getYMax());
					}
				}
			}

			// If no important points were found, then use default range.
			if (lowestY == Double.POSITIVE_INFINITY) {
				lowestY = DEFAULT_MINY;
				highestY = DEFAULT_MAXY;
			} else {
				// Adjust the scales up a bit to catch a bit of free space/show
				// the
				// boring part of the line
				lowestY -= .01 * (highestY - lowestY);
				highestY += .01 * (highestY - lowestY);

				// Create a decent scale if it would be empty otherwise,
				// e.g. a flat line plot
				if (lowestY == highestY) {
					lowestY += DEFAULT_MINY;
					highestY += DEFAULT_MAXY;
				}
			}

			// Make the changes to the plot
			setYRange(lowestY, highestY);
		}
	}
	
	/**
	 * Finds the ratio of units in each axis per pixel
	 * 
	 * @param viewingWindow
	 *            Dimensions of the viewingWindow
	 * 
	 * @return ratios
	 *            The number of x- and y- axis units per pixel
	 */
	public Point2D.Double getRatios(Rectangle viewingWindow) {
		double xMin = xAxis.getRangeMin();
		double xMax = xAxis.getRangeMax();
		double yMin = yAxis.getRangeMin();
		double yMax = yAxis.getRangeMax();
		double xAxisSize = xMax - xMin;
		double yAxisSize = yMax - yMin;
		
		Point2D.Double minPt = new Point2D.Double(xMin, yMax);
		Point2D.Double maxPt = new Point2D.Double(xMax, yMin);
		
		Point minPix = plotToPixelCoords(minPt,	viewingWindow);
		Point maxPix = plotToPixelCoords(maxPt, viewingWindow);
		
		double xPixSize = maxPix.getX() - minPix.getX();
		double yPixSize = maxPix.getY() - minPix.getY();
		double xRatio = xAxisSize / xPixSize;
		double yRatio = yAxisSize / yPixSize;
		
		return new Point2D.Double(xRatio, yRatio);
	}
	
	/**
	 * Zooms in and out according to vertical mouse displacement
	 * 
	 * @param deltaY
	 *            The number of pixels of mouse movement
	 * @param viewingWindow
	 *            The dimensions of the viewingWindow
	 */
	public void zoomDrag(int deltaY, Rectangle viewingWindow) {
		int xPix = xAxis.plotToPixelCoords(xAxis.getLength(),
				viewingWindow.width) - xAxis.plotToPixelCoords(0,
						viewingWindow.width);
		int yPix = yAxis.plotToPixelCoords(yAxis.getLength(),
				viewingWindow.height) - yAxis.plotToPixelCoords(0,
						viewingWindow.height);
		double deltaX = ((((double) deltaY) / ((double) yPix)) * xPix);
		
		Point2D.Double deltaPt = pixelToPlotCoords(
				new Point((int) Math.round(deltaX), deltaY), viewingWindow);
		Point2D.Double zeroPt = pixelToPlotCoords(new Point(), viewingWindow);
		
		double addX = (deltaPt.getX() - zeroPt.getX()) / 2;
		double addY = (deltaPt.getY() - zeroPt.getY()) / 2;
		
		double newXMin = xAxis.getRangeMin() + addX;
		double newYMin = yAxis.getRangeMin() - addY;
		double newXMax = xAxis.getRangeMax() - addX;
		double newYMax = yAxis.getRangeMax() + addY;
		
		setXRange(newXMin, newXMax);
		setYRange(newYMin, newYMax);
	}
	
	/**
	 * Zooms one axis out so that the window is square.
	 * 
	 * @param viewingWindow
	 *            Dimensions of the viewing window
	 */
	public void zoomSquare(Rectangle viewingWindow) {
		double xMin = xAxis.getRangeMin();
		double xMax = xAxis.getRangeMax();
		double yMin = yAxis.getRangeMin();
		double yMax = yAxis.getRangeMax();
		double xAxisSize = xMax - xMin;
		double yAxisSize = yMax - yMin;
		
		Point2D.Double minPt = new Point2D.Double(xMin, yMax);
		Point2D.Double maxPt = new Point2D.Double(xMax, yMin);
		
		Point minPix = plotToPixelCoords(minPt,	viewingWindow);
		Point maxPix = plotToPixelCoords(maxPt, viewingWindow);
		
		double xPixSize = maxPix.getX() - minPix.getX();
		double yPixSize = maxPix.getY() - minPix.getY();
		double xRatio = xAxisSize / xPixSize;
		double yRatio = yAxisSize / yPixSize;
		
		if (xRatio > yRatio) {
			double newYAxisSize = (yPixSize * xRatio);
			double add = (newYAxisSize - yAxisSize) / 2.0;
			yMin = yMin - add;
			yMax = yMax + add;
		}
		else {
			double newXAxisSize = (xPixSize * yRatio);
			double add = (newXAxisSize - xAxisSize) / 2.0;
			xMin = xMin - add;
			xMax = xMax + add;
		}
		setXRange(xMin, xMax);
		setYRange(yMin, yMax);
	}

	/**
	 * Wrapper function for using Axis functions to convert pixel to plot coords
	 * 
	 * @param pt
	 *            coordinates in pixels relative to viewing window
	 * @param viewingWindow
	 *            dimensions of viewing window
	 * @return corresponding plot coords, in double precision
	 */
	public Point2D.Double pixelToPlotCoords(Point pt, Rectangle viewingWindow) {
		double xPt = xAxis.pixelToPlotCoords(pt.x - viewingWindow.x,
				viewingWindow.width);
		// We need to flip the y axis
		double yPt = yAxis.pixelToPlotCoords(viewingWindow.height
				+ viewingWindow.y - pt.y, viewingWindow.height);
		return new Point2D.Double(xPt, yPt);
	}

	/**
	 * Wrapper function for using Axis functions to convert plot to pixel coords
	 * 
	 * @param pt
	 *            plot coordinates
	 * @param viewingWindow
	 *            dimensions of viewing window
	 * @return corresponding screen coords wrt viewing window in pixels
	 */
	public Point plotToPixelCoords(Point2D.Double pt, Rectangle viewingWindow) {
		int xPt = xAxis.plotToPixelCoords(pt.x, viewingWindow.width);
		int yPt = yAxis.plotToPixelCoords(pt.y, viewingWindow.height);
		// We want the Y axis to start from the high end
		yPt = viewingWindow.height - yPt;
		return new Point(xPt + viewingWindow.x, yPt + viewingWindow.y);
	}

	/**
	 * Takes x- and y- displacement from the user interface for panning along
	 * with the viewing window dimensions to change plot axes accordingly.
	 * 
	 * @param xOffset
	 *            x-displacement to the viewing window width.
	 * @param yOffset
	 *            y-displacement to the viewing window height.
	 * @param viewingWindow
	 *            dimensions of plot view window in pixels.
	 */
	public void panAxes(int xOffset, int yOffset, Rectangle viewingWindow) {
		// offset to right reveals more of left, etc.
		xAxis.displace(xOffset, viewingWindow.width);
		// Need to reverse axes, since top is 0
		yAxis.displace(-yOffset, viewingWindow.height);
	}

	/**
	 * Takes new ranges for axes in terms of proportions with respect to viewing
	 * window and changes the plot axes accordingly. Assumes that coordinates
	 * are given from the user interface the same way for zooming out; the user
	 * interface determines theoretical pixel coordinates to make this work
	 * properly.
	 * 
	 * @param upperLeft
	 *            pixel coordinates of the upper left corner of the zoom box.
	 * @param lowerRight
	 *            pixel coordinates of the lower right corner of the zoom box.
	 * @param viewingWindow
	 *            dimensions of plot view window in pixels.
	 */
	public void zoomAxes(Point upperLeft, Point lowerRight,
			Rectangle viewingWindow) {
		Point2D.Double upperLeftPlot = pixelToPlotCoords(upperLeft,
				viewingWindow);
		Point2D.Double lowerRightPlot = pixelToPlotCoords(lowerRight,
				viewingWindow);

		setXRange(upperLeftPlot.getX(), lowerRightPlot.getX());
		setYRange(lowerRightPlot.getY(), upperLeftPlot.getY());
	}

	/**
	 * Plot states need to know which Drawer functions to call in order to draw
	 * themselves; they have access to their own private variables and can route
	 * them appropriately.
	 * 
	 * @param g
	 *            Graphics object corresponding to panel display.
	 * @return the reduced viewing window boundary
	 */
	public synchronized Rectangle drawMe(Graphics g) {
		if (autoscaleOn && autoscaleNeeded) {
			autoscale();
		}
		Rectangle viewingWindow = Drawer.drawPlotBackground(g, this);
		if (viewingWindow == null || viewingWindow.isEmpty())
			return null;

		// draw a direction field if this type of state has one and it is active
		drawMyDirField(g, viewingWindow);

		// offscreen buffer size
		int width = viewingWindow.width;
		int height = viewingWindow.height;
		extraX = width / 2;
		extraY = height / 2;

		PlotPanel.toDisplay = new BufferedImage(width + 2 * extraX, height + 2
				* extraY, BufferedImage.TYPE_INT_ARGB);
		Graphics offscreen = PlotPanel.toDisplay.getGraphics();

		offscreen.translate(extraX - viewingWindow.x, extraY - viewingWindow.y);
		drawMySolutions(offscreen, viewingWindow);
		offscreen.translate(-extraX + viewingWindow.x, -extraY
				+ viewingWindow.y);

		// Pasting plot onto screen
		offscreen.setClip(extraX, extraY, width, height);
		g.drawImage(((BufferedImage) PlotPanel.toDisplay).getSubimage(extraX,
				extraY, width, height), viewingWindow.x, viewingWindow.y, null);
		return viewingWindow;
	}

	/**
	 * Returns whether the direction field option is allowed in this plot.
	 * 
	 * @return true iff the direction field option is allowed in this plot
	 */
	public abstract boolean isDirFieldPossible();

	/**
	 * Abstract function for computing Bounds required by a given Curve.
	 * 
	 * @param c
	 *            the curve to compute important points
	 * @return the Bounds for the given Curve
	 */
	public abstract Bounds getAutoBounds(Curve c);

	/**
	 * Abstract function for computing Bounds required by a given Equilibrium.
	 * 
	 * @param eq
	 *            the Equilibrium to compute important points
	 * @return the Bounds for the given Equilibrium
	 */
	public abstract Bounds getAutoBounds(Equilibrium eq);

	/**
	 * Draws solution curves onto image buffer. The correct portion of the
	 * buffer must be later copied to the screen Graphics object.
	 * 
	 * @param offscreenPlot
	 *            Image buffer for offscreen solution drawing.
	 */
	protected abstract void drawMySolutions(Graphics offscreenPlot,
			Rectangle viewingWindow);

	/**
	 * Draws direction field onto screen if possible.
	 */
	protected abstract void drawMyDirField(Graphics graphics,
			Rectangle viewingWindow);

	/**
	 * Print this plot using hard-coded proportions and scaling the dpi higher.
	 * Note that the proportions are not WYSIWYG; it's difficult to pass the
	 * proportions of the plot on screen since the print call needs to follow
	 * the printable interface parameters. Ideally, we would like to use
	 * PostScript output to print instead, but don't know how to do this.
	 * 
	 * @return flag NO_SUCH_PAGE or PAGE_EXISTS, corresponding to the result of
	 *         print attempt
	 */
	public int print(Graphics g, PageFormat pageFormat, int page) {
		// The desired x to y ratio to draw. If we want this to come from
		double xToYRatio = 3d / 2d;

		// Desired dpi
		final double DPI = 110d;
		double theScaleFactor = DPI / 72d;

		// get page information
		double pageWidth = pageFormat.getImageableWidth();
		double pageHeight = pageFormat.getImageableHeight();
		double pageXToYRatio = pageWidth / pageHeight;

		if (page != 0)
			return NO_SUCH_PAGE;
		Graphics2D g2d = (Graphics2D) g;

		// User (0,0) is typically outside the imageable area (margins), so we
		// translate by the X and Y values in the PageFormat to avoid clipping
		g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

		// set rendering to nicest
		RenderingHints renderHints = new RenderingHints(
				RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHints(renderHints);

		// resize plot to draw within page bounds at given dpi
		double newPageWidth = pageWidth * theScaleFactor;
		double newPageHeight = pageHeight * theScaleFactor;
		double width, height;

		if (xToYRatio > pageXToYRatio) // if the length is the limiting
		// dimension
		{
			width = newPageWidth;
			height = newPageWidth / xToYRatio;
		} else // if the height is the limiting dimension
		{
			height = newPageHeight;
			width = newPageHeight * xToYRatio;
		}

		g2d.scale(1 / theScaleFactor, 1 / theScaleFactor);
		g2d.setClip(0, 0, (int) width, (int) height);
		drawMe(g2d);

		return PAGE_EXISTS;
	}

	/**
	 * Export a description of the plot in EPS format. If the argument is null,
	 * then nothing happens. Otherwise, it goes to the specified file. To send
	 * it to standard output, use <code>System.out</code> as an argument.
	 * 
	 * @param out
	 *            A data stream to which to send the description
	 * @param width
	 *            The desired width of the postscript document
	 * @param height
	 *            The desired height of the postscript document
	 */
	public void export(OutputStream out, int width, int height) {
		// the dotted lines etc would be useful for black/white printers
		boolean grayscale = false;
		EPSGraphics g = new EPSGraphics(out, width, height, grayscale);

		// we can't use drawMe since buffers aren't applicable
		Rectangle viewingWindow = Drawer.drawPlotBackground(g, this);
		if (viewingWindow == null || viewingWindow.isEmpty())
			return;

		g.setClip(viewingWindow.x, viewingWindow.y, viewingWindow.width,
				viewingWindow.height);
		drawMySolutions(g, viewingWindow);

		g.showpage();
	}

	/**
	 * Returns a String representation this PlotState.
	 * 
	 * @return a String representation this PlotState
	 */
	@Override
	public String toString() {
		return "  x: " + xAxis.toString() + "\n  y: " + yAxis.toString();
	}
}
