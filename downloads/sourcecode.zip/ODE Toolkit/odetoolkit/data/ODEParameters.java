/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

/**
 * The ODEParameters class contains data that is held for each ODE that
 * specifies the information found in the InputPanel (with the exception of the
 * name), including the ODE's definition, the initial conditions, and the solve
 * span, and also the direction to solve (forward or backward). An ODEParameters
 * object (along with ODE and SolverSettings objects) is created when the 'Enter
 * ODE' button is pressed if a new definition has been entered.
 * 
 * @author Andres Perez 2009, modified by Clinic 10-11
 */
public class ODEParameters {
	/** ODE that owns this ODEParameters object */
	private ODE odeOwner;

	/** String containing the ODE's definition */
	private String odeDefinition;

	/** Array containing current initial conditions */
	private double[] initialConditions;

	/** Current solve span for this ODE */
	private double solveSpan;

	/** True if solving forward, false if solving backward */
	private boolean solvingForward;

	/**
	 * Sole Constructor, sets the ODE owner and also initializes an
	 * appropriately-sized initial conditions array and the default solve span
	 * value.
	 * 
	 * @param varKeeper
	 *            the ODEVarKeeper for this workspace
	 * @param owner
	 *            ODE that owns these parameters
	 */
	public ODEParameters(ODEVarKeeper varKeeper, ODE owner) {
		odeOwner = owner;

		// Initialize the initial conditions array to zero values
		ODEVarVector variables = varKeeper
				.createVarVector(owner.getVariables());
		initialConditions = new double[variables.size()];
		for (int i = 0; i < variables.size(); i++)
			initialConditions[i] = 0;

		solveSpan = 10.0;
	}

	/**
	 * Returns the ODE that owns this set of parameters.
	 * 
	 * @return ODE that owns this ODEParameters object
	 */
	public ODE getODEOwner() {
		return odeOwner;
	}

	/**
	 * Returns the ODE's definition.
	 * 
	 * @return String containing the ODE's definition.
	 */
	public String getDefinition() {
		return odeDefinition;
	}

	/**
	 * Sets the specified string to be the definition of the ODE.
	 * 
	 * @param definition
	 *            String containing the ODE definition text
	 */
	public void setDefinition(String definition) {
		odeDefinition = definition;
	}

	/**
	 * Returns the current initial conditions array of the ODE.
	 * 
	 * @return double array of the ODE's current initial conditions
	 */
	public double[] getInitialConditions() {
		return initialConditions;
	}

	/**
	 * Sets the specified double array to the be the ODE's new initial
	 * conditions.
	 * 
	 * @param newInitialConditions
	 *            double array containing ODE's new initial conditions
	 */
	public void setInitialConditions(double[] newInitialConditions) {
		initialConditions = newInitialConditions;
	}

	/**
	 * Sets the specified ODEVar's initial condition to the given value. This
	 * method is used by the ICTableModel class to edit the initial conditions
	 * array when the user makes changes to the initial conditions in the
	 * InputPanel.
	 * 
	 * @param var
	 *            ODEVar to change the initial condition for
	 * @param value
	 *            double to set the specified ODEVar's initial condition to
	 */
	public void setSingleIC(ODEVar var, double value) {
		for (int i = 0; i < odeOwner.getVariables().size(); i++)
			if (var.equals(odeOwner.getVariables().get(i)))
				initialConditions[i] = value;
	}

	/**
	 * Returns the current solve span for the ODE.
	 * 
	 * @return double of the ODE's current solve span
	 */
	public double getSolveSpan() {
		return solveSpan;
	}

	/**
	 * Sets the ODE's solve span to the specified value.
	 * 
	 * @param newSolveSpan
	 *            the new solve span to set for this ODE
	 */
	public void setSolveSpan(double newSolveSpan) {
		solveSpan = newSolveSpan;
	}

	/**
	 * Returns true if this ODE's parameters are set to solve in the forward
	 * time direction, returns false if they're set to solve in the reverse time
	 * direction.
	 * 
	 * @return true if solving forward, false if solving backward
	 */
	public boolean isSolvingForward() {
		return solvingForward;
	}

	/**
	 * Sets whether the ODE will solve in the forward time direction.
	 * 
	 * @param forward
	 *            boolean representing whether the ODE will be solved in the
	 *            forward time direction
	 */
	public void setSolvingForward(boolean forward) {
		solvingForward = forward;
	}
}
