/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

/**
 * The SolverSettings class contains the settings for each of the solvers, as
 * well as a String indicating the currently active solver. Each ODE contains
 * its own SolverSettings object that is initialized upon entering the ODE.
 * 
 * @author Max Comstock 2013, modified from Andres Perez 2009
 */
public class SolverSettings {
	/** ODE that owns these solver settings */
	private ODE odeOwner;

	/** String designating the active solver, defaults to Rosenbrock */
	 // Note: this does not actually change the default solver, this must
	 // be changed in SolverOptionsPanel.java
	private String currentSolver = "RB";

	/** Runge-Kutta solver settings */
	private RKSolverSettings rkSettings;

	/** Euler solver settings */
	private EulerSolverSettings eulerSettings;

	/** Rosenbrock solver settings */
	private RBSolverSettings rbSettings;

	/**
	 * Default Constructor, sets the ODE owner and instantiates a settings
	 * object for each of the solvers.
	 * 
	 * @param owner
	 *            ODE corresponding to these settings
	 */
	public SolverSettings(ODE owner) {
		odeOwner = owner;
		rkSettings = new RKSolverSettings();
		eulerSettings = new EulerSolverSettings();
		rbSettings = new RBSolverSettings();
	}

	/**
	 * Copy Constructor, this is used by the SolverSettingsDialog class to make
	 * a backup copy of the ODE's SolverSettings.
	 * 
	 * @param originalSettings
	 *            SolverSettings to copy
	 */
	public SolverSettings(SolverSettings originalSettings) {
		odeOwner = originalSettings.getODEOwner();
		rkSettings = new RKSolverSettings(originalSettings.getRKSettings());
		eulerSettings = new EulerSolverSettings(
				originalSettings.getEulerSettings());
		rbSettings = new RBSolverSettings(originalSettings.getRBSettings());
	}

	/**
	 * Returns the ODE that owns these SolverSettings.
	 * 
	 * @return ODE which these SolverSettings correspond to
	 */
	public ODE getODEOwner() {
		return odeOwner;
	}

	/**
	 * Returns the String identifying the currently active solver for the ODE
	 * system.
	 * 
	 * @return String containing title of currently active solver
	 */
	public String getCurrentSolver() {
		return currentSolver;
	}

	/**
	 * Sets the solver specified by the parameter as the currently active solver
	 * for the ODE system.
	 * 
	 * @param solver
	 *            String containing title of solver to set as active
	 */
	public void setCurrentSolver(String solver) {
		currentSolver = solver;
	}

	/**
	 * Returns the RKSolverSettings object containing the parameters for the
	 * Runge-Kutta algorithm for the ODE system.
	 * 
	 * @return RKSolverSettings object containing this ODE's Runge-Kutta
	 *         algorithm solver parameters
	 */
	public RKSolverSettings getRKSettings() {
		return rkSettings;
	}

	/**
	 * Returns the EulerSolverSettings object containing the parameters for
	 * Euler's algorithm for the ODE system.
	 * 
	 * @return EulerSolverSettings object containing this ODE's Euler's
	 *         algorithm solver parameters
	 */
	public EulerSolverSettings getEulerSettings() {
		return eulerSettings;
	}

	/**
	 * Returns the RBSolverSettings object containing the parameters for the
	 * Rosenbrock algorithm for the ODE system.
	 * 
	 * @return RBSolverSettings object containing this ODE's Rosenbrock
	 *         algorithm solver parameters
	 */
	public RBSolverSettings getRBSettings() {
		return rbSettings;
	}

	/**
	 * The RKSolverSettings class serves as a container for the parameters of
	 * the Runge-Kutta algorithm for an ODE system.
	 * 
	 * @author Andres Perez 2009
	 */
	public class RKSolverSettings {
		/** Absolute tolerance */
		double absoluteTolerance;

		/** Relative tolerance */
		private double relativeTolerance;

		/** Minimum step size */
		private double minStepSize;

		/** Maximum step size */
		private double maxStepSize;

		/** Data points per unit of time */
		private double pointsPerTime;

		/**
		 * Default Constructor, initializes the default values for the absolute
		 * and relative tolerances, the minimum and maximum step sizes, and the
		 * resolution (i.e., data points per unit of time).
		 */
		public RKSolverSettings() {
			absoluteTolerance = 1E-7;
			relativeTolerance = 1E-7;
			minStepSize = 0.02;
			maxStepSize = 0.05;
			pointsPerTime = 500.0;
		}

		/**
		 * Copy Constructor, this is used by the SolverSettingsDialog class to
		 * make a backup copy of the ODE's RKSolverSettings.
		 * 
		 * @param originalSettings
		 *            RKSolverSettings object to copy
		 */
		public RKSolverSettings(RKSolverSettings originalSettings) {
			absoluteTolerance = originalSettings.getAbsoluteTolerance();
			relativeTolerance = originalSettings.getRelativeTolerance();
			minStepSize = originalSettings.getMinStepSize();
			maxStepSize = originalSettings.getMaxStepSize();
			pointsPerTime = originalSettings.getPointsPerTime();
		}

		/**
		 * Returns the absolute tolerance.
		 * 
		 * @return the absolute tolerance
		 */
		public double getAbsoluteTolerance() {
			return absoluteTolerance;
		}

		/**
		 * Set the absolute tolerance
		 * 
		 * @param absoluteTolerance
		 *            the new absolute tolerance
		 */
		public void setAbsoluteTolerance(double absoluteTolerance) {
			this.absoluteTolerance = absoluteTolerance;
		}

		/**
		 * Returns the relative tolerance.
		 * 
		 * @return the relative tolerance
		 */
		public double getRelativeTolerance() {
			return relativeTolerance;
		}

		/**
		 * Set the relative tolerance
		 * 
		 * @param relativeTolerance
		 *            the new relative tolerance
		 */
		public void setRelativeTolerance(double relativeTolerance) {
			this.relativeTolerance = relativeTolerance;
		}

		/**
		 * Returns the minimum step size.
		 * 
		 * @return the minimum step size
		 */
		public double getMinStepSize() {
			return minStepSize;
		}

		/**
		 * Set the minimum step size
		 * 
		 * @param minStepSize
		 *            the new minimum step size
		 */
		public void setMinStepSize(double minStepSize) {
			this.minStepSize = minStepSize;
		}

		/**
		 * Returns the maximum step size.
		 * 
		 * @return the maximum step size
		 */
		public double getMaxStepSize() {
			return maxStepSize;
		}

		/**
		 * Set the maximum step size
		 * 
		 * @param maxStepSize
		 *            the new maximum step size
		 */
		public void setMaxStepSize(double maxStepSize) {
			this.maxStepSize = maxStepSize;
		}

		/**
		 * Returns the resolution as number of points per unit time.
		 * 
		 * @return the resolution as number of points per unit time
		 */
		public double getPointsPerTime() {
			return pointsPerTime;
		}

		/**
		 * Set the resolution as number of points per unit time
		 * 
		 * @param pointsPerTime
		 *            the new resolution as number of points per unit time
		 */
		public void setPointsPerTime(double pointsPerTime) {
			this.pointsPerTime = pointsPerTime;
		}
	}

	/**
	 * The EulerSolverSettings class serves as a container for the parameters of
	 * Euler's algorithm for an ODE system.
	 * 
	 * @author Andres Perez 2009
	 */
	public class EulerSolverSettings {
		/** Data points per unit of time */
		private double pointsPerTime;

		/**
		 * Default Constructor, initializes the default value for the resolution
		 * (i.e., data points per unit of time).
		 */
		public EulerSolverSettings() {
			pointsPerTime = 500;
		}

		/**
		 * Copy Constructor, this is used by the SolverSettingsDialog class to
		 * make a backup copy of the ODE's EulerSolverSettings.
		 * 
		 * @param originalSettings
		 *            EulerSolverSettings object to copy
		 */
		public EulerSolverSettings(EulerSolverSettings originalSettings) {
			pointsPerTime = originalSettings.getPointsPerTime();
		}

		public double getPointsPerTime() {
			return pointsPerTime;
		}

		public void setPointsPerTime(double pointsPerTime) {
			this.pointsPerTime = pointsPerTime;
		}
	}

	/**
	 * The RBSolverSettings class serves as a container for the parameters of
	 * RB's algorithm for an ODE system. Possible Improvement: abstraction with
	 * RKSolverSettings
	 * 
	 * @author Clinic 10-11, modified from RKSolverSettings by Andres Perez 09
	 */
	public class RBSolverSettings {
		/** Absolute tolerance */
		double absoluteTolerance;

		/** Relative tolerance */
		private double relativeTolerance;

		/** Minimum step size */
		private double minStepSize;

		/** Maximum step size */
		private double maxStepSize;

		/** Data points per unit of time */
		private double pointsPerTime;

		/**
		 * Default Constructor, initializes the default values for the absolute
		 * and relative tolerances, the minimum and maximum step sizes, and the
		 * resolution (i.e., data points per unit of time).
		 */
		public RBSolverSettings() {
			absoluteTolerance = 1E-7;
			relativeTolerance = 1E-7;
			minStepSize = 0.02;
			maxStepSize = 0.05;
			pointsPerTime = 500.0;
		}

		/**
		 * Copy Constructor, this is used by the SolverSettingsDialog class to
		 * make a backup copy of the ODE's RBSolverSettings.
		 * 
		 * @param originalSettings
		 *            RBSolverSettings object to copy
		 */
		public RBSolverSettings(RBSolverSettings originalSettings) {
			absoluteTolerance = originalSettings.getAbsoluteTolerance();
			relativeTolerance = originalSettings.getRelativeTolerance();
			minStepSize = originalSettings.getMinStepSize();
			maxStepSize = originalSettings.getMaxStepSize();
			pointsPerTime = originalSettings.getPointsPerTime();
		}

		/**
		 * Returns the absolute tolerance.
		 * 
		 * @return the absolute tolerance
		 */
		public double getAbsoluteTolerance() {
			return absoluteTolerance;
		}

		/**
		 * Set the absolute tolerance
		 * 
		 * @param absoluteTolerance
		 *            the new absolute tolerance
		 */
		public void setAbsoluteTolerance(double absoluteTolerance) {
			this.absoluteTolerance = absoluteTolerance;
		}

		/**
		 * Returns the relative tolerance.
		 * 
		 * @return the relative tolerance
		 */
		public double getRelativeTolerance() {
			return relativeTolerance;
		}

		/**
		 * Set the relative tolerance
		 * 
		 * @param relativeTolerance
		 *            the new relative tolerance
		 */
		public void setRelativeTolerance(double relativeTolerance) {
			this.relativeTolerance = relativeTolerance;
		}

		/**
		 * Returns the minimum step size.
		 * 
		 * @return the minimum step size
		 */
		public double getMinStepSize() {
			return minStepSize;
		}

		/**
		 * Set the minimum step size
		 * 
		 * @param minStepSize
		 *            the new minimum step size
		 */
		public void setMinStepSize(double minStepSize) {
			this.minStepSize = minStepSize;
		}

		/**
		 * Returns the maximum step size.
		 * 
		 * @return the maximum step size
		 */
		public double getMaxStepSize() {
			return maxStepSize;
		}

		/**
		 * Set the maximum step size
		 * 
		 * @param maxStepSize
		 *            the new maximum step size
		 */
		public void setMaxStepSize(double maxStepSize) {
			this.maxStepSize = maxStepSize;
		}

		/**
		 * Returns the resolution as number of points per unit time.
		 * 
		 * @return the resolution as number of points per unit time
		 */
		public double getPointsPerTime() {
			return pointsPerTime;
		}

		/**
		 * Set the resolution as number of points per unit time
		 * 
		 * @param pointsPerTime
		 *            the new resolution as number of points per unit time
		 */
		public void setPointsPerTime(double pointsPerTime) {
			this.pointsPerTime = pointsPerTime;
		}
	}
}
