/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

import java.awt.geom.Point2D;
import java.util.Comparator;

/**
 * This class defines a simple comparator for the x-coordinates of points. It
 * provides for easy sorting of points in the Curve class methods.
 * 
 * @author Andres Perez 2009
 */
public class PointComparer implements Comparator<Point2D.Double> {
	/**
	 * Compares two points by their x-coordinates to define an ordering over the
	 * set of points.
	 * 
	 * @param pt1
	 *            first plot point
	 * @param pt2
	 *            second plot point
	 * @return a negative int, zero or a positive int if the first argument is
	 *         less than, equal to, or a greater than the second argument,
	 *         respectively
	 */
	public int compare(Point2D.Double pt1, Point2D.Double pt2) {
		if (pt1.x < pt2.x)
			return -1;
		else if (pt1.x > pt2.x)
			return 1;
		else
			return 0;
	}
}
