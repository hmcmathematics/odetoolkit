/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * The Tick class contains the data for a tick mark on the axes. Each Tick has a
 * pixel location along the axis, as well as a label and a flag indicating
 * whether it is using scientific notation, all of which are interpreted by the
 * Drawer.
 * 
 * @author ODE Clinic 08-09, modified by Andres Perez 09
 */
public class Tick {
	/** Position along the axis, measured in pixels */
	private int pixelPosition;

	/** String to draw under tick mark */
	private String label;

	/** Indicates whether scientific notation is used in the label */
	private boolean usesSciNotation;

	/**
	 * Sole Constructor, sets the position
	 * 
	 * @param value
	 *            the plot coordinate marked by the tick mark
	 * @param position
	 *            the position along the axis from the origin, measured in
	 *            pixels
	 * @param step
	 *            the separation width in between each tick mark
	 * @param sciNotation
	 *            true if the label needs to use scientific notation
	 */
	public Tick(double value, int position, double step, boolean sciNotation) {
		pixelPosition = position;
		usesSciNotation = sciNotation;

		// Determine the number of digits that will fit given the step size
		int digitsToUse = (int) Math.floor(Math.log10(step));
		// Create the NumberFormat to use given the number of possible digits
		NumberFormat f = NumberFormat.getInstance();
		f.setMinimumFractionDigits(Math.max(-digitsToUse, 0));
		f.setMaximumFractionDigits(Math.max(-digitsToUse, 0));
		// If scientific notation is used, set the appropriate appearance
		if (usesSciNotation)
			((DecimalFormat) f).applyPattern("0.#E0");

		label = f.format(value).toLowerCase();
	}

	/**
	 * Returns the position along the axis, measured in pixels.
	 * 
	 * @return number of pixels from the origin to draw the tick mark
	 */
	public int getPixelPosition() {
		return pixelPosition;
	}

	/**
	 * Returns the tick mark label, parsed as a double in order to correctly
	 * interpret scientific notation. Currently unused.
	 * 
	 * @return double representation of the tick mark label
	 */
	public double getValue() {
		return Double.parseDouble(label);
	}

	/**
	 * Returns a String representation of the tick mark, i.e., the label.
	 * 
	 * @return the label
	 */
	@Override
	public String toString() {
		return label;
	}
}
