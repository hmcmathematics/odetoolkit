/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package data;

import java.util.ListIterator;
import java.util.Vector;

/**
 * The ODEVarVector class is an extension of the Vector class for ODEVars, with
 * a handful of convenient accessor functions. Each ODE contains a single
 * ODEVarVector containing all the variables that are parsed out from the ODE
 * definition.
 * 
 * @author Richard Mehlinger 09, modified by Andres Perez 09 and Clinic 10-11
 */
@SuppressWarnings("serial")
public class ODEVarVector extends Vector<ODEVar> {
	/**
	 * Returns a Vector of Strings containing the names of each ODEVar.
	 * 
	 * @return Vector of Strings containing the variable names
	 */
	public Vector<String> getNames() {
		Vector<String> names = new Vector<String>();

		// loop through each ODEVar and store the name
		ListIterator<ODEVar> iter = listIterator();
		while (iter.hasNext())
			names.add((iter.next()).getName());

		return names;
	}

	/**
	 * Returns the name of the ODEVar with the specified position in the
	 * ODEVarVector.
	 * 
	 * @param index
	 *            the index of the desired variable
	 * @return the name of the variable
	 */
	public String getName(int index) {
		return get(index).getName();
	}

	/**
	 * Returns the index of the specified ODEVar in the ODEVarVector. If none
	 * are found, the method returns -1.
	 * 
	 * @param var
	 *            the ODEVar to find the index of
	 * @return the index of the ODEVar
	 */
	public int indexOf(ODEVar var) {
		// compare with each element in the Vector until a match is found
		for (int i = 0; i < size(); i++)
			if (get(i).equals(var))
				return i;

		// return -1 if not found
		return -1;
	}

	/**
	 * Returns whether this ODEVarVector contains the specified variable.
	 * 
	 * @param var
	 *            the ODEVar to search for
	 * @return true if the ODEVarVector contains the ODEVar
	 */
	public boolean contains(ODEVar var) {
		return indexOf(var) != -1;
	}

	/**
	 * Removes the specified ODEVar from the ODEVarVector.
	 * 
	 * @param var
	 *            the ODEVar to remove
	 */
	public void remove(ODEVar var) {
		if (this.contains(var))
			remove(indexOf(var));
	}
}
