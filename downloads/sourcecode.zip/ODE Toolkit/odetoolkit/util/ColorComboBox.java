/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

import java.awt.Color;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

/**
 * The ColorComboBox class defines a color choice JComboBox. It's used for
 * changing the direction field color in the direction field settings dialog
 * box.
 * 
 * @author Clinic 10-11, modified from 08-09
 */
@SuppressWarnings("serial")
public class ColorComboBox extends JComboBox {
	/**
	 * This Vector holds the icons for choosing a color. Each color selection
	 * will be an element in the Vector.
	 */
	private Vector<ColorIcon> colors;

	/**
	 * Default constructor which creates the box used to select colors for
	 * direction fields. It does not allow the option of not selecting a color.
	 */
	public ColorComboBox() {
		super();
		initIcons(false);
		DefaultComboBoxModel model = new DefaultComboBoxModel(colors);
		setModel(model);
		setRenderer(new ColorRenderer());
	}

	/**
	 * Constructor which creates the box used to select colors for direction
	 * fields.
	 * 
	 * @param allowNone
	 *            if true, it will be possible to not choose a color
	 * 
	 */
	public ColorComboBox(boolean allowNone) {
		super();
		initIcons(allowNone);
		DefaultComboBoxModel model = new DefaultComboBoxModel(colors);
		setModel(model);
		setRenderer(new ColorRenderer());
	}

	/**
	 * Creates the icons for selecting colors and stores them in colors.
	 * 
	 * @param allowNone
	 *            if true, adds an icon for the option of not selecting a color
	 * 
	 */
	private void initIcons(boolean allowNone) {
		colors = new Vector<ColorIcon>();
		if (allowNone)
			colors.add(new ColorIcon("no selection", new Color(0, 0, 0, 0)));
		colors.add(new ColorIcon("Black", Color.black));
		colors.add(new ColorIcon("Blue", Color.blue));
		colors.add(new ColorIcon("Cyan", Color.cyan));
		colors.add(new ColorIcon("Gray", Color.gray));
		colors.add(new ColorIcon("Green", Color.green));
		colors.add(new ColorIcon("Magenta", Color.magenta));
		colors.add(new ColorIcon("Orange", Color.orange));
		colors.add(new ColorIcon("Pink", Color.pink));
		colors.add(new ColorIcon("Red", Color.red));
		colors.add(new ColorIcon("White", Color.white));
		colors.add(new ColorIcon("Yellow", Color.yellow));
	}

	/**
	 * Searches for color in colors and calls a JComboBox method to select it
	 * 
	 * @param color
	 *            the selected color icon
	 */
	public void setSelectedItem(Color color) {
		for (int i = 0; i < colors.size(); i++)
			if (color.equals(colors.elementAt(i).getColor()))
				setSelectedIndex(i);
	}
}
