/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

import java.awt.geom.Point2D;

/**
 * PointClickedListener is an interface to be used with PlotBox2D. If you want a
 * class to be notified every time a point is clicked on the plot box, have the
 * class implement this interface and then add it to the plot panel using
 * PlotBox2D.addPointReadyListener(). Then every time the user clicks a point,
 * your class' pointClicked() function gets called with the point's coordinates.
 * 
 * @author Eric Harley, modified by Clinic 10-11
 */
public interface PointClickedListener {

	/**
	 * When a user clicks on a plot panel the pointClicked() method of any
	 * PointClicked listeners is called. This translates screen coordinates to
	 * useful equation space coordinates.
	 * 
	 * @param point
	 *            [] Values of the horizontal and vertical variables
	 */
	public void pointClicked(Point2D.Double point);

	/**
	 * Handle the error condition
	 * 
	 * @param ex
	 *            the exception to be handled
	 */
	public void errorCondition(Exception ex);

	/**
	 * Handle the error condition
	 * 
	 * @param error
	 *            string describing error condition
	 */
	public void errorCondition(String error);

}
