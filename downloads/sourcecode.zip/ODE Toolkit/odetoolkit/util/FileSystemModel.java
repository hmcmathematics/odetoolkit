/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/
/*

//This class has to do with the old way of dealing with the Library, which we don't use anymore.

package util;

import java.io.File;
import java.io.FilenameFilter;
import java.io.Serializable;
import java.util.Comparator;

import javax.swing.tree.TreePath;

@SuppressWarnings("serial")
public class FileSystemModel implements Serializable
{

	String root;

	public FileSystemModel() {
		this(System.getProperty("user.home"));
	}

	public FileSystemModel(String startPath) {
		root = startPath;
	}

	public Object getRoot() {
		return new File(root);
	}

	public class ODEFilenameFilter implements FilenameFilter {
		public boolean accept(File directory, String filename) {
			if (filename.toLowerCase().endsWith(".ode"))
				return true;
			return (new File(directory, filename)).isDirectory();
		}
	}

	public Object getChild(Object parent, int index) {
		File directory = (File) parent;
		String[] children = directory.list(new ODEFilenameFilter());
		java.util.Arrays.sort(children, new FileComparator(directory));
		return new File(directory, children[index]);
	}

	public int getChildCount(Object parent) {
		File fileSysEntity = (File) parent;
		if (fileSysEntity.isDirectory()) {
			String[] children = fileSysEntity.list(new ODEFilenameFilter());
			return children.length;
		} else {
			return 0;
		}
	}

	public boolean isLeaf(Object node) {
		return ((File) node).isFile();
	}

	public void valueForPathChanged(TreePath path, Object newValue) {
	}

	public int getIndexOfChild(Object parent, Object child) {
		File directory = (File) parent;
		File fileSysEntity = (File) child;
		String[] children = directory.list();
		int result = -1;

		for (int i = 0; i < children.length; ++i) {
			if (fileSysEntity.getName().equals(children[i])) {
				result = i;
				break;
			}
		}

		return result;
	}

	public class FileComparator implements Comparator<String> {
		private File directory;

		public FileComparator(File directory) {
			this.directory = directory;
		}

		public int compare(String o1, String o2) {
			File f1 = new File(directory, o1);
			File f2 = new File(directory, o2);

			if (f1.isDirectory() && f2.isFile()) {
				return -1;
			}
			if (f1.isFile() && f2.isDirectory()) {
				return 1;
			}

			return o1.compareTo(o2);
		}
	}
}
*/