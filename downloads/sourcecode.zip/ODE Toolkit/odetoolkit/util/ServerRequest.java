/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

/**
 * This class provides static constants for putting together request strings
 * that the VMS ode server can understand.
 * 
 * RemoteSolver uses this class to build the requests it sends to the server.
 * SolverParameters and ODE use this class in their toString() methods to
 * provide String serializations of themselves.
 * 
 * @author Clinic 08-09
 */
public class ServerRequest {
	/** Separates each parameter */
	public static final String DELIMITER = "&";

	/** Specifies which solver to use */
	public static final String SOLVER = "EXEC=";
	/** Specifies which solver to use (Euler) */
	public static final String SOLVER_EULER = "EULER";
	/** Specifies which solver to use (Runga-Kutta) */
	public static final String SOLVER_RK = "RK";
	/** Specifies which solver to use (Rosenbrock) */
	public static final String SOLVER_RB = "RB";

	/** Specifies which direction we're solving in the independent var */
	public static final String DIRECTION = "DIRECTION=";
	/** Specifies solving forward */
	public static final String DIRECTION_FORWARD = "FORWARD";
	/** Specifies solving backward */
	public static final String DIRECTION_BACKWARD = "BACK";

	/** The number of equations */
	public static final String ODE_ORDER = "NEQ=";

	/** The values of the equations */
	public static final String ODES = "ODES=";

	/** the independent variable and dependent variables */
	public static final String VARIABLES = "VARS=";

	/** Initial value of the independent variable */
	public static final String INITIAL_VALUE_INDEPENDENT_VAR = "INITT=";

	/** Initial values of y and y', or just y if first order. */
	public static final String INITIAL_VALUE_DEPENDENT_VARS = "INITX=";

	/** The names of the functions */
	public static final String FUNCTIONS = "CONSTANTS=";

	/** The values of the defined functions */
	public static final String FUNCTION_VALUES = "VALUES=";

	/** solver step size. = 1 / points/time */
	public static final String STEP_SIZE = "STEPSIZE=";

	/** The size of the interval on which to solve */
	public static final String SOLVE_SPAN = "LENGTH=";

	/** Relative tolerance. Default value 1.0e-7 */
	public static final String RELATIVE_TOLERANCE = "RTOL=";

	/** Absolute tolerance. Default value is 1.0e-7 */
	public static final String ABSOLUTE_TOLERANCE = "ATOL=";

	/** Output mode. determines the format of the server output */
	public static final String OUTPUT_MODE = "OUTPUTMODE=";
	/** server output mode specified as streamed. */
	public static final String OUTPUT_MODE_STREAMED = "STREAMED";
	/** server output mode specified as ascii. */
	public static final String OUTPUT_MODE_ASCII = "ASCII";

	/**
	 * Only in the request if the solver is set to euler. Seems to just be
	 * solvespan x points/time = number of points
	 */
	public static final String EULER_MAXSTEP = "MAXSTEP=";

	/** Only needed if the solver is RK. Always has value 1. */
	public static final String RK_IFLAG = "IFLAG=";

	/** Only needed if the solver is RB. Always has value 1. */
	public static final String RB_IFLAG = "IFLAG=";
}
