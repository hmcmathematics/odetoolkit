/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.SystemColor;

import javax.swing.Icon;

/**
 * The ColorIcon class defines an Icon object of the specified size consisting
 * of a small square box filled with the specified color. It is used by the
 * color sub-menu of the Graph Options menu in the toolbar and by the
 * ColorComboBox class used by the direction field settings dialog box.
 * 
 * Code is adapted from CoreJFC by Kim Topley
 * @author Clinic 08-09
 */
public class ColorIcon implements Icon {
	/** Dimension of this icon, including border. */
	private int width, height;
	/** Dimension of the color part of this icon (not including border).*/
	private int fillWidth, fillHeight;
	/** Thickness of the border around this icon. */
	private int borderSize;

	/** The color of this icon (not including border). */
	private Color fillColor;
	/** The color of the border for this icon.
	 * Called shadow because this is drawn first, then the
	 * fill color is drawn on top of it. */
	private Color shadow;

	/** The label (a color) for this icon. */
	private String name;

	/** Default thickness of border around icon. */
	private static final int BORDER_SIZE = 2;
	/** Default width and height of icon. */
	private static final int DEFAULT_SIZE = 20;

	/**
	 * Constructor that creates a new icon with the specified color and dimensions.
	 * It calculates fillWidth and fillHeight based on the width, height, and borderSize,
	 * and sets shadow to a system default.
	 * 
	 * @param name
	 * 				the label for this icon
	 * @param fill
	 * 				the color of this icon
	 * @param width
	 * 				the total width of this icon
	 * @param height
	 * 				the total height of this icon
	 * @param border
	 * 				the thickness of the border for this icon
	 */
	public ColorIcon(String name, Color fill, int width, int height, int border) {
		this.name = name;
		fillColor = fill;
		borderSize = border;
		this.width = width;
		this.height = height;

		shadow = SystemColor.control;// Color.black; (probably)
		fillWidth = width - 2 * borderSize;
		fillHeight = height - 2 * borderSize;
	}
	
	/**
	 * Constructor that calls a more detailed constructor with size as height and width
	 * and the default BORDER_SIZE for the border.
	 * 
	 * @param name
	 * 				the label for this icon
	 * @param fill
	 * 				the color of this icon
	 * @param size
	 * 				the width and height of the icon
	 */
	public ColorIcon(String name, Color fill, int size) {
		this(name, fill, size, size, BORDER_SIZE);
	}

	/**
	 * Constructor that calls a more details constructor with default size.
	 * 
	 * @param name
	 * 				the label for this icon
	 * @param fill
	 * 				the width and height of the icon
	 */
	public ColorIcon(String name, Color fill) {
		this(name, fill, DEFAULT_SIZE);
	}

	/**
	 * Returns the label (a color name) for this icon.
	 * 
	 * @return String containing the name of this icon
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the fillColor of this icon.
	 * 
	 * @return a Color containing the fillColor of this icon.
	 */
	public Color getColor() {
		return fillColor;
	}
	
	/**
	 * Sets the color for the border of this icon.
	 * 
	 * @param c
	 * 			the new color for the border
	 */
	public void setShadow(Color c) {
		shadow = c;
	}

	/**
	 * Sets the main color of this icon.
	 * 
	 * @param c
	 * 			the new color for this icon
	 */
	public void setFillColor(Color c) {
		fillColor = c;
	}

	public int getIconWidth() {
		return width;
	}

	public int getIconHeight() {
		return height;
	}
	//This is an inherited abstract method which must be implemented.
	public void paintIcon(Component comp, Graphics g, int x, int y) {
		Color c = g.getColor();

		if (borderSize > 0) {
			g.setColor(shadow);
			for (int i = 0; i < borderSize; ++i)
				g.drawRect(x + i, y + i, width - 2 * i - 1, height - 2 * i - 1);
		}

		g.setColor(fillColor);
		g.fillRect(x + borderSize, y + borderSize, fillWidth, fillHeight);

		g.setColor(c);
	}
}
