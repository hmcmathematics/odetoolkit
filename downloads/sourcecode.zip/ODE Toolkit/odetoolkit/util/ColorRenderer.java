/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

import java.awt.Component;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 * The ColorRenderer class describes a ListCellRenderer for ColorIcons.
 * 
 * Code is adapted from CoreJFC by Kim Topley
 * @author Clinic 08-09
 */
@SuppressWarnings("serial")
public class ColorRenderer extends JLabel implements ListCellRenderer {
	final Font selectedFont = new Font("Serif", Font.BOLD, 14);
	final Font normalFont = new Font("Serif", Font.PLAIN, 12);

	public Component getListCellRendererComponent(JList list, Object value,
			int index, boolean isSelected, boolean hasFocus) {
		setOpaque(true);

		ColorIcon icon = (ColorIcon) value;
		setIcon(icon);
		setText(icon.getName());
		if (isSelected) {
			setBackground(SystemColor.controlShadow);
			// setForeground(Color.white);
			// setFont(selectedFont);
		} else {
			setBackground(SystemColor.control);
			// setForeground(Color.black);
			// setFont(normalFont);
		}
		return this;
	}
}
