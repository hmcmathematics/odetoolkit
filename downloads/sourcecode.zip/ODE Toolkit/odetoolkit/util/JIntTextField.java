/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;

/**
 * The JIntTextField class is an extension of JTextField, designed to only
 * allow the strings corresponding to valid Integers. In the case of invalid
 * input, the display reverts to the last known valid input, or 0 if no such
 * input exists.
 * 
 * @author Aaron Becker, modified by Clinic 10-11
 */
@SuppressWarnings("serial")
public class JIntTextField extends JTextField implements FocusListener {
	/**
	 * if true, this will allow negative ints in the text field; otherwise
	 * only positive values will be considered valid
	 */
	private boolean allow_negatives = true;
	/**
	 * holds any text that was in the text field previously, in case the new
	 * input is invalid
	 */
	private String oldText;

	/**
	 * The default constructor, which provides the default value <code>0</code>
	 */
	public JIntTextField() {
		this("0", true);
	}

	/**
	 * Constructor specifying the validity of negative numbers.
	 * 
	 * @param neg
	 *            Boolean value: true if negative numbers are valid.
	 */
	public JIntTextField(boolean neg) {
		this("0", neg);
	}

	/**
	 * Constructor allowing specification of the intitial int. If the given
	 * String does not represent a valid double, 0 will be used.
	 * 
	 * @param s
	 *            String representing the intitial int
	 */
	public JIntTextField(String s) {
		this(s, true);
	}

	/**
	 * Constructor allowing specification of the initial int. 
	 * 
	 * @param i
	 *            the initial int
	 */
	public JIntTextField(int i) {
		this(Integer.toString(i), true);
	}

	/**
	 * Constructor allowing specification of both the validity of negative numbers 
	 * and the initial int.
	 * 
	 * @param i
	 *            the initial int
	 * @param neg
	 *            Boolean value: true if negative numbers are valid.
	 */
	public JIntTextField(int i, boolean neg) {
		this(Integer.toString(i), neg);
	}

	/**
	 * Constructor allowing specification of both the validity of negative
	 * numbers and the initial value.
	 * 
	 * @param s
	 *            String representing the initial int
	 * @param neg
	 *            Boolean value: true if negative numbers are allowed
	 */
	public JIntTextField(String s, boolean neg) {
		super();
		int value;
		try {
			value = Integer.valueOf(s).intValue();
		} catch (Exception ex) {
			s = "0";
			value = 0;
			oldText = "0";
		}

		allow_negatives = neg;
		if (!allow_negatives && value < 0) {
			value = (-1) * value;
			s = Integer.toString(value);
		}

		setText(s);
		addFocusListener(this);
	}

	/**
	 * Get the integer in the field.
	 * 
	 * @return The int held by the text field
	 */
	public int getInt() {
		return Integer.valueOf(super.getText()).intValue();
	}
	
	/**
	 * Set the int in this text field to newVal, rounding if necessary. 
	 * 
	 * @param i
	 * 				The int to display in this text field.
	 */
	public void setInt(int i) {
		Integer eye = new Integer(i);
		setText(eye.toString());
	}

	public void focusGained(FocusEvent e) {
	}

	/**
	 * When the user selects something other than this text field, 
	 * make sure the value is valid.
	 */
	public void focusLost(FocusEvent e) {
		// If the current value is not valid, replace it with the last known
		// valid input. Record the input so that we can go back to it later
		// if necessary.
		try {
			int value = Integer.valueOf(super.getText()).intValue();
			if (!allow_negatives && value < 0)
				value = (-1) * value;
			oldText = Integer.toString(value);
		} catch (NumberFormatException ex) {
			// Do nothing, old value is fine.
		}
		setText(oldText);
	}
}
