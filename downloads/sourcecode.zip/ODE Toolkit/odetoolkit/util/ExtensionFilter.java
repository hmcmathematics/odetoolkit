/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

import java.io.File;

/**
 * Filter to restrict file choices to a given suffix. Adapted from Core JFC by
 * Kim Topley
 * @author Clinic 08-09
 */
public class ExtensionFilter extends javax.swing.filechooser.FileFilter {
	/**
	 * When navigating the file system to open or save a file, this will be
	 * shown as one of the options for filtering which types of files appear.
	 */
	String info;
	/** When filtering, only show files with this extension. */
	String ext;

	/**
	 * Constructor that creates a filter when searching the file system to open
	 * or save files.
	 * 
	 * @param info
	 *            the label that will describe the type of file that the filter
	 *            is looking for
	 * @param ext
	 *            the extension the filter is looking for
	 */
	public ExtensionFilter(String info, String ext) {
		this.info = info;
		this.ext = ext;
	}

	@Override
	public boolean accept(File f) {
		if (f.isDirectory())
			return true;

		String name = f.getName();
		if (name.endsWith(ext)
				&& name.charAt(name.length() - ext.length()) == '.')
			return true;

		return false;
	}

	@Override
	public String getDescription() {
		return info;
	}
}
