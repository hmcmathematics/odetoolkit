/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

package util;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.NumberFormat;

import javax.swing.JTextField;

/**
 * The JDoubleTextField class is an extension of JTextField, designed to only
 * allow strings corresponding to valid Doubles. In the case of invalid input,
 * the display reverts to the last known valid input, or 0.0 if no such input
 * exists.
 * 
 * This is an adaptation of Jascha Swisher's JDoubleTextField with the editing
 * and caret bugs removed and with the ability to revert to the last known good
 * input in the case of a non-numeric field. The ability to create
 * JDoubleTextFields with arbitrary text in them has also been removed--now if
 * you pass an invalid String as the text argument it will be replaced with 0.0.
 * 
 * @author Aaron Becker, modified by Clinic 10-11
 */
@SuppressWarnings("serial")
public class JDoubleTextField extends JTextField implements FocusListener {

	/**
	 * if true, this will allow negative doubles in the text field; otherwise
	 * only positive values will be considered valid
	 */
	private boolean allow_negatives = true;

	/**
	 * holds any text that was in the text field previously, in case the new
	 * input is invalid
	 */
	private String oldText;

	/** 
	 * Number format cache used by _formatNum.
	 * See the comment in _formatNum for more information.
	 */
	protected transient NumberFormat numberFormat;

	/** number of digits after the decimal point to maintain. */
	protected int TRUNK = 7;

	/**
	 * The default constructor, which provides the default value
	 * <code>0.0</code>
	 */
	public JDoubleTextField() {
		this("0.0", true);
	}

	/**
	 * Constructor specifying the validity of negative numbers.
	 * 
	 * @param neg
	 *            Boolean value: true if negative numbers are valid.
	 */
	public JDoubleTextField(boolean neg) {
		this("0.0", neg);
	}

	/**
	 * Constructor allowing specification of the initial double. If the given
	 * String does not represent a valid double, 0.0 will be used.
	 * 
	 * @param s
	 *            String representing the initial double
	 */
	public JDoubleTextField(String s) {
		this(s, true);
	}

	/**
	 * Constructor allowing specification of the initial double. 
	 * 
	 * @param d
	 *            the initial double
	 */
	public JDoubleTextField(double d) {
		this(Double.toString(d), true);
	}

	/**
	 * Constructor allowing specification of both the validity of negative numbers 
	 * and the initial double.
	 * 
	 * @param d
	 *            the initial double
	 * @param neg
	 *            Boolean value: true if negative numbers are valid.
	 */
	public JDoubleTextField(double d, boolean neg) {
		this(Double.toString(d), neg);
	}

	/**
	 * Constructor allowing specification of both the validity of negative
	 * numbers and the initial value.
	 * 
	 * @param s
	 *            String representing the initial double
	 * @param neg
	 *            Boolean value: true if negative numbers are allowed
	 */
	public JDoubleTextField(String s, boolean neg) {
		super();

		// Cache the number format so that we don't have to get
		// info about local language etc. from the OS each time.
		numberFormat = NumberFormat.getInstance();
		numberFormat.setMinimumFractionDigits(TRUNK);
		numberFormat.setMaximumFractionDigits(TRUNK);

		double value;
		try {
			value = Double.parseDouble(s);
		} catch (Exception ex) {
			s = "0.0";
			value = 0.0;
			oldText = "0.0";
		}

		allow_negatives = neg;
		if (!allow_negatives && value < 0.0) {
			value = (-1) * value;
			s = Double.toString(value);
		}

		if (s.length() > TRUNK) {
			setText(round(value));
		} else
			setText(s);
		setScrollOffset(0);
		addFocusListener(this);
	}

	/**
	 * Get the double held by the text field.
	 * 
	 * @return The double in this field.
	 */
	public double getDouble() {
		// return Double.valueOf(super.getText()).doubleValue();
		try {
			return numberFormat.parse(super.getText()).doubleValue();
		} catch (Exception e) {
			// do something...
			return 0.0;
		}
	}

	/**
	 * Set the double in this text field to newVal, rounding if necessary. 
	 * 
	 * @param newVal
	 * 				The double to display in this text field.
	 */
	public void setDouble(double newVal) {
		String text = Double.toString(newVal);
		if (text.length() > TRUNK) {
			setText(round(newVal));
		} else
			setText(text);
	}

	/**
	 * Selects this text field.
	 */
	public void focusGained(FocusEvent e) {
		this.selectAll();
	}

	/**
	 * When the user selects something other than this text field, make sure the value
	 * is valid and at the right precision.
	 */
	public void focusLost(FocusEvent e) {
		// If the current value is invalid, revert to the last known good
		// value. If not, record it so we can come back to it if necessary.
		try {
			double value = Double.valueOf(super.getText()).doubleValue();
			if (!allow_negatives && value < 0.0)
				value = (-1) * value;

			oldText = Double.toString(value);
			if (oldText.length() > TRUNK)
				oldText = round(value);

		} catch (NumberFormatException ex) {
			// Do nothing, old value is fine.
		}
		setText(oldText);
		setScrollOffset(20);
	}

	/**
	 * Rounds the given double to a default precision.
	 * 
	 * @param num
	 * 			the double to be rounded
	 * 
	 * @return a String with the formatted double to display in this text field
	 */
	protected String round(double num) {
		return numberFormat.format(num);

	} // round()

	/**
	 * Sets the precision of the number stored in the text field. The integer
	 * must be non-negative.
	 * 
	 * @param numDigits
	 *            The number of digits after the decimal point to display
	 */
	public void setPrecision(int numDigits) {

		// Can't display less than 0 digits after the decimal point.
		if (numDigits < 0)
			return;

		TRUNK = numDigits;

		// update the panel
		try {
			double value = Double.valueOf(super.getText()).doubleValue();

			oldText = round(value);

			setText(oldText);

			setScrollOffset(20);

		} catch (NumberFormatException ex) {
			// Some sort of error...

		}

	}

	/**
	 * Returns the precision of the number stored in the text field.
	 * 
	 * @return The number held by the text field
	 */
	public int getPrecision() {
		return TRUNK;
	}

}
