/*******************************************************************************
 * This file is part of ODE Toolkit: a free application for solving systems of
 * ordinary differential equations.
 *  
 * Copyright (C) 2002-2011 Max Comstock, Beky Kotcon, Samantha Mesuro, Daniel Rozenfeld,
 * Anak Yodpinyanee, Andres Perez, Eric Doi, Richard Mehlinger, Steven Ehrlich,
 * Martin Hunt, George Tucker, Peter Scherpelz, Aaron Becker, Eric Harley,
 * Chris Moore
 * 
 * ODE Toolkit is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option) any
 * later version.
 * 
 * ODE Toolkit is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * ODE Toolkit.  If not, see <http://www.gnu.org/licenses/>.
 ******************************************************************************/

/*
 * author: Ken Dye - kdye@hmc.edu
 * summer 2002
 *
 */

package util;

/**
 * SolutionReadyListener is the interface to implement if you want your class to
 * be notified by a Solver when the entire solution is ready, that is, it has
 * solved for as many points as it is going to solve for. To use it, just have
 * your class implement it and then add your class to a Solver using
 * Solver.addSolutionReadyListener(). When the solution is ready,
 * solutionReady() will be called.
 * 
 * Implementing classes: Curve, ODE
 * @author Clinic 10-11, modified from 08-09
 */
public interface SolutionReadyListener {
	/**
	 * solutionReady() gets called when the Solver has completed its solution.
	 * the double[][] contains all the points in the solution.'
	 */
	public void solutionReady(double[][] solution);

	/**
	 * Handle the error condition
	 * 
	 * @param ex
	 *            the exception to be handled
	 */
	public void errorCondition(Exception ex);

	/**
	 * Handle the error condition
	 * 
	 * @param error
	 *            string describing error condition
	 */
	public void errorCondition(String error);
}
